﻿# 真劍鬧鐘：不碰 Windows Forms 的純邏輯函式
# 設定視窗(Alarm_Manager_GUI.ps1)、背景提醒(Alarm_Tray.ps1)、tests.ps1 都用 . 載入這支。
# 注意：只能用 Windows PowerShell 5.1 有的語法（不要 ??、?.、三元運算子）。

$script:AppName = "真劍鬧鐘"
$script:AppVersion = "1.8.6"
$script:SalonUrl = "https://vocus.cc/salon/ai-new-kneel"
$script:PrivacyUrl = "https://lovanddes.github.io/shinken-alarm/privacy.html"   # 隱私權政策（網頁）
$script:SiteUrl = "https://lovanddes.github.io/shinken-alarm/"                    # App 下載頁（分享給朋友用）
$script:DefaultCategory = "未分類"

# ---------- 日期小工具 ----------

# 把 json 讀出來的日期（通常是 "yyyy-MM-dd" 字串）轉成 DateTime；轉不了就回傳 $null
function ConvertTo-DateOnly($value) {
    if ($null -eq $value) { return $null }
    if ($value -is [DateTime]) { return $value.Date }
    $s = "$value".Trim()
    if ($s -eq "") { return $null }
    try { return [DateTime]::ParseExact($s, "yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture) } catch { return $null }
}

# 把 "HH:mm" 拆成 @(時, 分)
function Get-AlarmTimeParts($a) {
    $parts = "$($a.time)" -split ":"
    return @([int]$parts[0], [int]$parts[1])
}

# 某年某月的第 day 號；這個月沒有那一天（2/29 平年、4/31、2/30…）就改成那個月的最後一天
function Resolve-MonthDay([int]$year, [int]$month, [int]$day) {
    $last = [DateTime]::DaysInMonth($year, $month)
    if ($day -gt $last) { $day = $last }
    if ($day -lt 1) { $day = 1 }
    return New-Object DateTime($year, $month, $day)
}

# ---------- 每年固定日期（單一日期舊格式 + 多月多日新格式） ----------

# 回傳 @{ Months = @(..); Days = @(..) }；資料壞掉就回傳 $null
#   新格式：months = [3, 9], days = [1, 15]
#   舊格式：date = "2025-03-15"（年份不管，只看月/日）
function Get-YearlyRule($a) {
    $months = @()
    $days = @()
    if ($null -ne $a.months) { $months = @($a.months | Where-Object { $null -ne $_ -and "$_" -ne "" } | ForEach-Object { [int]$_ }) }
    if ($null -ne $a.days) { $days = @($a.days | Where-Object { $null -ne $_ -and "$_" -ne "" } | ForEach-Object { [int]$_ }) }
    if ($months.Count -gt 0 -and $days.Count -gt 0) {
        return @{ Months = @($months | Sort-Object -Unique); Days = @($days | Sort-Object -Unique) }
    }
    $src = ConvertTo-DateOnly $a.date
    if ($null -eq $src) { return $null }
    return @{ Months = @($src.Month); Days = @($src.Day) }
}

# 這一天是不是「每年固定日期」規則要響的日子（含：日期不存在 → 那個月最後一天響）
function Test-YearlyRuleMatch($rule, [DateTime]$d) {
    if ($null -eq $rule) { return $false }
    if ($rule.Months -notcontains $d.Month) { return $false }
    foreach ($day in $rule.Days) {
        $resolved = Resolve-MonthDay $d.Year $d.Month $day
        if ($resolved.Day -eq $d.Day) { return $true }
    }
    return $false
}

# ---------- 分類 ----------

function Get-AlarmCategory($a) {
    if ($null -eq $a.category) { return $script:DefaultCategory }
    $c = "$($a.category)".Trim()
    if ($c -eq "") { return $script:DefaultCategory }
    return $c
}

# ---------- 顯示文字 ----------

function Get-YearlyText($a) {
    $rule = Get-YearlyRule $a
    if ($null -eq $rule) { return "每年 $($a.date)" }
    $hasNew = ($null -ne $a.months -and @($a.months).Count -gt 0)
    if (-not $hasNew) { return "每年 $($rule.Months[0]) 月 $($rule.Days[0]) 日" }
    return "每年 $($rule.Months -join '、') 月的 $($rule.Days -join '、') 號"
}

function Get-AlarmBaseType($a) {
    if ($a.type -eq "yearly") { return (Get-YearlyText $a) }
    if ($a.type -eq "monthly") { return "每月 $($a.days -join ',') 號" }
    elseif ($a.type -eq "daily") { return "每天" }
    elseif ($a.type -eq "weekly") {
        $names = @("一","二","三","四","五","六","日")
        $list = @()
        foreach ($d in $a.days) { $list += $names[$d - 1] }
        return "每週 星期" + ($list -join "、")
    }
    elseif ($a.type -eq "once") { return "單次 $($a.date)" }
    elseif ($a.type -eq "interval") { return "每$($a.intervalDays)天（下次:$($a.nextDueDate)）" }
    return ""
}

# ---------- 重要程度（工單 8.11 B） ----------
# 欄位 importance：normal（普通，預設）／quiz（要答題才能延後）／must（絕對不能延後）。沒有欄位、看不懂的值 = normal。
# quiz／must 一律走認真型流程（完成要答題）。跟手機版同一套規則。
$script:ImportanceKeys = @("normal", "quiz", "must")
$script:ImportanceLabels = @{ normal = "普通"; quiz = "要答題才能延後"; must = "絕對不能延後" }
function Get-AlarmImportance($a) {
    $v = ""
    try { $v = "$($a.importance)" } catch {}
    if ($script:ImportanceKeys -contains $v) { return $v }
    return "normal"
}
function Test-AlarmStrict($a) {
    if ((Get-AlarmImportance $a) -ne "normal") { return $true }
    if ($null -ne $a.strict) { return [bool]$a.strict }
    return (-not [bool]$a.timeLimited)
}

# 現在開著的提醒視窗裡，「重要鬧鐘」（要答題才能延後／絕對不能延後）的有哪些（系統匣的緊急停止用）
function Get-ImportantOpenForms($openForms) {
    $out = @()
    if ($null -eq $openForms) { return $out }
    foreach ($k in @($openForms.Keys)) {
        $f = $openForms[$k]
        if ($null -eq $f -or $f.IsDisposed) { continue }
        $imp = ""
        try { $imp = "$($f.Tag.Importance)" } catch {}
        if ($imp -eq "quiz" -or $imp -eq "must") { $out += , $f }
    }
    return $out
}

function Get-AlarmDescription($a) {
    $base = Get-AlarmBaseType $a
    $tags = @()
    if ($a.timeLimited) { $tags += "限時15分內" }
    if ($a.playSound -eq $false) { $tags += "靜音" }
    $isStrict = Test-AlarmStrict $a
    if (-not $isStrict) { $tags += "隨意型" }
    $imp = Get-AlarmImportance $a
    if ($imp -ne "normal") { $tags += $script:ImportanceLabels[$imp] }
    if ($tags.Count -gt 0) { $base = "$base（$($tags -join '、')）" }
    return $base
}

# ---------- 該不該響：候選日期（漏響補提醒的規則都在這） ----------

function Get-CandidateDates($a, $now) {
    $candidates = @()
    if ($a.type -eq "daily") {
        $candidates += $now.Date
    }
    elseif ($a.type -eq "monthly") {
        for ($i = 0; $i -le 35; $i++) {
            $d = $now.Date.AddDays(-$i)
            if ($a.days -contains $d.Day) { $candidates += $d }
        }
    }
    elseif ($a.type -eq "weekly") {
        for ($i = 0; $i -le 21; $i++) {
            $d = $now.Date.AddDays(-$i)
            $wd = [int]$d.DayOfWeek
            $iso = $wd
            if ($wd -eq 0) { $iso = 7 }
            if ($a.days -contains $iso) { $candidates += $d }
        }
    }
    elseif ($a.type -eq "once") {
        $d = ConvertTo-DateOnly $a.date
        if ($null -ne $d -and $d.Date -le $now.Date) { $candidates += $d.Date }
    }
    elseif ($a.type -eq "yearly") {
        # 每年固定日期（單一日期或多月多日）。**只往回看 7 天,而且找到最近一次就停**。
        # 不補幾個月前漏掉的 —— 認真型鬧鐘要答題,補一整年份會一次要你補答一堆題。
        # 日期不存在（2/29 平年、4/31…）→ 改在那個月最後一天響。
        $rule = Get-YearlyRule $a
        if ($null -ne $rule) {
            for ($i = 0; $i -le 7; $i++) {
                $d = $now.Date.AddDays(-$i)
                if (Test-YearlyRuleMatch $rule $d) {
                    $candidates += $d
                    break
                }
            }
        }
    }
    elseif ($a.type -eq "interval") {
        $d = ConvertTo-DateOnly $a.nextDueDate
        if ($null -ne $d -and $d.Date -le $now.Date) { $candidates += $d.Date }
    }

    $created = ConvertTo-DateOnly $a.createdDate
    if ($null -ne $created) {
        $candidates = @($candidates | Where-Object { $_.Date -ge $created.Date })
    }

    return ($candidates | Sort-Object)
}

# ---------- 同一個鬧鐘只留一筆待響（工單 8.8） ----------
# keepKey：留下來的那個日子（正要跳出來／正被延後的）；keepPending=$false（答對收掉）時連它也不留。
# 這個鬧鐘別的日子的「真的沒空」紀錄、狀態一律清掉；還欠著的其他應響日子（過了時間、沒完成）併進這一次、記成已完成，
# 不會之後一個一個再跳、一個一個再要答題。定期倒數只有一個到期日，不用併。
# $snoozeTable／$stateTable 是 hashtable（key 是「鬧鐘編號|日期」），直接改；回傳 @{ AlarmChanged; SnoozeChanged }
function Merge-AlarmPending($a, $snoozeTable, $stateTable, [string]$keepKey, [DateTime]$now, [bool]$keepPending = $true) {
    $res = @{ AlarmChanged = $false; SnoozeChanged = $false }
    $id = "$($a.id)"
    $keep = "$id|$keepKey"
    foreach ($k in @($snoozeTable.Keys)) {
        if ("$k".StartsWith("$id|") -and "$k" -ne $keep) { $snoozeTable.Remove($k); $res.SnoozeChanged = $true }
    }
    foreach ($k in @($stateTable.Keys)) {
        if ("$k".StartsWith("$id|") -and "$k" -ne $keep) { $stateTable.Remove($k) }
    }
    if ($a.type -ne "interval") {
        $tp = $null
        try { $tp = Get-AlarmTimeParts $a } catch {}
        if ($null -ne $tp) {
            if ($null -eq $a.triggeredDates) { $a | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @() -Force }
            foreach ($cd in @(Get-CandidateDates $a $now)) {
                if ($null -eq $cd) { continue }
                $key = $cd.ToString("yyyy-MM-dd")
                if ($key -eq $keepKey -or $a.triggeredDates -contains $key) { continue }
                if ($cd.Date.AddHours($tp[0]).AddMinutes($tp[1]) -gt $now) { continue }
                $a.triggeredDates = @($a.triggeredDates) + $key
                $res.AlarmChanged = $true
            }
        }
    }
    if (-not $keepPending) {
        if ($snoozeTable.ContainsKey($keep)) { $snoozeTable.Remove($keep); $res.SnoozeChanged = $true }
        if ($stateTable.ContainsKey($keep)) { $stateTable.Remove($keep) }
    }
    return $res
}

# 啟動時掃一次（升級後第一次開、開機後）：已經累積的重複「真的沒空」清掉，每個鬧鐘只留 until 最晚的那一筆
function Clear-DuplicateSnoozes($alarms, $snoozeTable, $stateTable, [DateTime]$now) {
    $res = @{ AlarmChanged = $false; SnoozeChanged = $false }
    foreach ($a in @($alarms)) {
        $id = "$($a.id)"
        $mine = @($snoozeTable.Keys | Where-Object { "$_".StartsWith("$id|") })
        if ($mine.Count -le 1) { continue }
        $best = @($mine | Sort-Object -Property @{ Expression = { $snoozeTable[$_].Until } }, @{ Expression = { "$_" } })[-1]
        $m = Merge-AlarmPending $a $snoozeTable $stateTable ($best.Substring($id.Length + 1)) $now $true
        if ($m.AlarmChanged) { $res.AlarmChanged = $true }
        if ($m.SnoozeChanged) { $res.SnoozeChanged = $true }
    }
    return $res
}

# ---------- 下次響的時間（列表排序、顯示用） ----------

# 回傳「現在之後」下一次要響的時間；單次鬧鐘已經過了就回傳 $null。
# 定期倒數(interval) 直接用 nextDueDate（過期未完成也照樣回傳，代表還欠著）。
function Get-NextOccurrence($a, $now) {
    try {
        $tp = Get-AlarmTimeParts $a
        $h = $tp[0]; $m = $tp[1]
    } catch { return $null }

    if ($a.type -eq "once") {
        $d = ConvertTo-DateOnly $a.date
        if ($null -eq $d) { return $null }
        $t = $d.AddHours($h).AddMinutes($m)
        if ($t -gt $now) { return $t }
        return $null
    }
    if ($a.type -eq "interval") {
        $d = ConvertTo-DateOnly $a.nextDueDate
        if ($null -eq $d) { return $null }
        return $d.AddHours($h).AddMinutes($m)
    }

    $rule = $null
    $maxDays = 0
    if ($a.type -eq "daily") { $maxDays = 1 }
    elseif ($a.type -eq "weekly") { $maxDays = 7 }
    elseif ($a.type -eq "monthly") { $maxDays = 400 }
    elseif ($a.type -eq "yearly") {
        $rule = Get-YearlyRule $a
        if ($null -eq $rule) { return $null }
        $maxDays = 370
    }
    else { return $null }

    for ($i = 0; $i -le $maxDays; $i++) {
        $d = $now.Date.AddDays($i)
        $ok = $false
        if ($a.type -eq "daily") { $ok = $true }
        elseif ($a.type -eq "weekly") {
            $iso = [int]$d.DayOfWeek
            if ($iso -eq 0) { $iso = 7 }
            $ok = ($a.days -contains $iso)
        }
        elseif ($a.type -eq "monthly") { $ok = ($a.days -contains $d.Day) }
        elseif ($a.type -eq "yearly") { $ok = (Test-YearlyRuleMatch $rule $d) }
        if ($ok) {
            $t = $d.AddHours($h).AddMinutes($m)
            if ($t -gt $now) { return $t }
        }
    }
    return $null
}

# 列表排序：SortBy = "category"（分類，同分類再依下次時間）/ "next"（下次響的時間）/ "name"（名稱）
function Get-SortedAlarms($alarms, [string]$sortBy, $now) {
    $list = @($alarms | Where-Object { $null -ne $_ })
    $far = [DateTime]::MaxValue
    $nextKey = { $n = Get-NextOccurrence $_ $now; if ($null -eq $n) { $far } else { $n } }
    $nameKey = { "$($_.label)" }
    if ($sortBy -eq "name") {
        return @($list | Sort-Object -Property @{ Expression = $nameKey }, @{ Expression = $nextKey })
    }
    if ($sortBy -eq "next") {
        return @($list | Sort-Object -Property @{ Expression = $nextKey }, @{ Expression = $nameKey })
    }
    # 分類：「未分類」排最後
    $isDefaultKey = { if ((Get-AlarmCategory $_) -eq $script:DefaultCategory) { 1 } else { 0 } }
    $catKey = { Get-AlarmCategory $_ }
    return @($list | Sort-Object -Property @{ Expression = $isDefaultKey }, @{ Expression = $catKey }, @{ Expression = $nextKey }, @{ Expression = $nameKey })
}

# 所有出現過的分類名稱（加上使用者自己新增、目前還沒有鬧鐘的分類）
function Get-AllCategories($alarms, $extra) {
    $set = @()
    foreach ($c in @($extra)) { if ($null -ne $c -and "$c".Trim() -ne "" -and $set -notcontains "$c".Trim()) { $set += "$c".Trim() } }
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        $c = Get-AlarmCategory $a
        if ($c -ne $script:DefaultCategory -and $set -notcontains $c) { $set += $c }
    }
    return @($set | Sort-Object) + @($script:DefaultCategory)
}

# ---------- 「真的沒空」：延到幾點 ----------

# Choice: "30m" / "2h" / "tonight"（今晚 20:00，已過 20:00 → 明晚 20:00）/ "tomorrow"（明天早上 09:00）/ "custom"
# custom 的時間必須在「現在」之後，不然回傳 $null
function Get-NoTimeUntil([string]$choice, [DateTime]$now, $custom) {
    if ($choice -eq "30m") { return $now.AddMinutes(30) }
    if ($choice -eq "2h") { return $now.AddHours(2) }
    if ($choice -eq "tonight") {
        $t = $now.Date.AddHours(20)
        if ($t -le $now) { $t = $t.AddDays(1) }
        return $t
    }
    if ($choice -eq "tomorrow") { return $now.Date.AddDays(1).AddHours(9) }
    if ($choice -eq "custom") {
        if ($null -eq $custom) { return $null }
        $c = [DateTime]$custom
        $c = New-Object DateTime($c.Year, $c.Month, $c.Day, $c.Hour, $c.Minute, 0)
        if ($c -le $now) { return $null }
        return $c
    }
    return $null
}

# ---------- 「真的沒空」：存檔（重開機、重開程式也不會忘） ----------
# snoozes.json 只由背景提醒程式寫。格式：
#   [ { "alarmId": 3, "dateKey": "2026-09-30", "until": "2026-09-30 20:00:00" } ]

$script:SnoozeTimeFormat = "yyyy-MM-dd HH:mm:ss"

function Read-SnoozeFile([string]$path) {
    $table = @{}
    if (-not (Test-Path -LiteralPath $path)) { return $table }
    try {
        $content = Get-Content -LiteralPath $path -Raw -Encoding UTF8
        if ($null -eq $content -or $content.Trim() -eq "") { return $table }
        $data = $content | ConvertFrom-Json
        foreach ($s in @($data)) {
            if ($null -eq $s) { continue }
            $until = $null
            try { $until = [DateTime]::ParseExact("$($s.until)", $script:SnoozeTimeFormat, [System.Globalization.CultureInfo]::InvariantCulture) } catch { continue }
            $key = "$($s.alarmId)|$($s.dateKey)"
            $table[$key] = @{ AlarmId = $s.alarmId; DateKey = "$($s.dateKey)"; Until = $until }
        }
    } catch {}
    return $table
}

function Write-SnoozeFile([string]$path, $table) {
    $list = @()
    foreach ($k in @($table.Keys | Sort-Object)) {
        $s = $table[$k]
        $list += [PSCustomObject]@{ alarmId = $s.AlarmId; dateKey = $s.DateKey; until = $s.Until.ToString($script:SnoozeTimeFormat, [System.Globalization.CultureInfo]::InvariantCulture) }
    }
    ConvertTo-Json -InputObject @($list) -Depth 3 | Out-File -FilePath $path -Encoding UTF8
}

function Set-NoTimeSnooze([string]$path, $alarmId, [string]$dateKey, [DateTime]$until) {
    $table = Read-SnoozeFile $path
    $table["$alarmId|$dateKey"] = @{ AlarmId = $alarmId; DateKey = $dateKey; Until = $until }
    Write-SnoozeFile $path $table
}

function Remove-NoTimeSnooze([string]$path, $alarmId, [string]$dateKey) {
    $table = Read-SnoozeFile $path
    $key = "$alarmId|$dateKey"
    if ($table.ContainsKey($key)) {
        $table.Remove($key)
        Write-SnoozeFile $path $table
    }
}

# 這個鬧鐘有哪些「真的沒空」已經到時間、該再跳出來的（最早的排前面）
function Get-DueNoTimeSnoozes($table, $alarmId, [DateTime]$now) {
    $due = @()
    foreach ($k in @($table.Keys)) {
        $s = $table[$k]
        if ("$($s.AlarmId)" -eq "$alarmId" -and $now -ge $s.Until) { $due += $s }
    }
    return @($due | Sort-Object -Property @{ Expression = { $_.Until } })
}

# ---------- alarms.json 讀寫 ----------

function Read-AlarmFile([string]$path) {
    if (Test-Path -LiteralPath $path) {
        $content = Get-Content -LiteralPath $path -Raw -Encoding UTF8
        if ($null -eq $content -or $content.Trim() -eq "") { return @() }
        $data = $content | ConvertFrom-Json
        if ($data -isnot [System.Array]) { $data = @($data) }
        return $data
    } else { return @() }
}

function Write-AlarmFile([string]$path, $alarms) {
    $alarms | ConvertTo-Json -Depth 5 | Out-File -FilePath $path -Encoding UTF8
}

# 第一次使用（沒有 alarms.json）時建一個範例鬧鐘；有建就回傳 $true
function Initialize-AlarmFile([string]$path, $now) {
    if (Test-Path -LiteralPath $path) { return $false }
    if ($null -eq $now) { $now = Get-Date }
    # 第一次打開已經過了 21:00 → 從明天才開始算，免得一打開就跳出來嚇人
    $start = $now.Date
    if ($now -ge $now.Date.AddHours(21)) { $start = $start.AddDays(1) }
    $sample = [PSCustomObject]@{
        type = "daily"; label = "喝水！（這是範例鬧鐘，可以改掉或刪掉）"; time = "21:00"; days = @(); date = ""
        timeLimited = $false; playSound = $true; strict = $true
        notes = "起來倒杯水。`r`n答對算術題才能關掉，這就是「真劍」。"
        category = "範例"
        id = 1; triggeredDates = @(); createdDate = $start.ToString("yyyy-MM-dd")
    }
    Write-AlarmFile $path @($sample)
    return $true
}

# ---------- 「開始生效」時間 armedAt（工單 8.2；Android 的 AlarmCore.kt 是同一套規則） ----------
# 漏響補提醒只補「開始生效之後」的應響時刻；建立、改時間／類型的那一刻之前的，一律不算漏響。
#   armedAt   ：建立、修改（時間／類型／日期…）時記下的 UTC 時間，跟著同步
#   armedLocal：這台裝置自己記的（舊資料第一次載入、同步／匯入進來的那一刻），不同步
# 兩個取較晚的。都沒有（舊資料還沒蓋章）→ 不限制。
$script:ScheduleFields = @("type", "time", "days", "months", "date", "intervalDays")

function ConvertTo-ArmedText([DateTime]$t) {
    return $t.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ", [System.Globalization.CultureInfo]::InvariantCulture)
}

function ConvertFrom-ArmedText($text) {
    if ($null -eq $text -or "$text" -eq "") { return $null }
    try { return [DateTime]::Parse("$text", [System.Globalization.CultureInfo]::InvariantCulture, ([System.Globalization.DateTimeStyles]::AdjustToUniversal -bor [System.Globalization.DateTimeStyles]::AssumeUniversal)) } catch { return $null }
}

# 回傳本地時間的 DateTime；沒有任何生效時間 → $null
function Get-AlarmArmedTime($a) {
    $best = $null
    foreach ($f in @("armedAt", "armedLocal")) {
        $p = $a.PSObject.Properties[$f]
        if ($null -eq $p) { continue }
        $t = ConvertFrom-ArmedText $p.Value
        if ($null -eq $t) { continue }
        if ($null -eq $best -or $t -gt $best) { $best = $t }
    }
    if ($null -eq $best) { return $null }
    return $best.ToLocalTime()
}

function Set-AlarmArmed($a, [DateTime]$now) { $a | Add-Member -NotePropertyName armedAt -NotePropertyValue (ConvertTo-ArmedText $now) -Force }
function Set-AlarmArmedLocal($a, [DateTime]$now) { $a | Add-Member -NotePropertyName armedLocal -NotePropertyValue (ConvertTo-ArmedText $now) -Force }

# 兩份鬧鐘資料的「排程相關欄位」一樣嗎（改了時間、類型、日期這類才需要重新生效）
# 編輯存檔時要留下的 triggeredDates（工單 8.16）：排程有改才拿掉今天；沒改就全部保留
function Get-PreservedTriggeredDates($existing, $edited, [string]$todayKey) {
    $all = @($existing.triggeredDates | Where-Object { $null -ne $_ -and "$_" -ne "" })
    if (Test-SameSchedule $existing $edited) { return $all }
    return @($all | Where-Object { $_ -ne $todayKey })
}

function Test-SameSchedule($x, $y) {
    foreach ($f in $script:ScheduleFields) {
        $px = $x.PSObject.Properties[$f]; $py = $y.PSObject.Properties[$f]
        $vx = if ($null -eq $px -or $null -eq $px.Value) { "" } else { (@($px.Value) | ForEach-Object { "$_" }) -join "," }
        $vy = if ($null -eq $py -or $null -eq $py.Value) { "" } else { (@($py.Value) | ForEach-Object { "$_" }) -join "," }
        if ($vx -ne $vy) { return $false }
    }
    return $true
}

# 這個應響時刻在「開始生效」之前嗎（是 → 不算漏響，不補響）；沒有生效時間 → 否
function Test-OccurrenceBeforeArmed($a, [DateTime]$occ) {
    $armed = Get-AlarmArmedTime $a
    if ($null -eq $armed) { return $false }
    return ($occ -le $armed)
}

# 舊資料沒有任何生效時間：蓋成現在（寧可少補一次，也不要亂響）；有蓋到回傳 $true
function Set-MissingArmed($alarms, [DateTime]$now) {
    $changed = $false
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        if ($null -eq $a.PSObject.Properties["armedAt"] -and $null -eq $a.PSObject.Properties["armedLocal"]) { Set-AlarmArmedLocal $a $now; $changed = $true }
    }
    return $changed
}

# 編輯鬧鐘時：把舊鬧鐘有、新結果沒有的欄位照抄過去（未來新欄位、別的版本的欄位都不會掉）
function Copy-MissingAlarmFields($from, $to) {
    foreach ($p in $from.PSObject.Properties) {
        if ($null -eq $to.PSObject.Properties[$p.Name]) {
            $to | Add-Member -NotePropertyName $p.Name -NotePropertyValue $p.Value -Force
        }
    }
    return $to
}

# ---------- 設定視窗的小設定（排序方式、自己新增的分類、字體大小、粗體、外觀） ----------
# settings.json 舊版只有 sortBy / categories；新欄位讀不到就用預設值（標準字、淺色）

$script:FontSizeChoices = @("normal", "large", "xlarge")
$script:ThemeChoices = @("light", "dark")

function Read-AppSettings([string]$path) {
    $s = @{ sortBy = "category"; categories = @(); fontSize = "normal"; bold = $false; theme = "light"; categoryColors = @{}; privateCategories = @() }
    if (-not (Test-Path -LiteralPath $path)) { return $s }
    try {
        $data = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($null -ne $data.sortBy -and @("category", "next", "name") -contains "$($data.sortBy)") { $s.sortBy = "$($data.sortBy)" }
        if ($null -ne $data.categories) { $s.categories = @($data.categories | ForEach-Object { "$_" }) }
        if ($null -ne $data.fontSize -and $script:FontSizeChoices -contains "$($data.fontSize)") { $s.fontSize = "$($data.fontSize)" }
        if ($null -ne $data.bold) { $s.bold = ("$($data.bold)" -eq "True") }
        if ($null -ne $data.theme -and $script:ThemeChoices -contains "$($data.theme)") { $s.theme = "$($data.theme)" }
        $s.categoryColors = ConvertFrom-CategoryColorObject $data.categoryColors
        $s.privateCategories = @(Get-CleanPrivateCategories $data.privateCategories)
    } catch {}
    return $s
}

function Write-AppSettings([string]$path, $settings) {
    $fontSize = "normal"
    if ($script:FontSizeChoices -contains "$($settings.fontSize)") { $fontSize = "$($settings.fontSize)" }
    $bold = $false
    if ($settings.bold -eq $true) { $bold = $true }
    $theme = "light"
    if ($script:ThemeChoices -contains "$($settings.theme)") { $theme = "$($settings.theme)" }
    [PSCustomObject]@{ sortBy = $settings.sortBy; categories = @($settings.categories); fontSize = $fontSize; bold = $bold; theme = $theme; categoryColors = (ConvertTo-CategoryColorObject $settings.categoryColors); privateCategories = @(Get-CleanPrivateCategories $settings.privateCategories) } | ConvertTo-Json -Depth 4 | Out-File -FilePath $path -Encoding UTF8
}

# 字體大小 → 放大倍率（標準 1.0 / 大 1.3 / 特大 1.6）
function Get-FontScaleFactor([string]$fontSize) {
    if ($fontSize -eq "large") { return 1.3 }
    if ($fontSize -eq "xlarge") { return 1.6 }
    return 1.0
}

# ---------- 分類管理：改名、刪除（只改記憶體裡的清單，存檔交給呼叫的人） ----------

# 每個分類底下有幾個鬧鐘：回傳 @( @{ Name = "工作"; Count = 3 }, ... )，「未分類」永遠在最後
function Get-CategoryCounts($alarms, $extra) {
    $result = @()
    foreach ($c in (Get-AllCategories $alarms $extra)) {
        $n = @(@($alarms) | Where-Object { $null -ne $_ -and (Get-AlarmCategory $_) -eq $c }).Count
        $result += @{ Name = $c; Count = $n }
    }
    return $result
}

# 改名：用到舊名稱的鬧鐘全部改成新名稱；自己新增的分類清單也一起改。新名稱已經存在 → 兩個分類合併。
# 回傳 @{ Ok; Error; Changed(改到幾個鬧鐘); Categories(新的分類清單) }
function Rename-AlarmCategory($alarms, $categories, [string]$oldName, [string]$newName) {
    $old = "$oldName".Trim()
    $new = "$newName".Trim()
    $cats = @(@($categories) | Where-Object { $null -ne $_ -and "$_".Trim() -ne "" } | ForEach-Object { "$_".Trim() })
    if ($old -eq $script:DefaultCategory) { return @{ Ok = $false; Error = "「$($script:DefaultCategory)」不能改名。"; Changed = 0; Categories = $cats } }
    if ($new -eq "") { return @{ Ok = $false; Error = "新名稱不能是空的。"; Changed = 0; Categories = $cats } }
    if ($new -eq $script:DefaultCategory) { return @{ Ok = $false; Error = "不能改成「$($script:DefaultCategory)」。想把鬧鐘變回未分類，請用「刪除」。"; Changed = 0; Categories = $cats } }
    if ($new -eq $old) { return @{ Ok = $true; Error = ""; Changed = 0; Categories = $cats } }

    $changed = 0
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        if ((Get-AlarmCategory $a) -eq $old) {
            $a | Add-Member -NotePropertyName category -NotePropertyValue $new -Force
            $changed++
        }
    }
    $newCats = @()
    foreach ($c in $cats) {
        $n = $c
        if ($c -eq $old) { $n = $new }
        if ($newCats -notcontains $n) { $newCats += $n }
    }
    return @{ Ok = $true; Error = ""; Changed = $changed; Categories = $newCats }
}

# 刪除：底下的鬧鐘不刪，改成「未分類」；分類清單拿掉這個名字。
# 回傳 @{ Ok; Error; Changed(變成未分類的鬧鐘數); Categories }
function Remove-AlarmCategory($alarms, $categories, [string]$name) {
    $target = "$name".Trim()
    $cats = @(@($categories) | Where-Object { $null -ne $_ -and "$_".Trim() -ne "" } | ForEach-Object { "$_".Trim() })
    if ($target -eq $script:DefaultCategory -or $target -eq "") { return @{ Ok = $false; Error = "「$($script:DefaultCategory)」不能刪除。"; Changed = 0; Categories = $cats } }
    $changed = 0
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        if ((Get-AlarmCategory $a) -eq $target) {
            $a | Add-Member -NotePropertyName category -NotePropertyValue $script:DefaultCategory -Force
            $changed++
        }
    }
    return @{ Ok = $true; Error = ""; Changed = $changed; Categories = @($cats | Where-Object { $_ -ne $target }) }
}

# ---------- 列表欄寬：視窗放大時，多出來的寬度依各欄原本寬度的比例分配 ----------
# $firstWeight：第一欄（內容）多拿一點的倍數，例如 2 = 以兩倍的權重分；可用寬度沒比原本大就回到原寬度
function Get-DistributedColumnWidths($baseWidths, [int]$available, [double]$firstWeight) {
    $base = @($baseWidths | ForEach-Object { [int]$_ })
    $total = 0
    foreach ($w in $base) { $total += $w }
    $extra = $available - $total
    if ($base.Count -eq 0 -or $extra -le 0) { return $base }
    $weights = @()
    for ($i = 0; $i -lt $base.Count; $i++) {
        $wt = [double]$base[$i]
        if ($i -eq 0) { $wt = $wt * $firstWeight }
        $weights += $wt
    }
    $sumW = 0.0
    foreach ($wt in $weights) { $sumW += $wt }
    $result = @()
    $given = 0
    for ($i = 0; $i -lt $base.Count; $i++) {
        $add = [int][Math]::Floor($extra * $weights[$i] / $sumW)
        $result += ($base[$i] + $add)
        $given += $add
    }
    $result[0] = $result[0] + ($extra - $given)
    return $result
}

# ---------- 匯出／匯入（v1.3；跟 Android 版共用同一個格式） ----------
# 匯出檔：{"format": "shinken-alarm", "version": 1, "exportedAt": "...", "alarms": [...], "categories": [...]}
#   alarms 用 alarms.json 原本的鬧鐘欄位；**不匯出**這台裝置自己的狀態（已完成紀錄 triggeredDates 等），
#   「真的沒空」的延後本來就在另一個檔（snoozes.json），也不會帶過去。
#   讀不懂的欄位照留（之後版本加欄位才不會互相洗掉）。

$script:ExportFormat = "shinken-alarm"
$script:ExportVersion = 1
# 屬於「這台裝置自己的狀態」、不跟著匯出的欄位
$script:ExportStateFields = @("triggeredDates", "snoozes", "lastTriggered", "lastTriggeredAt", "lastRang", "lastRangAt", "armedLocal")
# 判斷「是不是同一個鬧鐘的內容」時不看的欄位（編號、狀態、建立日、定期倒數的進度）
$script:ContentIgnoreFields = @("id", "createdDate", "nextDueDate", "armedAt") + $script:ExportStateFields

# 預設檔名：真劍鬧鐘_我的鬧鐘_20261001.json
function Get-ExportFileName($now) {
    if ($null -eq $now) { $now = Get-Date }
    return "真劍鬧鐘_我的鬧鐘_$($now.ToString('yyyyMMdd', [System.Globalization.CultureInfo]::InvariantCulture)).json"
}

# 深拷貝一個鬧鐘（不動到原本的物件）
function Copy-AlarmObject($a) {
    return ($a | ConvertTo-Json -Depth 8 -Compress | ConvertFrom-Json)
}

# 拿掉裝置狀態欄位後的鬧鐘（拷貝）
function Get-AlarmWithoutState($a) {
    $c = Copy-AlarmObject $a
    foreach ($f in $script:ExportStateFields) {
        if ($null -ne $c.PSObject.Properties[$f]) { $c.PSObject.Properties.Remove($f) }
    }
    # 匯出不帶「生效時間」：匯入進來的那一刻才起算
    if ($null -ne $c.PSObject.Properties["armedAt"]) { $c.PSObject.Properties.Remove("armedAt") }
    return $c
}

# 組出匯出內容（PSCustomObject）。$categories：使用者自己新增的分類（settings.json 的 categories）
function New-AlarmExport($alarms, $categories, $now, $colors, $privateCats = $null) {
    if ($null -eq $now) { $now = Get-Date }
    $list = @()
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        $list += (Get-AlarmWithoutState $a)
    }
    $cats = @()
    foreach ($c in @(Get-AllCategories $alarms $categories)) {
        if ($c -ne $script:DefaultCategory -and $cats -notcontains $c) { $cats += $c }
    }
    $export = [PSCustomObject]@{
        format     = $script:ExportFormat
        version    = $script:ExportVersion
        exportedAt = $now.ToString("yyyy-MM-ddTHH:mm:sszzz", [System.Globalization.CultureInfo]::InvariantCulture)
        app        = "$($script:AppName) Windows v$($script:AppVersion)"
        alarms     = $list
        categories = $cats
    }
    # 分類顏色（v1.6 之後）：舊版讀到這個欄位會直接忽略
    $cc = Update-CategoryColors $cats $colors
    if ($cc.Count -gt 0) { $export | Add-Member -NotePropertyName categoryColors -NotePropertyValue (ConvertTo-CategoryColorObject $cc) }
    # 私密分類（v1.6.1 之後）：舊版讀到忽略。鬧鐘自己的「私密」是鬧鐘的 private 欄位，隨鬧鐘一起匯出
    $pc = @(Get-CleanPrivateCategories $privateCats | Where-Object { $cats -contains $_ })
    if ($pc.Count -gt 0) { $export | Add-Member -NotePropertyName privateCategories -NotePropertyValue @($pc) }
    return $export
}

# 匯出成 json 字串（alarms、categories 是物件的屬性，只有一個鬧鐘時也會是陣列）
function ConvertTo-AlarmExportJson($export) {
    return ($export | ConvertTo-Json -Depth 8)
}

# 寫出匯出檔（UTF-8、不加 BOM，手機和其他程式都讀得懂）
function Export-AlarmFile([string]$path, $alarms, $categories, $now, $colors, $privateCats = $null) {
    $export = New-AlarmExport $alarms $categories $now $colors $privateCats
    $json = ConvertTo-AlarmExportJson $export
    [System.IO.File]::WriteAllText($path, $json, (New-Object System.Text.UTF8Encoding($false)))
    return $export
}

# 讀匯出檔：回傳 @{ Ok; Error; Alarms; Categories; Version; ExportedAt }
function Read-AlarmExport([string]$path) {
    $bad = @{ Ok = $false; Error = ""; Alarms = @(); Categories = @(); Version = 0; ExportedAt = ""; Colors = @{} }
    if (-not (Test-Path -LiteralPath $path)) { $bad.Error = "找不到檔案：$path"; return $bad }
    $text = $null
    try {
        $bytes = [System.IO.File]::ReadAllBytes($path)
        $start = 0
        if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) { $start = 3 }
        $text = (New-Object System.Text.UTF8Encoding($false)).GetString($bytes, $start, $bytes.Length - $start)
    } catch { $bad.Error = "檔案讀不出來：$($_.Exception.Message)"; return $bad }
    return (ConvertFrom-AlarmExportJson $text)
}

function ConvertFrom-AlarmExportJson([string]$text) {
    $bad = @{ Ok = $false; Error = ""; Alarms = @(); Categories = @(); Version = 0; ExportedAt = ""; Colors = @{} }
    $notOurs = "這個檔案不是「$($script:AppName)」匯出的鬧鐘檔，沒有匯入。`n（請選檔名像「真劍鬧鐘_我的鬧鐘_日期.json」的檔案）"
    if ($null -eq $text -or $text.Trim() -eq "") { $bad.Error = "檔案是空的。`n$notOurs"; return $bad }
    $data = $null
    try { $data = $text | ConvertFrom-Json } catch { $bad.Error = $notOurs; return $bad }
    if ($null -eq $data -or $data -is [System.Array] -or $null -eq $data.PSObject.Properties["format"]) { $bad.Error = $notOurs; return $bad }
    if ("$($data.format)" -ne $script:ExportFormat) { $bad.Error = "$notOurs`n（檔案裡寫的格式是「$($data.format)」）"; return $bad }
    $ver = 0
    try { $ver = [int]$data.version } catch { $ver = 0 }
    $list = @()
    if ($null -ne $data.alarms) {
        foreach ($a in @($data.alarms)) {
            if ($null -eq $a -or $a -isnot [System.Management.Automation.PSCustomObject]) { continue }
            $list += $a
        }
    }
    $cats = @()
    if ($null -ne $data.categories) {
        foreach ($c in @($data.categories)) {
            if ($null -eq $c) { continue }
            $t = "$c".Trim()
            if ($t -ne "" -and $t -ne $script:DefaultCategory -and $cats -notcontains $t) { $cats += $t }
        }
    }
    return @{ Ok = $true; Error = ""; Alarms = $list; Categories = $cats; Version = $ver; ExportedAt = "$($data.exportedAt)"; Colors = (ConvertFrom-CategoryColorObject $data.categoryColors); PrivateCats = @(Get-CleanPrivateCategories $data.privateCategories) }
}

# 「內容」比對用的字串：不看編號、狀態、建立日；空值和沒有這個欄位視為一樣
function Get-AlarmContentKey($a) {
    $parts = @()
    foreach ($p in @($a.PSObject.Properties | Sort-Object -Property Name)) {
        if ($script:ContentIgnoreFields -contains $p.Name) { continue }
        $v = $p.Value
        $s = ""
        if ($null -eq $v) { $s = "" }
        elseif ($v -is [System.Array]) {
            $items = @($v | ForEach-Object { "$_" })
            if ($items.Count -eq 0) { $s = "" } else { $s = "[" + ($items -join ",") + "]" }
        }
        elseif ($v -is [bool]) { if ($v) { $s = "true" } else { $s = "false" } }
        elseif ($v -is [System.Management.Automation.PSCustomObject]) { $s = ($v | ConvertTo-Json -Depth 8 -Compress) }
        else { $s = "$v" }
        if ($s -eq "") { continue }
        $parts += "$($p.Name)=$s"
    }
    return ($parts -join "`n")
}

# 匯入進來的鬧鐘先整理：拿掉裝置狀態；**已經過去的那幾次當作處理過**（免得一匯入就跳一堆舊提醒）
function Initialize-ImportedAlarm($a, [DateTime]$now) {
    $c = Get-AlarmWithoutState $a
    $done = @()
    if ("$($c.type)" -ne "interval") {
        $h = -1; $m = 0
        try { $tp = Get-AlarmTimeParts $c; $h = $tp[0]; $m = $tp[1] } catch { $h = -1 }
        if ($h -ge 0) {
            foreach ($d in @(Get-CandidateDates $c $now)) {
                if ($null -eq $d) { continue }
                if ($d.AddHours($h).AddMinutes($m) -le $now) { $done += $d.ToString("yyyy-MM-dd") }
            }
        }
    }
    $c | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @($done) -Force
    # 匯入的鬧鐘從匯入那一刻起算生效
    Set-AlarmArmedLocal $c $now
    return $c
}

function Get-AlarmIdNumber($a) {
    if ($null -eq $a -or $null -eq $a.id) { return $null }
    $n = 0
    if ([int]::TryParse("$($a.id)", [ref]$n) -and $n -gt 0) { return $n }
    return $null
}

# 全部取代：回傳整理好的鬧鐘清單（編號重複或沒有編號的會給新編號）
function Get-ReplacedAlarms($imported, [DateTime]$now) {
    $result = @()
    $used = @{}
    $maxId = 0
    foreach ($b in @($imported)) { $n = Get-AlarmIdNumber $b; if ($null -ne $n -and $n -gt $maxId) { $maxId = $n } }
    foreach ($b in @($imported)) {
        if ($null -eq $b) { continue }
        $c = Initialize-ImportedAlarm $b $now
        $n = Get-AlarmIdNumber $c
        if ($null -eq $n -or $used.ContainsKey($n)) { $maxId++; $n = $maxId }
        $c | Add-Member -NotePropertyName id -NotePropertyValue $n -Force
        $used[$n] = $true
        $result += $c
    }
    return $result
}

# 合併：用內部編號判斷是不是同一個鬧鐘。
#   編號一樣、內容也一樣 → 不重複加（留本機的，本機的已完成紀錄不動）
#   編號一樣、內容不同   → 當成新鬧鐘，換新編號
#   本機沒有這個編號     → 直接加進來
# 回傳 @{ Alarms; Added; Skipped; Renumbered }
function Merge-ImportedAlarms($current, $imported, [DateTime]$now) {
    $result = @()
    foreach ($a in @($current)) { if ($null -ne $a) { $result += $a } }
    $byId = @{}
    $maxId = 0
    foreach ($a in $result) {
        $n = Get-AlarmIdNumber $a
        if ($null -ne $n) { $byId[$n] = $a; if ($n -gt $maxId) { $maxId = $n } }
    }
    foreach ($b in @($imported)) { $n = Get-AlarmIdNumber $b; if ($null -ne $n -and $n -gt $maxId) { $maxId = $n } }
    $added = 0; $skipped = 0; $renumbered = 0
    foreach ($b in @($imported)) {
        if ($null -eq $b) { continue }
        $c = Initialize-ImportedAlarm $b $now
        $n = Get-AlarmIdNumber $c
        if ($null -ne $n -and $byId.ContainsKey($n)) {
            if ((Get-AlarmContentKey $byId[$n]) -eq (Get-AlarmContentKey $c)) { $skipped++; continue }
            $maxId++; $n = $maxId; $renumbered++
        } elseif ($null -eq $n) {
            $maxId++; $n = $maxId; $renumbered++
        }
        $c | Add-Member -NotePropertyName id -NotePropertyValue $n -Force
        $byId[$n] = $c
        $result += $c
        $added++
    }
    return @{ Alarms = $result; Added = $added; Skipped = $skipped; Renumbered = $renumbered }
}

# 分類清單合併（不重複、不含「未分類」）
function Merge-CategoryLists($a, $b) {
    $out = @()
    foreach ($c in (@($a) + @($b))) {
        if ($null -eq $c) { continue }
        $t = "$c".Trim()
        if ($t -ne "" -and $t -ne $script:DefaultCategory -and $out -notcontains $t) { $out += $t }
    }
    return $out
}

# 全部取代前的備份：alarms.json → 同資料夾的 alarms_匯入前備份_20261001_153000.json；沒有原檔回傳 $null
function Backup-AlarmFileBeforeImport([string]$path, $now) {
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    if ($null -eq $now) { $now = Get-Date }
    $dir = Split-Path -Parent $path
    $name = "alarms_匯入前備份_$($now.ToString('yyyyMMdd_HHmmss', [System.Globalization.CultureInfo]::InvariantCulture)).json"
    $dest = Join-Path $dir $name
    $i = 2
    while (Test-Path -LiteralPath $dest) { $dest = Join-Path $dir ($name -replace "\.json$", "_$i.json"); $i++ }
    Copy-Item -LiteralPath $path -Destination $dest
    return $dest
}

# Google 雲端硬碟電腦版的資料夾（常見 G:\我的雲端硬碟、G:\My Drive）；找不到回傳 $null
# $candidates 不給就用預設的猜法（每個磁碟機 + 使用者資料夾）
function Get-GoogleDriveCandidates {
    $list = @()
    $roots = @()
    try { $roots = @([System.IO.DriveInfo]::GetDrives() | Where-Object { $_.IsReady } | ForEach-Object { $_.RootDirectory.FullName }) } catch {}
    # G: 最常見，先看
    $roots = @($roots | Where-Object { $_ -like "G:*" }) + @($roots | Where-Object { $_ -notlike "G:*" })
    foreach ($r in $roots) {
        $list += (Join-Path $r "我的雲端硬碟")
        $list += (Join-Path $r "My Drive")
    }
    if ($env:USERPROFILE) {
        foreach ($n in @("我的雲端硬碟", "My Drive", "Google Drive", "Google 雲端硬碟")) { $list += (Join-Path $env:USERPROFILE $n) }
    }
    return $list
}

function Find-GoogleDriveFolder($candidates) {
    if ($null -eq $candidates) { $candidates = Get-GoogleDriveCandidates }
    foreach ($c in @($candidates)) {
        if ($null -eq $c -or "$c" -eq "") { continue }
        try { if (Test-Path -LiteralPath $c -PathType Container) { return "$c" } } catch {}
    }
    return $null
}

# ---------- 分類顏色（工單 7.1；規則跟 Android 版 CategoryColorLogic.kt 一樣） ----------
#   ・每個分類一個顏色，存成「分類名稱 → 色票編號」（settings.json 的 categoryColors，跟著同步、匯出匯入一起帶）；
#   ・「未分類」固定灰色，不存；
#   ・新分類（或舊資料還沒有顏色的分類）自動挑一個還沒被別的分類用過的顏色；用完了就挑用得最少的；
#   ・同樣的分類清單，兩邊算出來的顏色要一樣：沒顏色的分類依名稱排序後逐個分配。

function Test-CategoryColorId($id) {
    if ($null -eq $id) { return $false }
    return ($script:CategoryColorIds -ccontains "$id")
}

# 某個色票在淺色／深色模式下的色值（RGB 整數）；找不到就用灰色
function Get-CategoryColorStyle($id, [bool]$dark) {
    $mode = "light"
    if ($dark) { $mode = "dark" }
    $t = $script:CategoryColorTable[$mode]
    if ($null -ne $id -and $t.ContainsKey("$id")) { return $t["$id"] }
    return $t["gray"]
}

# 補齊顏色：回傳新的對照表（只含目前存在的分類、不含「未分類」、色票編號都有效）
function Update-CategoryColors($categories, $colors) {
    $names = @()
    foreach ($c in @($categories)) {
        if ($null -eq $c) { continue }
        $t = "$c".Trim()
        if ($t -ne "" -and $t -ne $script:DefaultCategory -and $names -cnotcontains $t) { $names += $t }
    }
    $out = @{}
    foreach ($n in $names) {
        if ($null -ne $colors -and $colors.ContainsKey($n) -and (Test-CategoryColorId $colors[$n])) { $out[$n] = "$($colors[$n])" }
    }
    $missing = @($names | Where-Object { -not $out.ContainsKey($_) })
    [Array]::Sort($missing, [StringComparer]::Ordinal)
    foreach ($n in $missing) {
        $usage = @{}
        foreach ($id in $script:CategoryColorIds) { $usage[$id] = 0 }
        foreach ($v in @($out.Values)) { $usage["$v"]++ }
        $pick = $null
        foreach ($id in $script:CategoryColorIds) { if ($usage[$id] -eq 0) { $pick = $id; break } }
        if ($null -eq $pick) {
            $pick = $script:CategoryColorIds[0]
            foreach ($id in $script:CategoryColorIds) { if ($usage[$id] -lt $usage[$pick]) { $pick = $id } }
        }
        $out[$n] = $pick
    }
    return $out
}

# 這個分類的色票編號（未分類、沒顏色 → gray）
function Get-CategoryColorOf([string]$name, $colors) {
    if ($name -eq $script:DefaultCategory) { return "gray" }
    if ($null -ne $colors -and $colors.ContainsKey($name) -and (Test-CategoryColorId $colors[$name])) { return "$($colors[$name])" }
    return "gray"
}

# 改名：顏色跟著走；改成已經存在的名字（合併）→ 沿用那個分類原本的顏色
function Rename-CategoryColor($colors, [string]$old, [string]$new) {
    $out = @{}
    if ($null -ne $colors) { foreach ($k in @($colors.Keys)) { $out[$k] = $colors[$k] } }
    if ($out.ContainsKey($old)) {
        $c = $out[$old]
        $out.Remove($old)
        if (-not $out.ContainsKey($new)) { $out[$new] = $c }
    }
    return $out
}

function Remove-CategoryColor($colors, [string]$name) {
    $out = @{}
    if ($null -ne $colors) { foreach ($k in @($colors.Keys)) { if ($k -ne $name) { $out[$k] = $colors[$k] } } }
    return $out
}

# 對照表 ↔ 檔案裡的物件（名稱排序，色票編號無效的丟掉）
function ConvertFrom-CategoryColorObject($o) {
    $out = @{}
    if ($null -eq $o) { return $out }
    foreach ($p in @($o.PSObject.Properties)) {
        if ("$($p.Name)".Trim() -ne "" -and (Test-CategoryColorId $p.Value)) { $out["$($p.Name)"] = "$($p.Value)" }
    }
    return $out
}

function ConvertTo-CategoryColorObject($colors) {
    $o = [ordered]@{}
    if ($null -ne $colors) {
        $keys = @($colors.Keys | ForEach-Object { "$_" })
        [Array]::Sort($keys, [StringComparer]::Ordinal)
        foreach ($k in $keys) { $o[$k] = $colors[$k] }
    }
    return $o
}

# 對比度（WCAG）：兩個 RGB 整數
function Get-ColorLuminance([int]$rgb) {
    $v = @((($rgb -shr 16) -band 255), (($rgb -shr 8) -band 255), ($rgb -band 255)) | ForEach-Object {
        $x = $_ / 255.0
        if ($x -le 0.03928) { $x / 12.92 } else { [Math]::Pow(($x + 0.055) / 1.055, 2.4) }
    }
    return (0.2126 * $v[0] + 0.7152 * $v[1] + 0.0722 * $v[2])
}

function Get-ContrastRatio([int]$a, [int]$b) {
    $la = Get-ColorLuminance $a; $lb = Get-ColorLuminance $b
    return ([Math]::Max($la, $lb) + 0.05) / ([Math]::Min($la, $lb) + 0.05)
}

# ---------- 關鬧鐘的難度（工單 8.5；Android 的 core/Quiz.kt 是同一套） ----------
#   math1：算術 1 題（1～19 的加減）／math3：算術 3 題要連續答對／hard1：兩位數加減／hard2：兩位數×一位數／hard3：兩位數×兩位數
#   qr：掃 QR code（只有手機能用；電腦上改答 3 題算術）
$script:QuizChoices = @("math1", "math3", "hard1", "hard2", "hard3")
$script:QuizLabels = @{ math1 = "算術 1 題"; math3 = "算術 3 題（連續答對）"; hard1 = "變難 1：兩位數加減"; hard2 = "變難 2：兩位數 × 一位數"; hard3 = "變難 3：兩位數 × 兩位數"; qr = "手機掃 QR（電腦上改答 3 題）" }

# 這個鬧鐘的難度（不認得的值、沒有 → math1）；回傳 @{ Diff; Need }。qr 在電腦上等於 math3
function Get-QuizSpec($difficulty) {
    $d = "$difficulty"
    if ($d -eq "qr") { return @{ Diff = "math3"; Need = 3 } }
    if ($script:QuizChoices -notcontains $d) { $d = "math1" }
    $need = 1
    if ($d -eq "math3") { $need = 3 }
    return @{ Diff = $d; Need = $need }
}

# 出一題：回傳 @{ Text; Answer }
function Get-QuizQuestion($difficulty) {
    switch ("$difficulty") {
        "hard1" {
            $a = Get-Random -Minimum 10 -Maximum 100; $b = Get-Random -Minimum 10 -Maximum 100
            if ((Get-Random -Minimum 0 -Maximum 2) -eq 0) { return @{ Text = "$a + $b"; Answer = ($a + $b) } }
            if ($a -lt $b) { $t = $a; $a = $b; $b = $t }
            return @{ Text = "$a - $b"; Answer = ($a - $b) }
        }
        "hard2" { $a = Get-Random -Minimum 11 -Maximum 100; $b = Get-Random -Minimum 2 -Maximum 10; return @{ Text = "$a × $b"; Answer = ($a * $b) } }
        "hard3" { $a = Get-Random -Minimum 11 -Maximum 30; $b = Get-Random -Minimum 11 -Maximum 30; return @{ Text = "$a × $b"; Answer = ($a * $b) } }
        default {
            $n1 = Get-Random -Minimum 1 -Maximum 20; $n2 = Get-Random -Minimum 1 -Maximum 20
            if ((Get-Random -Minimum 0 -Maximum 2) -eq 0) { return @{ Text = "$n1 + $n2"; Answer = ($n1 + $n2) } }
            if ($n1 -lt $n2) { $t = $n1; $n1 = $n2; $n2 = $t }
            return @{ Text = "$n1 - $n2"; Answer = ($n1 - $n2) }
        }
    }
}

# ---------- 響鈴的時間規則（工單 8.4；Android 的 core/RingCycle.kt 是同一套） ----------
#   一直響到處理為止：連續響 10 分鐘沒人理 → 停聲 5 分鐘 → 再響；從開始響算起滿 60 分鐘還沒處理 → 不再出聲（視窗還在）
#   回傳 "ring"（該出聲）／"pause"（停聲中）／"gaveup"（放棄了）
function Get-RingPhase([double]$elapsedSeconds, [int]$ringMin = 10, [int]$pauseMin = 5, [int]$totalMin = 60) {
    if ($elapsedSeconds -lt 0) { return "ring" }
    if ($elapsedSeconds -ge ($totalMin * 60)) { return "gaveup" }
    $cycle = ($ringMin + $pauseMin) * 60
    if (($elapsedSeconds % $cycle) -lt ($ringMin * 60)) { return "ring" }
    return "pause"
}

# ---------- 每個鬧鐘的音量、漸強、鈴聲（2026-10-05 電腦版補齊；Android core/AlarmVolume.kt、core/RingSound.kt 同一套規則） ----------
# 鬧鐘欄位（跟著同步）：volume（20~100，%）、crescendo（true/false，沒有＝看重要程度與全域設定）、ringtone（""＝跟隨全域）
# 電腦上「音量 80%」＝ Windows 目前音量的 80%（電腦沒有獨立的鬧鐘音量，也不會去動系統音量）
$script:VolumeMin = 20
$script:VolumeMax = 100
$script:VolumeStep = 5
function Get-DefaultAlarmVolume([string]$importance) {
    switch ($importance) { "must" { return 100 } "quiz" { return 90 } default { return 80 } }
}
function Get-AlarmVolumeFloor([string]$importance) {
    switch ($importance) { "must" { return 50 } "quiz" { return 40 } default { return $script:VolumeMin } }
}
function Limit-AlarmVolume([int]$v, [string]$importance) {
    $r = [int]([Math]::Round($v / $script:VolumeStep, [MidpointRounding]::AwayFromZero) * $script:VolumeStep)
    return [Math]::Min($script:VolumeMax, [Math]::Max((Get-AlarmVolumeFloor $importance), $r))
}
function Get-AlarmVolume($a) {
    $imp = Get-AlarmImportance $a
    $v = $null
    try { if ($null -ne $a.volume -and "$($a.volume)" -match '^\s*-?\d+(\.0+)?\s*$') { $v = [int][double]"$($a.volume)" } } catch {}
    if ($null -eq $v) { $v = Get-DefaultAlarmVolume $imp }
    return (Limit-AlarmVolume $v $imp)
}
function Get-DefaultCrescendo([string]$importance, [bool]$global) {
    if ($importance -ne "normal") { return $false }
    return $global
}
function Get-AlarmCrescendo($a, [bool]$global) {
    try {
        if ($null -ne $a.crescendo) {
            $t = "$($a.crescendo)"
            if ($t -eq "True" -or $t -eq "true") { return $true }
            if ($t -eq "False" -or $t -eq "false") { return $false }
        }
    } catch {}
    return (Get-DefaultCrescendo (Get-AlarmImportance $a) $global)
}

# 鈴聲代號：phone（手機的鬧鐘鈴聲）／gentle／standard／loud（內建三種）／custom:<代號>（自訂，音檔只在那台裝置）
# 電腦另外有 system（Windows 提示音，1.8.3 以前的聲音）。電腦遇到 phone → 用這台電腦的全域設定
$script:ToneBuiltins = @("gentle", "standard", "loud")
$script:ToneCustomPrefix = "custom:"
function Test-CustomTone([string]$v) { return ($null -ne $v -and $v.StartsWith($script:ToneCustomPrefix) -and $v.Length -gt $script:ToneCustomPrefix.Length) }
function Get-CustomToneId([string]$v) { return $v.Substring($script:ToneCustomPrefix.Length) }
# 鬧鐘自己的欄位：空的、看不懂的 → ""（跟隨全域）；舊的 builtin → standard
function Get-ValidAlarmTone([string]$v) {
    if ([string]::IsNullOrEmpty($v)) { return "" }
    if ($v -eq "builtin") { return "standard" }
    if (@("phone") + $script:ToneBuiltins -contains $v -or (Test-CustomTone $v)) { return $v }
    return ""
}
# 這台電腦的全域鈴聲：預設「內建・標準」
function Get-ValidPcTone([string]$v) {
    if ($v -eq "builtin") { return "standard" }
    if (@("system") + $script:ToneBuiltins -contains $v -or (Test-CustomTone $v)) { return $v }
    return "standard"
}
# 這個鬧鐘在這台電腦上實際要放的鈴聲；$customExists：代號 → 這台有沒有那個音檔
function Resolve-PcTone([string]$alarmTone, [string]$pcGlobal, [scriptblock]$customExists) {
    $t = Get-ValidAlarmTone $alarmTone
    if ($t -eq "" -or $t -eq "phone") { $t = Get-ValidPcTone $pcGlobal }
    if ((Test-CustomTone $t) -and -not (& $customExists (Get-CustomToneId $t))) { $t = "standard" }
    return $t
}
function Get-ToneLabel([string]$v, [scriptblock]$customName) {
    if ($v -eq "") { return "跟隨全域設定" }
    if ($v -eq "phone") { return "手機的鬧鐘鈴聲（電腦上用全域設定）" }
    if ($v -eq "system") { return "Windows 提示音（舊版的聲音）" }
    if ($v -eq "gentle") { return "內建・溫和" }
    if ($v -eq "standard" -or $v -eq "builtin") { return "內建・標準" }
    if ($v -eq "loud") { return "內建・很吵" }
    if (Test-CustomTone $v) {
        $n = $null
        if ($null -ne $customName) { $n = & $customName (Get-CustomToneId $v) }
        if ($n) { return "自訂：$n" }
        return "自訂鈴聲（這台電腦沒有，改用內建・標準）"
    }
    return "內建・標準"
}
# 「絕對不能延後」又還是跟隨全域 → 建議改成很吵（跟手機一樣，只是預設）
function Get-SuggestedToneForImportance([string]$importance, [string]$current) {
    if ($importance -eq "must" -and $current -eq "") { return "loud" }
    return $current
}

# 漸強：從音量的一半開始，30 秒到設定的音量（每一段響鈴重新開始）
function Get-CrescendoVolume([int]$volume, [double]$secondsIntoSegment, [bool]$crescendo) {
    $full = $volume / 100.0
    if (-not $crescendo) { return $full }
    $f = [Math]::Min(1.0, [Math]::Max(0.0, $secondsIntoSegment / 30.0))
    return ($full * (0.5 + 0.5 * $f))
}

# 這台電腦的響鈴設定（只在這台；ring_settings.json）：全域鈴聲、普通鬧鐘預設要不要漸強
function Read-RingSettings([string]$path) {
    $s = @{ tone = "standard"; crescendo = $true }
    if (-not (Test-Path -LiteralPath $path)) { return $s }
    try {
        $d = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        $s.tone = Get-ValidPcTone "$($d.tone)"
        if ($null -ne $d.crescendo) { $s.crescendo = ("$($d.crescendo)" -eq "True") }
    } catch {}
    return $s
}
function Write-RingSettings([string]$path, $s) {
    [PSCustomObject]@{ tone = (Get-ValidPcTone "$($s.tone)"); crescendo = [bool]$s.crescendo } | ConvertTo-Json | Out-File -FilePath $path -Encoding UTF8
}

# 自訂鈴聲（只在這台電腦）：清單 ringtones.json，音檔複製到 ringtones\ 資料夾；規則跟手機一樣（最多 5 個、20 MB、30 字）
$script:CustomToneMaxCount = 5
$script:CustomToneMaxBytes = 20MB
$script:CustomToneMaxName = 30
$script:CustomToneExts = @("mp3", "wav", "wma", "m4a", "aac")
function Read-CustomTones([string]$path) {
    $out = @()
    if (-not (Test-Path -LiteralPath $path)) { return $out }
    try {
        $arr = @(Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json)
        foreach ($o in $arr) {
            if ($null -eq $o) { continue }
            $id = "$($o.id)"; $file = "$($o.file)"
            if ($id -eq "" -or $file -eq "" -or $file.Contains("\") -or $file.Contains("/") -or $file.Contains("..")) { continue }
            $name = "$($o.name)".Trim()
            if ($name -eq "") { $name = "自訂鈴聲" }
            $out += [PSCustomObject]@{ id = $id; name = $name; file = $file; bytes = [long]("0$($o.bytes)" -replace '[^\d]', '') }
        }
    } catch {}
    return $out
}
function Write-CustomTones([string]$path, $list) {
    $json = ConvertTo-Json -InputObject @($list | ForEach-Object { [PSCustomObject]@{ id = $_.id; name = $_.name; file = $_.file; bytes = [long]$_.bytes } }) -Depth 3
    if (@($list).Count -eq 0) { $json = "[]" }
    $json | Out-File -FilePath $path -Encoding UTF8
}
# 加得進來嗎？不行回傳原因（白話）；可以回傳 $null
function Test-CustomToneAddable([int]$count, [long]$bytes, [string]$fileName) {
    if ($count -ge $script:CustomToneMaxCount) { return "自訂鈴聲最多 $($script:CustomToneMaxCount) 個，請先刪掉一個。" }
    if ($bytes -gt $script:CustomToneMaxBytes) { return "音檔太大（上限 20 MB）。" }
    if ($bytes -le 0) { return "這個檔案是空的。" }
    $ext = [System.IO.Path]::GetExtension($fileName).TrimStart(".").ToLowerInvariant()
    if ($script:CustomToneExts -notcontains $ext) { return "電腦版只能用 mp3、wav、wma、m4a、aac 音檔。" }
    return $null
}
# 名稱：去頭尾空白、去副檔名、換行換空白、限制 30 字；空的給預設
function Get-CleanToneName([string]$raw) {
    $n = "$raw".Trim()
    $dot = $n.LastIndexOf(".")
    if ($dot -gt 0 -and ($n.Length - $dot) -le 5) { $n = $n.Substring(0, $dot) }
    $n = ($n -replace "[\r\n\t]", " ").Trim()
    if ($n.Length -gt $script:CustomToneMaxName) { $n = $n.Substring(0, $script:CustomToneMaxName) }
    if ($n -eq "") { $n = "自訂鈴聲" }
    return $n
}

# 編輯畫面的白話說明（跟手機的 AlarmVolume.describe 同一套說法，電腦版沒有音量鍵與鬧鐘音量那兩句）
function Get-VolumeDescription([string]$importance, [int]$volume, [bool]$crescendo, [bool]$playSound) {
    if (-not $playSound) { return "這個鬧鐘設成「不出聲音」：響的時候只跳出提醒視窗。" }
    $v = Limit-AlarmVolume $volume $importance
    if ($importance -eq "must" -and -not $crescendo) { $l = "這是「絕對不能延後」的鬧鐘：一響就是 $v% 音量，不會慢慢變大。" }
    elseif ($importance -eq "quiz" -and -not $crescendo) { $l = "這是「要答題才能延後」的鬧鐘：一響就是 $v% 音量，不會慢慢變大。" }
    elseif ($crescendo) { $l = "響起時從 $([int]($v / 2))% 慢慢變大，約 30 秒到 $v%。" }
    else { $l = "一響就是 $v% 音量，不會慢慢變大。" }
    return "$l`n電腦上的 $v% 是「Windows 目前音量」的 $v%：電腦整台靜音或音量很小時，鬧鐘也會很小聲。"
}

# ---------- 找鬧鐘：篩選／搜尋／即將響（工單 8.3；Android 的 core/ListFilter.kt 是同一套規則） ----------
#   篩選鍵：all（全部）／soon（即將響：下一次響的時間在現在起 24 小時內，含剛好 24 小時；已到期還沒完成的定期倒數也算）／cat:分類名稱
#   搜尋：依名稱，含部分字、不分大小寫
function Test-AlarmSoon($a, [DateTime]$now) {
    $n = Get-NextOccurrence $a $now
    if ($null -eq $n) { return $false }
    return ($n -le $now.AddHours(24))
}

function Test-AlarmMatchesQuery($a, [string]$query) {
    $q = "$query".Trim()
    if ($q -eq "") { return $true }
    return ("$($a.label)".IndexOf($q, [StringComparison]::OrdinalIgnoreCase) -ge 0)
}

function Get-FilteredAlarms($alarms, [string]$filterKey, [string]$query, [DateTime]$now) {
    $out = @()
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        $ok = $true
        if ($filterKey -eq "soon") { $ok = (Test-AlarmSoon $a $now) }
        elseif ($filterKey.StartsWith("cat:")) { $ok = ((Get-AlarmCategory $a) -eq $filterKey.Substring(4)) }
        if ($ok -and (Test-AlarmMatchesQuery $a $query)) { $out += $a }
    }
    return @($out)
}

# ---------- 私密鬧鐘（工單 8.1；Android 的 core/Privacy.kt 是同一套規則） ----------
#   ・鬧鐘本身的「私密」是 alarms.json 的 private 欄位（跟著同步、匯出匯入；沒這欄 = 不私密）
#   ・分類可設「私密」（settings.json 的 privateCategories、同步的 categories.private、匯出的 privateCategories）→ 底下鬧鐘都視為私密
#   ・Windows 的提醒視窗是在自己的電腦上，照常顯示；「私密」主要給手機用（開車不念內容、鎖定畫面不露內容）
function Get-CleanPrivateCategories($names) {
    $out = @()
    foreach ($n in @($names)) {
        if ($null -eq $n) { continue }
        $t = "$n".Trim()
        if ($t -ne "" -and $t -ne $script:DefaultCategory -and $out -notcontains $t) { $out += $t }
    }
    return @($out | Sort-Object { $_ } -CaseSensitive)
}

function Test-AlarmOwnPrivate($a) {
    if ($null -eq $a) { return $false }
    $p = $a.PSObject.Properties["private"]
    if ($null -eq $p) { return $false }
    return ("$($p.Value)" -eq "True")
}

function Test-AlarmViaCategoryPrivate($a, $privateCats) {
    if (Test-AlarmOwnPrivate $a) { return $false }
    return (@($privateCats) -contains (Get-AlarmCategory $a))
}

function Test-AlarmPrivate($a, $privateCats) {
    if (Test-AlarmOwnPrivate $a) { return $true }
    return (@($privateCats) -contains (Get-AlarmCategory $a))
}

function Rename-PrivateCategory($privateCats, [string]$old, [string]$new) {
    $l = @($privateCats)
    if ($l -contains $old) { $l = @($l | Where-Object { $_ -ne $old }) + $new }
    return @(Get-CleanPrivateCategories $l)
}

function Remove-PrivateCategory($privateCats, [string]$name) {
    return @(Get-CleanPrivateCategories @(@($privateCats) | Where-Object { $_ -ne $name }))
}

# ---- 分類色塊色值：由 android/tools/make-category-palette.py 產生（Android 的 CategoryColors.kt 用同一組），不要手改 ----
$script:CategoryColorIds = @("rose", "orange", "amber", "green", "teal", "blue", "indigo", "purple", "pink", "brown")
$script:CategoryColorNames = @{ rose = "玫瑰紅"; orange = "橘"; amber = "琥珀黃"; green = "綠"; teal = "青"; blue = "藍"; indigo = "靛"; purple = "紫"; pink = "粉紅"; brown = "棕"; gray = "灰" }
# 每個顏色：stripe 色條、tint 卡片底色、chip 分類標題色塊、chipText 色塊上的字、tag 分類名稱（RGB，0xRRGGBB）
$script:CategoryColorTable = @{
    light = @{
        rose = @{ stripe = 0xB6354A; tint = 0xEFE3E2; chip = 0xD8B0B2; chipText = 0x1B2420; tag = 0xAB3246 }
        orange = @{ stripe = 0xB66B35; tint = 0xEFE9E0; chip = 0xD8C2AB; chipText = 0x1B2420; tag = 0x8E5329 }
        amber = @{ stripe = 0xB69635; tint = 0xEFEEE0; chip = 0xD8D1AB; chipText = 0x1B2420; tag = 0x766122 }
        green = @{ stripe = 0x35B655; tint = 0xE1F2E3; chip = 0xACDCB6; chipText = 0x1B2420; tag = 0x227637 }
        teal = @{ stripe = 0x35B6AB; tint = 0xE1F2ED; chip = 0xACDCD3; chipText = 0x1B2420; tag = 0x206F68 }
        blue = @{ stripe = 0x3575B6; tint = 0xE1EBEE; chip = 0xACC6D7; chipText = 0x1B2420; tag = 0x2C6197 }
        indigo = @{ stripe = 0x3540B6; tint = 0xE1E5EE; chip = 0xACB3D7; chipText = 0x1B2420; tag = 0x3540B6 }
        purple = @{ stripe = 0x8B35B6; tint = 0xEAE3EE; chip = 0xC9B0D7; chipText = 0x1B2420; tag = 0x8B35B6 }
        pink = @{ stripe = 0xB6358B; tint = 0xEFE3E9; chip = 0xD8B0C8; chipText = 0x1B2420; tag = 0xAB3282 }
        brown = @{ stripe = 0xB66035; tint = 0xEFE8E0; chip = 0xD8BEAB; chipText = 0x1B2420; tag = 0x97502C }
        gray = @{ stripe = 0x969C98; tint = 0xEBEFEB; chip = 0xCDD3CD; chipText = 0x1B2420; tag = 0x616563 }
    }
    dark = @{
        rose = @{ stripe = 0xC77583; tint = 0x39353A; chip = 0x6A4950; chipText = 0xF4F1EA; tag = 0xD3949E }
        orange = @{ stripe = 0xC79775; tint = 0x393839; chip = 0x6A574A; chipText = 0xF4F1EA; tag = 0xCA9E7E }
        amber = @{ stripe = 0xC7B275; tint = 0x393A39; chip = 0x6A624A; chipText = 0xF4F1EA; tag = 0xC7B275 }
        green = @{ stripe = 0x75C78A; tint = 0x323C3A; chip = 0x476B53; chipText = 0xF4F1EA; tag = 0x75C78A }
        teal = @{ stripe = 0x75C7C0; tint = 0x323C3F; chip = 0x476B6A; chipText = 0xF4F1EA; tag = 0x75C7C0 }
        blue = @{ stripe = 0x759EC7; tint = 0x323840; chip = 0x475A6C; chipText = 0xF4F1EA; tag = 0x85A9CD }
        indigo = @{ stripe = 0x757CC7; tint = 0x323640; chip = 0x474B6C; chipText = 0xF4F1EA; tag = 0x9A9FD6 }
        purple = @{ stripe = 0xAC75C7; tint = 0x373540; chip = 0x5E496C; chipText = 0xF4F1EA; tag = 0xC29AD6 }
        pink = @{ stripe = 0xC775AC; tint = 0x39353D; chip = 0x6A4961; chipText = 0xF4F1EA; tag = 0xD394BE }
        brown = @{ stripe = 0xC79175; tint = 0x393739; chip = 0x6A544A; chipText = 0xF4F1EA; tag = 0xCD9D85 }
        gray = @{ stripe = 0x8C9094; tint = 0x34373B; chip = 0x515457; chipText = 0xF4F1EA; tag = 0xA5A8AB }
    }
}
# ---- 分類色塊色值結束 ----


# ---- 設定分類與搜尋（工單 8.6；跟 Android 版同一套 key，Windows 沒有的功能就沒有那一項）----
function Get-SettingsSections {
    return @(
        @{ Id = "ring";    Icon = "⏰"; Title = "響鈴" },
        @{ Id = "privacy"; Icon = "🔒"; Title = "隱私" },
        @{ Id = "sync";    Icon = "☁";  Title = "同步與備份" },
        @{ Id = "look";    Icon = "🎨"; Title = "外觀" },
        @{ Id = "setup";   Icon = "🔋"; Title = "讓鬧鐘準時響" },
        @{ Id = "about";   Icon = "⬆";  Title = "更新與關於" }
    )
}

function Get-SettingsEntries {
    return @(
        @{ Key = "ring.tone";      Section = "ring";    Label = "鈴聲選項（內建三種／自訂／Windows 提示音）"; Keywords = @("鈴聲", "鈴聲選項", "內建鈴聲", "換鈴聲", "聲音", "溫和", "標準", "很吵", "提示音") },
        @{ Key = "ring.preview";   Section = "ring";    Label = "試聽鈴聲";                       Keywords = @("試聽", "聽聽看", "測試聲音", "有沒有聲音") },
        @{ Key = "ring.crescendo"; Section = "ring";    Label = "漸強音量";                       Keywords = @("漸強", "音量", "由小到大", "小聲") },
        @{ Key = "ring.custom";    Section = "ring";    Label = "自訂鈴聲";                       Keywords = @("自訂", "自訂鈴聲", "音樂", "mp3", "自己的歌", "音檔") },
        @{ Key = "ring.rules";     Section = "ring";    Label = "響鈴規則（連續響、停聲、最久響）"; Keywords = @("響鈴", "連續響", "停聲", "最久響", "10 分鐘", "5 分鐘", "60 分鐘", "規則", "休息") },
        @{ Key = "ring.vibrate";   Section = "ring";    Label = "震動（電腦沒有）";               Keywords = @("震動", "振動") },
        @{ Key = "ring.confirm";   Section = "ring";    Label = "確認醒了、關鬧鐘難度";           Keywords = @("確認醒了", "難度", "算術", "答題") },
        @{ Key = "privacy.cats";   Section = "privacy"; Label = "私密分類";                       Keywords = @("私密", "隱私", "不顯示內容", "隱藏", "分類管理") },
        @{ Key = "privacy.data";   Section = "privacy"; Label = "資料存放說明";                   Keywords = @("資料", "收集", "不上傳") },
        @{ Key = "privacy.policy"; Section = "privacy"; Label = "隱私權政策（網頁）";             Keywords = @("隱私權", "政策", "隱私權政策", "條款") },
        @{ Key = "sync.account";   Section = "sync";    Label = "Google 帳號登入／登出、立即同步"; Keywords = @("同步", "Google", "登入", "登出", "帳號", "雲端", "立即同步", "上次同步") },
        @{ Key = "sync.export";    Section = "sync";    Label = "匯出鬧鐘";                       Keywords = @("匯出", "備份", "存檔", "json") },
        @{ Key = "sync.import";    Section = "sync";    Label = "匯入鬧鐘";                       Keywords = @("匯入", "還原", "新電腦", "搬家") },
        @{ Key = "look.font";      Section = "look";    Label = "字體大小";                       Keywords = @("字體", "字級", "大字", "特大") },
        @{ Key = "look.bold";      Section = "look";    Label = "粗體";                           Keywords = @("粗體", "粗字", "加粗") },
        @{ Key = "look.theme";     Section = "look";    Label = "深色／淺色";                     Keywords = @("深色", "淺色", "夜間", "暗色", "護眼", "主題", "外觀") },
        @{ Key = "look.catcolor";  Section = "look";    Label = "分類顏色";                       Keywords = @("分類顏色", "色塊", "顏色", "分類管理") },
        @{ Key = "setup.tray";     Section = "setup";   Label = "背景提醒（啟動／停止）";         Keywords = @("背景提醒", "常駐", "工作列", "準時", "啟動", "停止") },
        @{ Key = "setup.startup";  Section = "setup";   Label = "開機自動啟動";                   Keywords = @("開機", "自動啟動", "開機啟動") },
        @{ Key = "about.update";   Section = "about";   Label = "檢查更新";                       Keywords = @("更新", "新版", "版本", "下載") },
        @{ Key = "about.version";  Section = "about";   Label = "目前版本";                       Keywords = @("版本", "版號") },
        @{ Key = "about.about";    Section = "about";   Label = "關於真劍鬧鐘";                   Keywords = @("關於", "作者", "名字由來", "沙龍") },
        @{ Key = "about.privacy";  Section = "about";   Label = "隱私權政策";                     Keywords = @("隱私權", "隱私說明", "政策", "條款") },
        @{ Key = "about.share";    Section = "about";   Label = "分享給朋友";                     Keywords = @("分享", "朋友", "下載頁", "推薦", "網址", "連結") }
    )
}

# 搜尋：輸入用空白拆成幾個字，每個字都要在「名稱＋關鍵字＋分類名」裡找得到（不分大小寫）；名稱直接命中的排前面
function Search-SettingsIndex([string]$query) {
    $words = @(($query.Trim().ToLowerInvariant() -split '\s+') | Where-Object { $_ -ne "" })
    if ($words.Count -eq 0) { return @() }
    $secTitle = @{}
    foreach ($s in (Get-SettingsSections)) { $secTitle[$s.Id] = $s.Title }
    $hits = New-Object System.Collections.ArrayList
    $i = 0
    foreach ($e in (Get-SettingsEntries)) {
        $i++
        $label = $e.Label.ToLowerInvariant()
        $hay = $label + "`n" + $secTitle[$e.Section].ToLowerInvariant() + "`n" + (($e.Keywords | ForEach-Object { $_.ToLowerInvariant() }) -join "`n")
        $all = $true; $titleAll = $true
        foreach ($w in $words) {
            if (-not $hay.Contains($w)) { $all = $false }
            if (-not $label.Contains($w)) { $titleAll = $false }
        }
        if ($all) { [void]$hits.Add(@{ Rank = ($(if ($titleAll) { 0 } else { 1000 }) + $i); Entry = $e }) }
    }
    return @($hits | Sort-Object { $_.Rank } | ForEach-Object { $_.Entry })
}

# 「讓鬧鐘準時響」有問題（Windows：背景提醒沒在跑）→ 這個分類排最上面
function Get-SettingsSectionsOrdered([bool]$setupProblem) {
    $all = @(Get-SettingsSections)
    if (-not $setupProblem) { return $all }
    return @(@($all | Where-Object { $_.Id -eq "setup" }) + @($all | Where-Object { $_.Id -ne "setup" }))
}

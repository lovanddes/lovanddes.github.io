﻿# 真劍鬧鐘：共用的視窗小工具（圖檔、圖示、配色、「關於」視窗、在背景啟動另一支程式）
# 設定視窗和背景提醒都用 . 載入這支。圖檔找不到時一律回傳 $null，程式照常能用、只是不顯示圖。

# 欸唉新跪配色：主色淺灰綠(POLO 衫)、點綴紅(龍蝦)、淺藍(水母)
$script:ThemeBack    = [System.Drawing.Color]::FromArgb(233, 239, 232)
$script:ThemePanel   = [System.Drawing.Color]::FromArgb(246, 249, 245)
$script:ThemeRed     = [System.Drawing.Color]::FromArgb(201, 58, 50)
$script:ThemeJelly   = [System.Drawing.Color]::FromArgb(196, 232, 248)
$script:ThemeText    = [System.Drawing.Color]::FromArgb(45, 55, 50)

$script:AppAssetDir = Join-Path $PSScriptRoot "assets"
$script:AppImageCache = @{}
$script:AppIconCache = @{}

function Get-AppImage([string]$name) {
    if ($script:AppImageCache.ContainsKey($name)) { return $script:AppImageCache[$name] }
    $img = $null
    try {
        $p = Join-Path $script:AppAssetDir $name
        if (Test-Path -LiteralPath $p) {
            # 用記憶體串流讀，不鎖住圖檔（串流要一直留著，圖才不會壞）
            $bytes = [System.IO.File]::ReadAllBytes($p)
            $ms = New-Object System.IO.MemoryStream(, $bytes)
            $img = [System.Drawing.Image]::FromStream($ms)
        }
    } catch { $img = $null }
    $script:AppImageCache[$name] = $img
    return $img
}

# 水母圖示；$small = $true 時挑適合系統匣的小尺寸
function Get-AppIcon([bool]$small) {
    $key = "$small"
    if ($script:AppIconCache.ContainsKey($key)) { return $script:AppIconCache[$key] }
    $icon = $null
    try {
        $p = Join-Path $script:AppAssetDir "jellyfish.ico"
        if (Test-Path -LiteralPath $p) {
            if ($small) { $icon = New-Object System.Drawing.Icon($p, [System.Windows.Forms.SystemInformation]::SmallIconSize) }
            else { $icon = New-Object System.Drawing.Icon($p) }
        }
    } catch { $icon = $null }
    $script:AppIconCache[$key] = $icon
    return $icon
}

# 水母圖示右上角加一顆紅點（有新版時用：視窗裡的水母、系統匣圖示）
function Get-AppIconWithDot([bool]$small) {
    $key = "dot$small"
    if ($script:AppIconCache.ContainsKey($key)) { return $script:AppIconCache[$key] }
    $icon = $null
    try {
        $base = Get-AppIcon $small
        if ($null -ne $base) {
            $bmp = $base.ToBitmap()
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
            $d = [int][Math]::Max(7, [Math]::Round($bmp.Width * 0.5))
            $x = $bmp.Width - $d
            $white = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::White)
            $red = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 211, 47, 47))
            $g.FillEllipse($white, $x - 1, 0, $d + 1, $d + 1)
            $g.FillEllipse($red, $x + 1, 2, $d - 3, $d - 3)
            $g.Dispose()
            $icon = [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
        }
    } catch { $icon = $null }
    $script:AppIconCache[$key] = $icon
    return $icon
}

# 視窗左上角換成水母、底色換成新跪的淺灰綠
function Set-AppFormStyle($form) {
    try {
        $icon = Get-AppIcon $false
        if ($null -ne $icon) { $form.Icon = $icon }
    } catch {}
    try { $form.BackColor = $script:ThemeBack } catch {}
}

# 放一張角色圖；圖檔不在就回傳 $null（呼叫的人不用另外判斷，Controls.Add 前檢查一下就好）
function New-AppPictureBox([string]$imageName, [int]$x, [int]$y, [int]$w, [int]$h) {
    $pb = New-Object System.Windows.Forms.PictureBox
    $pb.Location = New-Object System.Drawing.Point($x, $y)
    $pb.Size = New-Object System.Drawing.Size($w, $h)
    $pb.SizeMode = [System.Windows.Forms.PictureBoxSizeMode]::Zoom
    $pb.BackColor = [System.Drawing.Color]::Transparent
    $img = Get-AppImage $imageName
    if ($null -ne $img) { $pb.Image = $img } else { $pb.Visible = $false }
    return $pb
}

# 換圖（圖檔不在就維持原樣）
function Set-AppPicture($pictureBox, [string]$imageName) {
    try {
        if ($null -eq $pictureBox) { return }
        $img = Get-AppImage $imageName
        if ($null -ne $img) { $pictureBox.Image = $img; $pictureBox.Visible = $true }
    } catch {}
}

# 用 Windows PowerShell 在背景（不跳黑色視窗）啟動同資料夾的另一支 .ps1
function Start-AppScript([string]$fileName, [string[]]$extraArgs) {
    $path = Join-Path $PSScriptRoot $fileName
    $exe = Join-Path $PSHOME "powershell.exe"
    if (-not (Test-Path -LiteralPath $exe)) { $exe = "powershell.exe" }
    $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", "`"$path`"")
    if ($null -ne $extraArgs) { $argList += $extraArgs }
    Start-Process -FilePath $exe -ArgumentList $argList -WindowStyle Hidden
}

# 右下角跳一個小小的角色提示，幾秒後自己消失（點一下也會關）
function Show-TipForm([string]$imageName, [string]$title, [string]$text, [int]$ms) {
    try {
        if ($ms -le 0) { $ms = 3000 }
        $tip = New-Object System.Windows.Forms.Form
        $tip.FormBorderStyle = "FixedToolWindow"
        $tip.Text = $script:AppName
        $tip.ShowInTaskbar = $false
        $tip.TopMost = $true
        $tip.Size = New-Object System.Drawing.Size(340, 150)
        Set-AppFormStyle $tip
        $tip.StartPosition = "Manual"

        $pb = New-AppPictureBox $imageName 8 8 100 100
        $tip.Controls.Add($pb)

        $lblTitle = New-Object System.Windows.Forms.Label
        $lblTitle.Text = $title
        $lblTitle.Font = New-Object System.Drawing.Font($lblTitle.Font.FontFamily, 11, [System.Drawing.FontStyle]::Bold)
        $lblTitle.ForeColor = $script:ThemeRed
        $lblTitle.Location = New-Object System.Drawing.Point(115, 12)
        $lblTitle.Size = New-Object System.Drawing.Size(205, 26)
        $tip.Controls.Add($lblTitle)

        $lblText = New-Object System.Windows.Forms.Label
        $lblText.Text = $text
        $lblText.ForeColor = $script:ThemeText
        $lblText.Location = New-Object System.Drawing.Point(115, 42)
        $lblText.Size = New-Object System.Drawing.Size(205, 66)
        $tip.Controls.Add($lblText)

        $closeTip = { try { $tip.Close() } catch {} }.GetNewClosure()
        $lblText.Add_Click($closeTip)
        $lblTitle.Add_Click($closeTip)
        $pb.Add_Click($closeTip)

        $tipTimer = New-Object System.Windows.Forms.Timer
        $tipTimer.Interval = $ms
        $tipTimer.Add_Tick({
            try { $tipTimer.Stop(); $tipTimer.Dispose() } catch {}
            try { if (-not $tip.IsDisposed) { $tip.Close() } } catch {}
        }.GetNewClosure())
        # 套用大字／深色之後再算位置，才會剛好貼在右下角
        Complete-AppForm $tip
        $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $tip.Location = New-Object System.Drawing.Point(($wa.Right - $tip.Width - 12), ($wa.Bottom - $tip.Height - 12))
        $tip.Show()
        $tipTimer.Start()
    } catch {}
}

# 「關於真劍鬧鐘」
# 分享給朋友：把 App 下載頁網址複製到剪貼簿（貼到 LINE、訊息就好）
function Copy-SiteUrlToClipboard {
    try {
        [System.Windows.Forms.Clipboard]::SetText("$($script:AppName)：不答對算術題就不讓你關的鬧鐘。下載：$($script:SiteUrl)")
        Show-AppMessage("已複製下載網址，可以貼給朋友了：`n$($script:SiteUrl)", "$($script:AppName) - 分享給朋友") | Out-Null
    } catch {
        Show-AppMessage("沒辦法複製，請自己抄這個網址給朋友：`n$($script:SiteUrl)", "$($script:AppName) - 分享給朋友") | Out-Null
    }
}

function Show-AboutDialog($owner) {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "關於 $($script:AppName)"
    $dlg.Size = New-Object System.Drawing.Size(560, 450)
    $dlg.StartPosition = "CenterScreen"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.TopMost = $true
    Set-AppFormStyle $dlg

    $pb = New-AppPictureBox "xg_about.png" 15 15 180 220
    $dlg.Controls.Add($pb)

    $pbJelly = New-AppPictureBox "jellyfish.png" 15 245 70 70
    $dlg.Controls.Add($pbJelly)

    $lblName = New-Object System.Windows.Forms.Label
    $lblName.Text = "$($script:AppName)  v$($script:AppVersion)"
    $lblName.Font = New-Object System.Drawing.Font($lblName.Font.FontFamily, 15, [System.Drawing.FontStyle]::Bold)
    $lblName.ForeColor = $script:ThemeRed
    $lblName.Location = New-Object System.Drawing.Point(210, 15)
    $lblName.Size = New-Object System.Drawing.Size(320, 34)
    $dlg.Controls.Add($lblName)

    $lblBody = New-Object System.Windows.Forms.Label
    $lblBody.Text = "名字由來：`n" +
        "「真剣（しんけん）」是日文的「認真、玩真的」。`n" +
        "可是台灣人一看，十個有九個會唸成「真賤鬧鐘」——`n" +
        "沒關係，它真的很賤：不答對算術題，就不讓你關。`n`n" +
        "出品：欸唉新跪`n" +
        "一個跟不上 AI 時代、一邊硬撐一邊自嘲的上班族，`n" +
        "頭上趴著紅龍蝦，身邊飄著一隻淺藍水母（他的 AI）。`n`n" +
        "免費分享，請勿轉售。"
    $lblBody.ForeColor = $script:ThemeText
    $lblBody.Location = New-Object System.Drawing.Point(210, 55)
    $lblBody.Size = New-Object System.Drawing.Size(330, 200)
    $dlg.Controls.Add($lblBody)

    $link = New-Object System.Windows.Forms.LinkLabel
    $link.Text = "欸唉新跪的 vocus 沙龍：$($script:SalonUrl)"
    $link.Location = New-Object System.Drawing.Point(95, 265)
    $link.Size = New-Object System.Drawing.Size(440, 40)
    $link.Add_LinkClicked({
        try { Start-Process "https://vocus.cc/salon/ai-new-kneel" } catch {}
    })
    $dlg.Controls.Add($link)

    $linkPrivacy = New-Object System.Windows.Forms.LinkLabel
    $linkPrivacy.Text = "隱私權政策：$($script:PrivacyUrl)"
    $linkPrivacy.Location = New-Object System.Drawing.Point(95, 305)
    $linkPrivacy.Size = New-Object System.Drawing.Size(440, 40)
    $linkPrivacy.Add_LinkClicked({
        try { Start-Process $script:PrivacyUrl } catch {}
    })
    $dlg.Controls.Add($linkPrivacy)

    $btnShare = New-Object System.Windows.Forms.Button
    $btnShare.Text = "分享給朋友（複製下載網址）"
    $btnShare.Location = New-Object System.Drawing.Point(15, 355)
    $btnShare.Size = New-Object System.Drawing.Size(240, 32)
    $btnShare.Add_Click({ Copy-SiteUrlToClipboard })
    $dlg.Controls.Add($btnShare)

    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = "好喔"
    $btnOk.Location = New-Object System.Drawing.Point(430, 355)
    $btnOk.Size = New-Object System.Drawing.Size(100, 32)
    $btnOk.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $dlg.AcceptButton = $btnOk
    $dlg.Controls.Add($btnOk)

    Complete-AppForm $dlg
    if ($null -ne $owner) { $dlg.ShowDialog($owner) | Out-Null } else { $dlg.ShowDialog() | Out-Null }
    $dlg.Dispose()
}

# =====================================================================
# 大字模式、粗體、深色模式（v1.1 起，v1.2 把深色做到真的護眼）
# 每個視窗把控制項都加好之後、Show/ShowDialog 之前呼叫一次 Complete-AppForm。
# 設定存在 app 資料夾的 settings.json（跟排序方式同一個檔），每次開視窗都重讀，
# 所以在設定視窗改了之後，新跳出來的提醒視窗馬上就會用新的設定。
# =====================================================================

# 深色配色（v1.2）：柔和、不刺眼。背景 #26282B、列表 #2C2F33、隔行 #303338、
# 主要字 #DAD6CE（米白，不是純白）、次要字 #AAA69E、選取列 #3E4A57（暗藍灰）、分組標題 #8FB3D9
$script:DarkBack     = [System.Drawing.Color]::FromArgb(0x26, 0x28, 0x2B)
$script:DarkList     = [System.Drawing.Color]::FromArgb(0x2C, 0x2F, 0x33)
$script:DarkInput    = $script:DarkList
$script:DarkAltRow   = [System.Drawing.Color]::FromArgb(0x30, 0x33, 0x38)
$script:DarkHeader   = [System.Drawing.Color]::FromArgb(0x22, 0x24, 0x27)
$script:DarkButton   = [System.Drawing.Color]::FromArgb(0x3A, 0x3D, 0x42)
$script:DarkButtonHover = [System.Drawing.Color]::FromArgb(0x45, 0x49, 0x4F)
$script:DarkButtonDown  = [System.Drawing.Color]::FromArgb(0x32, 0x35, 0x39)
$script:DarkBorder   = [System.Drawing.Color]::FromArgb(0x4A, 0x4D, 0x52)
$script:DarkText     = [System.Drawing.Color]::FromArgb(0xDA, 0xD6, 0xCE)
$script:DarkHint     = [System.Drawing.Color]::FromArgb(0xAA, 0xA6, 0x9E)
$script:DarkRed      = [System.Drawing.Color]::FromArgb(0xE0, 0x8A, 0x80)
$script:DarkGreen    = [System.Drawing.Color]::FromArgb(0x8C, 0xC0, 0x8C)
$script:DarkJelly    = [System.Drawing.Color]::FromArgb(0x30, 0x44, 0x56)
$script:DarkNotes    = [System.Drawing.Color]::FromArgb(0x3A, 0x37, 0x2E)
$script:DarkSelect   = [System.Drawing.Color]::FromArgb(0x3E, 0x4A, 0x57)
$script:DarkGroupBack = $script:DarkBack
$script:DarkGroupText = [System.Drawing.Color]::FromArgb(0x8F, 0xB3, 0xD9)
$script:DarkLink     = $script:DarkGroupText

# 標題列變黑（DWM）、捲軸變深色（uxtheme）：要呼叫 Windows 的函式
if (-not ([System.Management.Automation.PSTypeName]'ShinkenNative').Type) {
    try {
        Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class ShinkenNative {
    [DllImport("dwmapi.dll")]
    public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int value, int size);
    [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)]
    public static extern int SetWindowTheme(IntPtr hwnd, string subAppName, string subIdList);
}
"@
    } catch {}
}

function Get-AppAppearance {
    $a = @{ Scale = 1.0; Dark = $false; Bold = $false; FontSize = "normal"; Theme = "light" }
    try {
        $s = Read-AppSettings (Join-Path $PSScriptRoot "settings.json")
        $a.FontSize = $s.fontSize
        $a.Theme = $s.theme
        $a.Bold = [bool]$s.bold
        $a.Scale = Get-FontScaleFactor $s.fontSize
        $a.Dark = ($s.theme -eq "dark")
    } catch {}
    return $a
}
$script:UiAppearance = Get-AppAppearance

# 狀態文字的顏色（開機自動啟動：已啟用／未啟用…），深色模式下換成柔和一點的
function Get-StatusColor([string]$kind) {
    if ($script:UiAppearance.Dark) {
        if ($kind -eq "ok") { return $script:DarkGreen }
        if ($kind -eq "bad") { return $script:DarkRed }
        return $script:DarkHint
    }
    if ($kind -eq "ok") { return [System.Drawing.Color]::Green }
    if ($kind -eq "bad") { return [System.Drawing.Color]::Red }
    return [System.Drawing.Color]::DimGray
}

function Get-AllControls($root) {
    $list = New-Object System.Collections.ArrayList
    $stack = New-Object System.Collections.Stack
    $stack.Push($root)
    while ($stack.Count -gt 0) {
        $c = $stack.Pop()
        [void]$list.Add($c)
        foreach ($child in $c.Controls) { $stack.Push($child) }
    }
    return ,$list
}

function Test-SameColor($a, $b) { return ($a.ToArgb() -eq $b.ToArgb()) }

# 淺色時的字色 → 深色時的字色
function Get-DarkForeColor($c) {
    if ((Test-SameColor $c ([System.Drawing.Color]::Red)) -or (Test-SameColor $c $script:ThemeRed)) { return $script:DarkRed }
    if ((Test-SameColor $c ([System.Drawing.Color]::Gray)) -or (Test-SameColor $c ([System.Drawing.Color]::DimGray))) { return $script:DarkHint }
    if (Test-SameColor $c ([System.Drawing.Color]::Green)) { return $script:DarkGreen }
    return $script:DarkText
}

# ---------- 字型：統一用微軟正黑體（找不到就用系統預設），可加粗 ----------
$script:AppFontName = $null
function Get-AppFontName {
    if ($null -ne $script:AppFontName) { return $script:AppFontName }
    $script:AppFontName = ""
    try {
        $fc = New-Object System.Drawing.Text.InstalledFontCollection
        foreach ($fam in $fc.Families) {
            if ($fam.Name -eq "Microsoft JhengHei UI") { $script:AppFontName = $fam.Name; break }
        }
        $fc.Dispose()
    } catch {}
    return $script:AppFontName
}

# 每個控制項的字型換成正黑體；要粗體的話加上粗體。大小和其他樣式不動
function Set-AppFonts($form, [bool]$bold) {
    $name = Get-AppFontName
    foreach ($c in (Get-AllControls $form)) {
        try {
            $fo = $c.Font
            $style = $fo.Style
            if ($bold) { $style = $style -bor [System.Drawing.FontStyle]::Bold }
            if ($name -ne "") { $c.Font = New-Object System.Drawing.Font($name, $fo.Size, $style, $fo.Unit) }
            elseif ($bold) { $c.Font = New-Object System.Drawing.Font($fo.FontFamily, $fo.Size, $style, $fo.Unit) }
        } catch {}
    }
}

# ---------- 標題列、捲軸 ----------
function Set-TitleBarTheme($form, [bool]$dark) {
    try {
        if (-not ([System.Management.Automation.PSTypeName]'ShinkenNative').Type) { return }
        $v = 0
        if ($dark) { $v = 1 }
        $h = $form.Handle
        # 20 = DWMWA_USE_IMMERSIVE_DARK_MODE；舊版 Windows 10 是 19
        $r = [ShinkenNative]::DwmSetWindowAttribute($h, 20, [ref]$v, 4)
        if ($r -ne 0) { [void][ShinkenNative]::DwmSetWindowAttribute($h, 19, [ref]$v, 4) }
    } catch {}
}

function Set-ControlDarkScroll($c, [string]$theme) {
    try {
        if (-not ([System.Management.Automation.PSTypeName]'ShinkenNative').Type) { return }
        [void][ShinkenNative]::SetWindowTheme($c.Handle, $theme, $null)
    } catch {}
}

# 深色時：列表、清單、多行輸入框的捲軸、下拉選單的按鈕都換成深色
# （控制項重建之後會失去設定，所以每次建好 handle 都再套一次）
function Enable-DarkScrollbars($c, [string]$theme) {
    Set-ControlDarkScroll $c $theme
    $c.Add_HandleCreated({ param($s, $e) Set-ControlDarkScroll $s $script:DarkThemeFor[$s.GetType().Name] })
}
$script:DarkThemeFor = @{ ListView = "DarkMode_Explorer"; ListBox = "DarkMode_Explorer"; CheckedListBox = "DarkMode_Explorer"; TextBox = "DarkMode_Explorer"; ComboBox = "DarkMode_CFD" }

function Set-DarkTheme($form) {
    foreach ($c in (Get-AllControls $form)) {
        try {
            if ($c -is [System.Windows.Forms.Form]) {
                $c.BackColor = $script:DarkBack
                $c.ForeColor = $script:DarkText
            }
            elseif ($c -is [System.Windows.Forms.LinkLabel]) {
                $c.LinkColor = $script:DarkLink
                $c.ActiveLinkColor = $script:DarkLink
                $c.VisitedLinkColor = $script:DarkLink
                $c.ForeColor = $script:DarkText
            }
            elseif ($c -is [System.Windows.Forms.Label] -or $c -is [System.Windows.Forms.CheckBox] -or $c -is [System.Windows.Forms.RadioButton] -or $c -is [System.Windows.Forms.GroupBox]) {
                $c.ForeColor = Get-DarkForeColor $c.ForeColor
            }
            elseif ($c -is [System.Windows.Forms.Button]) {
                $isJelly = Test-SameColor $c.BackColor $script:ThemeJelly
                $c.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
                $c.FlatAppearance.BorderColor = $script:DarkBorder
                $c.FlatAppearance.MouseOverBackColor = $script:DarkButtonHover
                $c.FlatAppearance.MouseDownBackColor = $script:DarkButtonDown
                if ($isJelly) { $c.BackColor = $script:DarkJelly } else { $c.BackColor = $script:DarkButton }
                $c.ForeColor = $script:DarkText
            }
            elseif ($c -is [System.Windows.Forms.TextBox]) {
                $isNotes = Test-SameColor $c.BackColor ([System.Drawing.Color]::FromArgb(255, 250, 235))
                if ($isNotes) { $c.BackColor = $script:DarkNotes } else { $c.BackColor = $script:DarkInput }
                $c.ForeColor = $script:DarkText
                $c.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
                if ($c.Multiline) { Enable-DarkScrollbars $c "DarkMode_Explorer" }
            }
            elseif ($c -is [System.Windows.Forms.ComboBox]) {
                # 下拉選單：框、展開的清單都深色（清單項目自己畫）
                $c.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
                $c.BackColor = $script:DarkInput
                $c.ForeColor = $script:DarkText
                $c.DrawMode = [System.Windows.Forms.DrawMode]::OwnerDrawFixed
                $c.Add_DrawItem({
                    param($sender, $e)
                    if ($e.Index -lt 0) { return }
                    $inEdit = (($e.State -band [System.Windows.Forms.DrawItemState]::ComboBoxEdit) -ne 0)
                    $hot = ((($e.State -band [System.Windows.Forms.DrawItemState]::Selected) -ne 0) -and -not $inEdit)
                    $back = $script:DarkInput
                    if ($hot) { $back = $script:DarkSelect }
                    $br = New-Object System.Drawing.SolidBrush($back)
                    $e.Graphics.FillRectangle($br, $e.Bounds)
                    $br.Dispose()
                    $r = New-Object System.Drawing.Rectangle(($e.Bounds.X + 3), $e.Bounds.Y, ($e.Bounds.Width - 4), $e.Bounds.Height)
                    $flags = [System.Windows.Forms.TextFormatFlags]"Left, VerticalCenter, SingleLine, EndEllipsis, NoPrefix"
                    [System.Windows.Forms.TextRenderer]::DrawText($e.Graphics, "$($sender.Items[$e.Index])", $e.Font, $r, $script:DarkText, $flags)
                })
                Enable-DarkScrollbars $c "DarkMode_CFD"
            }
            elseif ($c -is [System.Windows.Forms.ListView]) {
                $c.BackColor = $script:DarkList
                $c.ForeColor = $script:DarkText
                $c.GridLines = $false
                $c.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
                Enable-DarkListView $c
                Enable-DarkScrollbars $c "DarkMode_Explorer"
            }
            elseif ($c -is [System.Windows.Forms.ListBox]) {
                # CheckedListBox 也是 ListBox
                $c.BackColor = $script:DarkList
                $c.ForeColor = $script:DarkText
                $c.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
                Enable-DarkScrollbars $c "DarkMode_Explorer"
            }
            elseif ($c -is [System.Windows.Forms.DateTimePicker]) {
                # 日期時間欄位本身 Windows 不讓改底色，只能改下拉月曆
                $c.CalendarMonthBackground = $script:DarkInput
                $c.CalendarForeColor = $script:DarkText
                $c.CalendarTitleBackColor = $script:DarkJelly
                $c.CalendarTitleForeColor = $script:DarkText
                $c.CalendarTrailingForeColor = $script:DarkHint
            }
            elseif ($c -is [System.Windows.Forms.PictureBox]) {
                # 新跪、水母是透明底 PNG：底色跟著視窗，不會出現白框
                $c.BackColor = [System.Drawing.Color]::Transparent
            }
        } catch {}
    }
}

# 深色時列表自己畫（v1.2）：沒有格線、用極淡的隔行底色分列、選取列是暗藍灰、
# 分類標題列文字和前面的色塊都是柔和藍，表頭深色。列高另外加高，字不貼著線。
function Enable-DarkListView($lv) { Enable-ColorListView $lv $true }

# 列表自己畫（淺色、深色都用；v1.6 分類色塊）：
#   ・分類標題列（Name = "__group__"）：整條用該分類的色塊底色（item.BackColor）和字色（item.ForeColor）
#   ・鬧鐘列（Name = "c:RRGGBB"）：底色帶一點分類色調（item.BackColor），第一欄最左邊一條粗色條（RRGGBB）
#   ・其他（沒有分類色的列）照原本的樣子；深色：沒有格線、極淡隔行底色、選取列是暗藍灰、表頭深色
function Enable-ColorListView($lv, [bool]$dark) {
    if ($lv.View -ne [System.Windows.Forms.View]::Details) { return }
    try {
        $prop = $lv.GetType().GetProperty("DoubleBuffered", [System.Reflection.BindingFlags]"NonPublic, Instance")
        if ($null -ne $prop) { $prop.SetValue($lv, $true, $null) }
    } catch {}
    $script:ListDark = $dark
    $lv.OwnerDraw = $true
    $lv.Add_DrawColumnHeader({
        param($sender, $e)
        if (-not $script:ListDark) { $e.DrawDefault = $true; return }
        $bg = New-Object System.Drawing.SolidBrush($script:DarkHeader)
        $e.Graphics.FillRectangle($bg, $e.Bounds)
        $bg.Dispose()
        $pen = New-Object System.Drawing.Pen($script:DarkBorder)
        $e.Graphics.DrawLine($pen, $e.Bounds.Left, ($e.Bounds.Bottom - 1), $e.Bounds.Right, ($e.Bounds.Bottom - 1))
        $pen.Dispose()
        $r = New-Object System.Drawing.Rectangle(($e.Bounds.X + 4), $e.Bounds.Y, ($e.Bounds.Width - 6), $e.Bounds.Height)
        $flags = [System.Windows.Forms.TextFormatFlags]"Left, VerticalCenter, SingleLine, EndEllipsis, NoPrefix"
        [System.Windows.Forms.TextRenderer]::DrawText($e.Graphics, $e.Header.Text, $sender.Font, $r, $script:DarkText, $flags)
    })
    $lv.Add_DrawItem({ param($sender, $e) $e.DrawDefault = $false })
    $lv.Add_DrawSubItem({
        param($sender, $e)
        $item = $e.Item
        $name = "$($item.Name)"
        $isGroup = ($name -eq "__group__")
        $hasStripe = $name.StartsWith("c:")
        if ($script:ListDark) {
            $listBack = $script:DarkList; $altBack = $script:DarkAltRow; $selBack = $script:DarkSelect
            $normalFore = $script:DarkText; $selFore = $script:DarkText
        } else {
            $listBack = [System.Drawing.SystemColors]::Window; $altBack = [System.Drawing.SystemColors]::Window; $selBack = [System.Drawing.SystemColors]::Highlight
            $normalFore = [System.Drawing.SystemColors]::WindowText; $selFore = [System.Drawing.SystemColors]::HighlightText
        }
        $back = $listBack
        $fore = $normalFore
        if ($isGroup) { $back = $item.BackColor; $fore = $item.ForeColor }
        elseif ($item.Selected) { $back = $selBack; $fore = $selFore }
        elseif ($hasStripe) { $back = $item.BackColor }
        elseif (($e.ItemIndex % 2) -eq 1) { $back = $altBack }
        $bg = New-Object System.Drawing.SolidBrush($back)
        $e.Graphics.FillRectangle($bg, $e.Bounds)
        $bg.Dispose()
        $text = $e.SubItem.Text
        if ($isGroup -and $e.ColumnIndex -gt 0) { $text = "" }
        $x = $e.Bounds.X + 4
        $w = $e.Bounds.Width - 6
        if ($hasStripe -and $e.ColumnIndex -eq 0) {
            try {
                $rgb = [Convert]::ToInt32($name.Substring(2), 16)
                $sb = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, (($rgb -shr 16) -band 255), (($rgb -shr 8) -band 255), ($rgb -band 255)))
                $e.Graphics.FillRectangle($sb, $e.Bounds.X, $e.Bounds.Y, 6, $e.Bounds.Height)
                $sb.Dispose()
            } catch {}
            $x = $e.Bounds.X + 10
            $w = $e.Bounds.Width - 12
        }
        $r = New-Object System.Drawing.Rectangle($x, $e.Bounds.Y, $w, $e.Bounds.Height)
        $flags = [System.Windows.Forms.TextFormatFlags]"Left, VerticalCenter, SingleLine, EndEllipsis, NoPrefix"
        [System.Windows.Forms.TextRenderer]::DrawText($e.Graphics, $text, $item.Font, $r, $fore, $flags)
    })
}

# 深色時的尺寸：列表每一列比字高多留一點上下間距、下拉清單項目高度跟著字走。字體放大之後才能算。
function Set-DarkMetrics($form) {
    foreach ($c in (Get-AllControls $form)) {
        try {
            if ($c -is [System.Windows.Forms.ListView] -and $c.View -eq [System.Windows.Forms.View]::Details) {
                $h = [int]([Math]::Ceiling($c.Font.Height * 1.0) + 10)
                $il = New-Object System.Windows.Forms.ImageList
                $il.ImageSize = New-Object System.Drawing.Size(1, $h)
                $c.SmallImageList = $il
            }
            elseif ($c -is [System.Windows.Forms.ComboBox]) {
                $c.ItemHeight = [int]($c.Font.Height + 4)
            }
        } catch {}
    }
}

# 放大：位置、大小一起乘上 $layout，字體乘上 $fontFactor（粗體字比較寬，版面多放大一點才不會切字）
function Set-AppScale($form, [double]$layout, [double]$fontFactor) {
    if ($layout -le 1.0 -and $fontFactor -le 1.0) { return }
    $all = Get-AllControls $form
    $fonts = @()
    foreach ($c in $all) { $fonts += , @($c, $c.Font) }
    $keepLocation = ($form.StartPosition -eq [System.Windows.Forms.FormStartPosition]::Manual)
    $loc = $form.Location
    $minSize = $form.MinimumSize
    if ($layout -gt 1.0) {
        $form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::None
        $form.Scale((New-Object System.Drawing.SizeF([single]$layout, [single]$layout)))
        if ($keepLocation) { $form.Location = $loc }
        if ($minSize.Width -gt 0 -or $minSize.Height -gt 0) {
            $form.MinimumSize = New-Object System.Drawing.Size([int]($minSize.Width * $layout), [int]($minSize.Height * $layout))
        }
    }
    if ($fontFactor -gt 1.0) {
        foreach ($pair in $fonts) {
            $c = $pair[0]; $fo = $pair[1]
            try { $c.Font = New-Object System.Drawing.Font($fo.FontFamily, [single]($fo.Size * $fontFactor), $fo.Style, $fo.Unit) } catch {}
        }
    }
    if ($layout -gt 1.0) {
        foreach ($c in $all) {
            try {
                if ($c -is [System.Windows.Forms.ListView]) {
                    foreach ($col in $c.Columns) { $col.Width = [int]($col.Width * $layout) }
                }
                elseif ($c -is [System.Windows.Forms.CheckedListBox] -and $c.MultiColumn) {
                    $c.ColumnWidth = [int]($c.ColumnWidth * $layout)
                }
            } catch {}
        }
    }
}

# 放大後比螢幕還大（小筆電）→ 縮到螢幕裡；固定大小的對話框加捲軸，內容不會被切掉
function Set-FormFitScreen($form) {
    $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
    $w = $form.Width
    $h = $form.Height
    if ($w -gt $wa.Width -or $h -gt $wa.Height) {
        $nw = [Math]::Min($w, $wa.Width)
        $nh = [Math]::Min($h, $wa.Height)
        $ms = $form.MinimumSize
        if ($ms.Width -gt $nw -or $ms.Height -gt $nh) {
            $form.MinimumSize = New-Object System.Drawing.Size([Math]::Min($ms.Width, $nw), [Math]::Min($ms.Height, $nh))
        }
        if ($form.FormBorderStyle -ne [System.Windows.Forms.FormBorderStyle]::Sizable) { $form.AutoScroll = $true }
        $form.Size = New-Object System.Drawing.Size($nw, $nh)
    }
    if ($form.StartPosition -eq [System.Windows.Forms.FormStartPosition]::Manual) {
        $x = [Math]::Max($wa.Left, [Math]::Min($form.Left, $wa.Right - $form.Width))
        $y = [Math]::Max($wa.Top, [Math]::Min($form.Top, $wa.Bottom - $form.Height))
        $form.Location = New-Object System.Drawing.Point($x, $y)
    }
}

# 每個視窗顯示前呼叫：正黑體（＋粗體）→ 深色 → 放大 → 深色的列高 → 標題列 → 塞進螢幕
function Complete-AppForm($form) {
    try {
        $ap = Get-AppAppearance
        $script:UiAppearance = $ap
        Set-AppFonts $form $ap.Bold
        if ($ap.Dark) { Set-DarkTheme $form }
        else {
            # 淺色也自己畫列表：分類標題色塊、鬧鐘列的色條和底色（深色在 Set-DarkTheme 裡已經處理）
            foreach ($c in (Get-AllControls $form)) { if ($c -is [System.Windows.Forms.ListView]) { Enable-ColorListView $c $false } }
        }
        $layout = $ap.Scale
        if ($ap.Bold) { $layout = $layout * 1.08 }
        Set-AppScale $form $layout $ap.Scale
        if ($ap.Dark) { Set-DarkMetrics $form }
        Set-TitleBarTheme $form $ap.Dark
        # 視窗真正顯示出來時再設一次，標題列才一定會變黑
        $form.Add_Shown({ param($s, $e) Set-TitleBarTheme $s $script:UiAppearance.Dark })
        Set-FormFitScreen $form
    } catch {}
}

# ---------- 自己畫的訊息框（取代系統的 MessageBox，才能跟著深色／大字／粗體） ----------
# 用法跟 [MessageBox]::Show 一樣：Show-AppMessage("內容", "標題", [MessageBoxButtons]::YesNo)
# 淺色、標準字、不粗的時候直接用系統原本的訊息框（行為完全不變）。回傳 DialogResult。
function Show-AppMessage {
    $a = @($args)
    if ($a.Count -eq 1 -and $a[0] -is [array]) { $a = @($a[0]) }
    $text = ""; $title = $script:AppName; $buttons = [System.Windows.Forms.MessageBoxButtons]::OK
    if ($a.Count -ge 1) { $text = "$($a[0])" }
    if ($a.Count -ge 2) { $title = "$($a[1])" }
    if ($a.Count -ge 3) { $buttons = $a[2] }

    $ap = Get-AppAppearance
    if (-not $ap.Dark -and $ap.Scale -le 1.0 -and -not $ap.Bold) {
        return [System.Windows.Forms.MessageBox]::Show($text, $title, $buttons)
    }

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = $title
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.ShowInTaskbar = $false
    $dlg.TopMost = $true
    $dlg.StartPosition = "CenterScreen"
    $dlg.AutoSize = $true
    $dlg.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $dlg.Padding = New-Object System.Windows.Forms.Padding(18, 16, 18, 12)
    Set-AppFormStyle $dlg

    # 2026-10-05 先生回報：大字時訊息框太窄、字被切掉。原因：Form.AutoSize + 子控制項 Dock=Top/Bottom，
    # 寬度在放大字之前就定了、不會跟著長。改成 TableLayoutPanel（不用 Dock）：先量文字和按鈕，視窗再照著長。
    $table = New-Object System.Windows.Forms.TableLayoutPanel
    $table.AutoSize = $true
    $table.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $table.ColumnCount = 1
    $table.RowCount = 2
    $table.Location = New-Object System.Drawing.Point(0, 0)
    [void]$table.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
    [void]$table.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
    [void]$table.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))

    $panel = New-Object System.Windows.Forms.FlowLayoutPanel
    $panel.FlowDirection = "RightToLeft"
    $panel.AutoSize = $true
    $panel.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $panel.Anchor = [System.Windows.Forms.AnchorStyles]::Right
    $panel.Padding = New-Object System.Windows.Forms.Padding(0, 12, 0, 0)

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $text
    $lbl.AutoSize = $true
    $lbl.MaximumSize = New-Object System.Drawing.Size([int](430 * [Math]::Max(1.0, $ap.Scale)), 0)

    $isYesNo = ($buttons -eq [System.Windows.Forms.MessageBoxButtons]::YesNo -or $buttons -eq [System.Windows.Forms.MessageBoxButtons]::YesNoCancel)
    $defs = @()
    if ($isYesNo) {
        $defs += , @("否", [System.Windows.Forms.DialogResult]::No)
        $defs += , @("是", [System.Windows.Forms.DialogResult]::Yes)
    } else {
        $defs += , @("好", [System.Windows.Forms.DialogResult]::OK)
    }
    $first = $null
    foreach ($d in $defs) {
        $b = New-Object System.Windows.Forms.Button
        $b.Text = $d[0]
        $b.DialogResult = $d[1]
        $b.AutoSize = $true
        $b.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
        $b.MinimumSize = New-Object System.Drawing.Size([int](92 * [Math]::Max(1.0, $ap.Scale)), [int](32 * [Math]::Max(1.0, $ap.Scale)))
        $b.Margin = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)
        $panel.Controls.Add($b)
        if ($d[1] -eq [System.Windows.Forms.DialogResult]::Yes -or $d[1] -eq [System.Windows.Forms.DialogResult]::OK) { $dlg.AcceptButton = $b }
    }
    $dlg.CancelButton = $panel.Controls[0]
    $table.Controls.Add($lbl, 0, 0)
    $table.Controls.Add($panel, 0, 1)
    $dlg.Controls.Add($table)

    # 訊息框自己排版（AutoSize），所以只套字型、顏色、字級，不用 Scale()
    Set-AppFonts $dlg $ap.Bold
    if ($ap.Dark) { Set-DarkTheme $dlg }
    if ($ap.Scale -gt 1.0) {
        foreach ($c in (Get-AllControls $dlg)) {
            try { $fo = $c.Font; $c.Font = New-Object System.Drawing.Font($fo.FontFamily, [single]($fo.Size * $ap.Scale), $fo.Style, $fo.Unit) } catch {}
        }
    }
    Set-TitleBarTheme $dlg $ap.Dark
    $dlg.Add_Shown({ param($s, $e) Set-TitleBarTheme $s $script:UiAppearance.Dark })
    $r = $dlg.ShowDialog()
    $dlg.Dispose()
    return $r
}

# 自己畫的「請輸入文字」小視窗（取代系統的 InputBox，才能跟著大字／深色）；按取消回傳 $null
function Show-TextInputDialog($owner, [string]$title, [string]$prompt, [string]$default) {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = $title
    $dlg.Size = New-Object System.Drawing.Size(400, 200)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $prompt
    $lbl.Location = New-Object System.Drawing.Point(15, 12)
    $lbl.Size = New-Object System.Drawing.Size(355, 50)
    $dlg.Controls.Add($lbl)

    $txt = New-Object System.Windows.Forms.TextBox
    $txt.Location = New-Object System.Drawing.Point(15, 68)
    $txt.Size = New-Object System.Drawing.Size(355, 24)
    $txt.Text = $default
    $dlg.Controls.Add($txt)

    $ok = New-Object System.Windows.Forms.Button
    $ok.Text = "確定"
    $ok.Location = New-Object System.Drawing.Point(160, 108)
    $ok.Size = New-Object System.Drawing.Size(100, 32)
    $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $dlg.Controls.Add($ok)
    $dlg.AcceptButton = $ok

    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = "取消"
    $cancel.Location = New-Object System.Drawing.Point(270, 108)
    $cancel.Size = New-Object System.Drawing.Size(100, 32)
    $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($cancel)
    $dlg.CancelButton = $cancel

    Complete-AppForm $dlg
    $txt.SelectAll()
    if ($null -ne $owner) { $r = $dlg.ShowDialog($owner) } else { $r = $dlg.ShowDialog() }
    $value = $txt.Text
    $dlg.Dispose()
    if ($r -eq [System.Windows.Forms.DialogResult]::OK) { return $value }
    return $null
}

# ---------- 放鈴聲（2026-10-05 電腦版補齊：內建三種、自訂、每個鬧鐘的音量與漸強） ----------
# 用 Windows 內建的 winmm（MCI）播 mp3/wav：不用另外裝東西，也不會載入 WPF。
# ⚠ 1.8.4 用的是 WPF 的 MediaPlayer：先生 10/5 回報「一按試聽，整個視窗變回標準字型」——WPF 一載入就會動到整個程式的
#    畫面縮放設定，大字被打回標準。所以這裡刻意不碰 WPF（PresentationCore）。
# 循環、漸強、讀不到檔的保底都由一個 0.25 秒的計時器處理。讀不到或播不出來 → 改回 Windows 提示音，每 3 秒一聲（1.8.3 以前的聲音），不會沒聲音。
$script:MciReady = $null
function Test-MciPlayback {
    if ($null -eq $script:MciReady) {
        try {
            if (-not ([System.Management.Automation.PSTypeName]'ShinkenMci').Type) {
                Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class ShinkenMci {
    [DllImport("winmm.dll", CharSet = CharSet.Unicode)]
    private static extern int mciSendStringW(string command, StringBuilder ret, int retLength, IntPtr callback);
    // 成功回傳 MCI 的回覆文字；失敗回傳 "ERR" + 錯誤碼
    public static string Send(string command) {
        StringBuilder sb = new StringBuilder(256);
        int r = mciSendStringW(command, sb, 256, IntPtr.Zero);
        return r == 0 ? sb.ToString() : "ERR" + r;
    }
}
"@
            }
            $script:MciReady = $true
        } catch { $script:MciReady = $false }
    }
    return $script:MciReady
}
$script:MciCounter = 0
function Send-Mci([string]$cmd) { try { return [ShinkenMci]::Send($cmd) } catch { return "ERR" } }

$script:RingtoneDir = Join-Path $PSScriptRoot "ringtones"
$script:RingtoneListPath = Join-Path $PSScriptRoot "ringtones.json"
$script:RingSettingsPath = Join-Path $PSScriptRoot "ring_settings.json"

function Get-PcCustomTones { return (Read-CustomTones $script:RingtoneListPath) }
function Test-PcCustomToneExists([string]$id) {
    foreach ($t in @(Get-PcCustomTones)) { if ($t.id -eq $id -and (Test-Path -LiteralPath (Join-Path $script:RingtoneDir $t.file))) { return $true } }
    return $false
}
function Get-PcCustomToneName([string]$id) {
    foreach ($t in @(Get-PcCustomTones)) { if ($t.id -eq $id) { return $t.name } }
    return $null
}

# 鈴聲代號 → 音檔路徑；system（Windows 提示音）回傳 $null
function Get-ToneFilePath([string]$tone) {
    if ($script:ToneBuiltins -contains $tone) { return (Join-Path (Join-Path $PSScriptRoot "assets") "tone_$tone.mp3") }
    if (Test-CustomTone $tone) {
        $id = Get-CustomToneId $tone
        foreach ($t in @(Get-PcCustomTones)) { if ($t.id -eq $id) { return (Join-Path $script:RingtoneDir $t.file) } }
    }
    return $null
}

# 這個鬧鐘在這台電腦上怎麼響：@{ Tone; Volume(%); Crescendo }
function Get-PcRingPlan($a) {
    $rs = Read-RingSettings $script:RingSettingsPath
    $tone = Resolve-PcTone "$($a.ringtone)" $rs.tone { param($id) Test-PcCustomToneExists $id }
    return @{ Tone = $tone; Volume = (Get-AlarmVolume $a); Crescendo = (Get-AlarmCrescendo $a ([bool]$rs.crescendo)) }
}

# 開始放（會一直循環到 Stop-TonePlayback）。回傳控制用的 hashtable；Player 是 MCI 的別名
function Start-TonePlayback([string]$tone, [int]$volume, [bool]$crescendo) {
    $h = @{ Player = $null; Timer = $null; Fallback = $false; LastBeep = [DateTime]::MinValue; Started = Get-Date; SegmentStart = Get-Date; Volume = $volume; Crescendo = $crescendo; Paused = $false }
    $path = Get-ToneFilePath $tone
    if ($null -ne $path -and (Test-Path -LiteralPath $path) -and (Test-MciPlayback)) {
        $script:MciCounter++
        $alias = "shinken$PID" + "_" + $script:MciCounter
        $r = Send-Mci ('open "' + $path + '" type mpegvideo alias ' + $alias)
        if (-not $r.StartsWith("ERR")) {
            [void](Send-Mci "set $alias time format milliseconds")
            $len = Send-Mci "status $alias length"
            $ms = 0
            if ([int]::TryParse($len, [ref]$ms) -and $ms -gt 0) {
                [void](Send-Mci ("setaudio $alias volume to " + [int](1000 * (Get-CrescendoVolume $volume 0 $crescendo))))
                if (-not (Send-Mci "play $alias").StartsWith("ERR")) { $h.Player = $alias }
            }
            if ($null -eq $h.Player) { [void](Send-Mci "close $alias") }
        }
    }
    if ($null -eq $h.Player) { $h.Fallback = $true }
    $t = New-Object System.Windows.Forms.Timer
    $t.Interval = 250
    $t.Tag = $h
    $t.Add_Tick({
        param($s, $e)
        $x = $s.Tag
        try {
            if ($x.Paused) { return }
            $now = Get-Date
            if (-not $x.Fallback) {
                $al = $x.Player
                $mode = Send-Mci "status $al mode"
                if ($mode.StartsWith("ERR")) { $x.Fallback = $true; [void](Send-Mci "close $al") }
                else {
                    # 放完一遍 → 從頭再放（循環）
                    if ($mode -eq "stopped") { [void](Send-Mci "seek $al to start"); [void](Send-Mci "play $al") }
                    [void](Send-Mci ("setaudio $al volume to " + [int](1000 * (Get-CrescendoVolume $x.Volume (($now - $x.SegmentStart).TotalSeconds) $x.Crescendo))))
                }
            }
            if ($x.Fallback -and ($now - $x.LastBeep).TotalSeconds -ge 3) { [System.Media.SystemSounds]::Exclamation.Play(); $x.LastBeep = $now }
        } catch {}
    })
    $t.Start()
    $h.Timer = $t
    return $h
}

# 停聲中（響鈴規則的「停聲」）先暫停；再響時從頭、漸強重新開始
function Suspend-TonePlayback($h) {
    if ($null -eq $h -or $h.Paused) { return }
    $h.Paused = $true
    if ($null -ne $h.Player) { [void](Send-Mci "pause $($h.Player)") }
}
function Resume-TonePlayback($h) {
    if ($null -eq $h -or -not $h.Paused) { return }
    $h.Paused = $false
    $h.SegmentStart = Get-Date
    if ($null -ne $h.Player -and -not $h.Fallback) { [void](Send-Mci "seek $($h.Player) to start"); [void](Send-Mci "play $($h.Player)") }
}
function Stop-TonePlayback($h) {
    if ($null -eq $h) { return }
    try { if ($null -ne $h.Timer) { $h.Timer.Stop(); $h.Timer.Dispose() } } catch {}
    if ($null -ne $h.Player) { [void](Send-Mci "stop $($h.Player)"); [void](Send-Mci "close $($h.Player)") }
    $h.Player = $null; $h.Timer = $null
}

# 試聽（編輯視窗、設定視窗共用）：放 5 秒自己停，同時間只有一個在放。全部用 script 層的狀態和函式，
# 計時器晚到、視窗已經關掉也不會出錯（1.8.4 曾因為呼叫視窗裡的函式而當掉）
$script:PreviewState = $null
function Start-PreviewPlayback([string]$tone, [int]$volume, [bool]$crescendo, $button = $null) {
    Stop-PreviewPlayback
    $pb = Start-TonePlayback $tone $volume $crescendo
    $timer = New-Object System.Windows.Forms.Timer
    $timer.Interval = 5000
    $st = @{ Playback = $pb; Timer = $timer; Button = $button }
    $timer.Tag = $st
    $timer.Add_Tick({ param($s, $e) if ($script:PreviewState -eq $s.Tag) { Stop-PreviewPlayback } else { try { $s.Stop(); $s.Dispose() } catch {} } })
    $script:PreviewState = $st
    $timer.Start()
}
function Stop-PreviewPlayback {
    $st = $script:PreviewState
    $script:PreviewState = $null
    if ($null -eq $st) { return }
    try { $st.Timer.Stop(); $st.Timer.Dispose() } catch {}
    Stop-TonePlayback $st.Playback
    try { if ($null -ne $st.Button -and -not $st.Button.IsDisposed) { $st.Button.Text = "試聽" } } catch {}
}

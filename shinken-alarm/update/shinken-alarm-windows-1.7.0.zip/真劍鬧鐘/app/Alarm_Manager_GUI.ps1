﻿# 真劍鬧鐘：設定視窗（鬧鐘列表）
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
[System.Windows.Forms.Application]::EnableVisualStyles()

. (Join-Path $PSScriptRoot "AlarmCore.ps1")
. (Join-Path $PSScriptRoot "AlarmSync.ps1")
. (Join-Path $PSScriptRoot "AlarmUpdate.ps1")
. (Join-Path $PSScriptRoot "AlarmUi.ps1")

$jsonPath = Join-Path $PSScriptRoot "alarms.json"
# 排序方式、自己新增的分類名稱（只有設定視窗會寫）
$settingsPath = Join-Path $PSScriptRoot "settings.json"

# 第一次使用（沒有 alarms.json）→ 建一個範例鬧鐘
try { Initialize-AlarmFile $jsonPath (Get-Date) | Out-Null } catch {}

function Load-Alarms {
    $data = Read-AlarmFile $jsonPath
    if ($data.Count -eq 0) { return @() }
    $data = Repair-DuplicateIds $data
    return $data
}

function Repair-DuplicateIds($alarms) {
    if ($alarms.Count -eq 0) { return $alarms }
    $seen = @{}
    $maxId = 0
    foreach ($a in $alarms) {
        if ($a.id -gt $maxId) { $maxId = $a.id }
    }
    $changed = $false
    foreach ($a in $alarms) {
        if ($seen.ContainsKey($a.id)) {
            $maxId++
            $a.id = $maxId
            $changed = $true
        } else {
            $seen[$a.id] = $true
        }
    }
    if ($changed) {
        Show-AppMessage("偵測到有兩個鬧鐘的內部編號重複（這會導致它們互相影響、其中一個可能不再提醒），已自動改成不重複的編號並存檔。", "$($script:AppName) - 自動修正") | Out-Null
        Save-Alarms $alarms
    }
    return $alarms
}

function Save-Alarms($alarms) {
    Write-AlarmFile $jsonPath $alarms
}

# Get-AlarmBaseType、Get-AlarmDescription 搬到 AlarmCore.ps1（每年固定日期多選的顯示也在那裡）

function Show-AlarmDialog {
    param($existing)

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 鬧鐘設定"
    $dlg.Size = New-Object System.Drawing.Size(380, 680)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $lblType = New-Object System.Windows.Forms.Label
    $lblType.Text = "類型："
    $lblType.Location = New-Object System.Drawing.Point(20, 20)
    $lblType.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblType)

    $cmbType = New-Object System.Windows.Forms.ComboBox
    $cmbType.Location = New-Object System.Drawing.Point(110, 18)
    $cmbType.Size = New-Object System.Drawing.Size(220, 24)
    $cmbType.DropDownStyle = "DropDownList"
    $cmbType.Items.AddRange(@("每月固定日期", "每天", "每週固定星期幾", "單次", "定期倒數提醒", "每年固定日期"))
    $dlg.Controls.Add($cmbType)

    $lblLabel = New-Object System.Windows.Forms.Label
    $lblLabel.Text = "提醒內容："
    $lblLabel.Location = New-Object System.Drawing.Point(20, 60)
    $lblLabel.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblLabel)

    $txtLabel = New-Object System.Windows.Forms.TextBox
    $txtLabel.Location = New-Object System.Drawing.Point(110, 58)
    $txtLabel.Size = New-Object System.Drawing.Size(220, 24)
    $dlg.Controls.Add($txtLabel)

    $lblTime = New-Object System.Windows.Forms.Label
    $lblTime.Text = "提醒時間："
    $lblTime.Location = New-Object System.Drawing.Point(20, 100)
    $lblTime.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblTime)

    $dtpTime = New-Object System.Windows.Forms.DateTimePicker
    $dtpTime.Location = New-Object System.Drawing.Point(110, 98)
    $dtpTime.Size = New-Object System.Drawing.Size(120, 24)
    $dtpTime.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
    $dtpTime.CustomFormat = "HH:mm"
    $dtpTime.ShowUpDown = $true
    $dlg.Controls.Add($dtpTime)

    $lblDays = New-Object System.Windows.Forms.Label
    $lblDays.Text = "哪幾號："
    $lblDays.Location = New-Object System.Drawing.Point(20, 140)
    $lblDays.Size = New-Object System.Drawing.Size(80, 24)

    $txtDays = New-Object System.Windows.Forms.TextBox
    $txtDays.Location = New-Object System.Drawing.Point(110, 138)
    $txtDays.Size = New-Object System.Drawing.Size(220, 24)

    $lblDaysHint = New-Object System.Windows.Forms.Label
    $lblDaysHint.Text = "用逗號分隔，例如 1,16"
    $lblDaysHint.Location = New-Object System.Drawing.Point(110, 164)
    $lblDaysHint.Size = New-Object System.Drawing.Size(220, 20)
    $lblDaysHint.ForeColor = [System.Drawing.Color]::Gray
    $lblDaysHint.Font = New-Object System.Drawing.Font($lblDaysHint.Font.FontFamily, 8)

    $dlg.Controls.Add($lblDays)
    $dlg.Controls.Add($txtDays)
    $dlg.Controls.Add($lblDaysHint)

    $lblWeek = New-Object System.Windows.Forms.Label
    $lblWeek.Text = "星期幾："
    $lblWeek.Location = New-Object System.Drawing.Point(20, 140)
    $lblWeek.Size = New-Object System.Drawing.Size(80, 24)

    $clbWeek = New-Object System.Windows.Forms.CheckedListBox
    $clbWeek.Location = New-Object System.Drawing.Point(110, 138)
    $clbWeek.Size = New-Object System.Drawing.Size(160, 130)
    $clbWeek.Items.AddRange(@("星期一","星期二","星期三","星期四","星期五","星期六","星期日"))
    $clbWeek.CheckOnClick = $true

    $dlg.Controls.Add($lblWeek)
    $dlg.Controls.Add($clbWeek)

    $lblDate = New-Object System.Windows.Forms.Label
    $lblDate.Text = "日期："
    $lblDate.Location = New-Object System.Drawing.Point(20, 140)
    $lblDate.Size = New-Object System.Drawing.Size(80, 24)

    $dtpDate = New-Object System.Windows.Forms.DateTimePicker
    $dtpDate.Location = New-Object System.Drawing.Point(110, 138)
    $dtpDate.Size = New-Object System.Drawing.Size(160, 24)
    $dtpDate.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
    $dtpDate.CustomFormat = "yyyy-MM-dd"

    $dlg.Controls.Add($lblDate)
    $dlg.Controls.Add($dtpDate)

    $lblInterval = New-Object System.Windows.Forms.Label
    $lblInterval.Text = "間隔天數："
    $lblInterval.Location = New-Object System.Drawing.Point(20, 140)
    $lblInterval.Size = New-Object System.Drawing.Size(80, 24)

    $txtInterval = New-Object System.Windows.Forms.TextBox
    $txtInterval.Location = New-Object System.Drawing.Point(110, 138)
    $txtInterval.Size = New-Object System.Drawing.Size(80, 24)

    $lblIntervalHint = New-Object System.Windows.Forms.Label
    $lblIntervalHint.Text = "例如填 80，代表每 80 天提醒一次；`n第一次會從今天算起 80 天後開始，`n之後每次你按「已完成」，就會從那天重新倒數 80 天。"
    $lblIntervalHint.Location = New-Object System.Drawing.Point(110, 164)
    $lblIntervalHint.Size = New-Object System.Drawing.Size(230, 60)
    $lblIntervalHint.ForeColor = [System.Drawing.Color]::Gray
    $lblIntervalHint.Font = New-Object System.Drawing.Font($lblIntervalHint.Font.FontFamily, 8)

    $dlg.Controls.Add($lblInterval)
    $dlg.Controls.Add($txtInterval)
    $dlg.Controls.Add($lblIntervalHint)

    # 每年固定日期：月份可以多選 × 日期可以多個（例如 3、9 月的 1、15 號）
    $lblYearMonths = New-Object System.Windows.Forms.Label
    $lblYearMonths.Text = "哪幾月："
    $lblYearMonths.Location = New-Object System.Drawing.Point(20, 140)
    $lblYearMonths.Size = New-Object System.Drawing.Size(80, 24)

    $clbYearMonths = New-Object System.Windows.Forms.CheckedListBox
    $clbYearMonths.Location = New-Object System.Drawing.Point(110, 138)
    $clbYearMonths.Size = New-Object System.Drawing.Size(240, 56)
    $clbYearMonths.MultiColumn = $true
    $clbYearMonths.ColumnWidth = 58
    $clbYearMonths.CheckOnClick = $true
    $clbYearMonths.Items.AddRange(@("1 月","2 月","3 月","4 月","5 月","6 月","7 月","8 月","9 月","10 月","11 月","12 月"))

    $lblYearDays = New-Object System.Windows.Forms.Label
    $lblYearDays.Text = "哪幾號："
    $lblYearDays.Location = New-Object System.Drawing.Point(20, 200)
    $lblYearDays.Size = New-Object System.Drawing.Size(80, 24)

    $txtYearDays = New-Object System.Windows.Forms.TextBox
    $txtYearDays.Location = New-Object System.Drawing.Point(110, 198)
    $txtYearDays.Size = New-Object System.Drawing.Size(80, 24)

    $lblYearHint = New-Object System.Windows.Forms.Label
    $lblYearHint.Text = "逗號分隔，例如 1,15`n沒有那天(2/30)→月底響"
    $lblYearHint.Location = New-Object System.Drawing.Point(195, 196)
    $lblYearHint.Size = New-Object System.Drawing.Size(160, 30)
    $lblYearHint.ForeColor = [System.Drawing.Color]::Gray
    $lblYearHint.Font = New-Object System.Drawing.Font($lblYearHint.Font.FontFamily, 8)

    $dlg.Controls.Add($lblYearMonths)
    $dlg.Controls.Add($clbYearMonths)
    $dlg.Controls.Add($lblYearDays)
    $dlg.Controls.Add($txtYearDays)
    $dlg.Controls.Add($lblYearHint)

    $lblNotes = New-Object System.Windows.Forms.Label
    $lblNotes.Text = "備註（提醒跳出來時會一起顯示，可以寫步驟）："
    $lblNotes.Location = New-Object System.Drawing.Point(20, 228)
    $lblNotes.Size = New-Object System.Drawing.Size(330, 20)
    $dlg.Controls.Add($lblNotes)

    $txtNotes = New-Object System.Windows.Forms.TextBox
    $txtNotes.Location = New-Object System.Drawing.Point(20, 250)
    $txtNotes.Size = New-Object System.Drawing.Size(330, 65)
    $txtNotes.Multiline = $true
    $txtNotes.ScrollBars = "Vertical"
    $dlg.Controls.Add($txtNotes)

    function Update-PanelVisibility {
        $idx = $cmbType.SelectedIndex
        $lblDays.Visible = ($idx -eq 0)
        $txtDays.Visible = ($idx -eq 0)
        $lblDaysHint.Visible = ($idx -eq 0)

        $lblWeek.Visible = ($idx -eq 2)
        $clbWeek.Visible = ($idx -eq 2)

        $lblDate.Visible = ($idx -eq 3)
        $dtpDate.Visible = ($idx -eq 3)

        $lblYearMonths.Visible = ($idx -eq 5)
        $clbYearMonths.Visible = ($idx -eq 5)
        $lblYearDays.Visible = ($idx -eq 5)
        $txtYearDays.Visible = ($idx -eq 5)
        $lblYearHint.Visible = ($idx -eq 5)

        $lblInterval.Visible = ($idx -eq 4)
        $txtInterval.Visible = ($idx -eq 4)
        $lblIntervalHint.Visible = ($idx -eq 4)
    }

    $cmbType.Add_SelectedIndexChanged({ Update-PanelVisibility })

    $chkTimeLimited = New-Object System.Windows.Forms.CheckBox
    $chkTimeLimited.Text = "限時提醒（超過15分鐘沒看到就不補提醒）"
    $chkTimeLimited.Location = New-Object System.Drawing.Point(20, 325)
    $chkTimeLimited.Size = New-Object System.Drawing.Size(330, 24)
    $dlg.Controls.Add($chkTimeLimited)

    $chkPlaySound = New-Object System.Windows.Forms.CheckBox
    $chkPlaySound.Text = "提醒時要出聲音"
    $chkPlaySound.Location = New-Object System.Drawing.Point(20, 355)
    $chkPlaySound.Size = New-Object System.Drawing.Size(330, 24)
    $chkPlaySound.Checked = $true
    $dlg.Controls.Add($chkPlaySound)

    $chkTimeLimited.Add_CheckedChanged({
        if ($chkTimeLimited.Checked) { $chkPlaySound.Checked = $false }
    })

    $chkStrict = New-Object System.Windows.Forms.CheckBox
    $chkStrict.Text = "認真型：要確實完成（解題+二次確認）才會消失"
    # 不勾＝隨意型
    $chkStrict.Location = New-Object System.Drawing.Point(20, 385)
    $chkStrict.Size = New-Object System.Drawing.Size(330, 24)
    $chkStrict.Checked = $true
    $dlg.Controls.Add($chkStrict)

    $lblStrictHint = New-Object System.Windows.Forms.Label
    $lblStrictHint.Text = "不勾＝隨意型：跳出後按一下「知道了」就會關閉，不用解題"
    $lblStrictHint.Location = New-Object System.Drawing.Point(20, 409)
    $lblStrictHint.Size = New-Object System.Drawing.Size(330, 20)
    $lblStrictHint.ForeColor = [System.Drawing.Color]::Gray
    $lblStrictHint.Font = New-Object System.Drawing.Font($lblStrictHint.Font.FontFamily, 8)
    $dlg.Controls.Add($lblStrictHint)

    # 關鬧鐘的難度（工單 8.5；認真型才有）。手機專屬的「掃 QR」在電腦上會改答 3 題算術
    $lblDiff = New-Object System.Windows.Forms.Label
    $lblDiff.Text = "關閉難度："
    $lblDiff.Location = New-Object System.Drawing.Point(20, 440)
    $lblDiff.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblDiff)

    $cmbDiff = New-Object System.Windows.Forms.ComboBox
    $cmbDiff.Location = New-Object System.Drawing.Point(110, 437)
    $cmbDiff.Size = New-Object System.Drawing.Size(240, 24)
    $cmbDiff.DropDownStyle = "DropDownList"
    $script:diffKeys = @($script:QuizChoices)
    foreach ($k in $script:diffKeys) { $cmbDiff.Items.Add($script:QuizLabels[$k]) | Out-Null }
    $cmbDiff.SelectedIndex = 0
    $dlg.Controls.Add($cmbDiff)

    $lblDiffHint = New-Object System.Windows.Forms.Label
    $lblDiffHint.Text = "預設算 1 題。連答 3 題、兩位數乘法會更難醒。"
    $lblDiffHint.Location = New-Object System.Drawing.Point(110, 464)
    $lblDiffHint.Size = New-Object System.Drawing.Size(250, 20)
    $lblDiffHint.ForeColor = [System.Drawing.Color]::Gray
    $lblDiffHint.Font = New-Object System.Drawing.Font($lblDiffHint.Font.FontFamily, 8)
    $dlg.Controls.Add($lblDiffHint)
    $script:keepQr = $false
    $chkStrict.Add_CheckedChanged({ $cmbDiff.Enabled = $chkStrict.Checked })

    # 私密：開車不念內容、手機鎖定畫面不顯示內容（主要給手機用；電腦的提醒視窗在自己的電腦上，照常顯示）
    $chkPrivate = New-Object System.Windows.Forms.CheckBox
    $chkPrivate.Text = "私密（開車不念內容、手機鎖定時不顯示內容）"
    $chkPrivate.Location = New-Object System.Drawing.Point(20, 492)
    $chkPrivate.Size = New-Object System.Drawing.Size(340, 24)
    $dlg.Controls.Add($chkPrivate)
    $script:ownPrivate = $false
    $script:privBusy = $false
    $chkPrivate.Add_CheckedChanged({ if (-not $script:privBusy -and $chkPrivate.Enabled) { $script:ownPrivate = $chkPrivate.Checked } })

    $lblPrivateNote = New-Object System.Windows.Forms.Label
    $lblPrivateNote.Text = ""
    $lblPrivateNote.Location = New-Object System.Drawing.Point(38, 516)
    $lblPrivateNote.Size = New-Object System.Drawing.Size(320, 20)
    $lblPrivateNote.ForeColor = [System.Drawing.Color]::Gray
    $lblPrivateNote.Font = New-Object System.Drawing.Font($lblPrivateNote.Font.FontFamily, 8)
    $dlg.Controls.Add($lblPrivateNote)

    # 分類：可以從清單挑，也可以直接打一個新名字（例如 工作 / 家裡 / 孩子）
    $lblCategory = New-Object System.Windows.Forms.Label
    $lblCategory.Text = "分類："
    $lblCategory.Location = New-Object System.Drawing.Point(20, 550)
    $lblCategory.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblCategory)

    $cmbCategory = New-Object System.Windows.Forms.ComboBox
    $cmbCategory.Location = New-Object System.Drawing.Point(110, 548)
    $cmbCategory.Size = New-Object System.Drawing.Size(150, 24)
    $cmbCategory.DropDownStyle = "DropDown"
    foreach ($c in (Get-AllCategories $script:alarms $script:settings.categories)) { $cmbCategory.Items.Add($c) | Out-Null }
    $cmbCategory.Text = $script:DefaultCategory
    $dlg.Controls.Add($cmbCategory)

    $lblCategoryHint = New-Object System.Windows.Forms.Label
    $lblCategoryHint.Text = "可以直接打新的分類名稱"
    $lblCategoryHint.Location = New-Object System.Drawing.Point(265, 546)
    $lblCategoryHint.Size = New-Object System.Drawing.Size(95, 30)
    $lblCategoryHint.ForeColor = [System.Drawing.Color]::Gray
    $lblCategoryHint.Font = New-Object System.Drawing.Font($lblCategoryHint.Font.FontFamily, 8)
    $dlg.Controls.Add($lblCategoryHint)

    $btnSave = New-Object System.Windows.Forms.Button
    $btnSave.Text = "儲存"
    $btnSave.Location = New-Object System.Drawing.Point(110, 590)
    $btnSave.Size = New-Object System.Drawing.Size(100, 32)
    $dlg.Controls.Add($btnSave)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "取消"
    $btnCancel.Location = New-Object System.Drawing.Point(230, 590)
    $btnCancel.Size = New-Object System.Drawing.Size(100, 32)
    $dlg.Controls.Add($btnCancel)

    # 分類是私密的 → 勾選框鎖住、打勾（要取消請到「管理分類」）；不是 → 顯示這個鬧鐘自己的設定
    function Update-PrivateBox {
        $cat = $cmbCategory.Text.Trim()
        if ($cat -eq "") { $cat = $script:DefaultCategory }
        $script:privBusy = $true
        if (@($script:settings.privateCategories) -contains $cat) {
            $chkPrivate.Enabled = $false
            $chkPrivate.Checked = $true
            $lblPrivateNote.Text = "「$cat」是私密分類，要取消請到「管理分類」"
        } else {
            $chkPrivate.Enabled = $true
            $chkPrivate.Checked = $script:ownPrivate
            $lblPrivateNote.Text = ""
        }
        $script:privBusy = $false
    }
    $cmbCategory.Add_TextChanged({ Update-PrivateBox })
    Update-PrivateBox

    $script:dialogSaved = $null

    $btnSave.Add_Click({
        if ($txtLabel.Text.Trim() -eq "") {
            Show-AppMessage("請輸入提醒內容", "提醒") | Out-Null
            return
        }
        if ($cmbType.SelectedIndex -lt 0) {
            Show-AppMessage("請選擇類型", "提醒") | Out-Null
            return
        }

        $timeStr = $dtpTime.Value.ToString("HH:mm")
        $idx = $cmbType.SelectedIndex
        $timeLimited = $chkTimeLimited.Checked
        $playSound = $chkPlaySound.Checked
        $strict = $chkStrict.Checked
        $notes = $txtNotes.Text

        if ($idx -eq 0) {
            $daysText = $txtDays.Text.Trim()
            if ($daysText -eq "") {
                Show-AppMessage("請輸入日期（例如 1,16）", "提醒") | Out-Null
                return
            }
            $days = @($daysText -split "," | ForEach-Object { [int]$_.Trim() })
            $script:dialogSaved = [PSCustomObject]@{ type = "monthly"; label = $txtLabel.Text.Trim(); time = $timeStr; days = $days; date = ""; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes }
        }
        elseif ($idx -eq 1) {
            $script:dialogSaved = [PSCustomObject]@{ type = "daily"; label = $txtLabel.Text.Trim(); time = $timeStr; days = @(); date = ""; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes }
        }
        elseif ($idx -eq 2) {
            $days = @()
            for ($i = 0; $i -lt $clbWeek.Items.Count; $i++) {
                if ($clbWeek.GetItemChecked($i)) { $days += ($i + 1) }
            }
            if ($days.Count -eq 0) {
                Show-AppMessage("請至少勾選一個星期", "提醒") | Out-Null
                return
            }
            $script:dialogSaved = [PSCustomObject]@{ type = "weekly"; label = $txtLabel.Text.Trim(); time = $timeStr; days = $days; date = ""; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes }
        }
        elseif ($idx -eq 3) {
            # 單次鬧鐘：日期時間已經過了就不能存（存了也不會響，還會被誤當成漏響）→ 問要不要改成明天
            $onceAt = $dtpDate.Value.Date.AddHours($dtpTime.Value.Hour).AddMinutes($dtpTime.Value.Minute)
            if ($onceAt -le (Get-Date)) {
                $tomorrow = (Get-Date).Date.AddDays(1)
                $ask = Show-AppMessage("你設的 $($onceAt.ToString('yyyy-MM-dd HH:mm')) 已經過了。`n`n要改成明天（$($tomorrow.ToString('yyyy-MM-dd')) $timeStr）嗎？", "這個時間已經過了", [System.Windows.Forms.MessageBoxButtons]::YesNo)
                if ($ask -ne [System.Windows.Forms.DialogResult]::Yes) { return }
                $dtpDate.Value = $tomorrow
            }
            $dateStr = $dtpDate.Value.ToString("yyyy-MM-dd")
            $script:dialogSaved = [PSCustomObject]@{ type = "once"; label = $txtLabel.Text.Trim(); time = $timeStr; days = @(); date = $dateStr; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes }
        }
        elseif ($idx -eq 5) {
            $months = @()
            for ($i = 0; $i -lt $clbYearMonths.Items.Count; $i++) {
                if ($clbYearMonths.GetItemChecked($i)) { $months += ($i + 1) }
            }
            if ($months.Count -eq 0) {
                Show-AppMessage("請至少勾選一個月份", "$($script:AppName)") | Out-Null
                return
            }
            $yearDays = @()
            foreach ($part in ($txtYearDays.Text -split "[,，、 ]")) {
                $pt = $part.Trim()
                if ($pt -eq "") { continue }
                $dn = 0
                if (-not [int]::TryParse($pt, [ref]$dn) -or $dn -lt 1 -or $dn -gt 31) {
                    Show-AppMessage("「$pt」不是 1~31 的日期喔。請輸入像 1,15 這樣的數字。", "$($script:AppName)") | Out-Null
                    return
                }
                if ($yearDays -notcontains $dn) { $yearDays += $dn }
            }
            if ($yearDays.Count -eq 0) {
                Show-AppMessage("請輸入日期（例如 1,15）", "$($script:AppName)") | Out-Null
                return
            }
            $yearDays = @($yearDays | Sort-Object)
            $script:dialogSaved = [PSCustomObject]@{ type = "yearly"; label = $txtLabel.Text.Trim(); time = $timeStr; days = $yearDays; months = $months; date = ""; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes }
        }
        elseif ($idx -eq 4) {
            $intervalText = $txtInterval.Text.Trim()
            $intervalDays = 0
            if (-not [int]::TryParse($intervalText, [ref]$intervalDays) -or $intervalDays -le 0) {
                Show-AppMessage("請輸入大於0的間隔天數", "提醒") | Out-Null
                return
            }
            $script:dialogSaved = [PSCustomObject]@{ type = "interval"; label = $txtLabel.Text.Trim(); time = $timeStr; days = @(); date = ""; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes; intervalDays = $intervalDays; nextDueDate = (Get-Date).AddDays($intervalDays).ToString("yyyy-MM-dd") }
        }

        $cat = $cmbCategory.Text.Trim()
        if ($cat -eq "") { $cat = $script:DefaultCategory }
        $script:dialogSaved | Add-Member -NotePropertyName category -NotePropertyValue $cat -Force
        $script:dialogSaved | Add-Member -NotePropertyName private -NotePropertyValue ([bool]$script:ownPrivate) -Force
        # 難度：原本是手機的「掃 QR」而這次沒動它 → 維持 qr（QR 密碼也照留）；否則存選的
        $diffKey = "math1"
        if ($cmbDiff.SelectedIndex -ge 0 -and $cmbDiff.SelectedIndex -lt $script:diffKeys.Count) { $diffKey = $script:diffKeys[$cmbDiff.SelectedIndex] }
        if ($script:keepQr -and $diffKey -eq "math3") { $diffKey = "qr" }
        $script:dialogSaved | Add-Member -NotePropertyName difficulty -NotePropertyValue $diffKey -Force

        $dlg.Tag = "OK"
        $dlg.Close()
    })

    $btnCancel.Add_Click({
        $dlg.Tag = "CANCEL"
        $dlg.Close()
    })

    if ($existing) {
        $txtLabel.Text = $existing.label
        $tparts = $existing.time -split ":"
        $dtpTime.Value = (Get-Date -Hour ([int]$tparts[0]) -Minute ([int]$tparts[1]) -Second 0)
        $chkTimeLimited.Checked = [bool]$existing.timeLimited
        $chkPlaySound.Checked = ($existing.playSound -ne $false)
        if ($null -ne $existing.strict) { $chkStrict.Checked = [bool]$existing.strict }
        else { $chkStrict.Checked = -not [bool]$existing.timeLimited }
        $txtNotes.Text = "$($existing.notes)"
        $existingDiff = "$($existing.difficulty)"
        if ($existingDiff -eq "qr") { $script:keepQr = $true; $existingDiff = "math3" }
        $di = [Array]::IndexOf($script:diffKeys, $existingDiff)
        if ($di -ge 0) { $cmbDiff.SelectedIndex = $di }
        $cmbDiff.Enabled = $chkStrict.Checked
        $script:ownPrivate = (Test-AlarmOwnPrivate $existing)
        $cmbCategory.Text = (Get-AlarmCategory $existing)
        Update-PrivateBox

        if ($existing.type -eq "monthly") {
            $cmbType.SelectedIndex = 0
            $txtDays.Text = ($existing.days -join ",")
        }
        elseif ($existing.type -eq "daily") {
            $cmbType.SelectedIndex = 1
        }
        elseif ($existing.type -eq "weekly") {
            $cmbType.SelectedIndex = 2
            foreach ($d in $existing.days) { $clbWeek.SetItemChecked($d - 1, $true) }
        }
        elseif ($existing.type -eq "once") {
            $cmbType.SelectedIndex = 3
            $dtpDate.Value = [DateTime]::ParseExact($existing.date, "yyyy-MM-dd", $null)
        }
        elseif ($existing.type -eq "yearly") {
            $cmbType.SelectedIndex = 5
            # 舊的單一日期（date）和新的多月多日（months + days）都讀得進來
            $rule = Get-YearlyRule $existing
            if ($null -ne $rule) {
                foreach ($m in $rule.Months) { if ($m -ge 1 -and $m -le 12) { $clbYearMonths.SetItemChecked($m - 1, $true) } }
                $txtYearDays.Text = ($rule.Days -join ",")
            }
        }
        elseif ($existing.type -eq "interval") {
            $cmbType.SelectedIndex = 4
            $txtInterval.Text = "$($existing.intervalDays)"
        }
    } else {
        $cmbType.SelectedIndex = 0
    }

    Update-PanelVisibility

    # 大字／深色（v1.1）
    Complete-AppForm $dlg
    $dlg.ShowDialog() | Out-Null

    if ($dlg.Tag -eq "OK") { return $script:dialogSaved }
    else { return $null }
}

$script:settings = Read-AppSettings $settingsPath

$form = New-Object System.Windows.Forms.Form
$form.Text = "$($script:AppName) - 我的鬧鐘"
$form.Size = New-Object System.Drawing.Size(800, 560)
$form.StartPosition = "CenterScreen"
Set-AppFormStyle $form

# 排序方式：分類（同分類放一起）/ 下次響的時間 / 名稱
$lblSort = New-Object System.Windows.Forms.Label
$lblSort.Text = "排序："
$lblSort.Location = New-Object System.Drawing.Point(15, 15)
$lblSort.Size = New-Object System.Drawing.Size(45, 22)
$form.Controls.Add($lblSort)

$cmbSort = New-Object System.Windows.Forms.ComboBox
$cmbSort.Location = New-Object System.Drawing.Point(60, 12)
$cmbSort.Size = New-Object System.Drawing.Size(160, 24)
$cmbSort.DropDownStyle = "DropDownList"
$cmbSort.Items.AddRange(@("依分類", "依下次響的時間", "依名稱"))
$script:sortKeys = @("category", "next", "name")
$cmbSort.SelectedIndex = [Math]::Max(0, [Array]::IndexOf($script:sortKeys, $script:settings.sortBy))
$form.Controls.Add($cmbSort)

# 找鬧鐘（工單 8.3）：依名稱搜尋、依分類／即將響篩選
$lblSearch = New-Object System.Windows.Forms.Label
$lblSearch.Text = "搜尋："
$lblSearch.Location = New-Object System.Drawing.Point(15, 47)
$lblSearch.Size = New-Object System.Drawing.Size(45, 22)
$form.Controls.Add($lblSearch)

$txtSearch = New-Object System.Windows.Forms.TextBox
$txtSearch.Location = New-Object System.Drawing.Point(60, 44)
$txtSearch.Size = New-Object System.Drawing.Size(200, 24)
$form.Controls.Add($txtSearch)

$lblFilter = New-Object System.Windows.Forms.Label
$lblFilter.Text = "只看："
$lblFilter.Location = New-Object System.Drawing.Point(280, 47)
$lblFilter.Size = New-Object System.Drawing.Size(45, 22)
$form.Controls.Add($lblFilter)

$cmbFilter = New-Object System.Windows.Forms.ComboBox
$cmbFilter.Location = New-Object System.Drawing.Point(325, 44)
$cmbFilter.Size = New-Object System.Drawing.Size(190, 24)
$cmbFilter.DropDownStyle = "DropDownList"
$form.Controls.Add($cmbFilter)
$script:filterKeys = @("all")
$script:filterBusy = $false

$btnClearFilter = New-Object System.Windows.Forms.Button
$btnClearFilter.Text = "清除"
$btnClearFilter.Location = New-Object System.Drawing.Point(530, 43)
$btnClearFilter.Size = New-Object System.Drawing.Size(70, 26)
$form.Controls.Add($btnClearFilter)

$lblSortHint = New-Object System.Windows.Forms.Label
$lblSortHint.Text = "（雙擊一列可以直接編輯）"
$lblSortHint.Location = New-Object System.Drawing.Point(230, 15)
$lblSortHint.Size = New-Object System.Drawing.Size(180, 22)
$lblSortHint.ForeColor = [System.Drawing.Color]::Gray
$form.Controls.Add($lblSortHint)

# v1.1：字體大小（高齡友善）、外觀（深色對眼睛友善）。選了會記住，設定視窗會自己重新打開套用
$lblFontSize = New-Object System.Windows.Forms.Label
$lblFontSize.Text = "字體："
$lblFontSize.Location = New-Object System.Drawing.Point(415, 15)
$lblFontSize.Size = New-Object System.Drawing.Size(45, 22)
$form.Controls.Add($lblFontSize)

$cmbFontSize = New-Object System.Windows.Forms.ComboBox
$cmbFontSize.Location = New-Object System.Drawing.Point(460, 12)
$cmbFontSize.Size = New-Object System.Drawing.Size(75, 24)
$cmbFontSize.DropDownStyle = "DropDownList"
$cmbFontSize.Items.AddRange(@("標準", "大", "特大"))
$script:fontSizeKeys = @("normal", "large", "xlarge")
$cmbFontSize.SelectedIndex = [Math]::Max(0, [Array]::IndexOf($script:fontSizeKeys, $script:settings.fontSize))
$form.Controls.Add($cmbFontSize)

$chkBold = New-Object System.Windows.Forms.CheckBox
$chkBold.Text = "粗體"
$chkBold.Location = New-Object System.Drawing.Point(540, 12)
$chkBold.Size = New-Object System.Drawing.Size(62, 24)
$chkBold.Checked = [bool]$script:settings.bold
$form.Controls.Add($chkBold)

$lblTheme = New-Object System.Windows.Forms.Label
$lblTheme.Text = "外觀："
$lblTheme.Location = New-Object System.Drawing.Point(606, 15)
$lblTheme.Size = New-Object System.Drawing.Size(45, 22)
$form.Controls.Add($lblTheme)

$cmbTheme = New-Object System.Windows.Forms.ComboBox
$cmbTheme.Location = New-Object System.Drawing.Point(651, 12)
$cmbTheme.Size = New-Object System.Drawing.Size(119, 24)
$cmbTheme.DropDownStyle = "DropDownList"
$cmbTheme.Items.AddRange(@("淺色", "深色（護眼）"))
$script:themeKeys = @("light", "dark")
$cmbTheme.SelectedIndex = [Math]::Max(0, [Array]::IndexOf($script:themeKeys, $script:settings.theme))
$form.Controls.Add($cmbTheme)

$listView = New-Object System.Windows.Forms.ListView
$listView.Location = New-Object System.Drawing.Point(15, 74)
$listView.Size = New-Object System.Drawing.Size(755, 233)
$listView.View = [System.Windows.Forms.View]::Details
$listView.FullRowSelect = $true
$listView.GridLines = $true
$listView.HideSelection = $false
$listView.Columns.Add("內容", 150) | Out-Null
$listView.Columns.Add("分類", 70) | Out-Null
$listView.Columns.Add("類型", 150) | Out-Null
$listView.Columns.Add("時間", 50) | Out-Null
$listView.Columns.Add("下次響", 120) | Out-Null
$listView.Columns.Add("限時", 45) | Out-Null
$listView.Columns.Add("聲音", 45) | Out-Null
$listView.Columns.Add("模式", 50) | Out-Null
$form.Controls.Add($listView)

$btnAdd = New-Object System.Windows.Forms.Button
$btnAdd.Text = "新增"
$btnAdd.Location = New-Object System.Drawing.Point(15, 320)
$btnAdd.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnAdd)

$btnEdit = New-Object System.Windows.Forms.Button
$btnEdit.Text = "編輯"
$btnEdit.Location = New-Object System.Drawing.Point(125, 320)
$btnEdit.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnEdit)

$btnDelete = New-Object System.Windows.Forms.Button
$btnDelete.Text = "刪除"
$btnDelete.Location = New-Object System.Drawing.Point(235, 320)
$btnDelete.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnDelete)

$btnClose = New-Object System.Windows.Forms.Button
$btnClose.Text = "關閉"
$btnClose.Location = New-Object System.Drawing.Point(430, 320)
$btnClose.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnClose)

$btnAddCategory = New-Object System.Windows.Forms.Button
$btnAddCategory.Text = "管理分類"
$btnAddCategory.Location = New-Object System.Drawing.Point(560, 320)
$btnAddCategory.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnAddCategory)

$btnAbout = New-Object System.Windows.Forms.Button
$btnAbout.Text = "關於"
$btnAbout.Location = New-Object System.Drawing.Point(670, 320)
$btnAbout.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnAbout)

# 角落的新跪（圖檔不在就不顯示）
$picSettings = New-AppPictureBox "xg_settings.png" 600 362 170 150
$form.Controls.Add($picSettings)

$lblStartupStatus = New-Object System.Windows.Forms.Label
$lblStartupStatus.Location = New-Object System.Drawing.Point(15, 365)
$lblStartupStatus.Size = New-Object System.Drawing.Size(515, 24)
$lblStartupStatus.Font = New-Object System.Drawing.Font($lblStartupStatus.Font, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($lblStartupStatus)

$btnEnableStartup = New-Object System.Windows.Forms.Button
$btnEnableStartup.Text = "設定開機自動啟動"
$btnEnableStartup.Location = New-Object System.Drawing.Point(15, 395)
$btnEnableStartup.Size = New-Object System.Drawing.Size(160, 35)
$form.Controls.Add($btnEnableStartup)

$btnDisableStartup = New-Object System.Windows.Forms.Button
$btnDisableStartup.Text = "取消開機自動啟動"
$btnDisableStartup.Location = New-Object System.Drawing.Point(185, 395)
$btnDisableStartup.Size = New-Object System.Drawing.Size(160, 35)
$form.Controls.Add($btnDisableStartup)

# v1.3：匯出／匯入（換電腦、換手機時把鬧鐘帶走；格式跟 Android 版一樣）
$btnExport = New-Object System.Windows.Forms.Button
$btnExport.Text = "匯出鬧鐘"
$btnExport.Location = New-Object System.Drawing.Point(355, 395)
$btnExport.Size = New-Object System.Drawing.Size(110, 35)
$form.Controls.Add($btnExport)

$btnImport = New-Object System.Windows.Forms.Button
$btnImport.Text = "匯入鬧鐘"
$btnImport.Location = New-Object System.Drawing.Point(475, 395)
$btnImport.Size = New-Object System.Drawing.Size(110, 35)
$form.Controls.Add($btnImport)

$tipExport = New-Object System.Windows.Forms.ToolTip
$tipExport.SetToolTip($btnExport, "把鬧鐘存成一個 .json 檔（可以存到 Google 雲端硬碟，手機再匯入）")
$tipExport.SetToolTip($btnImport, "從匯出的 .json 檔把鬧鐘讀進來（可以選全部取代或合併）")

$startupFolder = [Environment]::GetFolderPath("Startup")
$shortcutPath = Join-Path $startupFolder "真劍鬧鐘.lnk"
# 改名前（桌面鬧鐘）建的開機捷徑：還在的話一樣算「已啟用」，取消時一起刪
$legacyShortcutPath = Join-Path $startupFolder "桌面鬧鐘背景提醒.lnk"

function Update-StartupStatus {
    if ((Test-Path -LiteralPath $shortcutPath) -or (Test-Path -LiteralPath $legacyShortcutPath)) {
        $lblStartupStatus.Text = "開機自動啟動：已啟用"
        $lblStartupStatus.ForeColor = Get-StatusColor "ok"
    } else {
        $lblStartupStatus.Text = "開機自動啟動：未啟用"
        $lblStartupStatus.ForeColor = Get-StatusColor "muted"
    }
}

$btnEnableStartup.Add_Click({
    try {
        $wshShell = New-Object -ComObject WScript.Shell
        $shortcut = $wshShell.CreateShortcut($shortcutPath)
        # 直接叫 powershell.exe 隱藏視窗執行（不用 .vbs，免得被防毒誤判）
        $shortcut.TargetPath = Join-Path $PSHOME "powershell.exe"
        $shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $PSScriptRoot 'Alarm_Tray.ps1')`""
        $shortcut.WorkingDirectory = $PSScriptRoot
        $shortcut.WindowStyle = 7
        $shortcut.IconLocation = Join-Path (Join-Path $PSScriptRoot "assets") "jellyfish.ico"
        $shortcut.Description = "真劍鬧鐘 背景提醒"
        $shortcut.Save()
        # 有了新捷徑，舊的就不用了（不然開機會啟動兩次，雖然第二個會自己結束）
        if (Test-Path -LiteralPath $legacyShortcutPath) { Remove-Item -LiteralPath $legacyShortcutPath -Force -ErrorAction SilentlyContinue }
        Update-StartupStatus
        Show-AppMessage("已設定為開機自動啟動背景提醒。", "$($script:AppName) - 完成") | Out-Null
    } catch {
        Show-AppMessage("設定失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

$btnDisableStartup.Add_Click({
    try {
        if ((Test-Path -LiteralPath $shortcutPath) -or (Test-Path -LiteralPath $legacyShortcutPath)) {
            if (Test-Path -LiteralPath $shortcutPath) { Remove-Item -LiteralPath $shortcutPath -Force }
            if (Test-Path -LiteralPath $legacyShortcutPath) { Remove-Item -LiteralPath $legacyShortcutPath -Force }
            Show-AppMessage("已取消開機自動啟動。", "$($script:AppName) - 完成") | Out-Null
        } else {
            Show-AppMessage("目前並未設定開機自動啟動。", "$($script:AppName)") | Out-Null
        }
        Update-StartupStatus
    } catch {
        Show-AppMessage("取消失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

$lblTrayStatus = New-Object System.Windows.Forms.Label
$lblTrayStatus.Location = New-Object System.Drawing.Point(15, 440)
$lblTrayStatus.Size = New-Object System.Drawing.Size(515, 24)
$lblTrayStatus.Font = New-Object System.Drawing.Font($lblTrayStatus.Font, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($lblTrayStatus)

$btnStartTray = New-Object System.Windows.Forms.Button
$btnStartTray.Text = "啟動背景提醒"
$btnStartTray.Location = New-Object System.Drawing.Point(15, 470)
$btnStartTray.Size = New-Object System.Drawing.Size(160, 35)
$form.Controls.Add($btnStartTray)

$btnStopTray = New-Object System.Windows.Forms.Button
$btnStopTray.Text = "停止背景提醒"
$btnStopTray.Location = New-Object System.Drawing.Point(185, 470)
$btnStopTray.Size = New-Object System.Drawing.Size(160, 35)
$form.Controls.Add($btnStopTray)

# v1.5：用 Google 帳號登入、電腦和手機同步鬧鐘
$btnSync = New-Object System.Windows.Forms.Button
$btnSync.Text = "同步"
$btnSync.Location = New-Object System.Drawing.Point(355, 470)
$btnSync.Size = New-Object System.Drawing.Size(110, 35)
$form.Controls.Add($btnSync)
$tipSync = New-Object System.Windows.Forms.ToolTip
$tipSync.SetToolTip($btnSync, "用 Google 帳號登入，電腦和手機的鬧鐘就會自動保持一樣")

# v1.6：檢查更新（每天第一次打開時背景安靜檢查，有新版這顆會變紅；不跳窗打擾）
$btnUpdate = New-Object System.Windows.Forms.Button
$btnUpdate.Text = "檢查更新"
$btnUpdate.Location = New-Object System.Drawing.Point(475, 470)
$btnUpdate.Size = New-Object System.Drawing.Size(110, 35)
$form.Controls.Add($btnUpdate)
$tipSync.SetToolTip($btnUpdate, "看有沒有新版；有的話按一下就能更新（鬧鐘和設定都會保留）")

# 視窗放大時跟著伸縮(2026-09-30 先生:鬧鐘太多,按放大以為能一次看完,結果只多出空白)
# 列表四邊都黏住 → 放大就多顯示幾列;下面的按鈕與狀態黏在下緣;右邊那排按鈕與新跪黏在右下角
$form.MinimumSize = $form.Size
$AnchorAll = [System.Windows.Forms.AnchorStyles]"Top, Bottom, Left, Right"
$AnchorBL = [System.Windows.Forms.AnchorStyles]"Bottom, Left"
$AnchorBR = [System.Windows.Forms.AnchorStyles]"Bottom, Right"
$listView.Anchor = $AnchorAll
foreach ($c in @($btnAdd, $btnEdit, $btnDelete, $lblStartupStatus, $btnEnableStartup, $btnDisableStartup, $lblTrayStatus, $btnStartTray, $btnStopTray)) { $c.Anchor = $AnchorBL }
foreach ($c in @($btnClose, $btnAddCategory, $btnAbout)) { $c.Anchor = $AnchorBR }
if ($picSettings) { $picSettings.Anchor = $AnchorBR }
foreach ($c in @($btnExport, $btnImport, $btnSync, $btnUpdate)) { $c.Anchor = $AnchorBL }
# 字體、外觀的選單黏在右上角
$AnchorTR = [System.Windows.Forms.AnchorStyles]"Top, Right"
foreach ($c in @($lblFontSize, $cmbFontSize, $chkBold, $lblTheme, $cmbTheme)) { $c.Anchor = $AnchorTR }
# 多出來的寬度依各欄原本寬度的比例分給每一欄（v1.1，先生 21:9 寬螢幕：以前全給「內容」欄，中間很空）
# 「內容」欄用 2 倍權重多拿一點；視窗縮回原大小時各欄回到原寬度。
# 原寬度要等套用大字（Complete-AppForm）之後才記，所以一開始是 $null。
$script:baseColumnWidths = $null
function Update-ContentColumnWidth {
    if ($null -eq $script:baseColumnWidths) { return }
    $widths = Get-DistributedColumnWidths $script:baseColumnWidths ($listView.ClientSize.Width - 4) 2.0
    for ($i = 0; $i -lt $listView.Columns.Count -and $i -lt $widths.Count; $i++) {
        if ($listView.Columns[$i].Width -ne $widths[$i]) { $listView.Columns[$i].Width = $widths[$i] }
    }
}
$listView.Add_Resize({ Update-ContentColumnWidth })

$pidFile = Join-Path $PSScriptRoot "tray.pid"
$trayScript = Join-Path $PSScriptRoot "Alarm_Tray.ps1"

function Test-TrayRunning {
    if (Test-Path $pidFile) {
        $storedPid = (Get-Content $pidFile -Raw).Trim()
        $proc = Get-Process -Id $storedPid -ErrorAction SilentlyContinue
        if ($proc) { return $true }
        else {
            Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
            return $false
        }
    }
    return $false
}

function Update-TrayStatus {
    if (Test-TrayRunning) {
        $lblTrayStatus.Text = "背景提醒：運作中（工作列有常駐圖示）"
        $lblTrayStatus.ForeColor = Get-StatusColor "ok"
    } else {
        $lblTrayStatus.Text = "背景提醒：未運作"
        $lblTrayStatus.ForeColor = Get-StatusColor "muted"
    }
}

$btnStartTray.Add_Click({
    if (Test-TrayRunning) {
        Show-AppMessage("背景提醒已經在運作中了。", "$($script:AppName)") | Out-Null
        return
    }
    try {
        Start-AppScript "Alarm_Tray.ps1"
        Start-Sleep -Milliseconds 800
        Update-TrayStatus
    } catch {
        Show-AppMessage("啟動失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

$btnStopTray.Add_Click({
    if (-not (Test-TrayRunning)) {
        Show-AppMessage("背景提醒目前並未運作。", "$($script:AppName)") | Out-Null
        return
    }
    try {
        $storedPid = (Get-Content $pidFile -Raw).Trim()
        Stop-Process -Id $storedPid -Force -ErrorAction SilentlyContinue
        Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
        Update-TrayStatus
        Show-AppMessage("已停止背景提醒。", "$($script:AppName) - 完成") | Out-Null
    } catch {
        Show-AppMessage("停止失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

# 一律用 @() 包起來：只有一個鬧鐘時才不會變成「不是陣列」而沒辦法編輯
$script:alarms = @(Load-Alarms)

function Get-NextText($a, $now) {
    $n = Get-NextOccurrence $a $now
    if ($null -eq $n) { return "（不會再響）" }
    $w = @("日","一","二","三","四","五","六")[[int]$n.DayOfWeek]
    $text = "$($n.ToString('yyyy-MM-dd'))（$w）"
    if ($n -le $now) { $text = "$text 待完成" }
    return $text
}

# 篩選下拉：全部｜即將響（24 小時內）｜各分類｜未分類（有鬧鐘才列），後面帶數量；記住目前選的
function Update-FilterCombo($now) {
    $cur = "all"
    if ($cmbFilter.SelectedIndex -ge 0 -and $cmbFilter.SelectedIndex -lt $script:filterKeys.Count) { $cur = $script:filterKeys[$cmbFilter.SelectedIndex] }
    $script:filterBusy = $true
    $cmbFilter.Items.Clear()
    $keys = @(); $labels = @()
    $keys += "all"; $labels += "全部（$(@($script:alarms).Count)）"
    $soonN = @($script:alarms | Where-Object { Test-AlarmSoon $_ $now }).Count
    $keys += "soon"; $labels += "即將響（24 小時內，$soonN）"
    foreach ($c in @(Get-AllCategories $script:alarms $script:settings.categories)) {
        $n = @($script:alarms | Where-Object { (Get-AlarmCategory $_) -eq $c }).Count
        if ($c -eq $script:DefaultCategory -and $n -eq 0) { continue }
        $keys += "cat:$c"; $labels += "$c（$n）"
    }
    foreach ($l in $labels) { $cmbFilter.Items.Add($l) | Out-Null }
    $script:filterKeys = $keys
    $i = [Array]::IndexOf($keys, $cur)
    if ($i -lt 0) { $i = 0 }
    $cmbFilter.SelectedIndex = $i
    $script:filterBusy = $false
}

function Refresh-List {
    $now = Get-Date
    $sortBy = $script:sortKeys[[Math]::Max(0, $cmbSort.SelectedIndex)]
    Update-FilterCombo $now
    $filterKey = $script:filterKeys[[Math]::Max(0, $cmbFilter.SelectedIndex)]
    $shownAlarms = @(Get-FilteredAlarms $script:alarms $filterKey $txtSearch.Text $now)
    if ($filterKey -eq "soon") { $sortBy = "next" }
    $sorted = @(Get-SortedAlarms $shownAlarms $sortBy $now)
    $showHeaders = ($sortBy -eq "category" -and $filterKey -eq "all")

    $listView.BeginUpdate()
    $listView.Items.Clear()
    $listView.Groups.Clear()
    # 分類標題一律自己畫成「有底色的色塊標籤列」（不能選來編輯），鬧鐘列帶該分類的色條和淡淡的底色（工單 7.1）
    $listView.ShowGroups = $false
    $isDark = [bool]$script:UiAppearance.Dark
    $colors = Update-CategoryColors (Get-AllCategories $script:alarms $script:settings.categories) $script:settings.categoryColors
    # 補上的顏色（新分類、舊資料）存回設定
    if ((ConvertTo-SyncCanonicalJson (ConvertTo-CategoryColorObject $colors)) -ne (ConvertTo-SyncCanonicalJson (ConvertTo-CategoryColorObject $script:settings.categoryColors))) {
        $script:settings.categoryColors = $colors
        try { Write-AppSettings $settingsPath $script:settings } catch {}
    }
    $lastCat = $null
    $boldFont = New-Object System.Drawing.Font($listView.Font, [System.Drawing.FontStyle]::Bold)

    foreach ($a in $sorted) {
        $cat = Get-AlarmCategory $a
        $style = Get-CategoryColorStyle (Get-CategoryColorOf $cat $colors) $isDark
        if ($showHeaders -and $cat -ne $lastCat) {
            $count = @($sorted | Where-Object { (Get-AlarmCategory $_) -eq $cat }).Count
            $header = New-Object System.Windows.Forms.ListViewItem("$cat（$count）")
            $header.Name = "__group__"
            $header.Tag = $null
            $header.Font = $boldFont
            $header.BackColor = [System.Drawing.Color]::FromArgb(255, (($style.chip -shr 16) -band 255), (($style.chip -shr 8) -band 255), ($style.chip -band 255))
            $header.ForeColor = [System.Drawing.Color]::FromArgb(255, (($style.chipText -shr 16) -band 255), (($style.chipText -shr 8) -band 255), ($style.chipText -band 255))
            for ($k = 1; $k -lt $listView.Columns.Count; $k++) { $header.SubItems.Add("") | Out-Null }
            $listView.Items.Add($header) | Out-Null
            $lastCat = $cat
        }
        $isStrict = if ($null -ne $a.strict) { [bool]$a.strict } else { -not [bool]$a.timeLimited }
        $lockMark = ""
        if (Test-AlarmPrivate $a $script:settings.privateCategories) { $lockMark = "[私密] " }
        $item = New-Object System.Windows.Forms.ListViewItem("$lockMark$($a.label)")
        # 排序後位置會變，用 id 對回鬧鐘（不能再用第幾列）
        $item.Tag = $a.id
        # 色條顏色放在 Name（"c:RRGGBB"），底色是淡淡的分類色調（列表自己畫，見 AlarmUi.ps1 的 Enable-ColorListView）
        $item.Name = "c:" + ("{0:X6}" -f $style.stripe)
        $item.BackColor = [System.Drawing.Color]::FromArgb(255, (($style.tint -shr 16) -band 255), (($style.tint -shr 8) -band 255), ($style.tint -band 255))
        $item.SubItems.Add($cat) | Out-Null
        $item.SubItems.Add((Get-AlarmBaseType $a)) | Out-Null
        $item.SubItems.Add($a.time) | Out-Null
        $item.SubItems.Add((Get-NextText $a $now)) | Out-Null
        $item.SubItems.Add($(if ($a.timeLimited) { "是" } else { "否" })) | Out-Null
        $item.SubItems.Add($(if ($a.playSound -ne $false) { "開" } else { "關" })) | Out-Null
        $item.SubItems.Add($(if ($isStrict) { "認真" } else { "隨意" })) | Out-Null
        $listView.Items.Add($item) | Out-Null
    }
    if ($sorted.Count -eq 0 -and @($script:alarms).Count -gt 0) {
        $msg = if ("$($txtSearch.Text)".Trim() -ne "") { "沒有名稱含「$("$($txtSearch.Text)".Trim())」的鬧鐘（按「清除」看全部）" } elseif ($filterKey -eq "soon") { "接下來 24 小時內沒有鬧鐘要響（按「清除」看全部）" } else { "這一類目前沒有鬧鐘（按「清除」看全部）" }
        $empty = New-Object System.Windows.Forms.ListViewItem($msg)
        $empty.Name = "__group__"
        $empty.Tag = $null
        for ($k = 1; $k -lt $listView.Columns.Count; $k++) { $empty.SubItems.Add("") | Out-Null }
        $listView.Items.Add($empty) | Out-Null
    }
    $listView.EndUpdate()
}

$cmbFilter.Add_SelectedIndexChanged({ if (-not $script:filterBusy) { Refresh-List } })
$txtSearch.Add_TextChanged({ Refresh-List })
$btnClearFilter.Add_Click({
    $txtSearch.Text = ""
    if ($cmbFilter.Items.Count -gt 0) { $script:filterBusy = $true; $cmbFilter.SelectedIndex = 0; $script:filterBusy = $false }
    Refresh-List
})

# 目前選到的鬧鐘在 $script:alarms 裡的位置；沒選回傳 -1
function Get-SelectedAlarmIndex {
    if ($listView.SelectedItems.Count -eq 0) { return -1 }
    $id = $listView.SelectedItems[0].Tag
    for ($i = 0; $i -lt $script:alarms.Count; $i++) {
        if ("$($script:alarms[$i].id)" -eq "$id") { return $i }
    }
    return -1
}

$cmbSort.Add_SelectedIndexChanged({
    try {
        $script:settings.sortBy = $script:sortKeys[[Math]::Max(0, $cmbSort.SelectedIndex)]
        Write-AppSettings $settingsPath $script:settings
    } catch {}
    Refresh-List
})

# 從調色盤選分類顏色：每個顏色一顆色塊按鈕（目前的打勾）。回傳色票編號，取消回傳 $null
function Show-CategoryColorPicker($owner, [string]$catName, [string]$current) {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 「$catName」的顏色"
    $dlg.Size = New-Object System.Drawing.Size(380, 380)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg
    $dark = [bool]$script:UiAppearance.Dark
    $script:pickedColor = $null
    $i = 0
    foreach ($id in $script:CategoryColorIds) {
        $st = Get-CategoryColorStyle $id $dark
        $b = New-Object System.Windows.Forms.Button
        $mark = ""
        if ($id -eq $current) { $mark = "✓ " }
        $b.Text = $mark + $script:CategoryColorNames[$id]
        $b.Tag = $id
        $b.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $b.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(255, (($st.stripe -shr 16) -band 255), (($st.stripe -shr 8) -band 255), ($st.stripe -band 255))
        $b.BackColor = [System.Drawing.Color]::FromArgb(255, (($st.chip -shr 16) -band 255), (($st.chip -shr 8) -band 255), ($st.chip -band 255))
        $b.ForeColor = [System.Drawing.Color]::FromArgb(255, (($st.chipText -shr 16) -band 255), (($st.chipText -shr 8) -band 255), ($st.chipText -band 255))
        $b.Location = New-Object System.Drawing.Point((15 + 175 * ($i % 2)), (15 + 55 * [Math]::Floor($i / 2)))
        $b.Size = New-Object System.Drawing.Size(160, 44)
        $b.Add_Click({ param($s, $e) $script:pickedColor = "$($s.Tag)"; $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK; $dlg.Close() })
        $dlg.Controls.Add($b)
        $i++
    }
    $btnX = New-Object System.Windows.Forms.Button
    $btnX.Text = "取消"
    $btnX.Location = New-Object System.Drawing.Point(255, 300)
    $btnX.Size = New-Object System.Drawing.Size(100, 35)
    $btnX.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($btnX)
    $dlg.CancelButton = $btnX
    Complete-AppForm $dlg
    $null = $dlg.ShowDialog($owner)
    $dlg.Dispose()
    return $script:pickedColor
}

# v1.1：分類管理（新增、改名、刪除）。改名／刪除的邏輯在 AlarmCore.ps1（有測試）
function Show-CategoryManager {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 管理分類"
    $dlg.Size = New-Object System.Drawing.Size(440, 420)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $lblHead = New-Object System.Windows.Forms.Label
    $lblHead.Text = "分類（括號裡是底下有幾個鬧鐘）："
    $lblHead.Location = New-Object System.Drawing.Point(15, 12)
    $lblHead.Size = New-Object System.Drawing.Size(290, 22)
    $dlg.Controls.Add($lblHead)

    $lbCats = New-Object System.Windows.Forms.ListBox
    $lbCats.Location = New-Object System.Drawing.Point(15, 38)
    $lbCats.Size = New-Object System.Drawing.Size(270, 250)
    $lbCats.IntegralHeight = $false
    # 每個分類一個色塊：左側色條＋淡淡的底色（自己畫，淺色、深色都用同一套色值）
    $lbCats.DrawMode = [System.Windows.Forms.DrawMode]::OwnerDrawFixed
    $lbCats.ItemHeight = [int]($lbCats.Font.Height + 10)
    $lbCats.Add_DrawItem({
        param($sender, $e)
        if ($e.Index -lt 0) { return }
        $dark = [bool]$script:UiAppearance.Dark
        $name = $script:catNames[$e.Index]
        $style = Get-CategoryColorStyle (Get-CategoryColorOf $name $script:settings.categoryColors) $dark
        $sel = (($e.State -band [System.Windows.Forms.DrawItemState]::Selected) -ne 0)
        $back = [System.Drawing.Color]::FromArgb(255, (($style.tint -shr 16) -band 255), (($style.tint -shr 8) -band 255), ($style.tint -band 255))
        $fore = [System.Drawing.SystemColors]::WindowText
        if ($dark) { $fore = [System.Drawing.Color]::FromArgb(0xDA, 0xD6, 0xCE) }
        if ($sel) { $back = [System.Drawing.Color]::FromArgb(255, (($style.chip -shr 16) -band 255), (($style.chip -shr 8) -band 255), ($style.chip -band 255)); $fore = [System.Drawing.Color]::FromArgb(255, (($style.chipText -shr 16) -band 255), (($style.chipText -shr 8) -band 255), ($style.chipText -band 255)) }
        $br = New-Object System.Drawing.SolidBrush($back)
        $e.Graphics.FillRectangle($br, $e.Bounds)
        $br.Dispose()
        $sb = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, (($style.stripe -shr 16) -band 255), (($style.stripe -shr 8) -band 255), ($style.stripe -band 255)))
        $e.Graphics.FillRectangle($sb, $e.Bounds.X, $e.Bounds.Y, 6, $e.Bounds.Height)
        $sb.Dispose()
        $r = New-Object System.Drawing.Rectangle(($e.Bounds.X + 12), $e.Bounds.Y, ($e.Bounds.Width - 14), $e.Bounds.Height)
        $flags = [System.Windows.Forms.TextFormatFlags]"Left, VerticalCenter, SingleLine, EndEllipsis, NoPrefix"
        [System.Windows.Forms.TextRenderer]::DrawText($e.Graphics, "$($sender.Items[$e.Index])", $e.Font, $r, $fore, $flags)
    })
    $dlg.Controls.Add($lbCats)

    $btnCatAdd = New-Object System.Windows.Forms.Button
    $btnCatAdd.Text = "新增"
    $btnCatAdd.Location = New-Object System.Drawing.Point(300, 38)
    $btnCatAdd.Size = New-Object System.Drawing.Size(110, 35)
    $dlg.Controls.Add($btnCatAdd)

    $btnCatRename = New-Object System.Windows.Forms.Button
    $btnCatRename.Text = "改名"
    $btnCatRename.Location = New-Object System.Drawing.Point(300, 83)
    $btnCatRename.Size = New-Object System.Drawing.Size(110, 35)
    $dlg.Controls.Add($btnCatRename)

    $btnCatDelete = New-Object System.Windows.Forms.Button
    $btnCatDelete.Text = "刪除"
    $btnCatDelete.Location = New-Object System.Drawing.Point(300, 128)
    $btnCatDelete.Size = New-Object System.Drawing.Size(110, 35)
    $dlg.Controls.Add($btnCatDelete)

    $btnCatColor = New-Object System.Windows.Forms.Button
    $btnCatColor.Text = "改顏色"
    $btnCatColor.Location = New-Object System.Drawing.Point(300, 173)
    $btnCatColor.Size = New-Object System.Drawing.Size(110, 35)
    $dlg.Controls.Add($btnCatColor)

    $btnCatPrivate = New-Object System.Windows.Forms.Button
    $btnCatPrivate.Text = "設成私密"
    $btnCatPrivate.Location = New-Object System.Drawing.Point(300, 213)
    $btnCatPrivate.Size = New-Object System.Drawing.Size(110, 35)
    $dlg.Controls.Add($btnCatPrivate)

    $btnCatClose = New-Object System.Windows.Forms.Button
    $btnCatClose.Text = "關閉"
    $btnCatClose.Location = New-Object System.Drawing.Point(300, 253)
    $btnCatClose.Size = New-Object System.Drawing.Size(110, 35)
    $btnCatClose.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $dlg.Controls.Add($btnCatClose)
    $dlg.CancelButton = $btnCatClose

    $lblCatHint = New-Object System.Windows.Forms.Label
    $lblCatHint.Text = "・改名：用到這個分類的鬧鐘會一起改名`n・改顏色：主畫面的分類標題和鬧鐘都會用這個顏色`n・刪除：鬧鐘不會被刪，會變成「未分類」`n・「未分類」固定灰色，不能改名或刪除"
    $lblCatHint.Location = New-Object System.Drawing.Point(15, 296)
    $lblCatHint.Size = New-Object System.Drawing.Size(400, 74)
    $lblCatHint.ForeColor = [System.Drawing.Color]::Gray
    $dlg.Controls.Add($lblCatHint)

    # 清單裡每一列對應的分類名稱
    $script:catNames = @()
    function Refresh-CategoryList([string]$select) {
        $script:alarms = @(Load-Alarms)
        $counts = @(Get-CategoryCounts $script:alarms $script:settings.categories)
        $script:settings.categoryColors = Update-CategoryColors (@($counts | ForEach-Object { $_.Name })) $script:settings.categoryColors
        try { Write-AppSettings $settingsPath $script:settings } catch {}
        $lbCats.Items.Clear()
        $script:catNames = @()
        foreach ($c in $counts) {
            $lock = ""
            if (@($script:settings.privateCategories) -contains $c.Name) { $lock = "　[私密]" }
            $lbCats.Items.Add("$($c.Name)（$($c.Count)）$lock") | Out-Null
            $script:catNames += $c.Name
        }
        $i = [Array]::IndexOf($script:catNames, $select)
        if ($i -ge 0) { $lbCats.SelectedIndex = $i } elseif ($lbCats.Items.Count -gt 0) { $lbCats.SelectedIndex = 0 }
    }

    function Get-SelectedCategoryName {
        if ($lbCats.SelectedIndex -lt 0) { return $null }
        return $script:catNames[$lbCats.SelectedIndex]
    }

    $btnCatAdd.Add_Click({
        $name = Show-TextInputDialog $dlg "$($script:AppName) - 新增分類" "新分類的名字（例如 工作、家裡、孩子）：" ""
        if ($null -eq $name) { return }
        $name = "$name".Trim()
        if ($name -eq "" -or $name -eq $script:DefaultCategory) { return }
        $cats = @($script:settings.categories)
        if ($cats -notcontains $name) {
            $script:settings.categories = $cats + $name
            try { Write-AppSettings $settingsPath $script:settings } catch {}
        }
        Refresh-CategoryList $name
    })

    $btnCatRename.Add_Click({
        $old = Get-SelectedCategoryName
        if ($null -eq $old) { return }
        if ($old -eq $script:DefaultCategory) {
            Show-AppMessage("「$($script:DefaultCategory)」不能改名。", "$($script:AppName)") | Out-Null
            return
        }
        $new = Show-TextInputDialog $dlg "$($script:AppName) - 分類改名" "把「$old」改成：" $old
        if ($null -eq $new) { return }
        $new = "$new".Trim()
        if ($new -eq $old) { return }
        if ($script:catNames -contains $new -and $new -ne $script:DefaultCategory) {
            $merge = Show-AppMessage("「$new」已經有了。要把「$old」底下的鬧鐘全部併到「$new」嗎？", "$($script:AppName) - 合併分類", [System.Windows.Forms.MessageBoxButtons]::YesNo)
            if ($merge -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        }
        # 先重讀檔案再改，免得蓋掉背景提醒剛寫進去的紀錄
        $fresh = @(Load-Alarms)
        $r = Rename-AlarmCategory $fresh $script:settings.categories $old $new
        if (-not $r.Ok) {
            Show-AppMessage($r.Error, "$($script:AppName)") | Out-Null
            return
        }
        if ($r.Changed -gt 0) { Save-Alarms $fresh }
        $script:settings.categories = $r.Categories
        $script:settings.categoryColors = Rename-CategoryColor $script:settings.categoryColors $old $new
        $script:settings.privateCategories = @(Rename-PrivateCategory $script:settings.privateCategories $old $new)
        try { Write-AppSettings $settingsPath $script:settings } catch {}
        Refresh-CategoryList $new
    })

    $btnCatDelete.Add_Click({
        $name = Get-SelectedCategoryName
        if ($null -eq $name) { return }
        if ($name -eq $script:DefaultCategory) {
            Show-AppMessage("「$($script:DefaultCategory)」不能刪除。", "$($script:AppName)") | Out-Null
            return
        }
        $fresh = @(Load-Alarms)
        $n = @($fresh | Where-Object { (Get-AlarmCategory $_) -eq $name }).Count
        $msg = "確定要刪除分類「$name」嗎？"
        if ($n -gt 0) { $msg = "$msg`n`n底下有 $n 個鬧鐘會變成「$($script:DefaultCategory)」（鬧鐘本身不會被刪）。" }
        else { $msg = "$msg`n`n底下沒有鬧鐘。" }
        $ok = Show-AppMessage($msg, "$($script:AppName) - 刪除分類", [System.Windows.Forms.MessageBoxButtons]::YesNo)
        if ($ok -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        $r = Remove-AlarmCategory $fresh $script:settings.categories $name
        if (-not $r.Ok) {
            Show-AppMessage($r.Error, "$($script:AppName)") | Out-Null
            return
        }
        if ($r.Changed -gt 0) { Save-Alarms $fresh }
        $script:settings.categories = $r.Categories
        $script:settings.categoryColors = Remove-CategoryColor $script:settings.categoryColors $name
        $script:settings.privateCategories = @(Remove-PrivateCategory $script:settings.privateCategories $name)
        try { Write-AppSettings $settingsPath $script:settings } catch {}
        Refresh-CategoryList $script:DefaultCategory
    })

    # 私密分類：底下所有鬧鐘都視為私密（開車不念內容、手機鎖定畫面不顯示內容）
    $btnCatPrivate.Add_Click({
        $name = Get-SelectedCategoryName
        if ($null -eq $name) { return }
        if ($name -eq $script:DefaultCategory) {
            Show-AppMessage("「$($script:DefaultCategory)」不能設成私密分類。要私密的話，請在鬧鐘本身勾「私密」。", "$($script:AppName)") | Out-Null
            return
        }
        if (@($script:settings.privateCategories) -contains $name) { $script:settings.privateCategories = @(Remove-PrivateCategory $script:settings.privateCategories $name) }
        else { $script:settings.privateCategories = @(Get-CleanPrivateCategories (@($script:settings.privateCategories) + $name)) }
        try { Write-AppSettings $settingsPath $script:settings } catch {}
        Refresh-CategoryList $name
    })

    $lbCats.Add_SelectedIndexChanged({
        $n = Get-SelectedCategoryName
        if ($null -ne $n -and @($script:settings.privateCategories) -contains $n) { $btnCatPrivate.Text = "取消私密" } else { $btnCatPrivate.Text = "設成私密" }
    })

    $btnCatColor.Add_Click({
        $name = Get-SelectedCategoryName
        if ($null -eq $name) { return }
        if ($name -eq $script:DefaultCategory) {
            Show-AppMessage("「$($script:DefaultCategory)」固定是灰色，不能改顏色。", "$($script:AppName)") | Out-Null
            return
        }
        $cur = Get-CategoryColorOf $name $script:settings.categoryColors
        $pick = Show-CategoryColorPicker $dlg $name $cur
        if ($null -eq $pick -or $pick -eq $cur) { return }
        $script:settings.categoryColors[$name] = $pick
        try { Write-AppSettings $settingsPath $script:settings } catch {}
        $lbCats.Invalidate()
    })

    $lbCats.Add_DoubleClick({ $btnCatRename.PerformClick() })

    Refresh-CategoryList $null
    Complete-AppForm $dlg
    $dlg.ShowDialog($form) | Out-Null
    $dlg.Dispose()
}

$btnAddCategory.Add_Click({
    Show-CategoryManager
    $script:alarms = @(Load-Alarms)
    Refresh-List
})

# 換字體大小／外觀：存起來，設定視窗重新打開一次套用（提醒視窗下次跳出來就會用新的設定）
function Save-AppearanceAndReopen {
    $newFont = $script:fontSizeKeys[[Math]::Max(0, $cmbFontSize.SelectedIndex)]
    $newTheme = $script:themeKeys[[Math]::Max(0, $cmbTheme.SelectedIndex)]
    $newBold = [bool]$chkBold.Checked
    if ($newFont -eq $script:settings.fontSize -and $newTheme -eq $script:settings.theme -and $newBold -eq [bool]$script:settings.bold) { return }
    $script:settings.fontSize = $newFont
    $script:settings.bold = $newBold
    $script:settings.theme = $newTheme
    try { Write-AppSettings $settingsPath $script:settings } catch {}
    try {
        Start-AppScript "Alarm_Manager_GUI.ps1"
        $form.Close()
    } catch {
        Show-AppMessage("已經記住了，下次打開設定視窗就會套用。", "$($script:AppName)") | Out-Null
    }
}
$cmbFontSize.Add_SelectionChangeCommitted({ Save-AppearanceAndReopen })
$cmbTheme.Add_SelectionChangeCommitted({ Save-AppearanceAndReopen })
$chkBold.Add_Click({ Save-AppearanceAndReopen })

$btnAbout.Add_Click({ Show-AboutDialog $form })

$listView.Add_DoubleClick({ $btnEdit.PerformClick() })

$btnAdd.Add_Click({
    $result = Show-AlarmDialog $null
    if ($result) {
        # 先重讀一次檔案，免得蓋掉背景提醒剛寫進去的「已完成」紀錄
        $script:alarms = @(Load-Alarms)
        $newId = 1
        if ($script:alarms.Count -gt 0) { $newId = ($script:alarms | Measure-Object -Property id -Maximum).Maximum + 1 }
        $result | Add-Member -NotePropertyName id -NotePropertyValue $newId -Force
        $result | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @() -Force
        $result | Add-Member -NotePropertyName createdDate -NotePropertyValue ((Get-Date).ToString("yyyy-MM-dd")) -Force
        Set-AlarmArmed $result (Get-Date)      # 從建立這一刻起算生效
        $script:alarms = @($script:alarms) + $result
        Save-Alarms $script:alarms
        Refresh-List
    }
})

$btnEdit.Add_Click({
    if ($listView.SelectedIndices.Count -eq 0) {
        Show-AppMessage("請先選擇一個鬧鐘", "$($script:AppName)") | Out-Null
        return
    }
    $idx = Get-SelectedAlarmIndex
    if ($idx -lt 0) {
        Show-AppMessage("請先選擇一個鬧鐘（分類標題那一列不能編輯）", "$($script:AppName)") | Out-Null
        return
    }
    $existing = $script:alarms[$idx]
    $result = Show-AlarmDialog $existing
    if ($result) {
        # 先重讀一次檔案，免得蓋掉背景提醒剛寫進去的「已完成」紀錄
        $editId = $existing.id
        $script:alarms = @(Load-Alarms)
        $idx = -1
        for ($i = 0; $i -lt $script:alarms.Count; $i++) { if ("$($script:alarms[$i].id)" -eq "$editId") { $idx = $i } }
        if ($idx -lt 0) {
            Show-AppMessage("這個鬧鐘好像已經被刪掉了，沒有存。", "$($script:AppName)") | Out-Null
            Refresh-List
            return
        }
        $existing = $script:alarms[$idx]
        $todayKey = (Get-Date).ToString("yyyy-MM-dd")
        $preservedDates = @($existing.triggeredDates | Where-Object { $_ -ne $todayKey })
        $result | Add-Member -NotePropertyName id -NotePropertyValue $existing.id -Force
        $result | Add-Member -NotePropertyName triggeredDates -NotePropertyValue $preservedDates -Force
        if ($null -ne $existing.createdDate -and $existing.createdDate -ne "") {
            $result | Add-Member -NotePropertyName createdDate -NotePropertyValue $existing.createdDate -Force
        }
        if ($existing.type -eq "interval" -and $result.type -eq "interval" -and $null -ne $existing.nextDueDate -and $existing.nextDueDate -ne "") {
            $result | Add-Member -NotePropertyName nextDueDate -NotePropertyValue $existing.nextDueDate -Force
        }
        # 改了時間／類型／日期：從現在起算生效，不補已經過的時刻（沒改排程就沿用原本的生效時間）
        if (-not (Test-SameSchedule $existing $result)) { Set-AlarmArmed $result (Get-Date) }
        # 舊鬧鐘有、這次沒填到的欄位照留（例如別的版本加的欄位），不讓資料在編輯時掉了
        $result = Copy-MissingAlarmFields $existing $result
        $script:alarms[$idx] = $result
        Save-Alarms $script:alarms
        Refresh-List
    }
})

$btnDelete.Add_Click({
    if ($listView.SelectedIndices.Count -eq 0) {
        Show-AppMessage("請先選擇一個鬧鐘", "$($script:AppName)") | Out-Null
        return
    }
    $idx = Get-SelectedAlarmIndex
    if ($idx -lt 0) {
        Show-AppMessage("請先選擇一個鬧鐘（分類標題那一列不能編輯）", "$($script:AppName)") | Out-Null
        return
    }
    $confirm = Show-AppMessage("確定要刪除「$($script:alarms[$idx].label)」這個鬧鐘嗎？", "$($script:AppName) - 確認刪除", [System.Windows.Forms.MessageBoxButtons]::YesNo)
    if ($confirm -eq [System.Windows.Forms.DialogResult]::Yes) {
        $targetId = $script:alarms[$idx].id
        # 先重讀一次檔案，免得蓋掉背景提醒剛寫進去的「已完成」紀錄
        $script:alarms = @(Load-Alarms)
        $script:alarms = @($script:alarms | Where-Object { $_.id -ne $targetId })
        Save-Alarms $script:alarms
        Refresh-List
    }
})

# ---------- v1.3 匯出／匯入 ----------

# 問要「全部取代」還是「合併」：回傳 "replace" / "merge"，按取消回傳 $null
function Show-ImportModeDialog($owner, [int]$count, [string]$exportedAt) {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 匯入鬧鐘"
    $dlg.Size = New-Object System.Drawing.Size(500, 300)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $when = ""
    if ("$exportedAt" -ne "") { $when = "（匯出時間：$exportedAt）" }
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = "這個檔案裡有 $count 個鬧鐘$when。要怎麼匯入？`n`n" +
        "・全部取代：目前的鬧鐘換成檔案裡的。換之前會自動備份目前的鬧鐘（alarms_匯入前備份_時間.json，跟 alarms.json 放在一起）。`n`n" +
        "・合併：目前的鬧鐘都留著，只把檔案裡「這邊還沒有的」加進來；同一個鬧鐘不會重複加。"
    $lbl.Location = New-Object System.Drawing.Point(15, 12)
    $lbl.Size = New-Object System.Drawing.Size(455, 170)
    $dlg.Controls.Add($lbl)

    $btnReplace = New-Object System.Windows.Forms.Button
    $btnReplace.Text = "全部取代"
    $btnReplace.Location = New-Object System.Drawing.Point(15, 200)
    $btnReplace.Size = New-Object System.Drawing.Size(140, 38)
    $btnReplace.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    $dlg.Controls.Add($btnReplace)

    $btnMerge = New-Object System.Windows.Forms.Button
    $btnMerge.Text = "合併"
    $btnMerge.Location = New-Object System.Drawing.Point(170, 200)
    $btnMerge.Size = New-Object System.Drawing.Size(140, 38)
    $btnMerge.DialogResult = [System.Windows.Forms.DialogResult]::No
    $dlg.Controls.Add($btnMerge)

    $btnCancelImport = New-Object System.Windows.Forms.Button
    $btnCancelImport.Text = "取消"
    $btnCancelImport.Location = New-Object System.Drawing.Point(330, 200)
    $btnCancelImport.Size = New-Object System.Drawing.Size(140, 38)
    $btnCancelImport.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($btnCancelImport)
    $dlg.CancelButton = $btnCancelImport
    $dlg.AcceptButton = $btnMerge

    Complete-AppForm $dlg
    $r = $dlg.ShowDialog($owner)
    $dlg.Dispose()
    if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { return "replace" }
    if ($r -eq [System.Windows.Forms.DialogResult]::No) { return "merge" }
    return $null
}

$btnExport.Add_Click({
    try {
        # 先重讀一次檔案，匯出的才是最新的
        $fresh = @(Load-Alarms)
        $gdrive = Find-GoogleDriveFolder $null
        $dlgSave = New-Object System.Windows.Forms.SaveFileDialog
        $dlgSave.Filter = "真劍鬧鐘匯出檔 (*.json)|*.json|所有檔案 (*.*)|*.*"
        $dlgSave.DefaultExt = "json"
        $dlgSave.AddExtension = $true
        $dlgSave.OverwritePrompt = $true
        $dlgSave.FileName = Get-ExportFileName (Get-Date)
        if ($gdrive) {
            $dlgSave.InitialDirectory = $gdrive
            $dlgSave.Title = "匯出鬧鐘 —— 存在這裡（$gdrive）會自動上傳到 Google 雲端硬碟"
        } else {
            $dlgSave.InitialDirectory = [Environment]::GetFolderPath("Desktop")
            $dlgSave.Title = "匯出鬧鐘 —— 選一個地方存"
        }
        if ($dlgSave.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { $dlgSave.Dispose(); return }
        $path = $dlgSave.FileName
        $dlgSave.Dispose()
        $exp = Export-AlarmFile $path $fresh $script:settings.categories (Get-Date) $script:settings.categoryColors $script:settings.privateCategories
        $msg = "已匯出 $(@($exp.alarms).Count) 個鬧鐘到：`n$path"
        if ($gdrive -and $path.StartsWith($gdrive, [System.StringComparison]::OrdinalIgnoreCase)) {
            $msg = "$msg`n`n這個資料夾在 Google 雲端硬碟裡，會自動上傳。`n手機上打開真劍鬧鐘 →「匯入」→ 在檔案選擇器選「雲端硬碟」就找得到。"
        } else {
            $msg = "$msg`n`n要帶到手機：把這個檔案傳到手機（例如上傳到 Google 雲端硬碟），再從手機的真劍鬧鐘按「匯入」。"
        }
        $msg = "$msg`n`n（已完成紀錄、「真的沒空」的延後不會匯出，只匯出鬧鐘本身。）"
        Show-AppMessage($msg, "$($script:AppName) - 匯出完成") | Out-Null
    } catch {
        Show-AppMessage("匯出失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

$btnImport.Add_Click({
    try {
        $gdrive = Find-GoogleDriveFolder $null
        $dlgOpen = New-Object System.Windows.Forms.OpenFileDialog
        $dlgOpen.Filter = "真劍鬧鐘匯出檔 (*.json)|*.json|所有檔案 (*.*)|*.*"
        $dlgOpen.Title = "匯入鬧鐘 —— 選匯出的 .json 檔"
        if ($gdrive) { $dlgOpen.InitialDirectory = $gdrive } else { $dlgOpen.InitialDirectory = [Environment]::GetFolderPath("Desktop") }
        if ($dlgOpen.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { $dlgOpen.Dispose(); return }
        $path = $dlgOpen.FileName
        $dlgOpen.Dispose()

        $r = Read-AlarmExport $path
        if (-not $r.Ok) {
            Show-AppMessage($r.Error, "$($script:AppName) - 沒有匯入") | Out-Null
            return
        }
        $mode = Show-ImportModeDialog $form (@($r.Alarms).Count) $r.ExportedAt
        if ($null -eq $mode) { return }

        $now = Get-Date
        if ($mode -eq "replace") {
            $bk = Backup-AlarmFileBeforeImport $jsonPath $now
            $newAlarms = @(Get-ReplacedAlarms $r.Alarms $now)
            Save-Alarms $newAlarms
            $script:settings.categories = @(Merge-CategoryLists $r.Categories @())
            $script:settings.categoryColors = $r.Colors            # 全部取代：顏色也換成檔案裡的（沒帶顏色的之後自動補）
            $script:settings.privateCategories = @($r.PrivateCats)  # 私密分類也換成檔案裡的
            try { Write-AppSettings $settingsPath $script:settings } catch {}
            $msg = "已全部取代成檔案裡的 $($newAlarms.Count) 個鬧鐘。"
            if ($bk) { $msg = "$msg`n`n原本的鬧鐘備份在：`n$bk" }
        } else {
            # 先重讀一次檔案，免得蓋掉背景提醒剛寫進去的「已完成」紀錄
            $fresh = @(Load-Alarms)
            $m = Merge-ImportedAlarms $fresh $r.Alarms $now
            Save-Alarms @($m.Alarms)
            $script:settings.categories = @(Merge-CategoryLists $script:settings.categories $r.Categories)
            foreach ($k in @($r.Colors.Keys)) { if (-not $script:settings.categoryColors.ContainsKey($k)) { $script:settings.categoryColors[$k] = $r.Colors[$k] } }   # 合併：本機已經有顏色的分類不動
            $script:settings.privateCategories = @(Get-CleanPrivateCategories (@($script:settings.privateCategories) + @($r.PrivateCats)))   # 合併：私密只增不減（隱私優先）
            try { Write-AppSettings $settingsPath $script:settings } catch {}
            $msg = "合併完成：新增 $($m.Added) 個鬧鐘"
            if ($m.Renumbered -gt 0) { $msg = "$msg（其中 $($m.Renumbered) 個跟這邊的編號撞到、內容不同，當成新鬧鐘加入）" }
            $msg = "$msg；$($m.Skipped) 個這邊本來就有，沒有重複加。"
        }
        $msg = "$msg`n`n已經過去的提醒不會一次全部跳出來，從下一次開始照常響。"
        $script:alarms = @(Load-Alarms)
        Refresh-List
        Show-AppMessage($msg, "$($script:AppName) - 匯入完成") | Out-Null
    } catch {
        Show-AppMessage("匯入失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

# ---------- v1.5 Google 帳號同步 ----------
# 同步本身的邏輯在 AlarmSync.ps1（有測試）；這裡只有視窗。背景提醒程式（Alarm_Tray.ps1）每 15 分鐘會自己同步一次。
$script:syncCancel = $false

function Update-AfterSync($res) {
    if ($res.Changed) {
        $script:alarms = @(Load-Alarms)
        $script:settings = Read-AppSettings $settingsPath
        Refresh-List
    }
}

function Show-SyncDialog($owner) {
    $ctx = Get-SyncContext $PSScriptRoot
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 同步"
    $dlg.Size = New-Object System.Drawing.Size(520, 420)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $lblInfo = New-Object System.Windows.Forms.Label
    $lblInfo.Text = "用你自己的 Google 帳號登入後，電腦和手機的鬧鐘會自動保持一樣：新增、修改、刪除，連「已完成」「真的沒空」也一起同步（手機按了已完成，電腦就不會再催）。`n`n" +
        "資料只放在你自己 Google 雲端硬碟裡、這個 App 專用的隱藏資料夾，作者和別人都看不到。Google 的授權畫面只會問「存取這個 App 自己的資料」這一項。`n`n" +
        "沒登入的話，真劍鬧鐘照常運作，只是不同步。"
    $lblInfo.Location = New-Object System.Drawing.Point(15, 12)
    $lblInfo.Size = New-Object System.Drawing.Size(470, 170)
    $dlg.Controls.Add($lblInfo)

    $lblStatus = New-Object System.Windows.Forms.Label
    $lblStatus.Location = New-Object System.Drawing.Point(15, 190)
    $lblStatus.Size = New-Object System.Drawing.Size(470, 100)
    $lblStatus.Font = New-Object System.Drawing.Font($lblStatus.Font, [System.Drawing.FontStyle]::Bold)
    $dlg.Controls.Add($lblStatus)

    $btnLogin = New-Object System.Windows.Forms.Button
    $btnLogin.Text = "用 Google 帳號登入"
    $btnLogin.Location = New-Object System.Drawing.Point(15, 300)
    $btnLogin.Size = New-Object System.Drawing.Size(200, 38)
    $dlg.Controls.Add($btnLogin)

    $btnNow = New-Object System.Windows.Forms.Button
    $btnNow.Text = "立即同步"
    $btnNow.Location = New-Object System.Drawing.Point(15, 300)
    $btnNow.Size = New-Object System.Drawing.Size(140, 38)
    $dlg.Controls.Add($btnNow)

    $btnLogout = New-Object System.Windows.Forms.Button
    $btnLogout.Text = "登出"
    $btnLogout.Location = New-Object System.Drawing.Point(165, 300)
    $btnLogout.Size = New-Object System.Drawing.Size(120, 38)
    $dlg.Controls.Add($btnLogout)

    $btnCloseSync = New-Object System.Windows.Forms.Button
    $btnCloseSync.Text = "關閉"
    $btnCloseSync.Location = New-Object System.Drawing.Point(385, 300)
    $btnCloseSync.Size = New-Object System.Drawing.Size(100, 38)
    $btnCloseSync.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($btnCloseSync)
    $dlg.CancelButton = $btnCloseSync

    $refresh = {
        $signed = Test-GoogleSignedIn $ctx.TokenPath
        $lblStatus.Text = (@(Get-SyncStatusLines $ctx.StatePath $ctx.TokenPath) -join "`n")
        $btnLogin.Visible = (-not $signed)
        $btnNow.Visible = $signed
        $btnLogout.Visible = $signed
    }

    $syncNow = {
        $btnNow.Enabled = $false; $btnLogout.Enabled = $false
        $lblStatus.Text = "同步中…"
        [System.Windows.Forms.Application]::DoEvents()
        $res = Invoke-SyncRunWithRetry $ctx
        Update-AfterSync $res
        & $refresh
        $btnNow.Enabled = $true; $btnLogout.Enabled = $true
        if (-not $res.Ok) { Show-AppMessage($res.Error, "$($script:AppName) - 同步沒有成功") | Out-Null }
        return $res
    }

    $btnLogin.Add_Click({
        if ($btnLogin.Text -eq "取消登入") { $script:syncCancel = $true; return }
        $script:syncCancel = $false
        $btnLogin.Text = "取消登入"
        $lblStatus.Text = "已經用瀏覽器打開 Google 的登入畫面。請在那裡選帳號、按「允許」。`n登入完成後回到這裡。"
        try {
            Invoke-GoogleLogin $ctx.ClientPath $ctx.TokenPath $null { [System.Windows.Forms.Application]::DoEvents() } { $script:syncCancel } 180
            $btnLogin.Text = "用 Google 帳號登入"
            & $refresh
            $dlg.Activate()
            & $syncNow | Out-Null
        } catch {
            $info = Get-SyncErrorInfo $_
            $btnLogin.Text = "用 Google 帳號登入"
            & $refresh
            $dlg.Activate()
            if ($info.Text -ne "已取消登入。") { Show-AppMessage($info.Text, "$($script:AppName) - 登入沒有成功") | Out-Null }
        }
    })
    $btnNow.Add_Click({ & $syncNow | Out-Null })
    $btnLogout.Add_Click({
        $ans = Show-AppMessage("登出之後，這台電腦就不再同步。雲端上的資料和這台電腦上的鬧鐘都不會被刪掉。`n`n要登出嗎？", "$($script:AppName) - 登出", [System.Windows.Forms.MessageBoxButtons]::YesNo)
        if ($ans -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        Invoke-GoogleLogout $ctx.TokenPath
        Clear-SyncState $ctx.StatePath
        & $refresh
    })

    & $refresh
    Complete-AppForm $dlg
    if ($null -ne $owner) { $dlg.ShowDialog($owner) | Out-Null } else { $dlg.ShowDialog() | Out-Null }
    $script:syncCancel = $true
    $dlg.Dispose()
}

$btnSync.Add_Click({
    try { Show-SyncDialog $form } catch { Show-AppMessage("同步視窗發生錯誤：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null }
})

# ---------- v1.6 一鍵更新 ----------
# 更新的邏輯在 AlarmUpdate.ps1（有測試）；這裡只有視窗。流程：檢查 → 顯示說明 → 按「更新」→ 下載 → 核對指紋 → 關掉程式 → 換檔 → 自動重開。
$script:updateStatePath = Join-Path $PSScriptRoot "update_state.json"
$script:updateDotColor = $null

function Update-UpdateButton {
    $a = $null
    try { $a = Get-UpdateAvailableFromState $script:updateStatePath $script:AppVersion } catch {}
    if ($null -ne $a) {
        $btnUpdate.Text = "● 有新版"
        if ($null -eq $script:updateDotColor) { $script:updateDotColor = Get-StatusColor "bad" }
        $btnUpdate.ForeColor = $script:updateDotColor
    } else {
        $btnUpdate.Text = "檢查更新"
        $btnUpdate.ForeColor = $btnSync.ForeColor
    }
}

function Show-UpdateDialog($owner) {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 檢查更新"
    $dlg.Size = New-Object System.Drawing.Size(520, 400)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $lblVer = New-Object System.Windows.Forms.Label
    $lblVer.Text = "目前的版本：v$($script:AppVersion)"
    $lblVer.Location = New-Object System.Drawing.Point(15, 12)
    $lblVer.Size = New-Object System.Drawing.Size(470, 24)
    $dlg.Controls.Add($lblVer)

    $lblStatus = New-Object System.Windows.Forms.Label
    $lblStatus.Text = "正在看有沒有新版…"
    $lblStatus.Location = New-Object System.Drawing.Point(15, 42)
    $lblStatus.Size = New-Object System.Drawing.Size(470, 24)
    $lblStatus.Font = New-Object System.Drawing.Font($lblStatus.Font, [System.Drawing.FontStyle]::Bold)
    $dlg.Controls.Add($lblStatus)

    $txtNotes = New-Object System.Windows.Forms.TextBox
    $txtNotes.Multiline = $true
    $txtNotes.ReadOnly = $true
    $txtNotes.ScrollBars = "Vertical"
    $txtNotes.Location = New-Object System.Drawing.Point(15, 72)
    $txtNotes.Size = New-Object System.Drawing.Size(470, 150)
    $dlg.Controls.Add($txtNotes)

    $prog = New-Object System.Windows.Forms.ProgressBar
    $prog.Location = New-Object System.Drawing.Point(15, 232)
    $prog.Size = New-Object System.Drawing.Size(470, 18)
    $prog.Visible = $false
    $dlg.Controls.Add($prog)

    $lblHint = New-Object System.Windows.Forms.Label
    $lblHint.Text = "更新會把背景提醒程式和這個視窗關掉再自動重開；你的鬧鐘、設定、同步登入都會保留（更新前也會自動備份一份）。"
    $lblHint.Location = New-Object System.Drawing.Point(15, 256)
    $lblHint.Size = New-Object System.Drawing.Size(470, 50)
    $dlg.Controls.Add($lblHint)

    $btnGo = New-Object System.Windows.Forms.Button
    $btnGo.Text = "更新"
    $btnGo.Location = New-Object System.Drawing.Point(15, 315)
    $btnGo.Size = New-Object System.Drawing.Size(140, 38)
    $btnGo.Visible = $false
    $dlg.Controls.Add($btnGo)

    $btnRecheck = New-Object System.Windows.Forms.Button
    $btnRecheck.Text = "再檢查一次"
    $btnRecheck.Location = New-Object System.Drawing.Point(165, 315)
    $btnRecheck.Size = New-Object System.Drawing.Size(140, 38)
    $dlg.Controls.Add($btnRecheck)

    $btnCloseUpd = New-Object System.Windows.Forms.Button
    $btnCloseUpd.Text = "關閉"
    $btnCloseUpd.Location = New-Object System.Drawing.Point(385, 315)
    $btnCloseUpd.Size = New-Object System.Drawing.Size(100, 38)
    $btnCloseUpd.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($btnCloseUpd)
    $dlg.CancelButton = $btnCloseUpd

    $state = @{ Check = $null; Busy = $false }

    $doCheck = {
        $btnGo.Visible = $false; $btnRecheck.Enabled = $false
        $lblStatus.Text = "正在看有沒有新版…"; $txtNotes.Text = ""
        [System.Windows.Forms.Application]::DoEvents()
        $r = Invoke-UpdateCheck $script:AppVersion
        $state.Check = $r
        if ($r.State -eq "available") {
            $lblStatus.Text = "有新版：v$($r.Version)"
            $txtNotes.Text = ("更新內容：`r`n" + ("$($r.Notes)" -replace "`r?`n", "`r`n"))
            $btnGo.Visible = $true
        } elseif ($r.State -eq "latest") {
            $lblStatus.Text = "已經是最新版了。"
            $txtNotes.Text = ""
        } else {
            $lblStatus.Text = "沒有檢查成功"
            $txtNotes.Text = "$($r.Error)"
        }
        # 順手更新「每天檢查」的記錄，主畫面的小紅點才會跟著變
        try {
            $s = Read-UpdateState $script:updateStatePath
            if ($r.State -ne "error") {
                $s.lastCheckDate = (Get-Date).ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
                if ($r.State -eq "available") { $s.availableVersion = $r.Version; $s.availableNotes = $r.Notes } else { $s.availableVersion = ""; $s.availableNotes = "" }
                Write-UpdateState $script:updateStatePath $s
            }
        } catch {}
        Update-UpdateButton
        $btnRecheck.Enabled = $true
    }

    $btnRecheck.Add_Click({ & $doCheck })
    $dlg.Add_Shown({ & $doCheck })

    $btnGo.Add_Click({
        $r = $state.Check
        if ($null -eq $r -or $r.State -ne "available" -or $state.Busy) { return }
        $ans = Show-AppMessage("要更新到 v$($r.Version) 嗎？`n`n更新時會把背景提醒程式和這個視窗關掉，換好檔案後自動重開（大約十幾秒）。你的鬧鐘、設定、同步登入都會保留，更新前也會自動備份一份。", "$($script:AppName) - 更新", [System.Windows.Forms.MessageBoxButtons]::YesNo)
        if ($ans -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        $state.Busy = $true
        $btnGo.Enabled = $false; $btnRecheck.Enabled = $false; $btnCloseUpd.Enabled = $false
        $prog.Visible = $true; $prog.Value = 0
        $lblStatus.Text = "下載中…"
        [System.Windows.Forms.Application]::DoEvents()
        try {
            $pkg = Get-UpdatePackage $r { param($done, $total)
                if ($total -gt 0) { $prog.Value = [Math]::Min(100, [int](100.0 * $done / $total)); $lblStatus.Text = "下載中… $([int](100.0 * $done / $total))%" }
                [System.Windows.Forms.Application]::DoEvents()
            }
            $lblStatus.Text = "下載完成、指紋核對過了，準備換檔…"
            [System.Windows.Forms.Application]::DoEvents()
            $waitPids = @($PID)
            try { $tp = [int](Get-Content -LiteralPath (Join-Path $PSScriptRoot "tray.pid") -ErrorAction Stop | Select-Object -First 1); if ($tp -gt 0) { $waitPids += $tp } } catch {}
            Start-UpdateApply $PSScriptRoot $pkg.NewAppDir $pkg.StagingRoot $script:AppVersion $r.Version $waitPids | Out-Null
            $form.Close()
            [System.Windows.Forms.Application]::Exit()
            return
        } catch {
            $info = Get-UpdateErrorInfo $_
            $lblStatus.Text = "更新沒有成功"
            $txtNotes.Text = $info.Text
            $prog.Visible = $false
            $btnGo.Enabled = $true; $btnRecheck.Enabled = $true; $btnCloseUpd.Enabled = $true
            $state.Busy = $false
            if ($info.Kind -eq "hash") { Show-AppMessage($info.Text, "$($script:AppName) - 為了安全沒有更新") | Out-Null }
        }
    })

    Complete-AppForm $dlg
    if ($null -ne $owner) { $dlg.ShowDialog($owner) | Out-Null } else { $dlg.ShowDialog() | Out-Null }
    $dlg.Dispose()
}

$btnUpdate.Add_Click({
    try { Show-UpdateDialog $form } catch { Show-AppMessage("更新視窗發生錯誤：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null }
})

$btnClose.Add_Click({ $form.Close() })

# 大字／深色（v1.1）：先套用，再記下各欄的原寬度、最小視窗大小
Complete-AppForm $form
$script:baseColumnWidths = @($listView.Columns | ForEach-Object { $_.Width })
Update-ContentColumnWidth

Refresh-List
Update-StartupStatus
Update-UpdateButton

if (-not (Test-TrayRunning)) {
    try {
        Start-AppScript "Alarm_Tray.ps1"
        Start-Sleep -Milliseconds 800
    } catch {}
}
Update-TrayStatus

[System.Windows.Forms.Application]::Run($form)

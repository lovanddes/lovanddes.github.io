@echo off
rem Shinken Alarm launcher (no .vbs). This file is ASCII only on purpose.
rem Unblock-File + start the tray icon hidden. If already running, opens the settings window.
start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0app\Setup.ps1" -Action Launch
exit /b 0

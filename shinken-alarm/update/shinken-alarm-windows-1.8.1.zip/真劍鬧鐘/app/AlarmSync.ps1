﻿# 真劍鬧鐘 v1.5：用 Google 帳號登入、把鬧鐘同步到「自己雲端硬碟的 App 專用隱藏資料夾」（drive.appdata）
# 不碰 Windows Forms 的純邏輯 + 網路呼叫；設定視窗、背景提醒、tests.ps1 都用 . 載入這支（要先載入 AlarmCore.ps1）。
# 注意：只能用 Windows PowerShell 5.1 有的語法（不要 ??、?.、三元運算子）。
#
# 做法（規格在 交件說明_真劍鬧鐘.md 的「同步規則」）：
#   每台裝置在 appDataFolder 裡寫自己的檔 devices/<裝置代號>.json（內容＝這台裝置合併後看到的全部），
#   讀的時候把所有裝置的檔合併：逐個鬧鐘比 updatedAt（新的贏），刪除留墓碑 30 天，
#   「已完成」「真的沒空」跟著走，分類以最後改的為準。時間一律 UTC。
#   同步只是加分：網路斷、登入失效、Google 回錯 → 白話提示，鬧鐘照常運作，本機資料絕不因為同步失敗而被弄壞。

$script:SyncFormat = "shinken-alarm-sync"
$script:SyncVersion = 2
$script:SyncEpoch = "1970-01-01T00:00:00.000Z"
$script:SyncTombstoneDays = 30
$script:SyncDoneKeepDays = 60
$script:SyncStateFields = @("triggeredDates", "snoozes", "lastTriggered", "lastTriggeredAt", "lastRang", "lastRangAt", "armedLocal")

# ---------- 時間（一律 UTC） ----------

function ConvertTo-SyncTime([DateTime]$when) {
    return $when.ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'", [System.Globalization.CultureInfo]::InvariantCulture)
}

# 收各種寫法（Z、+08:00、有沒有小數）；讀不懂回傳 $null
function ConvertFrom-SyncTime($value) {
    if ($null -eq $value) { return $null }
    if ($value -is [DateTime]) { return $value.ToUniversalTime() }
    try {
        $styles = [System.Globalization.DateTimeStyles]::AssumeUniversal -bor [System.Globalization.DateTimeStyles]::AdjustToUniversal
        return [DateTimeOffset]::Parse("$value", [System.Globalization.CultureInfo]::InvariantCulture, $styles).UtcDateTime
    } catch { return $null }
}

function Get-SyncDateKey([DateTime]$utc) { return $utc.ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture) }

# ---------- JSON 小工具 ----------

# PowerShell 7 的 ConvertFrom-Json 會把 ISO 時間字串自動變成 DateTime（5.1 不會），寫回去格式就變了。
# 先在這種字串前面加記號、讀完再拿掉，兩種版本都保證是原本的字串。
function ConvertFrom-SyncJson([string]$text) {
    if ($null -ne $text -and $text.Length -gt 0 -and [int][char]$text[0] -eq 0xFEFF) { $text = $text.Substring(1) }
    $marked = [regex]::Replace($text, '"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}[^"\\]*)"', '"~DT~$1"')
    $obj = $marked | ConvertFrom-Json
    return (Restore-SyncStrings $obj)
}

function Restore-SyncStrings($v) {
    if ($null -eq $v) { return $null }
    if ($v -is [string]) { if ($v.StartsWith("~DT~")) { return $v.Substring(4) } else { return $v } }
    if ($v -is [System.Array]) {
        $out = @()
        foreach ($x in $v) { $out += , (Restore-SyncStrings $x) }
        return , $out
    }
    if ($v -is [System.Management.Automation.PSCustomObject]) {
        foreach ($p in @($v.PSObject.Properties)) { $v.PSObject.Properties[$p.Name].Value = (Restore-SyncStrings $p.Value) }
        return $v
    }
    return $v
}

# 鍵排序、不留空白的 JSON：拿來算雜湊、比對結果（跟 Android 版的順序無關）
function ConvertTo-SyncCanonicalJson($v) {
    if ($null -eq $v) { return "null" }
    if ($v -is [string]) { return (ConvertTo-Json -InputObject ([string]$v) -Compress) }
    if ($v -is [bool]) { if ($v) { return "true" } else { return "false" } }
    if ($v -is [DateTime]) { return (ConvertTo-Json -InputObject (ConvertTo-SyncTime $v) -Compress) }
    if ($v -is [int] -or $v -is [long] -or $v -is [int16] -or $v -is [byte]) { return ([string]$v) }
    if ($v -is [double] -or $v -is [single] -or $v -is [decimal]) {
        $d = [double]$v
        if ($d -eq [math]::Floor($d) -and [math]::Abs($d) -lt 1e15) { return ([long]$d).ToString([System.Globalization.CultureInfo]::InvariantCulture) }
        return $d.ToString("R", [System.Globalization.CultureInfo]::InvariantCulture)
    }
    if ($v -is [System.Collections.IDictionary]) {
        $keys = @($v.Keys | ForEach-Object { "$_" })
        [Array]::Sort($keys, [StringComparer]::Ordinal)
        $parts = @()
        foreach ($k in $keys) { $parts += ((ConvertTo-Json -InputObject $k -Compress) + ":" + (ConvertTo-SyncCanonicalJson $v[$k])) }
        return "{" + ($parts -join ",") + "}"
    }
    if ($v -is [System.Management.Automation.PSCustomObject]) {
        $keys = @($v.PSObject.Properties | ForEach-Object { $_.Name })
        [Array]::Sort($keys, [StringComparer]::Ordinal)
        $parts = @()
        foreach ($k in $keys) { $parts += ((ConvertTo-Json -InputObject $k -Compress) + ":" + (ConvertTo-SyncCanonicalJson $v.PSObject.Properties[$k].Value)) }
        return "{" + ($parts -join ",") + "}"
    }
    if ($v -is [System.Collections.IEnumerable]) {
        $parts = @()
        foreach ($x in $v) { $parts += (ConvertTo-SyncCanonicalJson $x) }
        return "[" + ($parts -join ",") + "]"
    }
    return (ConvertTo-Json -InputObject ([string]$v) -Compress)
}

function Get-SyncHash($v) {
    $bytes = (New-Object System.Text.UTF8Encoding($false)).GetBytes((ConvertTo-SyncCanonicalJson $v))
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { return (($sha.ComputeHash($bytes) | ForEach-Object { $_.ToString("x2") }) -join "") } finally { $sha.Dispose() }
}

# 深拷貝（不經過 JSON 轉換：ConvertFrom-Json 會把空陣列變成 $null）
function Copy-SyncObject($v) {
    if ($null -eq $v) { return $null }
    if ($v -is [string] -or $v -is [bool] -or $v -is [int] -or $v -is [long] -or $v -is [double] -or $v -is [decimal] -or $v -is [byte] -or $v -is [int16] -or $v -is [single]) { return $v }
    if ($v -is [DateTime]) { return (ConvertTo-SyncTime $v) }
    if ($v -is [System.Collections.IDictionary]) {
        $o = New-Object PSObject
        foreach ($k in @($v.Keys)) { $o | Add-Member -NotePropertyName "$k" -NotePropertyValue (Copy-SyncObject $v[$k]) -Force }
        return $o
    }
    if ($v -is [System.Management.Automation.PSCustomObject]) {
        $o = New-Object PSObject
        foreach ($p in $v.PSObject.Properties) { $o | Add-Member -NotePropertyName $p.Name -NotePropertyValue (Copy-SyncObject $p.Value) -Force }
        return $o
    }
    if ($v -is [System.Collections.IEnumerable]) {
        $out = @()
        foreach ($x in $v) { $out += , (Copy-SyncObject $x) }
        return , $out
    }
    return $v
}

function Get-SyncProp($o, [string]$name) {
    if ($null -eq $o) { return $null }
    $p = $o.PSObject.Properties[$name]
    if ($null -eq $p) { return $null }
    return $p.Value
}

# ---------- 合併（兩邊共用的規格；測試用 samples/sync_cases/*.json） ----------

# 同一個鬧鐘的兩筆，哪筆比較新：先比 updatedAt；一樣新 → 沒被刪的贏；還是一樣 → updatedBy 大的贏（兩邊算出來才會一樣）
function Test-SyncEntryBetter($a, $b) {
    $ta = ConvertFrom-SyncTime (Get-SyncProp $a "updatedAt")
    $tb = ConvertFrom-SyncTime (Get-SyncProp $b "updatedAt")
    if ($null -eq $ta) { $ta = [DateTime]::MinValue }
    if ($null -eq $tb) { $tb = [DateTime]::MinValue }
    if ($ta -ne $tb) { return ($ta -gt $tb) }
    $da = ((Get-SyncProp $a "deleted") -eq $true)
    $db = ((Get-SyncProp $b "deleted") -eq $true)
    if ($da -ne $db) { return (-not $da) }
    return ([String]::CompareOrdinal("$(Get-SyncProp $a 'updatedBy')", "$(Get-SyncProp $b 'updatedBy')") -gt 0)
}

function Merge-SyncDatasets($datasets, [DateTime]$now) {
    $nowUtc = $now.ToUniversalTime()
    $dsList = @($datasets | Where-Object { $null -ne $_ })

    # --- 鬧鐘 ---
    $best = @{}
    foreach ($ds in $dsList) {
        foreach ($e in @(Get-SyncProp $ds "alarms")) {
            if ($null -eq $e) { continue }
            $uid = "$(Get-SyncProp $e 'uid')"
            if ($uid -eq "") { continue }
            if (-not $best.ContainsKey($uid) -or (Test-SyncEntryBetter $e $best[$uid])) { $best[$uid] = $e }
        }
    }
    $uids = @($best.Keys | ForEach-Object { "$_" })
    [Array]::Sort($uids, [StringComparer]::Ordinal)
    $alarms = @()
    $alive = @{}
    foreach ($uid in $uids) {
        $e = $best[$uid]
        $t = ConvertFrom-SyncTime (Get-SyncProp $e "updatedAt")
        if ((Get-SyncProp $e "deleted") -eq $true -and $null -ne $t -and ($nowUtc - $t).TotalDays -gt $script:SyncTombstoneDays) { continue }
        $copy = Copy-SyncObject $e
        $alarms += , $copy
        if ((Get-SyncProp $e "deleted") -ne $true) { $alive[$uid] = $copy }
    }

    # --- 分類：整份以最後改的為準；顏色（colors）如果最後改的那份沒有，就用最近一份有顏色的；看不懂的欄位原樣保留 ---
    $cats = [PSCustomObject]@{ list = @(); updatedAt = $script:SyncEpoch }
    $bestC = $null
    $bestCT = $null
    $sorted = @($dsList | Sort-Object -Property @{ Expression = { "$(Get-SyncProp $_ 'deviceId')" } })
    # Sort-Object 的字串排序不分大小寫、看語系；這裡只是平手時的順序，裝置代號都是小寫英數，沒差
    foreach ($ds in $sorted) {
        $c = Get-SyncProp $ds "categories"
        if ($null -eq $c) { continue }
        $ct = ConvertFrom-SyncTime (Get-SyncProp $c "updatedAt")
        if ($null -eq $ct) { continue }
        if ($null -eq $bestC -or $ct -gt $bestCT) { $bestC = $c; $bestCT = $ct }
    }
    if ($null -ne $bestC) {
        $cats = Copy-SyncObject $bestC
        $l = @()
        foreach ($x in @(Get-SyncProp $bestC "list")) { if ($null -ne $x) { $l += "$x" } }
        $cats | Add-Member -NotePropertyName list -NotePropertyValue $l -Force
        if ($null -eq $cats.PSObject.Properties["colors"]) {
            $colSrc = $null; $colSrcT = $null
            foreach ($ds in $sorted) {
                $c = Get-SyncProp $ds "categories"
                if ($null -eq $c) { continue }
                $cc = Get-SyncProp $c "colors"
                if ($null -eq $cc -or @($cc.PSObject.Properties).Count -eq 0) { continue }
                $ct = ConvertFrom-SyncTime (Get-SyncProp $c "updatedAt")
                if ($null -eq $ct) { continue }
                if ($null -eq $colSrc -or $ct -gt $colSrcT) { $colSrc = $cc; $colSrcT = $ct }
            }
            if ($null -ne $colSrc) { $cats | Add-Member -NotePropertyName colors -NotePropertyValue (Copy-SyncObject $colSrc) -Force }
        }
    }

    # --- 已完成：聯集；作廢規則見下 ---
    $doneAll = @{}
    foreach ($ds in $dsList) {
        foreach ($d in @(Get-SyncProp $ds "done")) {
            if ($null -eq $d) { continue }
            $k = "$(Get-SyncProp $d 'uid')|$(Get-SyncProp $d 'date')"
            $at = ConvertFrom-SyncTime (Get-SyncProp $d "at")
            if ($null -eq $at) { continue }
            if (-not $doneAll.ContainsKey($k) -or $at -gt (ConvertFrom-SyncTime (Get-SyncProp $doneAll[$k] "at"))) { $doneAll[$k] = $d }
        }
    }
    $cutoff = Get-SyncDateKey $nowUtc.AddDays(-$script:SyncDoneKeepDays)
    $keys = @($doneAll.Keys | ForEach-Object { "$_" })
    [Array]::Sort($keys, [StringComparer]::Ordinal)
    $done = @()
    foreach ($k in $keys) {
        $d = $doneAll[$k]
        $uid = "$(Get-SyncProp $d 'uid')"
        $date = "$(Get-SyncProp $d 'date')"
        if (-not $alive.ContainsKey($uid)) { continue }
        if ([String]::CompareOrdinal($date, $cutoff) -lt 0) { continue }
        $aUpd = ConvertFrom-SyncTime (Get-SyncProp $alive[$uid] "updatedAt")
        $dAt = ConvertFrom-SyncTime (Get-SyncProp $d "at")
        # 這個鬧鐘在「完成那天」之後被改過 → 那天的完成作廢（改了時間，今天還能再響）；改之前的日子不受影響
        # （PowerShell 的變數不分大小寫，所以 $aUpd 和 $dAt 要取不一樣的名字）
        if ($null -eq $aUpd -or [String]::CompareOrdinal($date, (Get-SyncDateKey $aUpd)) -lt 0 -or $dAt -ge $aUpd) { $done += , (Copy-SyncObject $d) }
    }

    # --- 真的沒空：同一次取最新的；完成比它新就作廢；太久以前的丟掉 ---
    $snAll = @{}
    foreach ($ds in $dsList) {
        foreach ($s in @(Get-SyncProp $ds "snoozes")) {
            if ($null -eq $s) { continue }
            $k = "$(Get-SyncProp $s 'uid')|$(Get-SyncProp $s 'date')"
            $at = ConvertFrom-SyncTime (Get-SyncProp $s "at")
            if ($null -eq $at) { continue }
            if (-not $snAll.ContainsKey($k) -or $at -gt (ConvertFrom-SyncTime (Get-SyncProp $snAll[$k] "at"))) { $snAll[$k] = $s }
        }
    }
    $old = Get-SyncDateKey $nowUtc.AddDays(-2)
    $keys = @($snAll.Keys | ForEach-Object { "$_" })
    [Array]::Sort($keys, [StringComparer]::Ordinal)
    $snoozes = @()
    foreach ($k in $keys) {
        $s = $snAll[$k]
        if (-not $alive.ContainsKey("$(Get-SyncProp $s 'uid')")) { continue }
        if ($doneAll.ContainsKey($k) -and (ConvertFrom-SyncTime (Get-SyncProp $doneAll[$k] "at")) -ge (ConvertFrom-SyncTime (Get-SyncProp $s "at"))) { continue }
        $until = "$(Get-SyncProp $s 'until')"
        if ($until.Length -ge 10 -and [String]::CompareOrdinal($until.Substring(0, 10), $old) -lt 0) { continue }
        $snoozes += , (Copy-SyncObject $s)
    }
    # 同一個鬧鐘只留一筆延後（工單 8.8）：at 最新的；一樣新留日期較晚的
    $bestSn = @{}
    foreach ($s in $snoozes) {
        $u = "$(Get-SyncProp $s 'uid')"
        if (-not $bestSn.ContainsKey($u)) { $bestSn[$u] = $s; continue }
        $ta = ConvertFrom-SyncTime (Get-SyncProp $s "at")
        $tb = ConvertFrom-SyncTime (Get-SyncProp $bestSn[$u] "at")
        if ($ta -gt $tb -or ($ta -eq $tb -and [String]::CompareOrdinal("$(Get-SyncProp $s 'date')", "$(Get-SyncProp $bestSn[$u] 'date')") -gt 0)) { $bestSn[$u] = $s }
    }
    $snoozesOne = @()
    foreach ($s in $snoozes) { if ([object]::ReferenceEquals($bestSn["$(Get-SyncProp $s 'uid')"], $s)) { $snoozesOne += , $s } }

    return [PSCustomObject]@{ alarms = $alarms; categories = $cats; done = $done; snoozes = $snoozesOne }
}

# ---------- 本機資料 ↔ 同步資料 ----------
# 本機的鬧鐘沒有「上次改的時間」，所以用「同步基準」(state.base) 記著上次同步完每個鬧鐘長什麼樣：
# 這次的內容雜湊跟基準不一樣 → 這次改過 → updatedAt = 現在。不用改任何編輯畫面的程式。

# 鬧鐘的「內容」：拿掉本機編號、同步用的 uid、裝置自己的狀態（已完成紀錄等）
function Get-SyncAlarmData($alarm) {
    $c = Copy-SyncObject $alarm
    foreach ($f in (@("id", "uid") + $script:SyncStateFields)) {
        if ($null -ne $c.PSObject.Properties[$f]) { $c.PSObject.Properties.Remove($f) }
    }
    return $c
}

function New-SyncUid { return [Guid]::NewGuid().ToString("N") }

function New-SyncState {
    return @{
        deviceId = ([Guid]::NewGuid().ToString("N").Substring(0, 12)); lastSyncAt = ""; lastError = ""; lastUploadedHash = ""
        base = @{ alarms = @{}; done = @{}; snoozes = @{}; categories = $null }
    }
}

function Read-SyncState([string]$path) {
    $s = New-SyncState
    if (-not (Test-Path -LiteralPath $path)) { return $s }
    try {
        $o = ConvertFrom-SyncJson ([System.IO.File]::ReadAllText($path, (New-Object System.Text.UTF8Encoding($false))))
        if ("$($o.deviceId)" -ne "") { $s.deviceId = "$($o.deviceId)" }
        $s.lastSyncAt = "$($o.lastSyncAt)"; $s.lastError = "$($o.lastError)"; $s.lastUploadedHash = "$($o.lastUploadedHash)"
        $b = $o.base
        if ($null -ne $b) {
            if ($null -ne $b.alarms) { foreach ($p in $b.alarms.PSObject.Properties) { $v = $p.Value; $s.base.alarms[$p.Name] = @{ hash = "$($v.hash)"; updatedAt = "$($v.updatedAt)"; updatedBy = "$($v.updatedBy)"; deleted = ($v.deleted -eq $true) } } }
            if ($null -ne $b.done) { foreach ($p in $b.done.PSObject.Properties) { $s.base.done[$p.Name] = "$($p.Value)" } }
            if ($null -ne $b.snoozes) { foreach ($p in $b.snoozes.PSObject.Properties) { $s.base.snoozes[$p.Name] = @{ until = "$($p.Value.until)"; at = "$($p.Value.at)" } } }
            if ($null -ne $b.categories) { $s.base.categories = @{ hash = "$($b.categories.hash)"; updatedAt = "$($b.categories.updatedAt)" } }
        }
    } catch {}
    return $s
}

function Write-SyncState([string]$path, $state) {
    $json = ConvertTo-Json -InputObject $state -Depth 8
    $tmp = "$path.tmp"
    [System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding($false)))
    if (Test-Path -LiteralPath $path) { Move-Item -LiteralPath $tmp -Destination $path -Force } else { Move-Item -LiteralPath $tmp -Destination $path }
}

# 這台的同步資料：本機鬧鐘（含這次改的、新增的）、墓碑（上次同步有、現在不見的）、已完成、真的沒空、分類
# $remoteAlive：別台已有的鬧鐘（uid → 內容雜湊），第一次同步時用內容相同來「認領」uid，避免兩邊本來就有的鬧鐘變成兩份
function New-LocalSyncDataset($alarms, $snoozes, $categories, $state, [string]$deviceName, [DateTime]$now, $remoteAlive, $colors = $null, $privateCats = $null) {
    $nowText = ConvertTo-SyncTime $now
    $me = $state.deviceId
    $base = $state.base
    $uidUsed = @{}
    foreach ($a in @($alarms)) { $u = Get-SyncProp $a "uid"; if ($null -ne $u -and "$u" -ne "") { $uidUsed["$u"] = $true } }
    $byHash = @{}
    if ($null -ne $remoteAlive) {
        foreach ($k in @($remoteAlive.Keys)) { $h = $remoteAlive[$k]; if (-not $byHash.ContainsKey($h)) { $byHash[$h] = @() }; $byHash[$h] += "$k" }
    }
    $entries = @()
    $localUids = @{}
    $idToUid = @{}
    $done = @()
    $cutoff = Get-SyncDateKey $now.ToUniversalTime().AddDays(-$script:SyncDoneKeepDays)
    $uidChanged = $false
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        $uid = "$(Get-SyncProp $a 'uid')"
        $data = Get-SyncAlarmData $a
        $h = Get-SyncHash $data
        if ($uid -eq "") {
            $adopt = $null
            if ($byHash.ContainsKey($h)) { foreach ($c in $byHash[$h]) { if (-not $uidUsed.ContainsKey($c)) { $adopt = $c; break } } }
            if ($null -ne $adopt) { $uid = $adopt } else { $uid = New-SyncUid }
            $uidUsed[$uid] = $true
            $a | Add-Member -NotePropertyName uid -NotePropertyValue $uid -Force
            $uidChanged = $true
        }
        $localUids[$uid] = $true
        $idToUid["$(Get-SyncProp $a 'id')"] = $uid
        $b = $null
        if ($base.alarms.ContainsKey($uid)) { $b = $base.alarms[$uid] }
        $at = $nowText; $by = $me
        if ($null -ne $b -and $b.deleted -ne $true -and $b.hash -eq $h) { $at = $b.updatedAt; $by = $b.updatedBy }
        $entries += , ([ordered]@{ uid = $uid; updatedAt = $at; updatedBy = $by; data = $data })
        if ("$(Get-SyncProp $a 'type')" -ne "interval") {
            foreach ($d in @(Get-SyncProp $a "triggeredDates")) {
                if ($null -eq $d) { continue }
                $dText = "$d"
                if ([String]::CompareOrdinal($dText, $cutoff) -lt 0) { continue }
                $k = "$uid|$dText"
                $dAt = $nowText
                if ($base.done.ContainsKey($k)) { $dAt = $base.done[$k] }
                $done += , ([ordered]@{ uid = $uid; date = $dText; at = $dAt })
            }
        }
    }
    # 墓碑：上次同步有、現在本機不見了 → 這次刪的；上次就是墓碑的原樣帶著（30 天後合併時會清掉）
    foreach ($uid in @($base.alarms.Keys)) {
        $b = $base.alarms[$uid]
        if ($localUids.ContainsKey($uid)) { continue }
        if ($b.deleted -eq $true) { $entries += , ([ordered]@{ uid = $uid; updatedAt = $b.updatedAt; updatedBy = $b.updatedBy; deleted = $true }) }
        else { $entries += , ([ordered]@{ uid = $uid; updatedAt = $nowText; updatedBy = $me; deleted = $true }) }
    }
    $snList = @()
    foreach ($k in @($snoozes.Keys)) {
        $s = $snoozes[$k]
        $uid = $idToUid["$($s.AlarmId)"]
        if ($null -eq $uid) { continue }
        $until = $s.Until.ToString($script:SnoozeTimeFormat, [System.Globalization.CultureInfo]::InvariantCulture)
        $bk = "$uid|$($s.DateKey)"
        $sAt = $nowText
        if ($base.snoozes.ContainsKey($bk) -and $base.snoozes[$bk].until -eq $until) { $sAt = $base.snoozes[$bk].at }
        $snList += , ([ordered]@{ uid = $uid; date = "$($s.DateKey)"; until = $until; at = $sAt })
    }
    $catList = @($categories | ForEach-Object { "$_" })
    $dataset = [ordered]@{ format = $script:SyncFormat; version = $script:SyncVersion; deviceId = $me; deviceName = $deviceName; updatedAt = $nowText }
    $privList = @(Get-CleanPrivateCategories $privateCats)
    $catHash = Get-SyncCatsHash $catList $colors $privList
    if ($null -ne $base.categories -or $catList.Count -gt 0) {
        $cAt = $nowText
        if ($null -ne $base.categories -and $base.categories.hash -eq $catHash) { $cAt = $base.categories.updatedAt }
        $catObj = [ordered]@{ list = $catList; updatedAt = $cAt }
        if ($null -ne $colors -and $colors.Count -gt 0) { $catObj["colors"] = (ConvertTo-CategoryColorObject $colors) }
        # 私密分類：一律寫（空清單也寫，這樣「全部取消私密」才傳得出去）；舊版讀到不認得，原樣保留不會壞
        $catObj["private"] = @($privList)
        $dataset["categories"] = $catObj
    }
    $dataset["alarms"] = $entries
    $dataset["done"] = $done
    $dataset["snoozes"] = $snList
    return @{ Dataset = (ConvertFrom-SyncJson (ConvertTo-SyncCanonicalJson $dataset)); UidChanged = $uidChanged }
}

# 分類清單＋顏色一起算雜湊（改了顏色也算「分類改過」）；沒有顏色時跟只算清單一樣
function Get-SyncCatsHash($catList, $colors, $privList = $null) {
    $hasColors = ($null -ne $colors -and $colors.Count -gt 0)
    $priv = @(Get-CleanPrivateCategories $privList)
    if (-not $hasColors -and $priv.Count -eq 0) { return (Get-SyncHash @($catList)) }
    $o = [ordered]@{ list = @($catList) }
    if ($hasColors) { $o["colors"] = (ConvertTo-CategoryColorObject $colors) }
    if ($priv.Count -gt 0) { $o["private"] = @($priv) }
    return (Get-SyncHash $o)
}

# 把合併結果套回本機。回傳新的本機資料、新的同步基準、有沒有改到
function Update-LocalFromSync($merged, $alarms, $snoozes, $categories, $state, [DateTime]$now, $colors = $null, $privateCats = $null) {
    $newColors = @{}
    if ($null -ne $colors) { foreach ($k in @($colors.Keys)) { $newColors[$k] = $colors[$k] } }
    $result = @{ Alarms = @(); Snoozes = $snoozes; Categories = @($categories); Colors = $newColors; PrivateCats = @(Get-CleanPrivateCategories $privateCats); Base = $null; AlarmsChanged = $false; SnoozesChanged = $false; CategoriesChanged = $false; NewlyDone = @(); Added = 0; Updated = 0; Removed = 0 }
    $nb = @{ alarms = @{}; done = @{}; snoozes = @{}; categories = $null }
    $byUid = @{}
    $maxId = 0
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        $u = "$(Get-SyncProp $a 'uid')"
        if ($u -ne "") { $byUid[$u] = $a }
        $n = 0
        if ([int]::TryParse("$(Get-SyncProp $a 'id')", [ref]$n) -and $n -gt $maxId) { $maxId = $n }
    }
    $doneBy = @{}
    foreach ($d in @($merged.done)) { $u = "$($d.uid)"; if (-not $doneBy.ContainsKey($u)) { $doneBy[$u] = @{} }; $doneBy[$u]["$($d.date)"] = "$($d.at)"; $nb.done["$($d.uid)|$($d.date)"] = "$($d.at)" }
    $cutoff = Get-SyncDateKey $now.ToUniversalTime().AddDays(-$script:SyncDoneKeepDays)
    $out = @()
    $mergedUids = @{}
    $idByUid = @{}
    foreach ($e in @($merged.alarms)) {
        $uid = "$($e.uid)"
        $mergedUids[$uid] = $true
        if ($e.deleted -eq $true) {
            $nb.alarms[$uid] = @{ hash = ""; updatedAt = "$($e.updatedAt)"; updatedBy = "$($e.updatedBy)"; deleted = $true }
            if ($byUid.ContainsKey($uid)) { $result.AlarmsChanged = $true; $result.Removed++ }
            continue
        }
        $data = $e.data
        $h = Get-SyncHash $data
        $local = $null
        if ($byUid.ContainsKey($uid)) { $local = $byUid[$uid] }
        $cur = $null
        if ($null -ne $local) {
            $cur = $local
            if ((Get-SyncHash (Get-SyncAlarmData $local)) -ne $h) {
                $new = New-Object PSObject
                foreach ($p in $data.PSObject.Properties) { $new | Add-Member -NotePropertyName $p.Name -NotePropertyValue (Copy-SyncObject $p.Value) -Force }
                $new | Add-Member -NotePropertyName id -NotePropertyValue (Get-SyncProp $local "id") -Force
                $new | Add-Member -NotePropertyName uid -NotePropertyValue $uid -Force
                foreach ($f in $script:SyncStateFields) { if ($null -ne $local.PSObject.Properties[$f]) { $new | Add-Member -NotePropertyName $f -NotePropertyValue $local.PSObject.Properties[$f].Value -Force } }
                if ($null -eq $new.PSObject.Properties["triggeredDates"]) { $new | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @() -Force }
                # 別台改了時間／類型 → 從收到的這一刻起算生效（同步之前已經過的時刻不算漏響）
                $oldArmed = $local.PSObject.Properties["armedAt"]; $newArmed = $data.PSObject.Properties["armedAt"]
                $oa = if ($null -eq $oldArmed) { "" } else { "$($oldArmed.Value)" }; $na = if ($null -eq $newArmed) { "" } else { "$($newArmed.Value)" }
                if (-not (Test-SameSchedule $local $data) -or $oa -ne $na) { Set-AlarmArmedLocal $new $now }
                $cur = $new
                $result.AlarmsChanged = $true; $result.Updated++
            }
        } else {
            $maxId++
            $new = New-Object PSObject
            foreach ($p in $data.PSObject.Properties) { $new | Add-Member -NotePropertyName $p.Name -NotePropertyValue (Copy-SyncObject $p.Value) -Force }
            $new | Add-Member -NotePropertyName id -NotePropertyValue $maxId -Force
            $new | Add-Member -NotePropertyName uid -NotePropertyValue $uid -Force
            $new | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @() -Force
            Set-AlarmArmedLocal $new $now      # 同步進來的新鬧鐘：收到的這一刻起算生效，不補之前已過的時刻
            $cur = $new
            $result.AlarmsChanged = $true; $result.Added++
        }
        # 已完成：聯集；被「改過鬧鐘」作廢的那幾天，本機也拿掉（改了時間，今天還能再響）
        if ("$($cur.type)" -ne "interval") {
            $mine = @()
            foreach ($d in @(Get-SyncProp $cur "triggeredDates")) { if ($null -ne $d) { $mine += "$d" } }
            $aUpd = ConvertFrom-SyncTime "$($e.updatedAt)"
            $aDay = ""
            if ($null -ne $aUpd) { $aDay = Get-SyncDateKey $aUpd }
            $theirs = @{}
            if ($doneBy.ContainsKey($uid)) { $theirs = $doneBy[$uid] }
            $final = @()
            foreach ($d in $mine) {
                if ($aDay -ne "" -and [String]::CompareOrdinal($d, $aDay) -ge 0 -and [String]::CompareOrdinal($d, $cutoff) -ge 0 -and -not $theirs.ContainsKey($d)) { continue }
                if ($final -notcontains $d) { $final += $d }
            }
            foreach ($d in @($theirs.Keys | Sort-Object)) {
                if ($final -notcontains $d) {
                    $final += $d
                    if ($mine -notcontains $d) { $result.NewlyDone += , @{ AlarmId = (Get-SyncProp $cur "id"); Date = $d } }
                }
            }
            if ((@($mine) -join ",") -ne (@($final) -join ",")) {
                $cur | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @($final) -Force
                $result.AlarmsChanged = $true
            }
        }
        $nb.alarms[$uid] = @{ hash = $h; updatedAt = "$($e.updatedAt)"; updatedBy = "$($e.updatedBy)"; deleted = $false }
        $idByUid[$uid] = Get-SyncProp $cur "id"
        $out += $cur
    }
    # 合併結果裡沒有的本機鬧鐘（不該發生）：留著，不動
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        $u = "$(Get-SyncProp $a 'uid')"
        if ($u -eq "" -or -not $mergedUids.ContainsKey($u)) { $out += $a }
    }
    $result.Alarms = $out

    # 真的沒空
    $table = @{}
    foreach ($k in @($snoozes.Keys)) { $table[$k] = $snoozes[$k] }
    $uidById = @{}
    foreach ($a in $out) { $uidById["$(Get-SyncProp $a 'id')"] = "$(Get-SyncProp $a 'uid')" }
    $mergedSn = @{}
    foreach ($s in @($merged.snoozes)) { $mergedSn["$($s.uid)|$($s.date)"] = $s; $nb.snoozes["$($s.uid)|$($s.date)"] = @{ until = "$($s.until)"; at = "$($s.at)" } }
    foreach ($k in @($table.Keys)) {
        $u = $uidById["$($table[$k].AlarmId)"]
        if ($null -ne $u -and $u -ne "" -and $mergedUids.ContainsKey($u) -and -not $mergedSn.ContainsKey("$u|$($table[$k].DateKey)")) { $table.Remove($k); $result.SnoozesChanged = $true }
    }
    foreach ($mk in @($mergedSn.Keys)) {
        $s = $mergedSn[$mk]
        if (-not $idByUid.ContainsKey("$($s.uid)")) { continue }
        $until = $null
        try { $until = [DateTime]::ParseExact("$($s.until)", $script:SnoozeTimeFormat, [System.Globalization.CultureInfo]::InvariantCulture) } catch { continue }
        $id = $idByUid["$($s.uid)"]
        $lk = "$id|$($s.date)"
        if (-not $table.ContainsKey($lk) -or $table[$lk].Until -ne $until) {
            $table[$lk] = @{ AlarmId = $id; DateKey = "$($s.date)"; Until = $until }
            $result.SnoozesChanged = $true
        }
    }
    $result.Snoozes = $table

    # 分類
    $mc = $merged.categories
    if ($null -ne $mc -and "$($mc.updatedAt)" -ne $script:SyncEpoch) {
        $newList = @($mc.list | ForEach-Object { "$_" })
        if ((@($categories) -join "`n") -ne ($newList -join "`n")) { $result.CategoriesChanged = $true }
        $result.Categories = $newList
        # 顏色：合併結果有顏色就用它（沒有就維持本機的）
        $mcc = Get-SyncProp $mc "colors"
        if ($null -ne $mcc) {
            $nc = ConvertFrom-CategoryColorObject $mcc
            if ((Get-SyncHash (ConvertTo-CategoryColorObject $nc)) -ne (Get-SyncHash (ConvertTo-CategoryColorObject $newColors))) { $result.CategoriesChanged = $true }
            $newColors = $nc
            $result.Colors = $nc
        }
        # 私密分類：合併結果有 private 就用它（舊版寫的檔沒有這欄 → 維持本機的，免得隱私設定被舊版蓋掉）
        # （空清單讀回來會變成 $null，所以看「有沒有這個欄位」，不看值）
        $mpa = Get-SyncProp $mc "private"
        if ($null -ne $mc.PSObject.Properties["private"]) {
            $pl = @(Get-CleanPrivateCategories $mpa)
            if ((@($pl) -join "`n") -ne (@(Get-CleanPrivateCategories $privateCats) -join "`n")) { $result.CategoriesChanged = $true }
            $result.PrivateCats = $pl
        }
        $nb.categories = @{ hash = (Get-SyncCatsHash $newList $newColors $result.PrivateCats); updatedAt = "$($mc.updatedAt)" }
    }
    $result.Base = $nb
    return $result
}

# 上傳的內容：合併結果 + 這台裝置的資料
function New-SyncUploadDataset($merged, $state, [string]$deviceName, [DateTime]$now) {
    $o = [ordered]@{ format = $script:SyncFormat; version = $script:SyncVersion; deviceId = $state.deviceId; deviceName = $deviceName; updatedAt = (ConvertTo-SyncTime $now) }
    if ("$($merged.categories.updatedAt)" -ne $script:SyncEpoch) { $o["categories"] = $merged.categories }
    $o["alarms"] = @($merged.alarms)
    $o["done"] = @($merged.done)
    $o["snoozes"] = @($merged.snoozes)
    return $o
}

# 驗證從雲端讀回來的某台裝置的檔；不是我們的格式 → $null
function ConvertFrom-SyncDeviceFile([string]$text) {
    try {
        $d = ConvertFrom-SyncJson $text
        if ($null -eq $d -or $d -is [System.Array] -or "$($d.format)" -ne $script:SyncFormat) { return $null }
        return $d
    } catch { return $null }
}

# ---------- Google 登入（OAuth 授權碼流程 + PKCE，loopback 回呼） ----------
# 範圍只有 drive.appdata（只能碰這個 App 自己的隱藏資料夾，看不到使用者其他的雲端硬碟檔案）。
# 電腦版用戶端的 client_secret 依 Google 文件不算機密（桌面 App 本來就擋不住），放在 oauth_client.json 隨程式散布；
# 但不要印在任何紀錄裡。refresh token 用 DPAPI（目前使用者）加密存檔，不寫明文。

$script:GoogleAuthEndpoint = "https://accounts.google.com/o/oauth2/v2/auth"
$script:GoogleTokenEndpoint = "https://oauth2.googleapis.com/token"
$script:GoogleRevokeEndpoint = "https://oauth2.googleapis.com/revoke"
$script:GoogleScope = "https://www.googleapis.com/auth/drive.appdata"
$script:DriveApiBase = "https://www.googleapis.com/drive/v3"
$script:DriveUploadBase = "https://www.googleapis.com/upload/drive/v3"
$script:GoogleTokenCache = $null

# 同步的錯誤一律丟 "SYNC|種類|白話說明"；種類：network（連不上）、auth（登入）、google（Google 回錯）、data（資料）
function Stop-Sync([string]$kind, [string]$text) { throw "SYNC|$kind|$text" }

function Get-SyncErrorInfo($ex) {
    $m = "$($ex.Exception.Message)"
    if ($m.StartsWith("SYNC|")) {
        $p = $m.Split("|", 3)
        return @{ Kind = $p[1]; Text = $p[2] }
    }
    return @{ Kind = "data"; Text = "同步時發生沒預料到的錯誤：$m" }
}

# 發 HTTP 要求；回傳 @{ Status; Body(字串) }。連不上才丟例外（測試時這個函式會被換成假的 Google）
function Send-GoogleHttp([string]$method, [string]$url, $headers, [byte[]]$body, [string]$contentType, [int]$timeoutSec = 20) {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
    $req = [System.Net.HttpWebRequest]::Create($url)
    $req.Method = $method
    $req.Timeout = $timeoutSec * 1000
    $req.ReadWriteTimeout = $timeoutSec * 1000
    $req.UserAgent = "ShinkenAlarm/$($script:AppVersion)"
    if ($null -ne $headers) { foreach ($k in @($headers.Keys)) { $req.Headers.Add("$k", "$($headers[$k])") } }
    if ($null -ne $body) {
        if ($contentType) { $req.ContentType = $contentType }
        $req.ContentLength = $body.Length
        $rs = $req.GetRequestStream()
        try { $rs.Write($body, 0, $body.Length) } finally { $rs.Dispose() }
    }
    $resp = $null
    try {
        $resp = $req.GetResponse()
    } catch [System.Net.WebException] {
        $resp = $_.Exception.Response
        if ($null -eq $resp) { throw }
    }
    try {
        $sr = New-Object System.IO.StreamReader($resp.GetResponseStream(), (New-Object System.Text.UTF8Encoding($false)))
        try { $text = $sr.ReadToEnd() } finally { $sr.Dispose() }
        return @{ Status = [int]$resp.StatusCode; Body = $text }
    } finally { $resp.Dispose() }
}

function ConvertTo-FormBody($pairs) {
    $parts = @()
    foreach ($k in @($pairs.Keys)) { $parts += ([Uri]::EscapeDataString("$k") + "=" + [Uri]::EscapeDataString("$($pairs[$k])")) }
    return (New-Object System.Text.UTF8Encoding($false)).GetBytes(($parts -join "&"))
}

function ConvertTo-Base64Url([byte[]]$bytes) {
    return ([Convert]::ToBase64String($bytes).TrimEnd("=").Replace("+", "-").Replace("/", "_"))
}

# PKCE：verifier 是隨機字串，challenge = base64url(SHA256(verifier))
function New-PkcePair([string]$verifier = "") {
    if ($verifier -eq "") {
        $b = New-Object byte[] 48
        $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
        try { $rng.GetBytes($b) } finally { $rng.Dispose() }
        $verifier = ConvertTo-Base64Url $b
    }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { $challenge = ConvertTo-Base64Url ($sha.ComputeHash([System.Text.Encoding]::ASCII.GetBytes($verifier))) } finally { $sha.Dispose() }
    return @{ Verifier = $verifier; Challenge = $challenge }
}

function Get-GoogleAuthUrl([string]$clientId, [string]$redirectUri, [string]$challenge, [string]$state) {
    $q = [ordered]@{
        client_id = $clientId; redirect_uri = $redirectUri; response_type = "code"; scope = $script:GoogleScope
        code_challenge = $challenge; code_challenge_method = "S256"; state = $state
        access_type = "offline"; prompt = "consent"
    }
    $parts = @()
    foreach ($k in @($q.Keys)) { $parts += ([Uri]::EscapeDataString("$k") + "=" + [Uri]::EscapeDataString("$($q[$k])")) }
    return ($script:GoogleAuthEndpoint + "?" + ($parts -join "&"))
}

# oauth_client.json（Google 下載的格式：{"installed": {"client_id": ..., "client_secret": ...}}）
function Read-GoogleClient([string]$path) {
    if (-not (Test-Path -LiteralPath $path)) { Stop-Sync "data" "找不到 Google 登入設定檔（oauth_client.json），這個版本不能用 Google 登入。" }
    try {
        $o = ConvertFrom-SyncJson ([System.IO.File]::ReadAllText($path, (New-Object System.Text.UTF8Encoding($false))))
        $c = $o.installed
        if ($null -eq $c) { $c = $o }
        if ("$($c.client_id)" -eq "") { throw "沒有 client_id" }
        return @{ ClientId = "$($c.client_id)"; ClientSecret = "$($c.client_secret)" }
    } catch { Stop-Sync "data" "Google 登入設定檔讀不懂。" }
}

# refresh token 的加密：Windows 用 DPAPI（目前使用者）；測試時可以換掉
function Protect-SyncSecret([string]$plain) {
    if ($null -ne $script:SyncProtectHook) { return (& $script:SyncProtectHook $plain) }
    if ([Environment]::OSVersion.Platform -ne "Win32NT") { Stop-Sync "data" "這個系統沒有 DPAPI，不能安全地存登入資料。" }
    return (ConvertFrom-SecureString (ConvertTo-SecureString $plain -AsPlainText -Force))
}

function Unprotect-SyncSecret([string]$cipher) {
    if ($null -ne $script:SyncUnprotectHook) { return (& $script:SyncUnprotectHook $cipher) }
    if ([Environment]::OSVersion.Platform -ne "Win32NT") { return $null }
    try {
        $ss = ConvertTo-SecureString $cipher
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($ss)
        try { return [System.Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) } finally { [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
    } catch { return $null }
}

function Save-GoogleRefreshToken([string]$tokenPath, [string]$refreshToken) {
    $cipher = Protect-SyncSecret $refreshToken
    [System.IO.File]::WriteAllText($tokenPath, $cipher, (New-Object System.Text.UTF8Encoding($false)))
}

function Read-GoogleRefreshToken([string]$tokenPath) {
    if (-not (Test-Path -LiteralPath $tokenPath)) { return $null }
    try { return (Unprotect-SyncSecret ([System.IO.File]::ReadAllText($tokenPath, (New-Object System.Text.UTF8Encoding($false))).Trim())) } catch { return $null }
}

function Test-GoogleSignedIn([string]$tokenPath) { return (Test-Path -LiteralPath $tokenPath) }

function Get-GoogleErrorCode([string]$body) {
    try { $o = $body | ConvertFrom-Json; if ($null -ne $o.error) { if ($o.error -is [string]) { return "$($o.error)" } else { return "$($o.error.status)" } } } catch {}
    return ""
}

# 用授權碼換 token（登入最後一步）；回傳 refresh token
function Convert-GoogleAuthCode($client, [string]$code, [string]$redirectUri, [string]$verifier, [string]$tokenPath) {
    $body = ConvertTo-FormBody ([ordered]@{ client_id = $client.ClientId; client_secret = $client.ClientSecret; code = $code; redirect_uri = $redirectUri; grant_type = "authorization_code"; code_verifier = $verifier })
    $r = $null
    try { $r = Send-GoogleHttp "POST" $script:GoogleTokenEndpoint $null $body "application/x-www-form-urlencoded" } catch { Stop-Sync "network" "連不上 Google，登入沒有完成。請檢查網路再試一次。" }
    if ($r.Status -ne 200) { Stop-Sync "auth" "Google 沒有接受這次登入（$($r.Status)）。請再按一次「用 Google 帳號登入」。" }
    $t = $r.Body | ConvertFrom-Json
    if ("$($t.refresh_token)" -eq "") { Stop-Sync "auth" "Google 沒有給長期登入的憑證。請再登入一次，並在授權畫面按「允許」。" }
    Save-GoogleRefreshToken $tokenPath "$($t.refresh_token)"
    $script:GoogleTokenCache = @{ Token = "$($t.access_token)"; Expires = (Get-Date).AddSeconds([int]$t.expires_in - 60) }
    return "$($t.refresh_token)"
}

# 互動登入：開瀏覽器 → 聽 http://localhost:<隨機埠>/ → 換 token。$pump 是等待時要呼叫的程式（視窗用來 DoEvents）；$cancelCheck 回傳 $true 就取消
function Invoke-GoogleLogin([string]$clientPath, [string]$tokenPath, [scriptblock]$openUrl, [scriptblock]$pump, [scriptblock]$cancelCheck, [int]$timeoutSec = 180) {
    $client = Read-GoogleClient $clientPath
    $pkce = New-PkcePair
    $state = [Guid]::NewGuid().ToString("N")
    $listener = $null
    $port = 0
    $rand = New-Object System.Random
    for ($i = 0; $i -lt 20; $i++) {
        $port = $rand.Next(49152, 65000)
        $l = New-Object System.Net.HttpListener
        $l.Prefixes.Add("http://localhost:$port/")
        try { $l.Start(); $listener = $l; break } catch { try { $l.Close() } catch {} }
    }
    if ($null -eq $listener) { Stop-Sync "network" "電腦上沒有可以用的連接埠，不能登入。" }
    try {
        $redirect = "http://localhost:$port/"
        $url = Get-GoogleAuthUrl $client.ClientId $redirect $pkce.Challenge $state
        if ($null -ne $openUrl) { & $openUrl $url } else { Start-Process $url }
        $deadline = (Get-Date).AddSeconds($timeoutSec)
        $ctx = $null
        while ($true) {
            $ar = $listener.BeginGetContext($null, $null)
            while (-not $ar.AsyncWaitHandle.WaitOne(100)) {
                if ($null -ne $pump) { & $pump }
                if ($null -ne $cancelCheck -and (& $cancelCheck)) { Stop-Sync "auth" "已取消登入。" }
                if ((Get-Date) -gt $deadline) { Stop-Sync "auth" "等太久了，登入沒有完成。請再試一次。" }
            }
            $ctx = $listener.EndGetContext($ar)
            $q = $ctx.Request.QueryString
            # 瀏覽器可能順便要 /favicon.ico：不是登入結果的要求就略過
            if ($null -eq $q["code"] -and $null -eq $q["error"]) {
                $ctx.Response.StatusCode = 404; $ctx.Response.Close(); continue
            }
            break
        }
        $code = $ctx.Request.QueryString["code"]
        $err = $ctx.Request.QueryString["error"]
        $okState = ("$($ctx.Request.QueryString['state'])" -eq $state)
        $html = "<html><head><meta charset='utf-8'><title>真劍鬧鐘</title></head><body style='font-family:sans-serif;text-align:center;margin-top:80px'>"
        if ($null -ne $code -and $okState) { $html += "<h2>登入完成</h2><p>可以關閉這個分頁，回到真劍鬧鐘了。</p>" } else { $html += "<h2>登入沒有成功</h2><p>請回到真劍鬧鐘再試一次。</p>" }
        $html += "</body></html>"
        $bytes = (New-Object System.Text.UTF8Encoding($false)).GetBytes($html)
        $ctx.Response.ContentType = "text/html; charset=utf-8"
        $ctx.Response.ContentLength64 = $bytes.Length
        $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
        $ctx.Response.Close()
        if ($null -ne $err) { Stop-Sync "auth" "沒有授權（$err）。要同步的話，請在 Google 的畫面按「允許」。" }
        if (-not $okState -or $null -eq $code) { Stop-Sync "auth" "登入回傳的資料不對，已經取消。請再試一次。" }
        Convert-GoogleAuthCode $client "$code" $redirect $pkce.Verifier $tokenPath | Out-Null
    } finally {
        try { $listener.Stop(); $listener.Close() } catch {}
    }
}

# 取 access token（沒過期就用快取；過期了用 refresh token 換）
function Get-GoogleAccessToken([string]$clientPath, [string]$tokenPath) {
    if ($null -ne $script:GoogleTokenCache -and $script:GoogleTokenCache.Expires -gt (Get-Date)) { return $script:GoogleTokenCache.Token }
    $refresh = Read-GoogleRefreshToken $tokenPath
    if ($null -eq $refresh -or $refresh -eq "") { Stop-Sync "auth" "還沒登入 Google（或登入資料換了電腦、換了使用者就讀不出來）。請按「用 Google 帳號登入」。" }
    $client = Read-GoogleClient $clientPath
    $body = ConvertTo-FormBody ([ordered]@{ client_id = $client.ClientId; client_secret = $client.ClientSecret; refresh_token = $refresh; grant_type = "refresh_token" })
    $r = $null
    try { $r = Send-GoogleHttp "POST" $script:GoogleTokenEndpoint $null $body "application/x-www-form-urlencoded" } catch { Stop-Sync "network" "連不上 Google（沒網路？），先不同步。鬧鐘照常運作。" }
    if ($r.Status -eq 200) {
        $t = $r.Body | ConvertFrom-Json
        $script:GoogleTokenCache = @{ Token = "$($t.access_token)"; Expires = (Get-Date).AddSeconds([int]$t.expires_in - 60) }
        return $script:GoogleTokenCache.Token
    }
    $code = Get-GoogleErrorCode $r.Body
    if ($r.Status -eq 400 -or $r.Status -eq 401) {
        if ($code -eq "invalid_grant" -or $code -eq "invalid_client" -or $code -eq "unauthorized_client") {
            Remove-Item -LiteralPath $tokenPath -Force -ErrorAction SilentlyContinue
            $script:GoogleTokenCache = $null
            Stop-Sync "auth" "Google 登入已經失效（可能在 Google 帳號裡移除了授權）。請重新登入。"
        }
    }
    Stop-Sync "google" "Google 暫時沒有回應正確的資料（$($r.Status)），稍後會再試。"
}

# 登出：通知 Google 作廢憑證、刪掉本機憑證
function Invoke-GoogleLogout([string]$tokenPath) {
    $refresh = Read-GoogleRefreshToken $tokenPath
    if ($null -ne $refresh -and $refresh -ne "") {
        try { Send-GoogleHttp "POST" $script:GoogleRevokeEndpoint $null (ConvertTo-FormBody ([ordered]@{ token = $refresh })) "application/x-www-form-urlencoded" 10 | Out-Null } catch {}
    }
    Remove-Item -LiteralPath $tokenPath -Force -ErrorAction SilentlyContinue
    $script:GoogleTokenCache = $null
}

# ---------- Drive REST（只用 appDataFolder） ----------

function Invoke-DriveRequest([string]$method, [string]$url, [string]$token, [byte[]]$body, [string]$contentType) {
    $h = @{ Authorization = "Bearer $token" }
    $r = $null
    try { $r = Send-GoogleHttp $method $url $h $body $contentType } catch { Stop-Sync "network" "連不上 Google（沒網路？），先不同步。鬧鐘照常運作。" }
    if ($r.Status -ge 200 -and $r.Status -lt 300) { return $r }
    if ($r.Status -eq 401) { $script:GoogleTokenCache = $null; Stop-Sync "auth" "Google 說登入不對（401）。稍後會自動再試；一直這樣的話請重新登入。" }
    if ($r.Status -eq 403) {
        $code = Get-GoogleErrorCode $r.Body
        if ($r.Body -like "*storageQuotaExceeded*") { Stop-Sync "google" "你的 Google 雲端硬碟空間滿了，沒辦法同步。" }
        if ($r.Body -like "*accessNotConfigured*" -or $r.Body -like "*SERVICE_DISABLED*") { Stop-Sync "google" "這個 App 的 Google 設定還沒開通 Drive（403）。請聯絡作者。" }
        Stop-Sync "google" "Google 拒絕了這次同步（403 $code）。請重新登入，或稍後再試。"
    }
    if ($r.Status -eq 429) { Stop-Sync "google" "Google 說要求太頻繁，稍後會再試。" }
    if ($r.Status -ge 500) { Stop-Sync "google" "Google 那邊暫時出問題（$($r.Status)），稍後會再試。" }
    Stop-Sync "google" "Google 回了預料之外的結果（$($r.Status)）。"
}

# appDataFolder 裡的檔案清單：@{ Id; Name; ModifiedTime }
function Get-DriveFileList([string]$token) {
    $files = @()
    $page = ""
    do {
        $url = "$($script:DriveApiBase)/files?spaces=appDataFolder&pageSize=100&fields=" + [Uri]::EscapeDataString("nextPageToken,files(id,name,modifiedTime)")
        if ($page -ne "") { $url += "&pageToken=" + [Uri]::EscapeDataString($page) }
        $r = Invoke-DriveRequest "GET" $url $token $null $null
        $o = $r.Body | ConvertFrom-Json
        foreach ($f in @($o.files)) { if ($null -ne $f) { $files += @{ Id = "$($f.id)"; Name = "$($f.name)"; ModifiedTime = "$($f.modifiedTime)" } } }
        $page = ""
        if ($null -ne $o.nextPageToken) { $page = "$($o.nextPageToken)" }
    } while ($page -ne "")
    return $files
}

function Get-DriveFileText([string]$token, [string]$id) {
    $r = Invoke-DriveRequest "GET" "$($script:DriveApiBase)/files/$([Uri]::EscapeDataString($id))?alt=media" $token $null $null
    return $r.Body
}

# 建立（沒有 $id）或整個換掉內容（有 $id）
function Save-DriveFileText([string]$token, [string]$name, [string]$text, [string]$id) {
    $utf8 = New-Object System.Text.UTF8Encoding($false)
    if ($id -ne "") {
        Invoke-DriveRequest "PATCH" "$($script:DriveUploadBase)/files/$([Uri]::EscapeDataString($id))?uploadType=media" $token ($utf8.GetBytes($text)) "application/json; charset=UTF-8" | Out-Null
        return $id
    }
    $boundary = "shinken" + [Guid]::NewGuid().ToString("N")
    $meta = ConvertTo-Json -InputObject ([ordered]@{ name = $name; parents = @("appDataFolder") }) -Compress
    $body = "--$boundary`r`nContent-Type: application/json; charset=UTF-8`r`n`r`n$meta`r`n--$boundary`r`nContent-Type: application/json; charset=UTF-8`r`n`r`n$text`r`n--$boundary--"
    $r = Invoke-DriveRequest "POST" "$($script:DriveUploadBase)/files?uploadType=multipart&fields=id" $token ($utf8.GetBytes($body)) "multipart/related; boundary=$boundary"
    return "$(($r.Body | ConvertFrom-Json).id)"
}

# ---------- 同步一次 ----------
# $ctx：@{ AlarmsPath; SnoozePath; SettingsPath; StatePath; TokenPath; ClientPath; DeviceName }
# 回傳 @{ Ok; Error; Kind; Changed（本機資料有沒有被改）; Uploaded; Counts }
function Invoke-SyncRun($ctx, [DateTime]$now, [bool]$recordError = $true) {
    if ($null -eq $now) { $now = Get-Date }
    $res = @{ Ok = $false; Error = ""; Kind = ""; Changed = $false; Uploaded = $false; Skipped = $false; Added = 0; Updated = 0; Removed = 0; NewlyDone = @() }
    $mutex = New-Object System.Threading.Mutex($false, "Local\ShinkenAlarmSyncRun")
    $got = $false
    try { $got = $mutex.WaitOne(0) } catch { $got = $true }
    if (-not $got) { $res.Ok = $true; $res.Skipped = $true; return $res }
    $state = Read-SyncState $ctx.StatePath
    try {
        $token = Get-GoogleAccessToken $ctx.ClientPath $ctx.TokenPath
        $files = Get-DriveFileList $token
        $ownName = "devices/$($state.deviceId).json"
        $ownId = ""
        $remotes = @()
        $remoteAlive = @{}
        foreach ($f in $files) {
            if ($f.Name -eq $ownName) { $ownId = $f.Id; continue }
            if (-not ($f.Name -like "devices/*.json")) { continue }
            $text = Get-DriveFileText $token $f.Id
            $d = ConvertFrom-SyncDeviceFile $text
            if ($null -eq $d) { continue }
            $remotes += , $d
            foreach ($e in @(Get-SyncProp $d "alarms")) {
                if ($null -ne $e -and (Get-SyncProp $e "deleted") -ne $true -and $null -ne (Get-SyncProp $e "data")) { $remoteAlive["$(Get-SyncProp $e 'uid')"] = (Get-SyncHash (Get-SyncProp $e "data")) }
            }
        }
        # 本機資料：讀、合併、套回去（這一段很快，不含網路）
        $alarms = @(Read-AlarmFile $ctx.AlarmsPath)
        $snoozes = Read-SnoozeFile $ctx.SnoozePath
        $settings = Read-AppSettings $ctx.SettingsPath
        $local = New-LocalSyncDataset $alarms $snoozes $settings.categories $state $ctx.DeviceName $now $remoteAlive $settings.categoryColors $settings.privateCategories
        $merged = Merge-SyncDatasets (@($local.Dataset) + @($remotes)) $now
        $applied = Update-LocalFromSync $merged $alarms $snoozes $settings.categories $state $now $settings.categoryColors $settings.privateCategories
        if ($applied.AlarmsChanged -or $local.UidChanged) { Write-AlarmFile $ctx.AlarmsPath $applied.Alarms }
        if ($applied.SnoozesChanged) { Write-SnoozeFile $ctx.SnoozePath $applied.Snoozes }
        if ($applied.CategoriesChanged) { $settings.categories = @($applied.Categories); $settings.categoryColors = $applied.Colors; $settings.privateCategories = @($applied.PrivateCats); Write-AppSettings $ctx.SettingsPath $settings }
        $res.Changed = ($applied.AlarmsChanged -or $applied.SnoozesChanged -or $applied.CategoriesChanged)
        $res.Added = $applied.Added; $res.Updated = $applied.Updated; $res.Removed = $applied.Removed; $res.NewlyDone = $applied.NewlyDone
        $state.base = $applied.Base
        Write-SyncState $ctx.StatePath $state
        # 上傳這台的檔（內容沒變、檔案也在 → 不用傳）
        $upload = New-SyncUploadDataset $merged $state $ctx.DeviceName $now
        $upHash = Get-SyncHash ([ordered]@{ alarms = $upload.alarms; done = $upload.done; snoozes = $upload.snoozes; categories = $upload.categories })
        if ($ownId -eq "" -or $state.lastUploadedHash -ne $upHash) {
            Save-DriveFileText $token $ownName (ConvertTo-SyncCanonicalJson $upload) $ownId | Out-Null
            $state.lastUploadedHash = $upHash
            $res.Uploaded = $true
        }
        $state.lastSyncAt = ConvertTo-SyncTime $now
        $state.lastError = ""
        Write-SyncState $ctx.StatePath $state
        $res.Ok = $true
    } catch {
        $info = Get-SyncErrorInfo $_
        $res.Error = $info.Text; $res.Kind = $info.Kind
        if ($recordError) { try { $state.lastError = $info.Text; Write-SyncState $ctx.StatePath $state } catch {} }
    } finally {
        if ($got) { try { $mutex.ReleaseMutex() } catch {} }
        $mutex.Dispose()
    }
    return $res
}

# 同步用到的檔案位置（跟 alarms.json 放同一個資料夾）
function Get-SyncContext([string]$appDir) {
    return @{
        AlarmsPath = (Join-Path $appDir "alarms.json"); SnoozePath = (Join-Path $appDir "snoozes.json"); SettingsPath = (Join-Path $appDir "settings.json")
        StatePath = (Join-Path $appDir "sync_state.json"); TokenPath = (Join-Path $appDir "sync_token.dat"); ClientPath = (Join-Path $appDir "oauth_client.json")
        DeviceName = "$env:COMPUTERNAME"
    }
}

# 暫時性的失敗（沒網路、Google 暫時回錯、授權還沒準備好）：登入完馬上同步時常遇到，隔幾秒再試就好。
# 中間失敗的那幾次不記成「上次沒成功的原因」（畫面才不會先閃一個錯誤），最後一次還是失敗才記；要重新登入（auth 且憑證被刪）的不重試。
# $delays 是每次失敗後等幾秒；$sleep 可以換掉（測試用）
function Invoke-SyncRunWithRetry($ctx, [double[]]$delays = @(2, 5), [scriptblock]$sleep = $null) {
    $attempt = 0
    while ($true) {
        $last = ($attempt -ge $delays.Count)
        $res = Invoke-SyncRun $ctx (Get-Date) $last
        $needLogin = ($res.Kind -eq "auth" -and -not (Test-GoogleSignedIn $ctx.TokenPath))
        if ($res.Ok -or $last -or $needLogin) {
            if (-not $res.Ok -and -not $last) {
                try { $st = Read-SyncState $ctx.StatePath; $st.lastError = $res.Error; Write-SyncState $ctx.StatePath $st } catch {}
            }
            return $res
        }
        if ($null -ne $sleep) { & $sleep $delays[$attempt] } else { Start-Sleep -Seconds $delays[$attempt] }
        $attempt++
    }
}

# 設定畫面上顯示的白話狀態
function Get-SyncStatusLines([string]$statePath, [string]$tokenPath) {
    $signed = Test-GoogleSignedIn $tokenPath
    $s = Read-SyncState $statePath
    $lines = @()
    if ($signed) { $lines += "已登入 Google 帳號。" } else { $lines += "還沒登入。登入後，電腦和手機的鬧鐘就會自動同步。" }
    if ($signed) {
        $t = ConvertFrom-SyncTime $s.lastSyncAt
        if ($null -ne $t) { $lines += "上次同步：" + $t.ToLocalTime().ToString("M/d HH:mm", [System.Globalization.CultureInfo]::InvariantCulture) } else { $lines += "還沒同步過。" }
        if ($s.lastError -ne "") { $lines += "上次沒成功的原因：$($s.lastError)" }
    }
    return $lines
}

# 登出時：同步基準清掉（換別的帳號登入時，本機鬧鐘才不會被誤當成「在雲端被刪掉」）
function Clear-SyncState([string]$statePath) {
    $s = Read-SyncState $statePath
    $n = New-SyncState
    $n.deviceId = $s.deviceId
    Write-SyncState $statePath $n
}

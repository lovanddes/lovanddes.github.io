﻿# 真劍鬧鐘：啟動 / 安裝 / 解除安裝（給資料夾裡的 .cmd 呼叫）
#   -Action Launch     解除「來自網際網路」的封鎖，啟動背景提醒（已經在跑就打開設定視窗）
#   -Action Install    複製到 %LOCALAPPDATA%\真劍鬧鐘、建立開始功能表/桌面捷徑、可選開機自動啟動
#   -Action Uninstall  停止程式、把鬧鐘備份到桌面、刪掉捷徑和安裝資料夾
# 不需要系統管理員權限。只用 Windows PowerShell 5.1 有的語法。
param(
    [ValidateSet("Launch", "Install", "Uninstall")]
    [string]$Action = "Launch"
)

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$AppName = "真劍鬧鐘"
$MutexName = "DesktopAlarmTray_SingleInstance_Lock"
$InstallRoot = Join-Path $env:LOCALAPPDATA $AppName
$InstallApp = Join-Path $InstallRoot "app"
# 使用者自己的資料，安裝/更新時絕對不能蓋掉
$DataFiles = @("alarms.json", "snoozes.json", "settings.json", "tray.pid", "alarm_debug.log", "sync_state.json", "sync_token.dat", "update_state.json", "update_result.json", "update_backup")

function Show-Msg([string]$text, [string]$icon) {
    if (-not $icon) { $icon = "Information" }
    [System.Windows.Forms.MessageBox]::Show($text, $AppName, [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::$icon) | Out-Null
}

function Ask-YesNo([string]$text) {
    $r = [System.Windows.Forms.MessageBox]::Show($text, $AppName, [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
    return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Get-PowerShellExe {
    $exe = Join-Path $PSHOME "powershell.exe"
    if (Test-Path -LiteralPath $exe) { return $exe }
    return "powershell.exe"
}

# 在背景啟動 app 資料夾裡的 .ps1（不跳黑色視窗）
function Start-Hidden([string]$scriptPath, [string[]]$extraArgs) {
    $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", "`"$scriptPath`"")
    if ($null -ne $extraArgs) { $argList += $extraArgs }
    Start-Process -FilePath (Get-PowerShellExe) -ArgumentList $argList -WindowStyle Hidden
}

# 從網路下載的 zip 解出來的檔案會被標記「來自網際網路」，PowerShell 會擋 → 先解除
function Unblock-Folder([string]$folder) {
    try {
        Get-ChildItem -LiteralPath $folder -Recurse -Force -ErrorAction SilentlyContinue |
            Where-Object { -not $_.PSIsContainer } |
            ForEach-Object { try { Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue } catch {} }
    } catch {}
}

function Test-TrayRunning {
    $m = $null
    try {
        if ([System.Threading.Mutex]::TryOpenExisting($MutexName, [ref]$m)) {
            $m.Dispose()
            return $true
        }
    } catch {}
    return $false
}

# 停掉某個資料夾裡的真劍鬧鐘（背景提醒 + 設定視窗）
function Stop-AppProcesses([string]$appFolder) {
    try {
        $procs = Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" -ErrorAction SilentlyContinue
        foreach ($p in $procs) {
            $cl = "$($p.CommandLine)"
            if ($cl -eq "") { continue }
            if (($cl -like "*Alarm_Tray.ps1*" -or $cl -like "*Alarm_Manager_GUI.ps1*") -and $cl.IndexOf($appFolder, [StringComparison]::OrdinalIgnoreCase) -ge 0) {
                try { Stop-Process -Id $p.ProcessId -Force -ErrorAction SilentlyContinue } catch {}
            }
        }
    } catch {}
    $pidFile = Join-Path $appFolder "tray.pid"
    if (Test-Path -LiteralPath $pidFile) { Remove-Item -LiteralPath $pidFile -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Milliseconds 600
}

function New-Shortcut([string]$path, [string]$target, [string]$arguments, [string]$workDir, [string]$icon, [string]$desc, [int]$windowStyle) {
    $dir = Split-Path $path -Parent
    if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $wsh = New-Object -ComObject WScript.Shell
    $sc = $wsh.CreateShortcut($path)
    $sc.TargetPath = $target
    if ($arguments) { $sc.Arguments = $arguments }
    if ($workDir) { $sc.WorkingDirectory = $workDir }
    if ($icon -and (Test-Path -LiteralPath $icon)) { $sc.IconLocation = $icon }
    if ($desc) { $sc.Description = $desc }
    if ($windowStyle -gt 0) { $sc.WindowStyle = $windowStyle }
    $sc.Save()
}

function Get-HiddenArgs([string]$scriptPath, [string]$extra) {
    $a = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$scriptPath`""
    if ($extra) { $a = "$a $extra" }
    return $a
}

$ProgramsDir = Join-Path ([Environment]::GetFolderPath("Programs")) $AppName
$DesktopLink = Join-Path ([Environment]::GetFolderPath("Desktop")) "$AppName.lnk"
$StartupLink = Join-Path ([Environment]::GetFolderPath("Startup")) "$AppName.lnk"

# ------------------------------------------------------------------
if ($Action -eq "Launch") {
    $appDir = $PSScriptRoot
    Unblock-Folder (Split-Path $appDir -Parent)
    if (Test-TrayRunning) {
        # 水母已經在右下角了 → 直接打開設定視窗
        Start-Hidden (Join-Path $appDir "Alarm_Manager_GUI.ps1") $null
    } else {
        Start-Hidden (Join-Path $appDir "Alarm_Tray.ps1") @("-Welcome")
    }
    exit 0
}

# ------------------------------------------------------------------
if ($Action -eq "Install") {
    try {
        $srcApp = $PSScriptRoot
        $srcRoot = Split-Path $srcApp -Parent
        Unblock-Folder $srcRoot

        if ($srcApp.TrimEnd('\') -ieq $InstallApp.TrimEnd('\')) {
            Show-Msg "這裡已經是安裝好的版本了，不用再裝一次。`n要打開請用「開始」功能表裡的「$AppName」。"
            exit 0
        }

        $go = Ask-YesNo ("要把「$AppName」安裝到你的電腦嗎？`n`n" +
            "會裝在：$InstallRoot`n（不需要系統管理員權限，也不會動到其他程式）`n`n" +
            "按「是」開始安裝，按「否」取消。")
        if (-not $go) { exit 0 }

        # 正在跑的（不管是解壓資料夾的還是舊的安裝）先停掉，免得檔案被占用
        Stop-AppProcesses $srcApp
        Stop-AppProcesses $InstallApp

        if (-not (Test-Path -LiteralPath $InstallApp)) { New-Item -ItemType Directory -Path $InstallApp -Force | Out-Null }

        # 複製程式檔（使用者資料不複製、不覆蓋）
        Get-ChildItem -LiteralPath $srcApp -Force | Where-Object { $DataFiles -notcontains $_.Name } | ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination $InstallApp -Recurse -Force
        }
        # 如果之前已經在解壓資料夾裡用過、設定過鬧鐘 → 搬過去（安裝的地方還沒有鬧鐘時才搬）
        foreach ($f in @("alarms.json", "snoozes.json", "settings.json")) {
            $from = Join-Path $srcApp $f
            $to = Join-Path $InstallApp $f
            if ((Test-Path -LiteralPath $from) -and -not (Test-Path -LiteralPath $to)) { Copy-Item -LiteralPath $from -Destination $to -Force }
        }
        foreach ($f in @("使用說明.txt", "解除安裝.cmd")) {
            $from = Join-Path $srcRoot $f
            if (Test-Path -LiteralPath $from) { Copy-Item -LiteralPath $from -Destination $InstallRoot -Force }
        }
        Unblock-Folder $InstallRoot

        $ps = Get-PowerShellExe
        $icon = Join-Path $InstallApp "assets\jellyfish.ico"
        $setup = Join-Path $InstallApp "Setup.ps1"
        $tray = Join-Path $InstallApp "Alarm_Tray.ps1"

        New-Shortcut (Join-Path $ProgramsDir "$AppName.lnk") $ps (Get-HiddenArgs $setup "-Action Launch") $InstallApp $icon "打開$AppName" 7
        New-Shortcut (Join-Path $ProgramsDir "使用說明.lnk") (Join-Path $InstallRoot "使用說明.txt") "" $InstallRoot "" "$AppName 使用說明" 0
        New-Shortcut (Join-Path $ProgramsDir "解除安裝$AppName.lnk") (Join-Path $InstallRoot "解除安裝.cmd") "" $InstallRoot $icon "解除安裝$AppName" 7
        New-Shortcut $DesktopLink $ps (Get-HiddenArgs $setup "-Action Launch") $InstallApp $icon "打開$AppName" 7

        $startupMsg = ""
        if (Ask-YesNo "要不要每次開機都自動啟動「$AppName」？`n（建議選「是」，不然重開機後鬧鐘不會響）`n`n之後也可以在設定視窗裡改。") {
            New-Shortcut $StartupLink $ps (Get-HiddenArgs $tray "") $InstallApp $icon "$AppName 背景提醒" 7
            $startupMsg = "開機會自動啟動。"
        } else {
            if (Test-Path -LiteralPath $StartupLink) { Remove-Item -LiteralPath $StartupLink -Force -ErrorAction SilentlyContinue }
            $startupMsg = "沒有設定開機自動啟動（重開機後要自己點桌面上的「$AppName」）。"
        }

        Start-Hidden $tray @("-Welcome")

        Show-Msg ("安裝好了！`n`n" +
            "・桌面和「開始」功能表都有「$AppName」可以點`n" +
            "・$startupMsg`n" +
            "・右下角出現水母，就是在跑了`n`n" +
            "解壓縮出來的那個資料夾現在可以刪掉了。")
    } catch {
        Show-Msg "安裝失敗：$($_.Exception.Message)`n`n可以改用「啟動真劍鬧鐘.cmd」直接從資料夾執行。" "Warning"
        exit 1
    }
    exit 0
}

# ------------------------------------------------------------------
if ($Action -eq "Uninstall") {
    # 這支可能是從 %TEMP% 的複本執行的，工作目錄先移出安裝資料夾，才刪得掉
    try { Set-Location -LiteralPath $env:TEMP } catch {}

    $installed = Test-Path -LiteralPath $InstallRoot
    if (-not $installed) {
        foreach ($l in @($StartupLink, $DesktopLink)) { if (Test-Path -LiteralPath $l) { Remove-Item -LiteralPath $l -Force -ErrorAction SilentlyContinue } }
        if (Test-Path -LiteralPath $ProgramsDir) { Remove-Item -LiteralPath $ProgramsDir -Recurse -Force -ErrorAction SilentlyContinue }
        Show-Msg ("找不到安裝版的$AppName（$InstallRoot）。`n`n" +
            "如果你是直接從解壓縮資料夾用的：`n" +
            "1. 右鍵點右下角的水母 →「結束背景提醒程式」`n" +
            "2. 想留鬧鐘的話，先把資料夾裡 app\alarms.json 複製出來`n" +
            "3. 把整個資料夾刪掉就好")
        exit 0
    }

    if (-not (Ask-YesNo "確定要解除安裝「$AppName」嗎？`n`n你的鬧鐘會先備份一份到桌面，之後想回來還用得到。")) { exit 0 }

    Stop-AppProcesses $InstallApp

    $backupMsg = ""
    $alarmsFile = Join-Path $InstallApp "alarms.json"
    if (Test-Path -LiteralPath $alarmsFile) {
        try {
            $backup = Join-Path ([Environment]::GetFolderPath("Desktop")) ("真劍鬧鐘_鬧鐘備份_" + (Get-Date).ToString("yyyyMMdd_HHmm") + ".json")
            Copy-Item -LiteralPath $alarmsFile -Destination $backup -Force
            $backupMsg = "`n`n你的鬧鐘已經備份到桌面：`n$(Split-Path $backup -Leaf)`n（以後重新安裝，把它改名成 alarms.json 放進 app 資料夾就回來了）"
        } catch { $backupMsg = "`n`n（鬧鐘備份失敗：$($_.Exception.Message)）" }
    }

    foreach ($l in @($StartupLink, $DesktopLink)) { if (Test-Path -LiteralPath $l) { Remove-Item -LiteralPath $l -Force -ErrorAction SilentlyContinue } }
    if (Test-Path -LiteralPath $ProgramsDir) { Remove-Item -LiteralPath $ProgramsDir -Recurse -Force -ErrorAction SilentlyContinue }

    $ok = $false
    for ($i = 0; $i -lt 5; $i++) {
        try {
            Remove-Item -LiteralPath $InstallRoot -Recurse -Force -ErrorAction Stop
            $ok = $true
            break
        } catch { Start-Sleep -Milliseconds 800 }
    }
    if ($ok) {
        Show-Msg "已經解除安裝了。謝謝你陪新跪認真過。$backupMsg"
    } else {
        Show-Msg "大部分都刪掉了，但有些檔案還在使用中。`n重開機後，把這個資料夾刪掉就好：`n$InstallRoot$backupMsg" "Warning"
    }
    exit 0
}

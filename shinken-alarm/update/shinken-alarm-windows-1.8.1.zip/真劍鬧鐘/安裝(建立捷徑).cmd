@echo off
rem Shinken Alarm installer: copies to %LOCALAPPDATA%, creates Start menu / desktop shortcuts,
rem optional auto-start. No admin rights needed. This file is ASCII only on purpose;
rem all Chinese messages are shown by Setup.ps1 (UTF-8 with BOM).
start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0app\Setup.ps1" -Action Install
exit /b 0

@echo off
rem Shinken Alarm uninstaller. This file is ASCII only on purpose.
rem Setup.ps1 is copied to %TEMP% first, so the install folder (which may contain
rem this very file) can be deleted while the uninstaller runs.
set "SHINKEN_SETUP=%~dp0app\Setup.ps1"
set "SHINKEN_TMP=%TEMP%\shinken_alarm_setup.ps1"
if not exist "%SHINKEN_SETUP%" (
  echo Setup.ps1 not found: "%SHINKEN_SETUP%"
  pause
  exit /b 1
)
copy /y "%SHINKEN_SETUP%" "%SHINKEN_TMP%" >nul
start "" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%SHINKEN_TMP%" -Action Uninstall
exit /b 0

﻿# 真劍鬧鐘：不碰 Windows Forms 的純邏輯函式
# 設定視窗(Alarm_Manager_GUI.ps1)、背景提醒(Alarm_Tray.ps1)、tests.ps1 都用 . 載入這支。
# 注意：只能用 Windows PowerShell 5.1 有的語法（不要 ??、?.、三元運算子）。

$script:AppName = "真劍鬧鐘"
$script:AppVersion = "1.17.2"
$script:SalonUrl = "https://vocus.cc/salon/ai-new-kneel"
$script:PrivacyUrl = "https://lovanddes.github.io/shinken-alarm/privacy.html"   # 隱私權政策（網頁）
$script:SiteUrl = "https://lovanddes.github.io/shinken-alarm/"                    # App 下載頁（分享給朋友用）
$script:DefaultCategory = "未分類"

# ---------- 日期小工具 ----------

# 把 json 讀出來的日期（通常是 "yyyy-MM-dd" 字串）轉成 DateTime；轉不了就回傳 $null
function ConvertTo-DateOnly($value) {
    if ($null -eq $value) { return $null }
    if ($value -is [DateTime]) { return $value.Date }
    $s = "$value".Trim()
    if ($s -eq "") { return $null }
    try { return [DateTime]::ParseExact($s, "yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture) } catch { return $null }
}

# 把 "HH:mm" 拆成 @(時, 分)
function Get-AlarmTimeParts($a) {
    $parts = "$($a.time)" -split ":"
    return @([int]$parts[0], [int]$parts[1])
}

# 某年某月的第 day 號；這個月沒有那一天（2/29 平年、4/31、2/30…）就改成那個月的最後一天
function Resolve-MonthDay([int]$year, [int]$month, [int]$day) {
    $last = [DateTime]::DaysInMonth($year, $month)
    if ($day -gt $last) { $day = $last }
    if ($day -lt 1) { $day = 1 }
    return New-Object DateTime($year, $month, $day)
}

# ---------- 每年固定日期（單一日期舊格式 + 多月多日新格式） ----------

# 回傳 @{ Months = @(..); Days = @(..) }；資料壞掉就回傳 $null
#   新格式：months = [3, 9], days = [1, 15]
#   舊格式：date = "2025-03-15"（年份不管，只看月/日）
function Get-YearlyRule($a) {
    $months = @()
    $days = @()
    if ($null -ne $a.months) { $months = @($a.months | Where-Object { $null -ne $_ -and "$_" -ne "" } | ForEach-Object { [int]$_ }) }
    if ($null -ne $a.days) { $days = @($a.days | Where-Object { $null -ne $_ -and "$_" -ne "" } | ForEach-Object { [int]$_ }) }
    if ($months.Count -gt 0 -and $days.Count -gt 0) {
        return @{ Months = @($months | Sort-Object -Unique); Days = @($days | Sort-Object -Unique) }
    }
    $src = ConvertTo-DateOnly $a.date
    if ($null -eq $src) { return $null }
    return @{ Months = @($src.Month); Days = @($src.Day) }
}

# 這一天是不是「每年固定日期」規則要響的日子（含：日期不存在 → 那個月最後一天響）
function Test-YearlyRuleMatch($rule, [DateTime]$d) {
    if ($null -eq $rule) { return $false }
    if ($rule.Months -notcontains $d.Month) { return $false }
    foreach ($day in $rule.Days) {
        $resolved = Resolve-MonthDay $d.Year $d.Month $day
        if ($resolved.Day -eq $d.Day) { return $true }
    }
    return $false
}

# ---------- 分類 ----------

function Get-AlarmCategory($a) {
    if ($null -eq $a.category) { return $script:DefaultCategory }
    $c = "$($a.category)".Trim()
    if ($c -eq "") { return $script:DefaultCategory }
    return $c
}

# ---------- 顯示文字 ----------

function Get-YearlyText($a) {
    $rule = Get-YearlyRule $a
    if ($null -eq $rule) { return "每年 $($a.date)" }
    $hasNew = ($null -ne $a.months -and @($a.months).Count -gt 0)
    if (-not $hasNew) { return "每年 $($rule.Months[0]) 月 $($rule.Days[0]) 日" }
    return "每年 $($rule.Months -join '、') 月的 $($rule.Days -join '、') 號"
}

function Get-AlarmBaseType($a) {
    if ($a.type -eq "yearly") { return (Get-YearlyText $a) }
    if ($a.type -eq "monthly") { return "每月 $($a.days -join ',') 號" }
    elseif ($a.type -eq "daily") { return "每天" }
    elseif ($a.type -eq "weekly") {
        $names = @("一","二","三","四","五","六","日")
        $list = @()
        foreach ($d in $a.days) { $list += $names[$d - 1] }
        return "每週 星期" + ($list -join "、")
    }
    elseif ($a.type -eq "once") { return "單次 $($a.date)" }
    elseif ($a.type -eq "interval") { return "每$($a.intervalDays)天（下次:$($a.nextDueDate)）" }
    return ""
}

# ---------- 重要程度（工單 8.11 B） ----------
# 欄位 importance：normal（普通，預設）／quiz（要答題才能延後）／must（絕對不能延後）。沒有欄位、看不懂的值 = normal。
# quiz／must 一律走認真型流程（完成要答題）。跟手機版同一套規則。
$script:ImportanceKeys = @("normal", "quiz", "must")
$script:ImportanceLabels = @{ normal = "普通"; quiz = "要答題才能延後"; must = "絕對不能延後" }
function Get-AlarmImportance($a) {
    $v = ""
    try { $v = "$($a.importance)" } catch {}
    if ($script:ImportanceKeys -contains $v) { return $v }
    return "normal"
}
function Test-AlarmStrict($a) {
    if ((Get-AlarmImportance $a) -ne "normal") { return $true }
    if ($null -ne $a.strict) { return [bool]$a.strict }
    return (-not [bool]$a.timeLimited)
}

# 現在開著的提醒視窗裡，「重要鬧鐘」（要答題才能延後／絕對不能延後）的有哪些（系統匣的緊急停止用）
function Get-ImportantOpenForms($openForms) {
    $out = @()
    if ($null -eq $openForms) { return $out }
    foreach ($k in @($openForms.Keys)) {
        $f = $openForms[$k]
        if ($null -eq $f -or $f.IsDisposed) { continue }
        $imp = ""
        try { $imp = "$($f.Tag.Importance)" } catch {}
        if ($imp -eq "quiz" -or $imp -eq "must") { $out += , $f }
    }
    return $out
}

function Get-AlarmDescription($a) {
    $base = Get-AlarmBaseType $a
    $tags = @()
    if ($a.timeLimited) { $tags += "限時15分內" }
    if ($a.playSound -eq $false) { $tags += "靜音" }
    $isStrict = Test-AlarmStrict $a
    if (-not $isStrict) { $tags += "隨意型" }
    $imp = Get-AlarmImportance $a
    if ($imp -ne "normal") { $tags += $script:ImportanceLabels[$imp] }
    if ($tags.Count -gt 0) { $base = "$base（$($tags -join '、')）" }
    return $base
}

# ---------- 該不該響：候選日期（漏響補提醒的規則都在這） ----------

# 工單 10.1：唯一的週期日期判斷，排程候選、下次時間與範圍列表共用。
# 同步欄位 ringsOn：both / phone / pc；缺欄或未知值維持兩端都響。
function Get-AlarmRingsOn($a) {
    if ("$($a.ringsOn)" -ceq "phone") { return "phone" }
    if ("$($a.ringsOn)" -ceq "pc") { return "pc" }
    return "both"
}
function Test-AlarmRingsHere($a) { return ((Get-AlarmRingsOn $a) -ne "phone") }

function Test-AlarmDisabled($a) { return ($null -ne $a.disabled -and "$($a.disabled)" -eq "True") }

function Set-AlarmDisabled($a, [bool]$disabled, [DateTime]$now) {
    $a | Add-Member -NotePropertyName disabled -NotePropertyValue $disabled -Force
    if (-not $disabled) {
        Set-AlarmArmed $a $now
        $a | Add-Member -NotePropertyName reEnabledAt -NotePropertyValue (ConvertTo-ArmedText $now) -Force
        $a | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @($a.triggeredDates | Where-Object { $_ -ne $now.ToString("yyyy-MM-dd") }) -Force
    }
}

function Test-AlarmOccursOn($a, [DateTime]$d, [bool]$estimateInterval = $false) {
    if (Test-AlarmDisabled $a) { return $false }
    switch ("$($a.type)") {
        "daily" { return $true }
        "weekly" { $iso = [int]$d.DayOfWeek; if ($iso -eq 0) { $iso = 7 }; return ($a.days -contains $iso) }
        "monthly" { return ($a.days -contains $d.Day) }
        "yearly" { return (Test-YearlyRuleMatch (Get-YearlyRule $a) $d) }
        "once" { $base = ConvertTo-DateOnly $a.date; return ($null -ne $base -and $base -eq $d.Date) }
        "interval" {
            $base = ConvertTo-DateOnly $a.nextDueDate
            if ($null -eq $base) { return $false }
            if ($base -eq $d.Date) { return $true }
            $n = [Math]::Max(1, [int]$a.intervalDays)
            return ($estimateInterval -and $d.Date -gt $base -and (($d.Date - $base).Days % $n) -eq 0)
        }
    }
    return $false
}

function Get-CandidateDates($a, $now) {
    if (Test-AlarmDisabled $a) { return @() }
    $candidates = @()
    if ($a.type -eq "daily") {
        if (Test-AlarmOccursOn $a $now.Date) { $candidates += $now.Date }
    }
    elseif ($a.type -eq "monthly") {
        for ($i = 0; $i -le 35; $i++) {
            $d = $now.Date.AddDays(-$i)
            if (Test-AlarmOccursOn $a $d) { $candidates += $d }
        }
    }
    elseif ($a.type -eq "weekly") {
        for ($i = 0; $i -le 21; $i++) {
            $d = $now.Date.AddDays(-$i)
            $wd = [int]$d.DayOfWeek
            $iso = $wd
            if ($wd -eq 0) { $iso = 7 }
            if (Test-AlarmOccursOn $a $d) { $candidates += $d }
        }
    }
    elseif ($a.type -eq "once") {
        $d = ConvertTo-DateOnly $a.date
        if ($null -ne $d -and $d.Date -le $now.Date -and (Test-AlarmOccursOn $a $d)) { $candidates += $d.Date }
    }
    elseif ($a.type -eq "yearly") {
        # 每年固定日期（單一日期或多月多日）。**只往回看 7 天,而且找到最近一次就停**。
        # 不補幾個月前漏掉的 —— 認真型鬧鐘要答題,補一整年份會一次要你補答一堆題。
        # 日期不存在（2/29 平年、4/31…）→ 改在那個月最後一天響。
        $rule = Get-YearlyRule $a
        if ($null -ne $rule) {
            for ($i = 0; $i -le 7; $i++) {
                $d = $now.Date.AddDays(-$i)
                if (Test-AlarmOccursOn $a $d) {
                    $candidates += $d
                    break
                }
            }
        }
    }
    elseif ($a.type -eq "interval") {
        $d = ConvertTo-DateOnly $a.nextDueDate
        if ($null -ne $d -and $d.Date -le $now.Date -and (Test-AlarmOccursOn $a $d)) { $candidates += $d.Date }
    }

    $created = ConvertTo-DateOnly $a.createdDate
    if ($null -ne $created) {
        $candidates = @($candidates | Where-Object { $_.Date -ge $created.Date })
    }

    return ($candidates | Sort-Object)
}

# ---------- 同一個鬧鐘只留一筆待響（工單 8.8） ----------
# keepKey：留下來的那個日子（正要跳出來／正被延後的）；keepPending=$false（答對收掉）時連它也不留。
# 這個鬧鐘別的日子的「真的沒空」紀錄、狀態一律清掉；還欠著的其他應響日子（過了時間、沒完成）併進這一次、記成已完成，
# 不會之後一個一個再跳、一個一個再要答題。定期倒數只有一個到期日，不用併。
# $snoozeTable／$stateTable 是 hashtable（key 是「鬧鐘編號|日期」），直接改；回傳 @{ AlarmChanged; SnoozeChanged }
function Merge-AlarmPending($a, $snoozeTable, $stateTable, [string]$keepKey, [DateTime]$now, [bool]$keepPending = $true) {
    $res = @{ AlarmChanged = $false; SnoozeChanged = $false }
    $id = "$($a.id)"
    $keep = "$id|$keepKey"
    foreach ($k in @($snoozeTable.Keys)) {
        if ("$k".StartsWith("$id|") -and "$k" -ne $keep) { $snoozeTable.Remove($k); $res.SnoozeChanged = $true }
    }
    foreach ($k in @($stateTable.Keys)) {
        if ("$k".StartsWith("$id|") -and "$k" -ne $keep) { $stateTable.Remove($k) }
    }
    if ($a.type -ne "interval") {
        $tp = $null
        try { $tp = Get-AlarmTimeParts $a } catch {}
        if ($null -ne $tp) {
            if ($null -eq $a.triggeredDates) { $a | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @() -Force }
            foreach ($cd in @(Get-CandidateDates $a $now)) {
                if ($null -eq $cd) { continue }
                $key = $cd.ToString("yyyy-MM-dd")
                if ($key -eq $keepKey -or $a.triggeredDates -contains $key) { continue }
                if ($cd.Date.AddHours($tp[0]).AddMinutes($tp[1]) -gt $now) { continue }
                $a.triggeredDates = @($a.triggeredDates) + $key
                $res.AlarmChanged = $true
            }
        }
    }
    if (-not $keepPending) {
        if ($snoozeTable.ContainsKey($keep)) { $snoozeTable.Remove($keep); $res.SnoozeChanged = $true }
        if ($stateTable.ContainsKey($keep)) { $stateTable.Remove($keep) }
    }
    return $res
}

# 啟動時掃一次（升級後第一次開、開機後）：已經累積的重複「真的沒空」清掉，每個鬧鐘只留 until 最晚的那一筆
function Clear-DuplicateSnoozes($alarms, $snoozeTable, $stateTable, [DateTime]$now) {
    $res = @{ AlarmChanged = $false; SnoozeChanged = $false }
    foreach ($a in @($alarms)) {
        if (Test-AlarmDisabled $a) { continue }
        $id = "$($a.id)"
        $mine = @($snoozeTable.Keys | Where-Object { "$_".StartsWith("$id|") })
        if ($mine.Count -le 1) { continue }
        $best = @($mine | Sort-Object -Property @{ Expression = { $snoozeTable[$_].Until } }, @{ Expression = { "$_" } })[-1]
        $m = Merge-AlarmPending $a $snoozeTable $stateTable ($best.Substring($id.Length + 1)) $now $true
        if ($m.AlarmChanged) { $res.AlarmChanged = $true }
        if ($m.SnoozeChanged) { $res.SnoozeChanged = $true }
    }
    return $res
}

# ---------- 下次響的時間（列表排序、顯示用） ----------

# 回傳「現在之後」下一次要響的時間；單次鬧鐘已經過了就回傳 $null。
# 定期倒數(interval) 直接用 nextDueDate（過期未完成也照樣回傳，代表還欠著）。
function Get-NextOccurrence($a, $now) {
    if (Test-AlarmDisabled $a) { return $null }
    try {
        $tp = Get-AlarmTimeParts $a
        $h = $tp[0]; $m = $tp[1]
    } catch { return $null }

    if ($a.type -eq "once") {
        $d = ConvertTo-DateOnly $a.date
        if ($null -eq $d) { return $null }
        $t = $d.AddHours($h).AddMinutes($m)
        if ($t -gt $now) { return $t }
        return $null
    }
    if ($a.type -eq "interval") {
        $d = ConvertTo-DateOnly $a.nextDueDate
        if ($null -eq $d) { return $null }
        return $d.AddHours($h).AddMinutes($m)
    }

    $rule = $null
    $maxDays = 0
    if ($a.type -eq "daily") { $maxDays = 1 }
    elseif ($a.type -eq "weekly") { $maxDays = 7 }
    elseif ($a.type -eq "monthly") { $maxDays = 400 }
    elseif ($a.type -eq "yearly") {
        $rule = Get-YearlyRule $a
        if ($null -eq $rule) { return $null }
        $maxDays = 370
    }
    else { return $null }

    for ($i = 0; $i -le $maxDays; $i++) {
        $d = $now.Date.AddDays($i)
        $ok = Test-AlarmOccursOn $a $d
        if ($ok) {
            $t = $d.AddHours($h).AddMinutes($m)
            if ($t -gt $now) { return $t }
        }
    }
    return $null
}

# 列表排序：SortBy = "category"（分類，同分類再依下次時間）/ "next"（下次響的時間）/ "name"（名稱）
function Get-SortedAlarms($alarms, [string]$sortBy, $now) {
    $list = @($alarms | Where-Object { $null -ne $_ })
    $far = [DateTime]::MaxValue
    $nextKey = { $n = Get-NextOccurrence $_ $now; if ($null -eq $n) { $far } else { $n } }
    $nameKey = { "$($_.label)" }
    if ($sortBy -eq "name") {
        return @($list | Sort-Object -Property @{ Expression = $nameKey }, @{ Expression = $nextKey })
    }
    if ($sortBy -eq "next") {
        return @($list | Sort-Object -Property @{ Expression = $nextKey }, @{ Expression = $nameKey })
    }
    # 分類：「未分類」排最後
    $isDefaultKey = { if ((Get-AlarmCategory $_) -eq $script:DefaultCategory) { 1 } else { 0 } }
    $catKey = { Get-AlarmCategory $_ }
    return @($list | Sort-Object -Property @{ Expression = $isDefaultKey }, @{ Expression = $catKey }, @{ Expression = $nextKey }, @{ Expression = $nameKey })
}

# 所有出現過的分類名稱（加上使用者自己新增、目前還沒有鬧鐘的分類）
function Get-AllCategories($alarms, $extra) {
    $set = @()
    foreach ($c in @($extra)) { if ($null -ne $c -and "$c".Trim() -ne "" -and $set -notcontains "$c".Trim()) { $set += "$c".Trim() } }
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        $c = Get-AlarmCategory $a
        if ($c -ne $script:DefaultCategory -and $set -notcontains $c) { $set += $c }
    }
    return @($set | Sort-Object) + @($script:DefaultCategory)
}

# ---------- 「真的沒空」：延到幾點 ----------

# Choice: "30m" / "2h" / "tonight"（今晚 20:00，已過 20:00 → 明晚 20:00）/ "tomorrow"（明天早上 09:00）/ "custom"
# custom 的時間必須在「現在」之後，不然回傳 $null
function Get-NoTimeUntil([string]$choice, [DateTime]$now, $custom) {
    if ($choice -eq "30m") { return $now.AddMinutes(30) }
    if ($choice -eq "2h") { return $now.AddHours(2) }
    if ($choice -eq "tonight") {
        $t = $now.Date.AddHours(20)
        if ($t -le $now) { $t = $t.AddDays(1) }
        return $t
    }
    if ($choice -eq "tomorrow") { return $now.Date.AddDays(1).AddHours(9) }
    if ($choice -eq "custom") {
        if ($null -eq $custom) { return $null }
        $c = [DateTime]$custom
        $c = New-Object DateTime($c.Year, $c.Month, $c.Day, $c.Hour, $c.Minute, 0)
        if ($c -le $now) { return $null }
        return $c
    }
    return $null
}

# ---------- 「真的沒空」：存檔（重開機、重開程式也不會忘） ----------
# snoozes.json 只由背景提醒程式寫。格式：
#   [ { "alarmId": 3, "dateKey": "2026-09-30", "until": "2026-09-30 20:00:00" } ]

$script:SnoozeTimeFormat = "yyyy-MM-dd HH:mm:ss"

function Read-SnoozeFile([string]$path) {
    $table = @{}
    if (-not (Test-Path -LiteralPath $path)) { return $table }
    try {
        $content = Get-Content -LiteralPath $path -Raw -Encoding UTF8
        if ($null -eq $content -or $content.Trim() -eq "") { return $table }
        $data = $content | ConvertFrom-Json
        foreach ($s in @($data)) {
            if ($null -eq $s) { continue }
            $until = $null
            try { $until = [DateTime]::ParseExact("$($s.until)", $script:SnoozeTimeFormat, [System.Globalization.CultureInfo]::InvariantCulture) } catch { continue }
            $key = "$($s.alarmId)|$($s.dateKey)"
            $table[$key] = @{ AlarmId = $s.alarmId; DateKey = "$($s.dateKey)"; Until = $until }
        }
    } catch {}
    return $table
}

function Write-SnoozeFile([string]$path, $table) {
    $dataMutex = Enter-AlarmDataLock $path
    try {
        $list = @()
        foreach ($k in @($table.Keys | Sort-Object)) {
            $s = $table[$k]
            $list += [PSCustomObject]@{ alarmId = $s.AlarmId; dateKey = $s.DateKey; until = $s.Until.ToString($script:SnoozeTimeFormat, [System.Globalization.CultureInfo]::InvariantCulture) }
        }
        Write-AtomicText $path (ConvertTo-Json -InputObject @($list) -Depth 3)
    } finally { try { $dataMutex.ReleaseMutex() } finally { $dataMutex.Dispose() } }
}

function Set-NoTimeSnooze([string]$path, $alarmId, [string]$dateKey, [DateTime]$until) {
    $dataMutex = Enter-AlarmDataLock $path
    try {
        $table = Read-SnoozeFile $path
        $table["$alarmId|$dateKey"] = @{ AlarmId = $alarmId; DateKey = $dateKey; Until = $until }
        Write-SnoozeFile $path $table
    } finally { try { $dataMutex.ReleaseMutex() } finally { $dataMutex.Dispose() } }
}

function Remove-NoTimeSnooze([string]$path, $alarmId, [string]$dateKey) {
    $dataMutex = Enter-AlarmDataLock $path
    try {
        $table = Read-SnoozeFile $path
        $key = "$alarmId|$dateKey"
        if ($table.ContainsKey($key)) {
            $table.Remove($key)
            Write-SnoozeFile $path $table
        }
    } finally { try { $dataMutex.ReleaseMutex() } finally { $dataMutex.Dispose() } }
}

# 這個鬧鐘有哪些「真的沒空」已經到時間、該再跳出來的（最早的排前面）
function Get-DueNoTimeSnoozes($table, $alarmId, [DateTime]$now) {
    $due = @()
    foreach ($k in @($table.Keys)) {
        $s = $table[$k]
        if ("$($s.AlarmId)" -eq "$alarmId" -and $now -ge $s.Until) { $due += $s }
    }
    return @($due | Sort-Object -Property @{ Expression = { $_.Until } })
}

# ---------- alarms.json 讀寫 ----------

# 同目錄寫完才替換；失敗一定拋出，不能讓同步把未存好的資料當成基準。
function Write-AtomicText([string]$path, [string]$text) {
    $path = [System.IO.Path]::GetFullPath($path)
    $tmp = "$path.$([Guid]::NewGuid().ToString('N')).tmp"
    try {
        [System.IO.File]::WriteAllText($tmp, $text, (New-Object System.Text.UTF8Encoding($true)))
        if ([System.IO.File]::Exists($path)) { [System.IO.File]::Replace($tmp, $path, [NullString]::Value) }
        else { [System.IO.File]::Move($tmp, $path) }
    } finally {
        if ([System.IO.File]::Exists($tmp)) { [System.IO.File]::Delete($tmp) }
    }
}

# 最低可執行結構；不要求 uid，也不丟棄未知欄位。
function Test-AlarmStructure($a) {
    $id = 0
    if (-not [int]::TryParse("$($a.id)", [ref]$id) -or $id -lt 1) { return $false }
    if ($a.label -isnot [string] -or $a.time -isnot [string] -or $a.time -notmatch '^([01]?[0-9]|2[0-3]):[0-5][0-9]$') { return $false }
    switch ("$($a.type)") {
        "daily" { return $true }
        "once" { return ($null -ne (ConvertTo-DateOnly $a.date)) }
        "interval" {
            $n = 0
            return ([int]::TryParse("$($a.intervalDays)", [ref]$n) -and $n -gt 0 -and $null -ne (ConvertTo-DateOnly $a.nextDueDate))
        }
        "weekly" { $max = 7 }
        "monthly" { $max = 31 }
        "yearly" {
            try { $rule = Get-YearlyRule $a } catch { return $false }
            if ($null -eq $rule) { return $false }
            foreach ($m in $rule.Months) { if ($m -lt 1 -or $m -gt 12) { return $false } }
            foreach ($d in $rule.Days) { if ($d -lt 1 -or $d -gt 31) { return $false } }
            return $true
        }
        default { return $false }
    }
    if (@($a.days).Count -eq 0) { return $false }
    foreach ($d in @($a.days)) {
        $n = 0
        if (-not [int]::TryParse("$d", [ref]$n) -or $n -lt 1 -or $n -gt $max) { return $false }
    }
    return $true
}

function Read-AlarmFile([string]$path, [ref]$status) {
    if ($null -ne $status) { $status.Value = "missing" }
    if (-not (Test-Path -LiteralPath $path)) { return @() }
    if ($null -ne $status) { $status.Value = "invalid" }
    $content = Get-Content -LiteralPath $path -Raw -Encoding UTF8 -ErrorAction Stop
    # 一般讀取維持舊版空檔不當掉；同步必須檢查 invalid，不能把它當刪除。
    if ([string]::IsNullOrWhiteSpace($content)) { return @() }
    if ($content.Trim() -match '^\[\s*\]$') {
        if ($null -ne $status) { $status.Value = "valid" }
        return @()
    }
    $data = ConvertFrom-Json -InputObject $content -ErrorAction Stop
    # 舊版本曾寫單一物件，仍相容；null、數字等不能冒充鬧鐘清單。
    if ($null -eq $data -or $content.Trim() -notmatch '^[\[{]') { throw "鬧鐘檔格式錯誤：$path" }
    # ConvertFrom-Json 的純量也可能包著 PSObject；用實際型別，不能只測 -is。
    foreach ($alarm in @($data)) {
        if ($null -eq $alarm -or $alarm.GetType() -ne [System.Management.Automation.PSCustomObject]) { throw "鬧鐘檔格式錯誤：$path" }
    }
    foreach ($alarm in @($data)) { if (-not (Test-AlarmStructure $alarm)) { throw "鬧鐘結構不完整：$path" } }
    if ($null -ne $status) { $status.Value = "valid" }
    return @($data)
}

# 所有鬧鐘／延後 writer 共用同目錄 mutex；abandoned mutex 由 OS 自動回收。
function Enter-AlarmDataLock([string]$path, [int]$timeoutMs = 1500) {
    $dir = [System.IO.Path]::GetFullPath((Split-Path -Parent $path)).ToUpperInvariant()
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { $key = ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($dir)))).Replace("-", "") } finally { $sha.Dispose() }
    $m = New-Object System.Threading.Mutex($false, "Local\ShinkenAlarmData_$key")
    $got = $false
    try {
        try { $got = $m.WaitOne($timeoutMs) } catch [System.Threading.AbandonedMutexException] { $got = $true }
        if (-not $got) { throw "鬧鐘資料忙碌，請稍後重試。" }
        return $m
    } catch { $m.Dispose(); throw }
}

# UI 在對話框外取得 baseline；只提交使用者改動的欄位，保留鎖內讀到的其他更新。
function Save-AlarmChanges([string]$path, $proposed, $baseline) {
    $m = Enter-AlarmDataLock $path
    try {
        $readStatus = ""
        $fresh = @(Read-AlarmFile $path ([ref]$readStatus))
        if ($readStatus -eq "invalid") { throw "鬧鐘檔無法讀取，這次未儲存。" }
        $result = @($fresh)
        foreach ($old in @($baseline)) {
            $next = @($proposed | Where-Object { "$($_.id)" -eq "$($old.id)" }) | Select-Object -First 1
            $live = @($result | Where-Object { "$($_.id)" -eq "$($old.id)" }) | Select-Object -First 1
            if ($null -ne $live -and -not [string]::IsNullOrEmpty("$($old.uid)") -and "$($old.uid)" -ne "$($live.uid)") { continue }
            if ($null -eq $next) { $result = @($result | Where-Object { "$($_.id)" -ne "$($old.id)" }); continue }
            if ($null -eq $live) { continue } # 已刪除的鬧鐘不能由舊編輯快照復活
            $scheduleChanged = -not (Test-SameSchedule $old $next)
            $newDates = @(Get-PreservedTriggeredDates $live $next ((Get-Date).ToString("yyyy-MM-dd")))
            foreach ($prop in $next.PSObject.Properties) {
                $before = $old.PSObject.Properties[$prop.Name]
                if ($null -eq $before -or (ConvertTo-Json -InputObject $before.Value -Depth 64 -Compress) -cne (ConvertTo-Json -InputObject $prop.Value -Depth 64 -Compress)) {
                    if ($prop.Name -eq "quizMix" -and [string]::IsNullOrEmpty("$($prop.Value)")) {
                        if ($null -ne $live.PSObject.Properties["quizMix"]) { $live.PSObject.Properties.Remove("quizMix") }
                        continue
                    }
                    if ($prop.Name -eq "triggeredDates" -and (Test-SameSchedule $old $next)) {
                        $removed = @($old.triggeredDates | Where-Object { $next.triggeredDates -notcontains $_ })
                        $value = @(@($live.triggeredDates | Where-Object { $removed -notcontains $_ }) + @($next.triggeredDates) | Select-Object -Unique)
                    } else { $value = $prop.Value }
                    $live | Add-Member -NotePropertyName $prop.Name -NotePropertyValue $value -Force
                }
            }
            if ($scheduleChanged) { $live | Add-Member -NotePropertyName triggeredDates -NotePropertyValue $newDates -Force }
        }
        foreach ($next in @($proposed)) {
            if (@($baseline | Where-Object { "$($_.id)" -eq "$($next.id)" }).Count -gt 0) { continue }
            if (@($result | Where-Object { "$($_.id)" -eq "$($next.id)" }).Count -gt 0) {
                $next.id = 1 + [int](($result | Measure-Object id -Maximum).Maximum)
            }
            if ($null -ne $next.PSObject.Properties["quizMix"] -and [string]::IsNullOrEmpty("$($next.quizMix)")) {
                $next.PSObject.Properties.Remove("quizMix")
            }
            if ([string]::IsNullOrEmpty("$($next.uid)")) { $next | Add-Member uid ([Guid]::NewGuid().ToString("N")) -Force; $next | Add-Member uidProvisional $true -Force }
            $result += $next
        }
        Write-AlarmFile $path $result
        return $result
    } finally { try { $m.ReleaseMutex() } finally { $m.Dispose() } }
}

# 原始 baseline 交給最終 writer 在鎖內核對 UID；只提交這一筆的使用者改動。
function Save-AlarmDialogChange([string]$path, $original, $result) {
    $next = Merge-AlarmDialogEdit $original $result $original
    $next | Add-Member id $original.id -Force
    $next | Add-Member triggeredDates @(Get-PreservedTriggeredDates $original $next ((Get-Date).ToString("yyyy-MM-dd"))) -Force
    if (-not (Test-SameSchedule $original $next)) { Set-AlarmArmed $next (Get-Date) }
    if ((Test-AlarmDisabled $original) -and -not (Test-AlarmDisabled $next)) { Set-AlarmDisabled $next $false (Get-Date) }
    $next = Copy-MissingAlarmFields $original $next
    $saved = @(Save-AlarmChanges $path @($next) @($original))
    $committed = @($saved | Where-Object { "$($_.id)" -eq "$($original.id)" -and "$($_.uid)" -eq "$($original.uid)" }) | Select-Object -First 1
    if ($null -ne $committed -and (Test-AlarmDisabled $committed) -eq (Test-AlarmDisabled $next) -and (Test-AlarmDisabled $original) -ne (Test-AlarmDisabled $next)) {
        $dir = Split-Path $path
        Clear-SnoozeCount (Join-Path $dir "snooze_counts.json") $original.id
        $snPath = Join-Path $dir "snoozes.json"
        foreach ($sn in (Read-SnoozeFile $snPath).Values) {
            if ("$($sn.AlarmId)" -eq "$($original.id)") { Remove-NoTimeSnooze $snPath $original.id $sn.DateKey }
        }
    }
    return $saved
}

function Write-AlarmFile([string]$path, $alarms) {
    $dataMutex = Enter-AlarmDataLock $path
    try {
        $json = ConvertTo-Json -InputObject @($alarms) -Depth 64
        if (@($alarms).Count -eq 0) { $json = "[]" }
        Write-AtomicText $path $json
    } finally { try { $dataMutex.ReleaseMutex() } finally { $dataMutex.Dispose() } }
}

# 工單 10.0：次數只存在本機，key 是同一鬧鐘＋原定日子，不能跟著同步。
function Get-AlarmSnoozeLimit($alarm) {
    $n = 0
    if ([int]::TryParse("$($alarm.snoozeLimit)", [ref]$n) -and $n -ge 0 -and $n -le 3) { return $n }
    return 0
}
function Read-SnoozeCounts([string]$path) {
    $out = @{}
    if (-not (Test-Path -LiteralPath $path)) { return $out }
    try {
        $o = Get-Content -LiteralPath $path -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        if ($null -eq $o -or $o.GetType() -ne [System.Management.Automation.PSCustomObject]) { throw "計數格式錯誤" }
        foreach ($p in $o.PSObject.Properties) {
            $n = 0
            if ($p.Value -is [string] -or $p.Value -is [bool] -or -not [int]::TryParse("$($p.Value)", [ref]$n) -or $n -lt 0) { throw "計數值錯誤" }
            $out[$p.Name] = $n
        }
    } catch {
        $out = @{}
        $backup = "$path.corrupt-$([Guid]::NewGuid().ToString('N'))"
        try { Move-Item -LiteralPath $path -Destination $backup -ErrorAction Stop }
        catch { Write-Warning "計數檔無法隔離，保留原件 $path；本輪採零次：$_" }
    }
    return $out
}
function Test-SnoozeAvailable($alarm, [int]$used) {
    $limit = Get-AlarmSnoozeLimit $alarm
    return ((Get-AlarmImportance $alarm) -ne "must" -and ($limit -eq 0 -or $used -lt $limit))
}
# FormClosing 和測試共用同一個判斷：重要鬧鐘或用完次數都不能用 X 延後。
function Test-SnoozeCloseBlocked($alarm, [int]$used) {
    return ((Get-AlarmImportance $alarm) -ne "normal" -or -not (Test-SnoozeAvailable $alarm $used))
}
function Add-SnoozeCount([string]$path, $alarm, [string]$dateKey) {
    $counts = Read-SnoozeCounts $path
    $key = "$($alarm.id)|$dateKey"
    if (-not (Test-SnoozeAvailable $alarm ([int]$counts[$key]))) { return $false }
    $counts[$key] = [int]$counts[$key] + 1
    Write-AtomicText $path (ConvertTo-Json -InputObject $counts)
    return $true
}
function Clear-SnoozeCount([string]$path, $alarmId) {
    $counts = Read-SnoozeCounts $path
    foreach ($k in @($counts.Keys)) { if ($k.StartsWith("$alarmId|")) { $counts.Remove($k) } }
    Write-AtomicText $path (ConvertTo-Json -InputObject $counts)
}
function Repair-SnoozeCounts([string]$path, $alarms) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    $counts = Read-SnoozeCounts $path
    $changed = $false
    foreach ($k in @($counts.Keys)) {
        $id, $day = $k -split '\|', 2
        $a = @($alarms | Where-Object { "$($_.id)" -eq $id })
        if ($a.Count -eq 0 -or @($a[0].triggeredDates) -contains $day -or ($a[0].type -eq "interval" -and "$($a[0].nextDueDate)" -gt $day)) {
            $counts.Remove($k); $changed = $true
        }
    }
    if ($changed) { Write-AtomicText $path (ConvertTo-Json -InputObject $counts) }
}

# 第一次使用（沒有 alarms.json）時建一個範例鬧鐘；有建就回傳 $true
function Initialize-AlarmFile([string]$path, $now) {
    $dataMutex = Enter-AlarmDataLock $path
    try {
        if (Test-Path -LiteralPath $path) { return $false }
        if ($null -eq $now) { $now = Get-Date }
        # 第一次打開已經過了 21:00 → 從明天才開始算，免得一打開就跳出來嚇人
        $start = $now.Date
        if ($now -ge $now.Date.AddHours(21)) { $start = $start.AddDays(1) }
        $sample = [PSCustomObject]@{
            type = "daily"; label = "喝水！（這是範例鬧鐘，可以改掉或刪掉）"; time = "21:00"; days = @(); date = ""
            timeLimited = $false; playSound = $true; strict = $true
            notes = "起來倒杯水。`r`n答對算術題才能關掉，這就是「真劍」。"
            category = "範例"
            id = 1; triggeredDates = @(); createdDate = $start.ToString("yyyy-MM-dd")
        }
        Write-AlarmFile $path @($sample)
        return $true
    } finally { try { $dataMutex.ReleaseMutex() } finally { $dataMutex.Dispose() } }
}

# ---------- 「開始生效」時間 armedAt（工單 8.2；Android 的 AlarmCore.kt 是同一套規則） ----------
# 漏響補提醒只補「開始生效之後」的應響時刻；建立、改時間／類型的那一刻之前的，一律不算漏響。
#   armedAt   ：建立、修改（時間／類型／日期…）時記下的 UTC 時間，跟著同步
#   armedLocal：這台裝置自己記的（舊資料第一次載入、同步／匯入進來的那一刻），不同步
# 兩個取較晚的。都沒有（舊資料還沒蓋章）→ 不限制。
$script:ScheduleFields = @("type", "time", "days", "months", "date", "intervalDays")

function ConvertTo-ArmedText([DateTime]$t) {
    return $t.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ", [System.Globalization.CultureInfo]::InvariantCulture)
}

function ConvertFrom-ArmedText($text) {
    if ($null -eq $text -or "$text" -eq "") { return $null }
    try { return [DateTime]::Parse("$text", [System.Globalization.CultureInfo]::InvariantCulture, ([System.Globalization.DateTimeStyles]::AdjustToUniversal -bor [System.Globalization.DateTimeStyles]::AssumeUniversal)) } catch { return $null }
}

# 回傳本地時間的 DateTime；沒有任何生效時間 → $null
function Get-AlarmArmedTime($a) {
    $best = $null
    foreach ($f in @("armedAt", "armedLocal")) {
        $p = $a.PSObject.Properties[$f]
        if ($null -eq $p) { continue }
        $t = ConvertFrom-ArmedText $p.Value
        if ($null -eq $t) { continue }
        if ($null -eq $best -or $t -gt $best) { $best = $t }
    }
    if ($null -eq $best) { return $null }
    return $best.ToLocalTime()
}

function Set-AlarmArmed($a, [DateTime]$now) {
    $a | Add-Member -NotePropertyName armedAt -NotePropertyValue (ConvertTo-ArmedText $now) -Force
    $local = $now
    if ($now.Kind -eq [DateTimeKind]::Utc) { $local = $now.ToLocalTime() }
    $a | Add-Member -NotePropertyName armedDate -NotePropertyValue ($local.ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture)) -Force
}
function Set-AlarmArmedLocal($a, [DateTime]$now) { $a | Add-Member -NotePropertyName armedLocal -NotePropertyValue (ConvertTo-ArmedText $now) -Force }

# 兩份鬧鐘資料的「排程相關欄位」一樣嗎（改了時間、類型、日期這類才需要重新生效）
# 編輯存檔時要留下的 triggeredDates（工單 8.16）：排程有改才拿掉今天；沒改就全部保留
function Get-PreservedTriggeredDates($existing, $edited, [string]$todayKey) {
    $all = @($existing.triggeredDates | Where-Object { $null -ne $_ -and "$_" -ne "" })
    if (Test-SameSchedule $existing $edited) { return $all }
    return @($all | Where-Object { $_ -ne $todayKey })
}

function Test-SameSchedule($x, $y) {
    foreach ($f in $script:ScheduleFields) {
        $px = $x.PSObject.Properties[$f]; $py = $y.PSObject.Properties[$f]
        $vx = if ($null -eq $px -or $null -eq $px.Value) { "" } else { (@($px.Value) | ForEach-Object { "$_" }) -join "," }
        $vy = if ($null -eq $py -or $null -eq $py.Value) { "" } else { (@($py.Value) | ForEach-Object { "$_" }) -join "," }
        if ($vx -ne $vy) { return $false }
    }
    return $true
}

# 這個應響時刻在「開始生效」之前嗎（是 → 不算漏響，不補響）；沒有生效時間 → 否
function Test-OccurrenceBeforeArmed($a, [DateTime]$occ) {
    $armed = Get-AlarmArmedTime $a
    if ($null -eq $armed) { return $false }
    return ($occ -le $armed)
}

# 舊資料沒有任何生效時間：蓋成現在（寧可少補一次，也不要亂響）；有蓋到回傳 $true
function Set-MissingArmed($alarms, [DateTime]$now) {
    $changed = $false
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        if ($null -eq $a.PSObject.Properties["armedAt"] -and $null -eq $a.PSObject.Properties["armedLocal"]) { Set-AlarmArmedLocal $a $now; $changed = $true }
    }
    return $changed
}

# 編輯鬧鐘時：把舊鬧鐘有、新結果沒有的欄位照抄過去（未來新欄位、別的版本的欄位都不會掉）
function Copy-MissingAlarmFields($from, $to) {
    foreach ($p in $from.PSObject.Properties) {
        if ($null -eq $to.PSObject.Properties[$p.Name]) {
            $to | Add-Member -NotePropertyName $p.Name -NotePropertyValue $p.Value -Force
        }
    }
    return $to
}

# ---------- 設定視窗的小設定（排序方式、自己新增的分類、字體大小、粗體、外觀） ----------
# settings.json 舊版只有 sortBy / categories；新欄位讀不到就用預設值（標準字、淺色）

$script:FontSizeChoices = @("normal", "large", "xlarge")
$script:ThemeChoices = @("light", "dark")

function Read-AppSettings([string]$path) {
    $s = @{ sortBy = "category"; categories = @(); fontSize = "normal"; bold = $false; theme = "light"; categoryColors = @{}; privateCategories = @() }
    if (-not (Test-Path -LiteralPath $path)) { return $s }
    try {
        $data = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($null -ne $data.sortBy -and @("category", "next", "name") -contains "$($data.sortBy)") { $s.sortBy = "$($data.sortBy)" }
        if ($null -ne $data.categories) { $s.categories = @($data.categories | ForEach-Object { "$_" }) }
        if ($null -ne $data.fontSize -and $script:FontSizeChoices -contains "$($data.fontSize)") { $s.fontSize = "$($data.fontSize)" }
        if ($null -ne $data.bold) { $s.bold = ("$($data.bold)" -eq "True") }
        if ($null -ne $data.theme -and $script:ThemeChoices -contains "$($data.theme)") { $s.theme = "$($data.theme)" }
        $s.categoryColors = ConvertFrom-CategoryColorObject $data.categoryColors
        $s.privateCategories = @(Get-CleanPrivateCategories $data.privateCategories)
    } catch {}
    return $s
}

function Write-AppSettings([string]$path, $settings) {
    $fontSize = "normal"
    if ($script:FontSizeChoices -contains "$($settings.fontSize)") { $fontSize = "$($settings.fontSize)" }
    $bold = $false
    if ($settings.bold -eq $true) { $bold = $true }
    $theme = "light"
    if ($script:ThemeChoices -contains "$($settings.theme)") { $theme = "$($settings.theme)" }
    $json = [PSCustomObject]@{ sortBy = $settings.sortBy; categories = @($settings.categories); fontSize = $fontSize; bold = $bold; theme = $theme; categoryColors = (ConvertTo-CategoryColorObject $settings.categoryColors); privateCategories = @(Get-CleanPrivateCategories $settings.privateCategories) } | ConvertTo-Json -Depth 4
    Write-AtomicText $path $json
}

# 字體大小 → 放大倍率（標準 1.0 / 大 1.3 / 特大 1.6）
function Get-FontScaleFactor([string]$fontSize) {
    if ($fontSize -eq "large") { return 1.3 }
    if ($fontSize -eq "xlarge") { return 1.6 }
    return 1.0
}

# ---------- 分類管理：改名、刪除（只改記憶體裡的清單，存檔交給呼叫的人） ----------

# 每個分類底下有幾個鬧鐘：回傳 @( @{ Name = "工作"; Count = 3 }, ... )，「未分類」永遠在最後
function Get-CategoryCounts($alarms, $extra) {
    $result = @()
    foreach ($c in (Get-AllCategories $alarms $extra)) {
        $n = @(@($alarms) | Where-Object { $null -ne $_ -and (Get-AlarmCategory $_) -eq $c }).Count
        $result += @{ Name = $c; Count = $n }
    }
    return $result
}

# 改名：用到舊名稱的鬧鐘全部改成新名稱；自己新增的分類清單也一起改。新名稱已經存在 → 兩個分類合併。
# 回傳 @{ Ok; Error; Changed(改到幾個鬧鐘); Categories(新的分類清單) }
function Rename-AlarmCategory($alarms, $categories, [string]$oldName, [string]$newName) {
    $old = "$oldName".Trim()
    $new = "$newName".Trim()
    $cats = @(@($categories) | Where-Object { $null -ne $_ -and "$_".Trim() -ne "" } | ForEach-Object { "$_".Trim() })
    if ($old -eq $script:DefaultCategory) { return @{ Ok = $false; Error = "「$($script:DefaultCategory)」不能改名。"; Changed = 0; Categories = $cats } }
    if ($new -eq "") { return @{ Ok = $false; Error = "新名稱不能是空的。"; Changed = 0; Categories = $cats } }
    if ($new -eq $script:DefaultCategory) { return @{ Ok = $false; Error = "不能改成「$($script:DefaultCategory)」。想把鬧鐘變回未分類，請用「刪除」。"; Changed = 0; Categories = $cats } }
    if ($new -eq $old) { return @{ Ok = $true; Error = ""; Changed = 0; Categories = $cats } }

    $changed = 0
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        if ((Get-AlarmCategory $a) -eq $old) {
            $a | Add-Member -NotePropertyName category -NotePropertyValue $new -Force
            $changed++
        }
    }
    $newCats = @()
    foreach ($c in $cats) {
        $n = $c
        if ($c -eq $old) { $n = $new }
        if ($newCats -notcontains $n) { $newCats += $n }
    }
    return @{ Ok = $true; Error = ""; Changed = $changed; Categories = $newCats }
}

# 刪除：底下的鬧鐘不刪，改成「未分類」；分類清單拿掉這個名字。
# 回傳 @{ Ok; Error; Changed(變成未分類的鬧鐘數); Categories }
function Remove-AlarmCategory($alarms, $categories, [string]$name) {
    $target = "$name".Trim()
    $cats = @(@($categories) | Where-Object { $null -ne $_ -and "$_".Trim() -ne "" } | ForEach-Object { "$_".Trim() })
    if ($target -eq $script:DefaultCategory -or $target -eq "") { return @{ Ok = $false; Error = "「$($script:DefaultCategory)」不能刪除。"; Changed = 0; Categories = $cats } }
    $changed = 0
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        if ((Get-AlarmCategory $a) -eq $target) {
            $a | Add-Member -NotePropertyName category -NotePropertyValue $script:DefaultCategory -Force
            $changed++
        }
    }
    return @{ Ok = $true; Error = ""; Changed = $changed; Categories = @($cats | Where-Object { $_ -ne $target }) }
}

# ---------- 列表欄寬：視窗放大時，多出來的寬度依各欄原本寬度的比例分配 ----------
# $firstWeight：第一欄（內容）多拿一點的倍數，例如 2 = 以兩倍的權重分；可用寬度沒比原本大就回到原寬度
function Get-DistributedColumnWidths($baseWidths, [int]$available, [double]$firstWeight) {
    $base = @($baseWidths | ForEach-Object { [int]$_ })
    $total = 0
    foreach ($w in $base) { $total += $w }
    $extra = $available - $total
    if ($base.Count -eq 0 -or $extra -le 0) { return $base }
    $weights = @()
    for ($i = 0; $i -lt $base.Count; $i++) {
        $wt = [double]$base[$i]
        if ($i -eq 0) { $wt = $wt * $firstWeight }
        $weights += $wt
    }
    $sumW = 0.0
    foreach ($wt in $weights) { $sumW += $wt }
    $result = @()
    $given = 0
    for ($i = 0; $i -lt $base.Count; $i++) {
        $add = [int][Math]::Floor($extra * $weights[$i] / $sumW)
        $result += ($base[$i] + $add)
        $given += $add
    }
    $result[0] = $result[0] + ($extra - $given)
    return $result
}

# ---------- 匯出／匯入（v1.3；跟 Android 版共用同一個格式） ----------
# 匯出檔：{"format": "shinken-alarm", "version": 1, "exportedAt": "...", "alarms": [...], "categories": [...]}
#   alarms 用 alarms.json 原本的鬧鐘欄位；**不匯出**這台裝置自己的狀態（已完成紀錄 triggeredDates 等），
#   「真的沒空」的延後本來就在另一個檔（snoozes.json），也不會帶過去。
#   讀不懂的欄位照留（之後版本加欄位才不會互相洗掉）。

$script:ExportFormat = "shinken-alarm"
$script:ExportVersion = 1
# 屬於「這台裝置自己的狀態」、不跟著匯出的欄位
$script:ExportStateFields = @("uidProvisional", "triggeredDates", "snoozes", "lastTriggered", "lastTriggeredAt", "lastRang", "lastRangAt", "armedLocal")
# 判斷「是不是同一個鬧鐘的內容」時不看的欄位（編號、狀態、建立日、定期倒數的進度）
$script:ContentIgnoreFields = @("id", "createdDate", "nextDueDate", "armedAt", "armedDate") + $script:ExportStateFields

# 預設檔名：真劍鬧鐘_我的鬧鐘_20261001.json
function Get-ExportFileName($now) {
    if ($null -eq $now) { $now = Get-Date }
    return "真劍鬧鐘_我的鬧鐘_$($now.ToString('yyyyMMdd', [System.Globalization.CultureInfo]::InvariantCulture)).json"
}

# 深拷貝一個鬧鐘（不動到原本的物件）
function Copy-AlarmObject($a) {
    return ($a | ConvertTo-Json -Depth 8 -Compress | ConvertFrom-Json)
}

# 拿掉裝置狀態欄位後的鬧鐘（拷貝）
function Get-AlarmWithoutState($a) {
    $c = Copy-AlarmObject $a
    foreach ($f in $script:ExportStateFields) {
        if ($null -ne $c.PSObject.Properties[$f]) { $c.PSObject.Properties.Remove($f) }
    }
    # 匯出不帶「生效時間」：匯入進來的那一刻才起算
    if ($null -ne $c.PSObject.Properties["armedAt"]) { $c.PSObject.Properties.Remove("armedAt") }
    $c.PSObject.Properties.Remove("armedDate")
    return $c
}

# 組出匯出內容（PSCustomObject）。$categories：使用者自己新增的分類（settings.json 的 categories）
function New-AlarmExport($alarms, $categories, $now, $colors, $privateCats = $null) {
    if ($null -eq $now) { $now = Get-Date }
    $list = @()
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        $list += (Get-AlarmWithoutState $a)
    }
    $cats = @()
    foreach ($c in @(Get-AllCategories $alarms $categories)) {
        if ($c -ne $script:DefaultCategory -and $cats -notcontains $c) { $cats += $c }
    }
    $export = [PSCustomObject]@{
        format     = $script:ExportFormat
        version    = $script:ExportVersion
        exportedAt = $now.ToString("yyyy-MM-ddTHH:mm:sszzz", [System.Globalization.CultureInfo]::InvariantCulture)
        app        = "$($script:AppName) Windows v$($script:AppVersion)"
        alarms     = $list
        categories = $cats
    }
    # 分類顏色（v1.6 之後）：舊版讀到這個欄位會直接忽略
    $cc = Update-CategoryColors $cats $colors
    if ($cc.Count -gt 0) { $export | Add-Member -NotePropertyName categoryColors -NotePropertyValue (ConvertTo-CategoryColorObject $cc) }
    # 私密分類（v1.6.1 之後）：舊版讀到忽略。鬧鐘自己的「私密」是鬧鐘的 private 欄位，隨鬧鐘一起匯出
    $pc = @(Get-CleanPrivateCategories $privateCats | Where-Object { $cats -contains $_ })
    if ($pc.Count -gt 0) { $export | Add-Member -NotePropertyName privateCategories -NotePropertyValue @($pc) }
    return $export
}

# 匯出成 json 字串（alarms、categories 是物件的屬性，只有一個鬧鐘時也會是陣列）
function ConvertTo-AlarmExportJson($export) {
    return ($export | ConvertTo-Json -Depth 8)
}

# 寫出匯出檔（UTF-8、不加 BOM，手機和其他程式都讀得懂）
function Export-AlarmFile([string]$path, $alarms, $categories, $now, $colors, $privateCats = $null) {
    $export = New-AlarmExport $alarms $categories $now $colors $privateCats
    $json = ConvertTo-AlarmExportJson $export
    [System.IO.File]::WriteAllText($path, $json, (New-Object System.Text.UTF8Encoding($false)))
    return $export
}

# 讀匯出檔：回傳 @{ Ok; Error; Alarms; Categories; Version; ExportedAt }
function Read-AlarmExport([string]$path) {
    $bad = @{ Ok = $false; Error = ""; Alarms = @(); Categories = @(); Version = 0; ExportedAt = ""; Colors = @{} }
    if (-not (Test-Path -LiteralPath $path)) { $bad.Error = "找不到檔案：$path"; return $bad }
    $text = $null
    try {
        $bytes = [System.IO.File]::ReadAllBytes($path)
        $start = 0
        if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) { $start = 3 }
        $text = (New-Object System.Text.UTF8Encoding($false)).GetString($bytes, $start, $bytes.Length - $start)
    } catch { $bad.Error = "檔案讀不出來：$($_.Exception.Message)"; return $bad }
    return (ConvertFrom-AlarmExportJson $text)
}

function ConvertFrom-AlarmExportJson([string]$text) {
    $bad = @{ Ok = $false; Error = ""; Alarms = @(); Categories = @(); Version = 0; ExportedAt = ""; Colors = @{} }
    $notOurs = "這個檔案不是「$($script:AppName)」匯出的鬧鐘檔，沒有匯入。`n（請選檔名像「真劍鬧鐘_我的鬧鐘_日期.json」的檔案）"
    if ($null -eq $text -or $text.Trim() -eq "") { $bad.Error = "檔案是空的。`n$notOurs"; return $bad }
    $data = $null
    try { $data = $text | ConvertFrom-Json } catch { $bad.Error = $notOurs; return $bad }
    if ($null -eq $data -or $data -is [System.Array] -or $null -eq $data.PSObject.Properties["format"]) { $bad.Error = $notOurs; return $bad }
    if ("$($data.format)" -ne $script:ExportFormat) { $bad.Error = "$notOurs`n（檔案裡寫的格式是「$($data.format)」）"; return $bad }
    $ver = 0
    try { $ver = [int]$data.version } catch { $ver = 0 }
    $list = @()
    if ($null -ne $data.alarms) {
        foreach ($a in @($data.alarms)) {
            if ($null -eq $a -or $a -isnot [System.Management.Automation.PSCustomObject]) { continue }
            $list += $a
        }
    }
    $cats = @()
    if ($null -ne $data.categories) {
        foreach ($c in @($data.categories)) {
            if ($null -eq $c) { continue }
            $t = "$c".Trim()
            if ($t -ne "" -and $t -ne $script:DefaultCategory -and $cats -notcontains $t) { $cats += $t }
        }
    }
    return @{ Ok = $true; Error = ""; Alarms = $list; Categories = $cats; Version = $ver; ExportedAt = "$($data.exportedAt)"; Colors = (ConvertFrom-CategoryColorObject $data.categoryColors); PrivateCats = @(Get-CleanPrivateCategories $data.privateCategories) }
}

# 「內容」比對用的字串：不看編號、狀態、建立日；空值和沒有這個欄位視為一樣
function Get-AlarmContentKey($a) {
    $parts = @()
    foreach ($p in @($a.PSObject.Properties | Sort-Object -Property Name)) {
        if ($script:ContentIgnoreFields -contains $p.Name) { continue }
        $v = $p.Value
        $s = ""
        if ($null -eq $v) { $s = "" }
        elseif ($v -is [System.Array]) {
            $items = @($v | ForEach-Object { "$_" })
            if ($items.Count -eq 0) { $s = "" } else { $s = "[" + ($items -join ",") + "]" }
        }
        elseif ($v -is [bool]) { if ($v) { $s = "true" } else { $s = "false" } }
        elseif ($v -is [System.Management.Automation.PSCustomObject]) { $s = ($v | ConvertTo-Json -Depth 8 -Compress) }
        else { $s = "$v" }
        if ($s -eq "") { continue }
        $parts += "$($p.Name)=$s"
    }
    return ($parts -join "`n")
}

# 匯入進來的鬧鐘先整理：拿掉裝置狀態；**已經過去的那幾次當作處理過**（免得一匯入就跳一堆舊提醒）
function Initialize-ImportedAlarm($a, [DateTime]$now) {
    $c = Get-AlarmWithoutState $a
    $done = @()
    if ("$($c.type)" -ne "interval") {
        $h = -1; $m = 0
        try { $tp = Get-AlarmTimeParts $c; $h = $tp[0]; $m = $tp[1] } catch { $h = -1 }
        if ($h -ge 0) {
            foreach ($d in @(Get-CandidateDates $c $now)) {
                if ($null -eq $d) { continue }
                if ($d.AddHours($h).AddMinutes($m) -le $now) { $done += $d.ToString("yyyy-MM-dd") }
            }
        }
    }
    $c | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @($done) -Force
    # 匯入的鬧鐘從匯入那一刻起算生效
    Set-AlarmArmedLocal $c $now
    return $c
}

function Get-AlarmIdNumber($a) {
    if ($null -eq $a -or $null -eq $a.id) { return $null }
    $n = 0
    if ([int]::TryParse("$($a.id)", [ref]$n) -and $n -gt 0) { return $n }
    return $null
}

# 全部取代：回傳整理好的鬧鐘清單（編號重複或沒有編號的會給新編號）
function Get-ReplacedAlarms($imported, [DateTime]$now) {
    $result = @()
    $used = @{}
    $maxId = 0
    foreach ($b in @($imported)) { $n = Get-AlarmIdNumber $b; if ($null -ne $n -and $n -gt $maxId) { $maxId = $n } }
    foreach ($b in @($imported)) {
        if ($null -eq $b) { continue }
        $c = Initialize-ImportedAlarm $b $now
        $n = Get-AlarmIdNumber $c
        if ($null -eq $n -or $used.ContainsKey($n)) { $maxId++; $n = $maxId }
        $c | Add-Member -NotePropertyName id -NotePropertyValue $n -Force
        $used[$n] = $true
        $result += $c
    }
    return $result
}

# 合併：用內部編號判斷是不是同一個鬧鐘。
#   編號一樣、內容也一樣 → 不重複加（留本機的，本機的已完成紀錄不動）
#   編號一樣、內容不同   → 當成新鬧鐘，換新編號
#   本機沒有這個編號     → 直接加進來
# 回傳 @{ Alarms; Added; Skipped; Renumbered }
function Merge-ImportedAlarms($current, $imported, [DateTime]$now) {
    $result = @()
    foreach ($a in @($current)) { if ($null -ne $a) { $result += $a } }
    $byId = @{}
    $maxId = 0
    foreach ($a in $result) {
        $n = Get-AlarmIdNumber $a
        if ($null -ne $n) { $byId[$n] = $a; if ($n -gt $maxId) { $maxId = $n } }
    }
    foreach ($b in @($imported)) { $n = Get-AlarmIdNumber $b; if ($null -ne $n -and $n -gt $maxId) { $maxId = $n } }
    $added = 0; $skipped = 0; $renumbered = 0
    foreach ($b in @($imported)) {
        if ($null -eq $b) { continue }
        $c = Initialize-ImportedAlarm $b $now
        $n = Get-AlarmIdNumber $c
        if ($null -ne $n -and $byId.ContainsKey($n)) {
            if ((Get-AlarmContentKey $byId[$n]) -eq (Get-AlarmContentKey $c)) { $skipped++; continue }
            $maxId++; $n = $maxId; $renumbered++
        } elseif ($null -eq $n) {
            $maxId++; $n = $maxId; $renumbered++
        }
        $c | Add-Member -NotePropertyName id -NotePropertyValue $n -Force
        $byId[$n] = $c
        $result += $c
        $added++
    }
    return @{ Alarms = $result; Added = $added; Skipped = $skipped; Renumbered = $renumbered }
}

# 分類清單合併（不重複、不含「未分類」）
function Merge-CategoryLists($a, $b) {
    $out = @()
    foreach ($c in (@($a) + @($b))) {
        if ($null -eq $c) { continue }
        $t = "$c".Trim()
        if ($t -ne "" -and $t -ne $script:DefaultCategory -and $out -notcontains $t) { $out += $t }
    }
    return $out
}

# 全部取代前的備份：alarms.json → 同資料夾的 alarms_匯入前備份_20261001_153000.json；沒有原檔回傳 $null
function Backup-AlarmFileBeforeImport([string]$path, $now) {
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    if ($null -eq $now) { $now = Get-Date }
    $dir = Split-Path -Parent $path
    $name = "alarms_匯入前備份_$($now.ToString('yyyyMMdd_HHmmss', [System.Globalization.CultureInfo]::InvariantCulture)).json"
    $dest = Join-Path $dir $name
    $i = 2
    while (Test-Path -LiteralPath $dest) { $dest = Join-Path $dir ($name -replace "\.json$", "_$i.json"); $i++ }
    Copy-Item -LiteralPath $path -Destination $dest
    return $dest
}

# Google 雲端硬碟電腦版的資料夾（常見 G:\我的雲端硬碟、G:\My Drive）；找不到回傳 $null
# $candidates 不給就用預設的猜法（每個磁碟機 + 使用者資料夾）
function Get-GoogleDriveCandidates {
    $list = @()
    $roots = @()
    try { $roots = @([System.IO.DriveInfo]::GetDrives() | Where-Object { $_.IsReady } | ForEach-Object { $_.RootDirectory.FullName }) } catch {}
    # G: 最常見，先看
    $roots = @($roots | Where-Object { $_ -like "G:*" }) + @($roots | Where-Object { $_ -notlike "G:*" })
    foreach ($r in $roots) {
        $list += (Join-Path $r "我的雲端硬碟")
        $list += (Join-Path $r "My Drive")
    }
    if ($env:USERPROFILE) {
        foreach ($n in @("我的雲端硬碟", "My Drive", "Google Drive", "Google 雲端硬碟")) { $list += (Join-Path $env:USERPROFILE $n) }
    }
    return $list
}

function Find-GoogleDriveFolder($candidates) {
    if ($null -eq $candidates) { $candidates = Get-GoogleDriveCandidates }
    foreach ($c in @($candidates)) {
        if ($null -eq $c -or "$c" -eq "") { continue }
        try { if (Test-Path -LiteralPath $c -PathType Container) { return "$c" } } catch {}
    }
    return $null
}

# ---------- 分類顏色（工單 7.1；規則跟 Android 版 CategoryColorLogic.kt 一樣） ----------
#   ・每個分類一個顏色，存成「分類名稱 → 色票編號」（settings.json 的 categoryColors，跟著同步、匯出匯入一起帶）；
#   ・「未分類」固定灰色，不存；
#   ・新分類（或舊資料還沒有顏色的分類）自動挑一個還沒被別的分類用過的顏色；用完了就挑用得最少的；
#   ・同樣的分類清單，兩邊算出來的顏色要一樣：沒顏色的分類依名稱排序後逐個分配。

function Test-CategoryColorId($id) {
    if ($null -eq $id) { return $false }
    return ($script:CategoryColorIds -ccontains "$id")
}

# 某個色票在淺色／深色模式下的色值（RGB 整數）；找不到就用灰色
function Get-CategoryColorStyle($id, [bool]$dark) {
    $mode = "light"
    if ($dark) { $mode = "dark" }
    $t = $script:CategoryColorTable[$mode]
    if ($null -ne $id -and $t.ContainsKey("$id")) { return $t["$id"] }
    return $t["gray"]
}

# 補齊顏色：回傳新的對照表（只含目前存在的分類、不含「未分類」、色票編號都有效）
function Update-CategoryColors($categories, $colors) {
    $names = @()
    foreach ($c in @($categories)) {
        if ($null -eq $c) { continue }
        $t = "$c".Trim()
        if ($t -ne "" -and $t -ne $script:DefaultCategory -and $names -cnotcontains $t) { $names += $t }
    }
    $out = @{}
    foreach ($n in $names) {
        if ($null -ne $colors -and $colors.ContainsKey($n) -and (Test-CategoryColorId $colors[$n])) { $out[$n] = "$($colors[$n])" }
    }
    $missing = @($names | Where-Object { -not $out.ContainsKey($_) })
    [Array]::Sort($missing, [StringComparer]::Ordinal)
    foreach ($n in $missing) {
        $usage = @{}
        foreach ($id in $script:CategoryColorIds) { $usage[$id] = 0 }
        foreach ($v in @($out.Values)) { $usage["$v"]++ }
        $pick = $null
        foreach ($id in $script:CategoryColorIds) { if ($usage[$id] -eq 0) { $pick = $id; break } }
        if ($null -eq $pick) {
            $pick = $script:CategoryColorIds[0]
            foreach ($id in $script:CategoryColorIds) { if ($usage[$id] -lt $usage[$pick]) { $pick = $id } }
        }
        $out[$n] = $pick
    }
    return $out
}

# 這個分類的色票編號（未分類、沒顏色 → gray）
function Get-CategoryColorOf([string]$name, $colors) {
    if ($name -eq $script:DefaultCategory) { return "gray" }
    if ($null -ne $colors -and $colors.ContainsKey($name) -and (Test-CategoryColorId $colors[$name])) { return "$($colors[$name])" }
    return "gray"
}

# 改名：顏色跟著走；改成已經存在的名字（合併）→ 沿用那個分類原本的顏色
function Rename-CategoryColor($colors, [string]$old, [string]$new) {
    $out = @{}
    if ($null -ne $colors) { foreach ($k in @($colors.Keys)) { $out[$k] = $colors[$k] } }
    if ($out.ContainsKey($old)) {
        $c = $out[$old]
        $out.Remove($old)
        if (-not $out.ContainsKey($new)) { $out[$new] = $c }
    }
    return $out
}

function Remove-CategoryColor($colors, [string]$name) {
    $out = @{}
    if ($null -ne $colors) { foreach ($k in @($colors.Keys)) { if ($k -ne $name) { $out[$k] = $colors[$k] } } }
    return $out
}

# 對照表 ↔ 檔案裡的物件（名稱排序，色票編號無效的丟掉）
function ConvertFrom-CategoryColorObject($o) {
    $out = @{}
    if ($null -eq $o) { return $out }
    foreach ($p in @($o.PSObject.Properties)) {
        if ("$($p.Name)".Trim() -ne "" -and (Test-CategoryColorId $p.Value)) { $out["$($p.Name)"] = "$($p.Value)" }
    }
    return $out
}

function ConvertTo-CategoryColorObject($colors) {
    $o = [ordered]@{}
    if ($null -ne $colors) {
        $keys = @($colors.Keys | ForEach-Object { "$_" })
        [Array]::Sort($keys, [StringComparer]::Ordinal)
        foreach ($k in $keys) { $o[$k] = $colors[$k] }
    }
    return $o
}

# 對比度（WCAG）：兩個 RGB 整數
function Get-ColorLuminance([int]$rgb) {
    $v = @((($rgb -shr 16) -band 255), (($rgb -shr 8) -band 255), ($rgb -band 255)) | ForEach-Object {
        $x = $_ / 255.0
        if ($x -le 0.03928) { $x / 12.92 } else { [Math]::Pow(($x + 0.055) / 1.055, 2.4) }
    }
    return (0.2126 * $v[0] + 0.7152 * $v[1] + 0.0722 * $v[2])
}

function Get-ContrastRatio([int]$a, [int]$b) {
    $la = Get-ColorLuminance $a; $lb = Get-ColorLuminance $b
    return ([Math]::Max($la, $lb) + 0.05) / ([Math]::Min($la, $lb) + 0.05)
}

# ---------- 關鬧鐘的難度（工單 8.5；Android 的 core/Quiz.kt 是同一套） ----------
#   math1：算術 1 題（1～19 的加減）／math3：算術 3 題要連續答對／hard1：兩位數加減／hard2：兩位數×一位數／hard3：兩位數×兩位數
#   sq：兩位數平方（11～99，排除 10 的倍數）／disc：打折計算（100～2000 的 20 倍數，95/9/85/8/75/7/65/6/5 折）
#   qr：掃 QR code（只有手機能用；電腦上改答 3 題算術）
#   trivia：常識題四選一（1.18.0 只有手機出題；電腦認得、存檔照留，響鈴改出算術。選單不列）
$script:QuizChoices = @("math1", "math3", "hard1", "hard2", "hard3", "sq", "disc")
$script:QuizMixChoices = @("math1", "hard1", "hard2", "hard3", "sq", "disc", "trivia")
$script:QuizAllChoices = @("math1", "math3", "hard1", "hard2", "hard3", "sq", "disc", "trivia", "qr")
$script:QuizLabels = @{ math1 = "算術 1 題"; math3 = "算術 3 題（連續答對）"; hard1 = "變難 1：兩位數加減"; hard2 = "變難 2：兩位數 × 一位數"; hard3 = "變難 3：兩位數 × 兩位數"; sq = "鍛腦 1：兩位數平方"; disc = "鍛腦 2：打折計算"; trivia = "常識題（手機出題；電腦上改答算術）"; qr = "手機掃 QR（電腦上改答 3 題）" }

# 讀取時決定題庫（與 Android Quiz.pool 同一套規則）
function Get-QuizPool($difficulty, $quizMix = "") {
    $d = "math1"
    if ($null -ne $difficulty -and ($difficulty -is [string]) -and $script:QuizAllChoices -ccontains $difficulty) { $d = $difficulty }
    if ($script:QuizMixChoices -ccontains $d -and ($quizMix -is [string]) -and -not [string]::IsNullOrWhiteSpace($quizMix)) {
        $tokens = @($quizMix -split "," | ForEach-Object { $_.Trim() } | Where-Object { $script:QuizMixChoices -ccontains $_ })
        $picked = @($script:QuizMixChoices | Where-Object { $tokens -ccontains $_ })
        if ($picked.Count -ge 2 -and ($picked -ccontains $d)) { return $picked }
    }
    return @($d)
}

# 勾選集合 → 存檔的 (difficulty, quizMix)
function ConvertTo-QuizSaveFields($picked) {
    $list = @()
    if ($null -ne $picked) {
        foreach ($x in @($picked)) {
            foreach ($y in @($x)) {
                if ($y -is [string] -and $y -ne "") { $list += $y }
            }
        }
    }
    if ($list -ccontains "qr") { return @{ difficulty = "qr"; quizMix = "" } }
    if ($list -ccontains "math3") { return @{ difficulty = "math3"; quizMix = "" } }
    $mix = @($script:QuizMixChoices | Where-Object { $list -ccontains $_ })
    if ($mix.Count -eq 0) { return @{ difficulty = "math1"; quizMix = "" } }
    if ($mix.Count -eq 1) { return @{ difficulty = $mix[0]; quizMix = "" } }
    return @{ difficulty = $mix[0]; quizMix = ($mix -join ",") }
}

function Get-QuizSaveFields($difficulty, $quizMix = "") {
    if ($difficulty -is [System.Collections.IEnumerable] -and $difficulty -isnot [string] -and [string]::IsNullOrEmpty("$quizMix")) {
        return (ConvertTo-QuizSaveFields $difficulty)
    }
    $pool = @(Get-QuizPool $difficulty $quizMix)
    return (ConvertTo-QuizSaveFields $pool)
}

function Get-QuizButtonText($difficulty, $quizMix = "") {
    $pool = @(Get-QuizPool $difficulty $quizMix)
    if ($pool.Count -ge 2) {
        $labels = @($pool | ForEach-Object { $script:QuizLabels[$_] })
        return "混合 $($pool.Count) 種：" + ($labels -join "、")
    }
    $k = if ($pool.Count -eq 1 -and $script:QuizLabels.ContainsKey($pool[0])) { $pool[0] } else { "math1" }
    return $script:QuizLabels[$k]
}

# 這個鬧鐘的難度（不認得的值、沒有 → math1）；回傳 @{ Diff; Need; Pool; QuizMix }。qr 在電腦上等於 math3
function Get-QuizSpec($difficulty, $quizMix = "") {
    $d = "$difficulty"
    if ($d -ceq "qr") { return @{ Diff = "math3"; Need = 3; Pool = @("math3"); QuizMix = "" } }
    if ($script:QuizChoices -cnotcontains $d) { $d = "math1" }
    $pool = @(Get-QuizPool $d $quizMix)
    $saved = Get-QuizSaveFields $d $quizMix
    $need = 1
    if ($d -ceq "math3") { $need = 3 }
    return @{ Diff = $d; Need = $need; Pool = $pool; QuizMix = $saved.quizMix }
}

# 出一題：回傳 @{ Type; Text; Answer }（支援單一難度字串、題庫陣列、或傳入 quizMix）
function Get-QuizQuestion($difficulty, $quizMix = "") {
    $chosen = $null
    if ($difficulty -is [System.Collections.IEnumerable] -and $difficulty -isnot [string]) {
        $arr = @($difficulty | Where-Object { $null -ne $_ -and "$_" -ne "" } | ForEach-Object { "$_" })
        if ($arr.Count -gt 1) { $chosen = $arr[(Get-Random -Minimum 0 -Maximum $arr.Count)] }
        elseif ($arr.Count -eq 1) { $chosen = $arr[0] }
        else { $chosen = "math1" }
    } elseif ($quizMix -is [string] -and -not [string]::IsNullOrWhiteSpace($quizMix)) {
        $pool = @(Get-QuizPool $difficulty $quizMix)
        if ($pool.Count -gt 1) { $chosen = $pool[(Get-Random -Minimum 0 -Maximum $pool.Count)] }
        else { $chosen = $pool[0] }
    } else {
        $chosen = "$difficulty"
    }
    $qType = if ($chosen -in @("math1", "math3", "hard1", "hard2", "hard3", "sq", "disc")) { "$chosen" } else { "math1" }
    switch ("$chosen") {
        "hard1" {
            $a = Get-Random -Minimum 10 -Maximum 100; $b = Get-Random -Minimum 10 -Maximum 100
            if ((Get-Random -Minimum 0 -Maximum 2) -eq 0) { return @{ Type = $qType; Text = "$a + $b"; Answer = ($a + $b) } }
            if ($a -lt $b) { $t = $a; $a = $b; $b = $t }
            return @{ Type = $qType; Text = "$a - $b"; Answer = ($a - $b) }
        }
        "hard2" { $a = Get-Random -Minimum 11 -Maximum 100; $b = Get-Random -Minimum 2 -Maximum 10; return @{ Type = $qType; Text = "$a × $b"; Answer = ($a * $b) } }
        "hard3" { $a = Get-Random -Minimum 11 -Maximum 30; $b = Get-Random -Minimum 11 -Maximum 30; return @{ Type = $qType; Text = "$a × $b"; Answer = ($a * $b) } }
        "sq" {
            $n = [int](Get-Random -Minimum 11 -Maximum 100)
            while (($n % 10) -eq 0) { $n = [int](Get-Random -Minimum 11 -Maximum 100) }
            return @{ Type = $qType; Text = "$($n)²"; Answer = ([int]($n * $n)) }
        }
        "disc" {
            $pcts = @(95, 90, 85, 80, 75, 70, 65, 60, 50)
            $price = [int]((Get-Random -Minimum 5 -Maximum 101) * 20)
            $pct = [int]$pcts[(Get-Random -Minimum 0 -Maximum $pcts.Count)]
            $fold = if (($pct % 10) -eq 0) { [int]($pct / 10) } else { $pct }
            return @{ Type = $qType; Text = "$price 元打 $fold 折"; Answer = ([int](($price * $pct) / 100)) }
        }
        default {
            $n1 = Get-Random -Minimum 1 -Maximum 20; $n2 = Get-Random -Minimum 1 -Maximum 20
            if ((Get-Random -Minimum 0 -Maximum 2) -eq 0) { return @{ Type = $qType; Text = "$n1 + $n2"; Answer = ($n1 + $n2) } }
            if ($n1 -lt $n2) { $t = $n1; $n1 = $n2; $n2 = $t }
            return @{ Type = $qType; Text = "$n1 - $n2"; Answer = ($n1 - $n2) }
        }
    }
}

# ---------- 答錯隔天再考（錯題本；Android core/QuizReview.kt 同一套規則） ----------
$script:QuizReviewMaxSize = 10

function Expand-QuizReviewList($book) {
    $flat = @()
    foreach ($item in @($book)) {
        if ($null -eq $item) { continue }
        if ($item -is [System.Array] -or ($item -is [System.Collections.IEnumerable] -and $item -isnot [string] -and $item -isnot [System.Collections.IDictionary] -and $null -eq $item.PSObject.Properties["text"])) {
            foreach ($sub in $item) { if ($null -ne $sub) { $flat += $sub } }
        } else {
            $flat += $item
        }
    }
    return $flat
}

function Add-QuizReview($book, [string]$type, [string]$text, [string]$answer, [string]$today) {
    $out = @()
    foreach ($e in @(Expand-QuizReviewList $book)) {
        if ($null -eq $e) { continue }
        $t = "$($e.text)"
        if ($t -ne "" -and $t -cne $text) {
            $out += [PSCustomObject]@{ type = "$($e.type)"; text = $t; answer = "$($e.answer)"; day = "$($e.day)" }
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($text)) {
        $out += [PSCustomObject]@{ type = "$type"; text = "$text"; answer = "$answer"; day = "$today" }
    }
    if ($out.Count -gt $script:QuizReviewMaxSize) {
        $out = @($out[($out.Count - $script:QuizReviewMaxSize)..($out.Count - 1)])
    }
    if ($out.Count -eq 1) { return , @($out) }
    return @($out)
}

function Get-QuizReviewPick($book, $pool, [string]$today) {
    $poolArr = @($pool | Where-Object { $null -ne $_ } | ForEach-Object { "$_" })
    foreach ($e in @(Expand-QuizReviewList $book)) {
        if ($null -eq $e) { continue }
        if ("$($e.day)" -cne $today -and ($poolArr -contains "$($e.type)")) {
            return [PSCustomObject]@{ type = "$($e.type)"; text = "$($e.text)"; answer = "$($e.answer)"; day = "$($e.day)" }
        }
    }
    return $null
}

function Resolve-QuizReview($book, [string]$text, [bool]$correct, [string]$today) {
    $out = @()
    $hit = $null
    foreach ($e in @(Expand-QuizReviewList $book)) {
        if ($null -eq $e) { continue }
        $t = "$($e.text)"
        if ($t -ceq $text) {
            if ($null -eq $hit) {
                $hit = [PSCustomObject]@{ type = "$($e.type)"; text = $t; answer = "$($e.answer)"; day = "$today" }
            }
        } elseif ($t -ne "") {
            $out += [PSCustomObject]@{ type = "$($e.type)"; text = $t; answer = "$($e.answer)"; day = "$($e.day)" }
        }
    }
    if (-not $correct -and $null -ne $hit) {
        $out += $hit
    }
    if ($out.Count -eq 1) { return , @($out) }
    return @($out)
}

function ConvertTo-QuizReviewJson($book) {
    $items = @()
    foreach ($e in @(Expand-QuizReviewList $book)) {
        if ($null -eq $e) { continue }
        $t = "$($e.text)"
        $ty = "$($e.type)"
        if ($t -ne "" -and $ty -ne "") {
            $items += [PSCustomObject]@{ type = $ty; text = $t; answer = "$($e.answer)"; day = "$($e.day)" }
        }
    }
    if ($items.Count -eq 0) { return "[]" }
    $json = ConvertTo-Json -InputObject @($items) -Depth 3
    if (-not $json.TrimStart().StartsWith("[")) { $json = "[$json]" }
    return $json
}

function ConvertFrom-QuizReviewJson([string]$raw) {
    $out = @()
    if ([string]::IsNullOrWhiteSpace($raw)) { return @($out) }
    try {
        $parsed = $raw | ConvertFrom-Json
        if ($null -eq $parsed) { return @($out) }
        $arr = if ($parsed -is [System.Array]) { $parsed } elseif ($parsed -is [System.Collections.IEnumerable] -and $parsed -isnot [string] -and $parsed -isnot [System.Collections.IDictionary]) { @($parsed) } else { @($parsed) }
        foreach ($o in $arr) {
            if ($null -eq $o) { continue }
            $pType = $o.PSObject.Properties["type"]
            $pText = $o.PSObject.Properties["text"]
            if ($null -eq $pType -or $null -eq $pText) { continue }
            $ty = "$($pType.Value)"
            $tx = "$($pText.Value)"
            $ans = if ($null -ne $o.PSObject.Properties["answer"]) { "$($o.answer)" } else { "" }
            $dy = if ($null -ne $o.PSObject.Properties["day"]) { "$($o.day)" } else { "" }
            if ($ty -ne "" -and $tx -ne "") {
                $out += [PSCustomObject]@{ type = $ty; text = $tx; answer = $ans; day = $dy }
            }
        }
        if ($out.Count -gt $script:QuizReviewMaxSize) {
            $out = @($out[($out.Count - $script:QuizReviewMaxSize)..($out.Count - 1)])
        }
    } catch {
        return @()
    }
    if ($out.Count -eq 1) { return , @($out) }
    return @($out)
}

function Read-QuizReview([string]$path) {
    if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path)) { return @() }
    try {
        $raw = Get-Content -LiteralPath $path -Raw -Encoding UTF8 -ErrorAction Stop
        $out = @(Expand-QuizReviewList (ConvertFrom-QuizReviewJson $raw))
        if ($out.Count -eq 1) { return , @($out) }
        return @($out)
    } catch {
        return @()
    }
}

function Write-QuizReview([string]$path, $book) {
    if ([string]::IsNullOrWhiteSpace($path)) { return }
    $json = ConvertTo-QuizReviewJson $book
    Write-AtomicText $path $json
}

# ---------- 響鈴的時間規則（工單 8.4；Android 的 core/RingCycle.kt 是同一套） ----------
#   一直響到處理為止：連續響 10 分鐘沒人理 → 停聲 5 分鐘 → 再響；從開始響算起滿 60 分鐘還沒處理 → 不再出聲（視窗還在）
#   回傳 "ring"（該出聲）／"pause"（停聲中）／"gaveup"（放棄了）
function Get-RingPhase([double]$elapsedSeconds, [int]$ringMin = 10, [int]$pauseMin = 5, [int]$totalMin = 60) {
    # 沒有明確傳入的數字才讀設定；保留原本可傳參數的純計算用法。
    if (-not $PSBoundParameters.ContainsKey("ringMin") -or -not $PSBoundParameters.ContainsKey("pauseMin") -or -not $PSBoundParameters.ContainsKey("totalMin")) {
        $path = $script:RingSettingsPath
        if ([string]::IsNullOrEmpty($path)) { $path = Join-Path $PSScriptRoot "ring_settings.json" }
        $r = Read-RingSettings $path
        if (-not $PSBoundParameters.ContainsKey("ringMin")) { $ringMin = $r.ringMin }
        if (-not $PSBoundParameters.ContainsKey("pauseMin")) { $pauseMin = $r.pauseMin }
        if (-not $PSBoundParameters.ContainsKey("totalMin")) { $totalMin = $r.totalMin }
    }
    if ($ringMin -le 0) { $ringMin = 10 }
    if ($pauseMin -le 0) { $pauseMin = 5 }
    if ($totalMin -le 0) { $totalMin = 60 }
    if ($elapsedSeconds -lt 0) { return "ring" }
    if ($elapsedSeconds -ge ($totalMin * 60)) { return "gaveup" }
    $cycle = ($ringMin + $pauseMin) * 60
    if (($elapsedSeconds % $cycle) -lt ($ringMin * 60)) { return "ring" }
    return "pause"
}

# ---------- 每個鬧鐘的音量、漸強、鈴聲（2026-10-05 電腦版補齊；Android core/AlarmVolume.kt、core/RingSound.kt 同一套規則） ----------
# 鬧鐘欄位（跟著同步）：volume（20~100，%）、crescendo（true/false，沒有＝看重要程度與全域設定）、ringtone（""＝跟隨全域）
# 電腦上「音量 80%」＝ Windows 目前音量的 80%（電腦沒有獨立的鬧鐘音量，也不會去動系統音量）
$script:VolumeMin = 20
$script:VolumeMax = 100
$script:VolumeStep = 5
function Get-DefaultAlarmVolume([string]$importance) {
    switch ($importance) { "must" { return 100 } "quiz" { return 90 } default { return 80 } }
}
function Get-AlarmVolumeFloor([string]$importance) {
    switch ($importance) { "must" { return 50 } "quiz" { return 40 } default { return $script:VolumeMin } }
}
function Limit-AlarmVolume([int]$v, [string]$importance) {
    $r = [int]([Math]::Round($v / $script:VolumeStep, [MidpointRounding]::AwayFromZero) * $script:VolumeStep)
    return [Math]::Min($script:VolumeMax, [Math]::Max((Get-AlarmVolumeFloor $importance), $r))
}
function Get-AlarmVolume($a) {
    $imp = Get-AlarmImportance $a
    $v = $null
    try { if ($null -ne $a.volume -and "$($a.volume)" -match '^\s*-?\d+(\.0+)?\s*$') { $v = [int][double]"$($a.volume)" } } catch {}
    if ($null -eq $v) { $v = Get-DefaultAlarmVolume $imp }
    return (Limit-AlarmVolume $v $imp)
}
function Get-DefaultCrescendo([string]$importance, [bool]$global) {
    if ($importance -ne "normal") { return $false }
    return $global
}
function Get-AlarmCrescendo($a, [bool]$global) {
    try {
        if ($null -ne $a.crescendo) {
            $t = "$($a.crescendo)"
            if ($t -eq "True" -or $t -eq "true") { return $true }
            if ($t -eq "False" -or $t -eq "false") { return $false }
        }
    } catch {}
    return (Get-DefaultCrescendo (Get-AlarmImportance $a) $global)
}

# 鈴聲代號：phone（手機的鬧鐘鈴聲）／gentle／standard／loud（內建三種）／custom:<代號>（自訂，音檔只在那台裝置）
# 電腦另外有 system（Windows 提示音，1.8.3 以前的聲音）。電腦遇到 phone → 用這台電腦的全域設定
# 2026-10-05:Mureka 鈴聲歌切出來的 20 段(跟 Android core/RingSound.kt 的 RingTone.SONGS 同一份,tests.ps1 會比對);音檔 assets/tone_<代號>.mp3
$script:ToneSongs = [ordered]@{
    song01 = "起床歌・溫和起床"; song02 = "起床歌・標準起床"; song03 = "起床歌・午睡起床"; song04 = "起床歌・吃藥喝水"
    song05 = "起床歌・出門"; song06 = "起床歌・很忙"; song07 = "起床歌・垃圾車繳費"; song08 = "起床歌・叫不醒"
    song09 = "起床歌・叫不醒(加長)"; song10 = "起床歌・晚安"
    fast01 = "快起來・開場"; fast02 = "快起來・起床"; fast03 = "快起來・出門"; fast04 = "快起來・吃藥喝水"
    fast05 = "快起來・開會上課"; fast06 = "快起來・叫不醒"
    inst01 = "純音樂・沉穩"; inst02 = "純音樂・輕快"; inst03 = "純音樂・明亮"; inst04 = "純音樂・收尾"
}
$script:ToneBuiltins = @("gentle", "standard", "loud") + @($script:ToneSongs.Keys)
$script:ToneCustomPrefix = "custom:"
function Test-CustomTone([string]$v) { return ($null -ne $v -and $v.StartsWith($script:ToneCustomPrefix) -and $v.Length -gt $script:ToneCustomPrefix.Length) }
function Get-CustomToneId([string]$v) { return $v.Substring($script:ToneCustomPrefix.Length) }
# 鬧鐘自己的欄位：空的、看不懂的 → ""（跟隨全域）；舊的 builtin → standard
function Get-ValidAlarmTone([string]$v) {
    if ([string]::IsNullOrEmpty($v)) { return "" }
    if ($v -eq "builtin") { return "standard" }
    if (@("phone") + $script:ToneBuiltins -contains $v -or (Test-CustomTone $v)) { return $v }
    return ""
}
# 這台電腦的全域鈴聲：預設「內建・標準」
function Get-ValidPcTone([string]$v) {
    if ($v -eq "builtin") { return "standard" }
    if (@("system") + $script:ToneBuiltins -contains $v -or (Test-CustomTone $v)) { return $v }
    return "standard"
}
# 這個鬧鐘在這台電腦上實際要放的鈴聲；$customExists：代號 → 這台有沒有那個音檔
function Resolve-PcTone([string]$alarmTone, [string]$pcGlobal, [scriptblock]$customExists) {
    $t = Get-ValidAlarmTone $alarmTone
    if ($t -eq "" -or $t -eq "phone") { $t = Get-ValidPcTone $pcGlobal }
    if ((Test-CustomTone $t) -and -not (& $customExists (Get-CustomToneId $t))) { $t = "standard" }
    return $t
}
function Get-ToneLabel([string]$v, [scriptblock]$customName) {
    if ($v -eq "") { return "跟隨全域設定" }
    if ($v -eq "phone") { return "手機的鬧鐘鈴聲（電腦上用全域設定）" }
    if ($v -eq "system") { return "Windows 提示音（舊版的聲音）" }
    if ($v -eq "gentle") { return "內建・溫和" }
    if ($v -eq "standard" -or $v -eq "builtin") { return "內建・標準" }
    if ($v -eq "loud") { return "內建・很吵" }
    if ($script:ToneSongs.Contains($v)) { return "內建・" + $script:ToneSongs[$v] }
    if (Test-CustomTone $v) {
        $n = $null
        if ($null -ne $customName) { $n = & $customName (Get-CustomToneId $v) }
        if ($n) { return "自訂：$n" }
        return "自訂鈴聲（這台電腦沒有，改用內建・標準）"
    }
    return "內建・標準"
}
# 「絕對不能延後」又還是跟隨全域 → 建議改成很吵（跟手機一樣，只是預設）
function Get-SuggestedToneForImportance([string]$importance, [string]$current) {
    if ($importance -eq "must" -and $current -eq "") { return "loud" }
    return $current
}

# 漸強：從音量的一半開始，30 秒到設定的音量（每一段響鈴重新開始）
function Get-CrescendoVolume([int]$volume, [double]$secondsIntoSegment, [bool]$crescendo) {
    $full = $volume / 100.0
    if (-not $crescendo) { return $full }
    $f = [Math]::Min(1.0, [Math]::Max(0.0, $secondsIntoSegment / 30.0))
    return ($full * (0.5 + 0.5 * $f))
}

# 手機、電腦共用的響鈴規則與新增難度；數值必須是選項中的數字，不把字串、布林或小數硬轉整數。
$script:RingMinChoices = @(5, 10, 15, 20, 30)
$script:PauseMinChoices = @(3, 5, 10, 15)
$script:TotalMinChoices = @(30, 60, 120)
$script:RingDifficultyChoices = @("math1", "math3", "hard1", "hard2", "hard3", "sq", "disc", "trivia", "qr")
function Get-ValidRingMinutes($v, $choices, [int]$fallback) {
    if ($v -is [int] -or $v -is [long] -or $v -is [double] -or $v -is [decimal] -or $v -is [float] -or $v -is [System.Int16] -or $v -is [byte]) {
        foreach ($n in $choices) { if ([double]$v -eq [double]$n) { return [int]$n } }
    }
    return $fallback
}
# ringPrefs 的 JSON 欄名跟 Android 一樣以 ordinal 精確比對；也支援本機的字典。
function Get-RingPrefField($o, [string]$name) {
    if ($null -eq $o) { return $null }
    if ($o -is [System.Collections.IDictionary]) {
        foreach ($key in $o.Keys) { if ([StringComparer]::Ordinal.Equals([string]$key, $name)) { return , $o[$key] } }
    } else {
        foreach ($p in $o.PSObject.Properties) { if ([StringComparer]::Ordinal.Equals($p.Name, $name)) { return , $p.Value } }
    }
    return $null
}
function Get-ValidRingPrefs($r) {
    $d = "math1"
    $difficulty = Get-RingPrefField $r "difficulty"
    if ($difficulty -is [string] -and $script:RingDifficultyChoices -ccontains $difficulty) { $d = $difficulty }
    $rawMix = Get-RingPrefField $r "quizMix"
    $mixStr = if ($rawMix -is [string]) { $rawMix } else { "" }
    $saved = Get-QuizSaveFields $d $mixStr
    $o = [ordered]@{
        ringMin = (Get-ValidRingMinutes (Get-RingPrefField $r "ringMin") $script:RingMinChoices 10)
        pauseMin = (Get-ValidRingMinutes (Get-RingPrefField $r "pauseMin") $script:PauseMinChoices 5)
        totalMin = (Get-ValidRingMinutes (Get-RingPrefField $r "totalMin") $script:TotalMinChoices 60)
        difficulty = $saved.difficulty
    }
    if ($saved.quizMix -ne "") { $o["quizMix"] = $saved.quizMix }
    return $o
}

# 響鈴設定（ring_settings.json）：四個共用值跟著同步，鈴聲、漸強、提前提醒仍留在本機。
function Read-RingSettings([string]$path, $readStatus = $null) {
    $s = @{ tone = "standard"; crescendo = $true; upcomingMin = $script:UpcomingDefaultMin }
    $status = "missing"
    if (-not [string]::IsNullOrEmpty($path)) {
        $stream = $null; $reader = $null
        try {
            $share = [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete
            $stream = [System.IO.File]::Open($path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, $share)
            $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8, $true)
            $text = $reader.ReadToEnd()
            if (-not $text.TrimStart().StartsWith("{")) { throw "響鈴設定必須是 JSON 物件" }
            $d = $text | ConvertFrom-Json -ErrorAction Stop
            if ($d -isnot [System.Management.Automation.PSCustomObject]) { throw "響鈴設定必須是 JSON 物件" }
            foreach ($p in $d.PSObject.Properties) { $s[$p.Name] = $p.Value }
            $status = "ok"
        } catch [System.IO.FileNotFoundException] {
            $status = "missing"
        } catch [System.IO.DirectoryNotFoundException] {
            $status = "missing"
        } catch {
            $status = "invalid"
        } finally {
            if ($null -ne $reader) { $reader.Dispose() }
            elseif ($null -ne $stream) { $stream.Dispose() }
        }
    }
    if ($readStatus -is [ref]) { $readStatus.Value = $status }
    $s.tone = Get-ValidPcTone "$($s.tone)"
    $s.crescendo = ("$($s.crescendo)" -eq "True")
    try { $s.upcomingMin = Get-ValidUpcomingMin ([int]"0$($s.upcomingMin)") } catch { $s.upcomingMin = $script:UpcomingDefaultMin }
    $r = Get-ValidRingPrefs $s
    foreach ($k in $r.Keys) { $s[$k] = $r[$k] }
    $s["quizMix"] = if ($r.Contains("quizMix")) { $r["quizMix"] } else { "" }
    return $s
}
# GUI 與同步共用同一把鎖；與同步鎖一樣使用 Local 範圍。逾時讓呼叫端顯示失敗，不掛住 UI。
function Enter-RingSettingsLock([int]$timeoutMs = 1500) {
    $mutex = New-Object System.Threading.Mutex($false, "Local\ShinkenAlarmRingSettings")
    $got = $false
    try {
        try { $got = $mutex.WaitOne($timeoutMs) }
        catch [System.Threading.AbandonedMutexException] { $got = $true }
        if (-not $got) { throw "響鈴設定正由另一個視窗或同步更新，這次未儲存，請稍後再試。" }
        return $mutex
    } finally {
        if (-not $got) { $mutex.Dispose() }
    }
}
function Write-RingSettings([string]$path, $s) {
    $mutex = Enter-RingSettingsLock
    try {
        # 只改傳入的欄位，原本的欄位（含新版才認得的）照留。
        $out = Read-RingSettings $path
        $hasDiff = ($null -ne (Get-RingPrefField $s "difficulty"))
        $hasMix = ($null -ne (Get-RingPrefField $s "quizMix"))
        if ($s -is [System.Collections.IDictionary]) { foreach ($k in $s.Keys) { $out[$k] = $s[$k] } }
        else { foreach ($p in $s.PSObject.Properties) { $out[$p.Name] = $p.Value } }
        if ($hasDiff -and -not $hasMix) { $out["quizMix"] = "" }
        $out.tone = Get-ValidPcTone "$($out.tone)"
        $out.crescendo = ("$($out.crescendo)" -eq "True")
        try { $out.upcomingMin = Get-ValidUpcomingMin ([int]$out.upcomingMin) } catch { $out.upcomingMin = $script:UpcomingDefaultMin }
        $r = Get-ValidRingPrefs $out
        foreach ($k in $r.Keys) { $out[$k] = $r[$k] }
        if (-not $r.Contains("quizMix")) { $out.Remove("quizMix") }
        # 提醒視窗每幾秒會讀一次：先完整寫好再換檔，避免讀到半份 JSON。
        $tmp = "$path.$([Guid]::NewGuid().ToString('N')).tmp"
        try {
            [System.IO.File]::WriteAllText($tmp, (ConvertTo-Json -InputObject $out -Depth 16), (New-Object System.Text.UTF8Encoding($true)))
            for ($attempt = 1; $attempt -le 5; $attempt++) {
                try {
                    if (Test-Path -LiteralPath $path) { [System.IO.File]::Replace($tmp, $path, [NullString]::Value) }
                    else { [System.IO.File]::Move($tmp, $path) }
                    break
                } catch [System.IO.IOException] {
                    if ($attempt -eq 5) { throw }
                    Start-Sleep -Milliseconds 100
                }
            }
        } finally {
            if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force }
        }
    } finally {
        try { $mutex.ReleaseMutex() } finally { $mutex.Dispose() }
    }
}

# ---------- 即將響鈴（2026-10-05 電腦版補齊；Android core/Upcoming.kt 同一套規則） ----------
# 響鈴前 N 分鐘（關閉／30／60／120，預設 120）：系統匣圖示的提示文字顯示「13:17 即將響鈴」，右鍵選單可以「跳過這一次」，
# 第一次進入提醒時間時跳一個通知氣泡。跳過 = 那一天提前記成已完成（定期倒數往後推一輪），同步後手機那次也不響。
# 重要鬧鐘（要答題才能延後／絕對不能延後）答題後才能跳過；普通鬧鐘一按就跳。
$script:UpcomingDefaultMin = 120
$script:UpcomingChoices = @(0, 30, 60, 120)
function Get-ValidUpcomingMin([int]$m) { if ($script:UpcomingChoices -contains $m) { return $m }; return $script:UpcomingDefaultMin }
function Get-UpcomingChoiceText([int]$m) {
    switch ($m) { 0 { return "關閉" } 60 { return "響鈴前 1 小時" } 120 { return "響鈴前 2 小時" } default { return "響鈴前 $m 分鐘" } }
}
# 「現在之後」下一次真的會響的時間：已經跳過（記成已完成）的那幾天略過
function Get-NextPendingOccurrence($a, [DateTime]$now) {
    if (Test-AlarmDisabled $a) { return $null }
    if ($a.type -eq "interval") {
        $t = Get-NextOccurrence $a $now
        if ($null -ne $t -and $t -gt $now) { return $t }
        return $null
    }
    $from = $now
    for ($i = 0; $i -lt 8; $i++) {
        $t = Get-NextOccurrence $a $from
        if ($null -eq $t) { return $null }
        if (@($a.triggeredDates) -notcontains $t.ToString("yyyy-MM-dd")) { return $t }
        $from = $t
    }
    return $null
}
# windowMin 分鐘內最早要響的那一次；$busyIds：正在提醒／延後中的鬧鐘編號（那些已經有自己的視窗，不算）
function Get-UpcomingAlarm($alarms, [DateTime]$now, [int]$windowMin, $busyIds = @()) {
    if ($windowMin -le 0) { return $null }
    $limit = $now.AddMinutes($windowMin)
    $best = $null
    foreach ($a in @($alarms)) {
        if ($null -eq $a -or $null -eq $a.id) { continue }
        if (@($busyIds) -contains "$($a.id)") { continue }
        $t = Get-NextPendingOccurrence $a $now
        if ($null -eq $t -or $t -gt $limit) { continue }
        if ($null -eq $best -or $t -lt $best.At -or ($t -eq $best.At -and [int]$a.id -lt [int]$best.Alarm.id)) {
            $best = @{ Alarm = $a; At = $t; DateKey = $t.ToString("yyyy-MM-dd") }
        }
    }
    return $best
}
function Test-UpcomingSkippable($a, [bool]$quizPassed = $false) { return ((Get-AlarmImportance $a) -eq "normal" -or $quizPassed) }
# 跳過這一次；未答對的重要鬧鐘、正在提醒／延後中、日子對不上、已經跳過 → $false。會直接改 $a
function Invoke-SkipUpcoming($a, [string]$dateKey, [DateTime]$now, [bool]$quizPassed = $false, $busyIds = @()) {
    if (-not (Test-UpcomingSkippable $a $quizPassed) -or @($busyIds) -contains "$($a.id)") { return $false }
    $t = Get-NextPendingOccurrence $a $now
    if ($null -eq $t -or $t.ToString("yyyy-MM-dd") -ne $dateKey) { return $false }
    if ($a.type -eq "interval") {
        $base = ConvertTo-DateOnly $a.nextDueDate
        if ($null -eq $base) { return $false }
        $n = [Math]::Max(1, [int]$a.intervalDays)
        $nd = $base.AddDays($n)
        while ($nd.Date -le $now.Date) { $nd = $nd.AddDays($n) }
        $a | Add-Member -NotePropertyName nextDueDate -NotePropertyValue $nd.ToString("yyyy-MM-dd") -Force
    } else {
        $list = @($a.triggeredDates | Where-Object { $null -ne $_ } | ForEach-Object { "$_" })
        if ($list -notcontains $dateKey) { $list += $dateKey }
        $a | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @($list) -Force
    }
    return $true
}
# 「13:17 即將響鈴」／「明天 00:30 即將響鈴」／「10/7 08:00 即將響鈴」
function Get-UpcomingTitle([DateTime]$at, [DateTime]$now) {
    $day = ""
    if ($at.Date -eq $now.Date.AddDays(1)) { $day = "明天 " }
    elseif ($at.Date -ne $now.Date) { $day = "$($at.Month)/$($at.Day) " }
    return "$day$($at.ToString('HH:mm')) 即將響鈴"
}

# ---------- 分類收合（2026-10-05；Android ListFilter.canCollapse 同一套）：依分類排序＋看全部＋沒在搜尋才能收 ----------
function Test-CanCollapse([string]$filterKey, [string]$sortBy, [string]$query) { return ($filterKey -eq "all" -and $sortBy -eq "category" -and "$query".Trim() -eq "") }
function Switch-CollapsedCategory($collapsed, [string]$cat) {
    $l = @($collapsed | Where-Object { $null -ne $_ } | ForEach-Object { "$_" })
    if ($l -contains $cat) { return @($l | Where-Object { $_ -ne $cat }) }
    return @($l + $cat)
}
# 這台電腦的畫面狀態（ui_state.json，不同步）：收起來的分類
function Read-UiState([string]$path) {
    $s = @{ collapsed = @(); upcomingRange = "24h" }
    if (-not (Test-Path -LiteralPath $path)) { return $s }
    try { $d = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json; if ($null -ne $d.collapsed) { $s.collapsed = @($d.collapsed | ForEach-Object { "$_" }) }; if ($d.upcomingRange -in @("24h", "today", "tomorrow", "week")) { $s.upcomingRange = "$($d.upcomingRange)" } } catch {}
    return $s
}
function Write-UiState([string]$path, $s) {
    $json = [PSCustomObject]@{ collapsed = @($s.collapsed); upcomingRange = "$($s.upcomingRange)" } | ConvertTo-Json -Depth 3
    Write-AtomicText $path $json
}

# ---------- 範例鬧鐘（2026-10-05；Android core/SampleAlarms.kt 同一套）：沒有鬧鐘時一鍵加入 ----------
function Get-SampleAlarmChoices {
    return @(
        @{ Key = "bill";   Button = "每月繳費（10 號 09:00）"; Label = "繳信用卡帳單" },
        @{ Key = "water";  Button = "每天喝水（15:00）";       Label = "喝水" },
        @{ Key = "filter"; Button = "每年換濾心（1、7 月）";   Label = "換濾水器濾心" }
    )
}
# 做一個範例鬧鐘（跟「新增」存檔一樣：給編號、記建立日、從現在起算生效）；key 不認得回傳 $null
function New-SampleAlarm([string]$key, $alarms, [DateTime]$now) {
    $c = Get-SampleAlarmChoices | Where-Object { $_.Key -eq $key } | Select-Object -First 1
    if ($null -eq $c) { return $null }
    $a = [PSCustomObject]@{ type = "daily"; label = $c.Label; time = "15:00"; days = @(); date = ""; timeLimited = $false; playSound = $true; strict = $false; notes = ""; category = "每天都要做"; private = $false; difficulty = "math1"; importance = "normal" }
    if ($key -eq "bill") { $a.type = "monthly"; $a.time = "09:00"; $a.days = @(10); $a.strict = $true; $a.category = "帳單" }
    elseif ($key -eq "filter") { $a.type = "yearly"; $a.time = "10:00"; $a.days = @(1); $a | Add-Member -NotePropertyName months -NotePropertyValue @(1, 7) -Force; $a.category = "家裡" }
    $newId = 1
    if (@($alarms).Count -gt 0) { $newId = (@($alarms) | Measure-Object -Property id -Maximum).Maximum + 1 }
    $a | Add-Member -NotePropertyName id -NotePropertyValue $newId -Force
    $a | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @() -Force
    $a | Add-Member -NotePropertyName createdDate -NotePropertyValue $now.ToString("yyyy-MM-dd") -Force
    Set-AlarmArmed $a $now
    return $a
}

# ---------- 一鍵回報問題（2026-10-05；Android core/BugReport.kt 同一套說法）：組內容、遮私密名稱、10 分鐘限一次 ----------
# 電腦版做法：內容先讓使用者看過 → 全部複製到剪貼簿＋存成文字檔 → 打開使用者自己的 Email 程式（不連網、不自動寄）
$script:BugReportEmail = "kclone424@gmail.com"
$script:BugReportPrivateName = "（私密鬧鐘）"
$script:BugReportHiddenName = "（名稱已隱藏）"
function Get-BugReportSubject([string]$version, [string]$osText) { return "[真劍回報] v$version Windows $osText".Trim() }
function Get-BugReportName($line, [bool]$hideAll) {
    if ($line.Private) { return $script:BugReportPrivateName }
    if ($hideAll) { return $script:BugReportHiddenName }
    if ("$($line.Label)".Trim() -eq "") { return "鬧鐘" }
    return $line.Label
}
# 文字裡出現的私密（或全部）鬧鐘名稱換掉；長的名字先換
function Hide-BugReportNames([string]$text, $lines, [bool]$hideAll) {
    $t = $text
    foreach ($l in @($lines | Where-Object { ($_.Private -or $hideAll) -and "$($_.Label)".Trim().Length -ge 2 } | Sort-Object { -("$($_.Label)".Trim().Length) })) {
        $t = $t.Replace("$($l.Label)".Trim(), (Get-BugReportName $l $hideAll))
    }
    return $t
}
# $lines：每個鬧鐘 @{ Id; Label; Time; Type; Importance; Ringtone; Private }
function Get-BugReportBody([string]$userText, [string]$version, [string]$osText, $settingsLines, $lines, [string]$log, [bool]$hideAll) {
    $sb = New-Object System.Text.StringBuilder
    $said = (Hide-BugReportNames "$userText".Trim() $lines $hideAll)
    if ($said -eq "") { $said = "（沒有填寫）" }
    [void]$sb.Append("發生了什麼事：`n$said`n`n—— 以下是真劍鬧鐘自動附上的診斷內容（寄出前已讓使用者看過）——`n`n")
    [void]$sb.Append("版本：v$version（電腦版）`n電腦：Windows $osText`n`n【相關設定】`n")
    foreach ($s in @($settingsLines)) { [void]$sb.Append("・$s`n") }
    [void]$sb.Append("`n【鬧鐘一覽】（編號對照診斷紀錄用）`n")
    if (@($lines).Count -eq 0) { [void]$sb.Append("（沒有鬧鐘）`n") }
    foreach ($l in @($lines)) {
        $tone = ""; if ("$($l.Ringtone)" -ne "") { $tone = "　鈴聲 $($l.Ringtone)" }
        [void]$sb.Append("#$($l.Id) $(Get-BugReportName $l $hideAll)　$($l.Time)　$($l.Type)　重要程度 $($l.Importance)$tone`n")
    }
    [void]$sb.Append("`n【背景提醒紀錄（最近 40 行）】`n$log`n")
    return (Hide-BugReportNames $sb.ToString() $lines $hideAll)
}
# 上次打開回報不到 10 分鐘 → 回傳還要等幾分鐘；可以 → $null
function Get-BugReportWaitMinutes([DateTime]$last, [DateTime]$now) {
    if ($last -eq [DateTime]::MinValue -or $now -lt $last) { return $null }
    $left = 10 - ($now - $last).TotalMinutes
    if ($left -le 0) { return $null }
    return [int][Math]::Ceiling($left)
}

# 自訂鈴聲（只在這台電腦）：清單 ringtones.json，音檔複製到 ringtones\ 資料夾；規則跟手機一樣（最多 5 個、20 MB、30 字）
$script:CustomToneMaxCount = 5
$script:CustomToneMaxBytes = 20MB
$script:CustomToneMaxName = 30
$script:CustomToneExts = @("mp3", "wav", "wma", "m4a", "aac")
function Read-CustomTones([string]$path) {
    $out = @()
    if (-not (Test-Path -LiteralPath $path)) { return $out }
    try {
        $arr = @(Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json)
        foreach ($o in $arr) {
            if ($null -eq $o) { continue }
            $id = "$($o.id)"; $file = "$($o.file)"
            if ($id -eq "" -or $file -eq "" -or $file.Contains("\") -or $file.Contains("/") -or $file.Contains("..")) { continue }
            $name = "$($o.name)".Trim()
            if ($name -eq "") { $name = "自訂鈴聲" }
            $out += [PSCustomObject]@{ id = $id; name = $name; file = $file; bytes = [long]("0$($o.bytes)" -replace '[^\d]', '') }
        }
    } catch {}
    return $out
}
function Write-CustomTones([string]$path, $list) {
    $json = ConvertTo-Json -InputObject @($list | ForEach-Object { [PSCustomObject]@{ id = $_.id; name = $_.name; file = $_.file; bytes = [long]$_.bytes } }) -Depth 3
    if (@($list).Count -eq 0) { $json = "[]" }
    Write-AtomicText $path $json
}
# 加得進來嗎？不行回傳原因（白話）；可以回傳 $null
function Test-CustomToneAddable([int]$count, [long]$bytes, [string]$fileName) {
    if ($count -ge $script:CustomToneMaxCount) { return "自訂鈴聲最多 $($script:CustomToneMaxCount) 個，請先刪掉一個。" }
    if ($bytes -gt $script:CustomToneMaxBytes) { return "音檔太大（上限 20 MB）。" }
    if ($bytes -le 0) { return "這個檔案是空的。" }
    $ext = [System.IO.Path]::GetExtension($fileName).TrimStart(".").ToLowerInvariant()
    if ($script:CustomToneExts -notcontains $ext) { return "電腦版只能用 mp3、wav、wma、m4a、aac 音檔。" }
    return $null
}
# 名稱：去頭尾空白、去副檔名、換行換空白、限制 30 字；空的給預設
function Get-CleanToneName([string]$raw) {
    $n = "$raw".Trim()
    $dot = $n.LastIndexOf(".")
    if ($dot -gt 0 -and ($n.Length - $dot) -le 5) { $n = $n.Substring(0, $dot) }
    $n = ($n -replace "[\r\n\t]", " ").Trim()
    if ($n.Length -gt $script:CustomToneMaxName) { $n = $n.Substring(0, $script:CustomToneMaxName) }
    if ($n -eq "") { $n = "自訂鈴聲" }
    return $n
}

# 編輯畫面的白話說明（跟手機的 AlarmVolume.describe 同一套說法，電腦版沒有音量鍵與鬧鐘音量那兩句）
function Get-VolumeDescription([string]$importance, [int]$volume, [bool]$crescendo, [bool]$playSound) {
    if (-not $playSound) { return "這個鬧鐘設成「不出聲音」：響的時候只跳出提醒視窗。" }
    $v = Limit-AlarmVolume $volume $importance
    if ($importance -eq "must" -and -not $crescendo) { $l = "這是「絕對不能延後」的鬧鐘：一響就是 $v% 音量，不會慢慢變大。" }
    elseif ($importance -eq "quiz" -and -not $crescendo) { $l = "這是「要答題才能延後」的鬧鐘：一響就是 $v% 音量，不會慢慢變大。" }
    elseif ($crescendo) { $l = "響起時從 $([int]($v / 2))% 慢慢變大，約 30 秒到 $v%。" }
    else { $l = "一響就是 $v% 音量，不會慢慢變大。" }
    return "$l`n電腦上的 $v% 是「Windows 目前音量」的 $v%：電腦整台靜音或音量很小時，鬧鐘也會很小聲。"
}

# ---------- 找鬧鐘：篩選／搜尋／即將響（工單 8.3；Android 的 core/ListFilter.kt 是同一套規則） ----------
#   篩選鍵：all（全部）／soon（即將響：下一次響的時間在現在起 24 小時內，含剛好 24 小時；已到期還沒完成的定期倒數也算）／cat:分類名稱
#   搜尋：依名稱，含部分字、不分大小寫
# Local Tray snapshot, excluded from sync. Identity/generation is checked against current disk data.
function Write-ReminderSnapshot([string]$alarmPath, $states) {
    $path = Join-Path (Split-Path -Parent $alarmPath) "reminder_state.json"
    $snapshot = @{}
    foreach ($key in $states.Keys) {
        $st = $states[$key]
        $snapshot[$key] = @{ Status = $st.Status; SnoozeUntil = $st.SnoozeUntil; AlarmObject = $st.AlarmObject; SnoozeTicks = $st.SnoozeTicks }
    }
    # A display snapshot must never prevent the real reminder from completing.
    try { Write-AtomicText $path (ConvertTo-Json -InputObject @{ pid = $PID; states = $snapshot } -Depth 64) } catch {}
}
function Read-ReminderSnapshot([string]$alarmPath, $alarms, $snoozes, [DateTime]$now) {
    $out = @{}
    try {
        $path = Join-Path (Split-Path -Parent $alarmPath) "reminder_state.json"
        $doc = Get-Content -LiteralPath $path -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json
        if ($null -eq (Get-Process -Id $doc.pid -ErrorAction SilentlyContinue)) { return $out }
        foreach ($p in $doc.states.PSObject.Properties) {
            $parts = $p.Name.Split('|'); $st = $p.Value
            $tag = @{ AlarmId = $parts[0]; DateKey = $parts[1]; AlarmObject = $st.AlarmObject }
            if ($null -eq $st.AlarmObject -or (Test-ReminderObsolete $tag $alarms $snoozes $now)) { continue }
            $until = $null
            if ($null -ne $st.SnoozeUntil) { $until = [DateTime]::Parse("$($st.SnoozeUntil)") }
            $out[$p.Name] = @{ Status = $st.Status; SnoozeUntil = $until; AlarmObject = $st.AlarmObject }
        }
    } catch {}
    return $out
}
function Get-GuiUpcomingRange([string]$alarmPath, $alarms, [string]$range, [DateTime]$now) {
    $sn = Read-SnoozeFile (Join-Path (Split-Path -Parent $alarmPath) "snoozes.json")
    $st = Read-ReminderSnapshot $alarmPath $alarms $sn $now
    return @(Get-UpcomingRange $alarms $range $now $sn $st)
}

function Get-UpcomingRangeBounds([string]$range, [DateTime]$now) {
    switch ($range) {
        "today" { return @($now.Date, $now.Date.AddDays(1)) }
        "tomorrow" { return @($now.Date.AddDays(1), $now.Date.AddDays(2)) }
        "week" { return @($now.Date, $now.Date.AddDays(7)) }
        default { return @($now, $now.AddHours(24)) }
    }
}
function Get-ReminderDelay($state) {
    if ($null -ne $state.SnoozeUntil) { return $state.SnoozeUntil }
    return $state.until
}
# Same pending gate for the live checker and projected occurrences.
function Test-ReminderPendingBlocks($state, [DateTime]$at) {
    if ($null -eq $state) { return $false }
    if ($state.Status -eq "showing" -or $state.Status -eq "driving") { return $true }
    $until = Get-ReminderDelay $state
    return ($state.Status -eq "snoozed" -and $null -ne $until -and $at -lt $until)
}
function Get-AlarmOccurrences($alarms, [DateTime]$from, [DateTime]$to, [DateTime]$now, $snoozes = @{}, $states = @{}, [bool]$inclusiveEnd = $false) {
    $windowFrom = $from
    if ($from -gt $now) { $from = $now }
    $pending = @{}
    foreach ($k in $snoozes.Keys) { $pending[$k] = $snoozes[$k] }
    foreach ($k in $states.Keys) {
        $st = $states[$k]; $delay = Get-ReminderDelay $st
        if ($st.Status -eq "snoozed" -and $null -ne $delay -and (-not $pending.ContainsKey($k) -or $delay -gt $pending[$k].until)) {
            $pending[$k] = @{ until = $delay }
        }
    }
    $snoozes = $pending
    $out = @()
    foreach ($a in @($alarms)) {
        if ($null -eq $a -or (Test-AlarmDisabled $a)) { continue }
        try { $tp = Get-AlarmTimeParts $a } catch { continue }
        $created = ConvertTo-DateOnly $a.createdDate
        $armed = Get-AlarmArmedTime $a
        for ($d = $from.Date; $d -le $to.Date; $d = $d.AddDays(1)) {
            if (-not (Test-AlarmOccursOn $a $d $true)) { continue }
            $key = $d.ToString("yyyy-MM-dd"); $stateKey = "$($a.id)|$key"
            if (@($a.triggeredDates) -contains $key) { continue }
            if ($null -ne $created -and $d -lt $created) { continue }
            $at = $d.AddHours($tp[0]).AddMinutes($tp[1]); $delayed = $false
            if ($null -ne $armed -and $at -le $armed) { continue }
            if ($snoozes.ContainsKey($stateKey)) { $at = $snoozes[$stateKey].until; $delayed = $true }
            if ($states.ContainsKey($stateKey)) {
                $st = $states[$stateKey]
                if (Test-ReminderPendingBlocks $st $at) { continue }
                if ($st.status -eq "snoozed" -and $null -ne (Get-ReminderDelay $st) -and (Get-ReminderDelay $st) -gt $at) { $at = Get-ReminderDelay $st; $delayed = $true }
            }
            if ($at -lt $from -or $at -lt $now -or $at -gt $to -or ($at -eq $to -and -not $inclusiveEnd)) { continue }
            $out += [PSCustomObject]@{ Alarm = $a; At = $at; DateKey = $key; Delayed = $delayed; Estimated = ($a.type -eq "interval" -and $key -ne "$($a.nextDueDate)") }
        }
        # 延後跨出 from 範圍時，原始日期可能不在上面的逐日窗口。
        foreach ($sk in @($snoozes.Keys)) {
            if (-not $sk.StartsWith("$($a.id)|")) { continue }
            $sn = $snoozes[$sk]; $key = $sk.Substring($sk.IndexOf('|') + 1)
            if (@($a.triggeredDates) -contains $key -or ($a.type -eq "interval" -and "$($a.nextDueDate)" -gt $key)) { continue }
            $at = $sn.until
            if ($states.ContainsKey($sk)) {
                $st = $states[$sk]
                if (Test-ReminderPendingBlocks $st $at) { continue }
                if ($st.status -eq "snoozed" -and $null -ne (Get-ReminderDelay $st) -and (Get-ReminderDelay $st) -gt $at) { $at = Get-ReminderDelay $st }
            }
            if ($at -lt $from -or $at -lt $now -or $at -gt $to -or ($at -eq $to -and -not $inclusiveEnd)) { continue }
            if (@($out | Where-Object { $_.Alarm.id -eq $a.id -and $_.DateKey -eq $key }).Count -eq 0) {
                $out += [PSCustomObject]@{ Alarm = $a; At = $at; DateKey = $key; Delayed = $true; Estimated = $false }
            }
        }
    }
    # Simulate the actual pending merge on copies in chronological order.
    $copies = @{}; $stateCopy = @{}; $projected = @()
    foreach ($a in $alarms) { $copies["$($a.id)"] = Copy-AlarmObject $a }
    foreach ($k in $states.Keys) { $stateCopy[$k] = $states[$k] }
    foreach ($e in @($out | Sort-Object At, { $_.Alarm.id })) {
        $a = $copies["$($e.Alarm.id)"]; $sk = "$($a.id)|$($e.DateKey)"
        if (@($a.triggeredDates) -contains $e.DateKey) { continue }
        if ($e.Delayed -and -not $pending.ContainsKey($sk)) { continue }
        $projected += $e
        Merge-AlarmPending $a $pending $stateCopy $e.DateKey $e.At $true | Out-Null
        # Assume this projected occurrence is handled before the next regular occurrence.
        $pending.Remove($sk); $stateCopy.Remove($sk)
    }
    return @($projected | Where-Object { $_.At -ge $windowFrom })
}
function Get-UpcomingRange($alarms, [string]$range, [DateTime]$now, $snoozes = @{}, $states = @{}) {
    $bounds = Get-UpcomingRangeBounds $range $now
    $out = @(Get-AlarmOccurrences $alarms $bounds[0] $bounds[1] $now $snoozes $states ($range -eq "24h"))
    # 舊 24 小時列表也包含逾期 interval（仍欠著）；今天／這週同樣顯示待完成。
    if ($range -ne "tomorrow") {
        foreach ($a in @($alarms)) {
            if ($null -eq $a -or $a.type -ne "interval") { continue }
            $due = Get-NextOccurrence $a $now
            if ($null -eq $due -or $due -gt $now) { continue }
            $key = "$($a.nextDueDate)"; $sk = "$($a.id)|$key"
            if (@($a.triggeredDates) -contains $key -or $snoozes.ContainsKey($sk) -or $states.ContainsKey($sk)) { continue }
            $armed = Get-AlarmArmedTime $a
            if ($null -ne $armed -and $due -le $armed) { continue }
            if (@($out | Where-Object { $_.Alarm.id -eq $a.id -and $_.DateKey -eq $key }).Count -eq 0) {
                $out += [PSCustomObject]@{ Alarm = $a; At = $now; DateKey = $key; Delayed = $false; Estimated = $false }
            }
        }
    }
    return @($out | Sort-Object At, { $_.Alarm.id })
}

function Test-AlarmSoon($a, [DateTime]$now) {
    $n = Get-NextOccurrence $a $now
    if ($null -eq $n) { return $false }
    return ($n -le $now.AddHours(24))
}

function Test-AlarmMatchesQuery($a, [string]$query) {
    $q = "$query".Trim()
    if ($q -eq "") { return $true }
    return ("$($a.label)".IndexOf($q, [StringComparison]::OrdinalIgnoreCase) -ge 0)
}

function Get-FilteredAlarms($alarms, [string]$filterKey, [string]$query, [DateTime]$now) {
    $out = @()
    foreach ($a in @($alarms)) {
        if ($null -eq $a) { continue }
        $ok = $true
        if ($filterKey -eq "soon") { $ok = (Test-AlarmSoon $a $now) }
        elseif ($filterKey.StartsWith("cat:")) { $ok = ((Get-AlarmCategory $a) -eq $filterKey.Substring(4)) }
        if ($ok -and (Test-AlarmMatchesQuery $a $query)) { $out += $a }
    }
    return @($out)
}

# ---------- 私密鬧鐘（工單 8.1；Android 的 core/Privacy.kt 是同一套規則） ----------
#   ・鬧鐘本身的「私密」是 alarms.json 的 private 欄位（跟著同步、匯出匯入；沒這欄 = 不私密）
#   ・分類可設「私密」（settings.json 的 privateCategories、同步的 categories.private、匯出的 privateCategories）→ 底下鬧鐘都視為私密
#   ・Windows 的提醒視窗是在自己的電腦上，照常顯示；「私密」主要給手機用（開車不念內容、鎖定畫面不露內容）
function Get-CleanPrivateCategories($names) {
    $out = @()
    foreach ($n in @($names)) {
        if ($null -eq $n) { continue }
        $t = "$n".Trim()
        if ($t -ne "" -and $t -ne $script:DefaultCategory -and $out -notcontains $t) { $out += $t }
    }
    return @($out | Sort-Object { $_ } -CaseSensitive)
}

function Test-AlarmOwnPrivate($a) {
    if ($null -eq $a) { return $false }
    $p = $a.PSObject.Properties["private"]
    if ($null -eq $p) { return $false }
    return ("$($p.Value)" -eq "True")
}

function Test-AlarmViaCategoryPrivate($a, $privateCats) {
    if (Test-AlarmOwnPrivate $a) { return $false }
    return (@($privateCats) -contains (Get-AlarmCategory $a))
}

function Test-AlarmPrivate($a, $privateCats) {
    if (Test-AlarmOwnPrivate $a) { return $true }
    return (@($privateCats) -contains (Get-AlarmCategory $a))
}

function Rename-PrivateCategory($privateCats, [string]$old, [string]$new) {
    $l = @($privateCats)
    if ($l -contains $old) { $l = @($l | Where-Object { $_ -ne $old }) + $new }
    return @(Get-CleanPrivateCategories $l)
}

function Remove-PrivateCategory($privateCats, [string]$name) {
    return @(Get-CleanPrivateCategories @(@($privateCats) | Where-Object { $_ -ne $name }))
}

# ---- 分類色塊色值：由 android/tools/make-category-palette.py 產生（Android 的 CategoryColors.kt 用同一組），不要手改 ----
$script:CategoryColorIds = @("rose", "orange", "amber", "green", "teal", "blue", "indigo", "purple", "pink", "brown")
$script:CategoryColorNames = @{ rose = "玫瑰紅"; orange = "橘"; amber = "琥珀黃"; green = "綠"; teal = "青"; blue = "藍"; indigo = "靛"; purple = "紫"; pink = "粉紅"; brown = "棕"; gray = "灰" }
# 每個顏色：stripe 色條、tint 卡片底色、chip 分類標題色塊、chipText 色塊上的字、tag 分類名稱（RGB，0xRRGGBB）
$script:CategoryColorTable = @{
    light = @{
        rose = @{ stripe = 0xB6354A; tint = 0xEFE3E2; chip = 0xD8B0B2; chipText = 0x1B2420; tag = 0xAB3246 }
        orange = @{ stripe = 0xB66B35; tint = 0xEFE9E0; chip = 0xD8C2AB; chipText = 0x1B2420; tag = 0x8E5329 }
        amber = @{ stripe = 0xB69635; tint = 0xEFEEE0; chip = 0xD8D1AB; chipText = 0x1B2420; tag = 0x766122 }
        green = @{ stripe = 0x35B655; tint = 0xE1F2E3; chip = 0xACDCB6; chipText = 0x1B2420; tag = 0x227637 }
        teal = @{ stripe = 0x35B6AB; tint = 0xE1F2ED; chip = 0xACDCD3; chipText = 0x1B2420; tag = 0x206F68 }
        blue = @{ stripe = 0x3575B6; tint = 0xE1EBEE; chip = 0xACC6D7; chipText = 0x1B2420; tag = 0x2C6197 }
        indigo = @{ stripe = 0x3540B6; tint = 0xE1E5EE; chip = 0xACB3D7; chipText = 0x1B2420; tag = 0x3540B6 }
        purple = @{ stripe = 0x8B35B6; tint = 0xEAE3EE; chip = 0xC9B0D7; chipText = 0x1B2420; tag = 0x8B35B6 }
        pink = @{ stripe = 0xB6358B; tint = 0xEFE3E9; chip = 0xD8B0C8; chipText = 0x1B2420; tag = 0xAB3282 }
        brown = @{ stripe = 0xB66035; tint = 0xEFE8E0; chip = 0xD8BEAB; chipText = 0x1B2420; tag = 0x97502C }
        gray = @{ stripe = 0x969C98; tint = 0xEBEFEB; chip = 0xCDD3CD; chipText = 0x1B2420; tag = 0x616563 }
    }
    dark = @{
        rose = @{ stripe = 0xC77583; tint = 0x39353A; chip = 0x6A4950; chipText = 0xF4F1EA; tag = 0xD3949E }
        orange = @{ stripe = 0xC79775; tint = 0x393839; chip = 0x6A574A; chipText = 0xF4F1EA; tag = 0xCA9E7E }
        amber = @{ stripe = 0xC7B275; tint = 0x393A39; chip = 0x6A624A; chipText = 0xF4F1EA; tag = 0xC7B275 }
        green = @{ stripe = 0x75C78A; tint = 0x323C3A; chip = 0x476B53; chipText = 0xF4F1EA; tag = 0x75C78A }
        teal = @{ stripe = 0x75C7C0; tint = 0x323C3F; chip = 0x476B6A; chipText = 0xF4F1EA; tag = 0x75C7C0 }
        blue = @{ stripe = 0x759EC7; tint = 0x323840; chip = 0x475A6C; chipText = 0xF4F1EA; tag = 0x85A9CD }
        indigo = @{ stripe = 0x757CC7; tint = 0x323640; chip = 0x474B6C; chipText = 0xF4F1EA; tag = 0x9A9FD6 }
        purple = @{ stripe = 0xAC75C7; tint = 0x373540; chip = 0x5E496C; chipText = 0xF4F1EA; tag = 0xC29AD6 }
        pink = @{ stripe = 0xC775AC; tint = 0x39353D; chip = 0x6A4961; chipText = 0xF4F1EA; tag = 0xD394BE }
        brown = @{ stripe = 0xC79175; tint = 0x393739; chip = 0x6A544A; chipText = 0xF4F1EA; tag = 0xCD9D85 }
        gray = @{ stripe = 0x8C9094; tint = 0x34373B; chip = 0x515457; chipText = 0xF4F1EA; tag = 0xA5A8AB }
    }
}
# ---- 分類色塊色值結束 ----


# ---- 設定分類與搜尋（工單 8.6；跟 Android 版同一套 key，Windows 沒有的功能就沒有那一項）----
function Get-SettingsSections {
    return @(
        @{ Id = "ring";    Icon = "⏰"; Title = "響鈴" },
        @{ Id = "privacy"; Icon = "🔒"; Title = "隱私" },
        @{ Id = "sync";    Icon = "☁";  Title = "同步與備份" },
        @{ Id = "look";    Icon = "🎨"; Title = "外觀" },
        @{ Id = "setup";   Icon = "🔋"; Title = "讓鬧鐘準時響" },
        @{ Id = "about";   Icon = "⬆";  Title = "更新與關於" }
    )
}

function Get-SettingsEntries {
    return @(
        @{ Key = "ring.tone";      Section = "ring";    Label = "鈴聲選項（內建三種／自訂／Windows 提示音）"; Keywords = @("鈴聲", "鈴聲選項", "內建鈴聲", "換鈴聲", "聲音", "溫和", "標準", "很吵", "提示音") },
        @{ Key = "ring.preview";   Section = "ring";    Label = "試聽鈴聲";                       Keywords = @("試聽", "聽聽看", "測試聲音", "有沒有聲音") },
        @{ Key = "ring.crescendo"; Section = "ring";    Label = "漸強音量";                       Keywords = @("漸強", "音量", "由小到大", "小聲") },
        @{ Key = "ring.custom";    Section = "ring";    Label = "自訂鈴聲";                       Keywords = @("自訂", "自訂鈴聲", "音樂", "mp3", "自己的歌", "音檔") },
        @{ Key = "ring.upcoming";  Section = "ring";    Label = "即將響鈴提醒（提前提醒、跳過這一次）"; Keywords = @("即將響鈴", "提前", "提醒", "跳過", "跳過這一次", "答題後跳過", "重要鬧鐘", "下一個鬧鐘", "關閉鬧鐘") },
        @{ Key = "ring.limit";     Section = "ring";    Label = "連續響"; Keywords = @("連續響", "響多久", "10 分鐘", "十分鐘", "停聲") },
        @{ Key = "ring.pause";     Section = "ring";    Label = "停聲"; Keywords = @("停聲", "休息", "5 分鐘", "五分鐘", "暫停") },
        @{ Key = "ring.total";     Section = "ring";    Label = "最久響"; Keywords = @("最久響", "60 分鐘", "一小時", "放棄", "規則") },
        @{ Key = "ring.difficulty"; Section = "ring";   Label = "新鬧鐘預設難度"; Keywords = @("新增", "預設", "難度", "算術", "答題", "QR", "掃碼") },
        @{ Key = "ring.vibrate";   Section = "ring";    Label = "震動（電腦沒有）";               Keywords = @("震動", "振動") },
        @{ Key = "ring.confirm";   Section = "ring";    Label = "確認醒了、關鬧鐘難度";           Keywords = @("確認醒了", "難度", "算術", "答題") },
        @{ Key = "privacy.cats";   Section = "privacy"; Label = "私密分類";                       Keywords = @("私密", "隱私", "不顯示內容", "隱藏", "分類管理") },
        @{ Key = "privacy.data";   Section = "privacy"; Label = "資料存放說明";                   Keywords = @("資料", "收集", "不上傳") },
        @{ Key = "privacy.policy"; Section = "privacy"; Label = "隱私權政策（網頁）";             Keywords = @("隱私權", "政策", "隱私權政策", "條款") },
        @{ Key = "sync.account";   Section = "sync";    Label = "Google 帳號登入／登出、立即同步"; Keywords = @("同步", "Google", "登入", "登出", "帳號", "雲端", "立即同步", "上次同步") },
        @{ Key = "sync.export";    Section = "sync";    Label = "匯出鬧鐘";                       Keywords = @("匯出", "備份", "存檔", "json") },
        @{ Key = "sync.import";    Section = "sync";    Label = "匯入鬧鐘";                       Keywords = @("匯入", "還原", "新電腦", "搬家") },
        @{ Key = "look.font";      Section = "look";    Label = "字體大小";                       Keywords = @("字體", "字級", "大字", "特大") },
        @{ Key = "look.bold";      Section = "look";    Label = "粗體";                           Keywords = @("粗體", "粗字", "加粗") },
        @{ Key = "look.theme";     Section = "look";    Label = "深色／淺色";                     Keywords = @("深色", "淺色", "夜間", "暗色", "護眼", "主題", "外觀") },
        @{ Key = "look.catcolor";  Section = "look";    Label = "分類顏色";                       Keywords = @("分類顏色", "色塊", "顏色", "分類管理") },
        @{ Key = "setup.tray";     Section = "setup";   Label = "背景提醒（啟動／停止）";         Keywords = @("背景提醒", "常駐", "工作列", "準時", "啟動", "停止") },
        @{ Key = "setup.startup";  Section = "setup";   Label = "開機自動啟動";                   Keywords = @("開機", "自動啟動", "開機啟動") },
        @{ Key = "about.update";   Section = "about";   Label = "檢查更新";                       Keywords = @("更新", "新版", "版本", "下載") },
        @{ Key = "about.version";  Section = "about";   Label = "目前版本";                       Keywords = @("版本", "版號") },
        @{ Key = "about.about";    Section = "about";   Label = "關於真劍鬧鐘";                   Keywords = @("關於", "作者", "名字由來", "沙龍") },
        @{ Key = "about.privacy";  Section = "about";   Label = "隱私權政策";                     Keywords = @("隱私權", "隱私說明", "政策", "條款") },
        @{ Key = "about.report";   Section = "about";   Label = "回報問題（用 Email 寄給開發者）"; Keywords = @("回報", "問題", "bug", "寄信", "Email", "意見", "當機", "沒響") },
        @{ Key = "about.share";    Section = "about";   Label = "分享給朋友";                     Keywords = @("分享", "朋友", "下載頁", "推薦", "網址", "連結") }
    )
}

# 搜尋：輸入用空白拆成幾個字，每個字都要在「名稱＋關鍵字＋分類名」裡找得到（不分大小寫）；名稱直接命中的排前面
function Search-SettingsIndex([string]$query) {
    $words = @(($query.Trim().ToLowerInvariant() -split '\s+') | Where-Object { $_ -ne "" })
    if ($words.Count -eq 0) { return @() }
    $secTitle = @{}
    foreach ($s in (Get-SettingsSections)) { $secTitle[$s.Id] = $s.Title }
    $hits = New-Object System.Collections.ArrayList
    $i = 0
    foreach ($e in (Get-SettingsEntries)) {
        $i++
        $label = $e.Label.ToLowerInvariant()
        $hay = $label + "`n" + $secTitle[$e.Section].ToLowerInvariant() + "`n" + (($e.Keywords | ForEach-Object { $_.ToLowerInvariant() }) -join "`n")
        $all = $true; $titleAll = $true
        foreach ($w in $words) {
            if (-not $hay.Contains($w)) { $all = $false }
            if (-not $label.Contains($w)) { $titleAll = $false }
        }
        if ($all) { [void]$hits.Add(@{ Rank = ($(if ($titleAll) { 0 } else { 1000 }) + $i); Entry = $e }) }
    }
    return @($hits | Sort-Object { $_.Rank } | ForEach-Object { $_.Entry })
}

# 「讓鬧鐘準時響」有問題（Windows：背景提醒沒在跑）→ 這個分類排最上面
function Get-SettingsSectionsOrdered([bool]$setupProblem) {
    $all = @(Get-SettingsSections)
    if (-not $setupProblem) { return $all }
    return @(@($all | Where-Object { $_.Id -eq "setup" }) + @($all | Where-Object { $_.Id -ne "setup" }))
}

function Get-ReminderSnoozeTicks($snoozes, [string]$key) {
    if ($snoozes.ContainsKey($key)) { return $snoozes[$key].Until.Ticks }
    return 0
}

# 在 UI thread 呼叫；只撤銷該 occurrence，FormClosing 不得寫新延後或完成。
function Test-ReminderObsolete($tag, $alarms, $snoozes, [DateTime]$now) {
    $a = $alarms | Where-Object { "$($_.id)" -eq "$($tag.AlarmId)" } | Select-Object -First 1
    if ($null -eq $a -or (Test-AlarmDisabled $a) -or -not (Test-AlarmRingsHere $a)) { return $true }
    if ($a.triggeredDates -contains $tag.DateKey) { return $true }
    if ($null -ne $tag.AlarmObject) {
        if ((-not [string]::IsNullOrEmpty("$($tag.AlarmObject.uid)") -and "$($a.uid)" -ne "$($tag.AlarmObject.uid)") -or "$($a.armedAt)" -ne "$($tag.AlarmObject.armedAt)" -or -not (Test-SameSchedule $a $tag.AlarmObject)) { return $true }
        if ($a.type -eq "interval" -and "$($a.nextDueDate)" -ne "$($tag.AlarmObject.nextDueDate)") { return $true }
    }
    $key = "$($tag.AlarmId)|$($tag.DateKey)"
    if (-not $snoozes.ContainsKey($key)) { return $false }
    if ($snoozes[$key].Until -gt $now) { return $true }
    # 新的遠端延後即使已到時間，也先撤銷舊 occurrence，再由 checker 開新提醒。
    return ($tag.ContainsKey("SnoozeTicks") -and $null -ne $tag.SnoozeTicks -and $tag.SnoozeTicks -ne $snoozes[$key].Until.Ticks)
}

function Sync-OpenReminderForms($alarms, $snoozes, [DateTime]$now) {
    foreach ($id in @($global:AlarmOpenForms.Keys)) {
        $f = $global:AlarmOpenForms[$id]
        if ($null -eq $f -or $f.IsDisposed) { continue }
        if (-not (Test-ReminderObsolete $f.Tag $alarms $snoozes $now)) { continue }
        $f.Tag.RemoteDismissed = $true
        $f.Tag.AllowClose = $true
        if ($null -ne $f.Tag.RingTimer) {
            Stop-ReminderSound $f
            $f.Tag.RingTimer.Stop()
            $f.Tag.RingTimer.Dispose()
            $f.Tag.RingTimer = $null
        }
        $f.Close()
        $global:AlarmOpenForms.Remove($id)
        $global:AlarmReminderState.Remove($f.Tag.StateKey)
    }
    foreach ($key in @($global:AlarmReminderState.Keys)) {
        $bits = "$key".Split('|')
        if ($bits.Count -ne 2) { continue }
        $st = $global:AlarmReminderState[$key]
        $tag = @{ AlarmId = $bits[0]; DateKey = $bits[1]; AlarmObject = $st.AlarmObject; SnoozeTicks = $st.SnoozeTicks }
        if (Test-ReminderObsolete $tag $alarms $snoozes $now) {
            if ($null -ne $st.Timer) { $st.Timer.Stop(); $st.Timer.Dispose() }
            $global:AlarmReminderState.Remove($key)
        }
    }
}

# 對話框開啟期間的背景改動：沒有在對話框改動的欄位沿用新讀到的值。
function Merge-AlarmDialogEdit($fresh, $edited, $opened) {
    $result = Copy-AlarmObject $fresh
    foreach ($p in $edited.PSObject.Properties) {
        $old = $opened.PSObject.Properties[$p.Name]
        if ($null -eq $old -or (ConvertTo-Json -InputObject $old.Value -Depth 64 -Compress) -cne (ConvertTo-Json -InputObject $p.Value -Depth 64 -Compress)) {
            $result | Add-Member -NotePropertyName $p.Name -NotePropertyValue $p.Value -Force
        }
    }
    return $result
}

﻿# 真劍鬧鐘 v1.6：檢查更新、下載、核對指紋、換掉程式檔（保留使用者資料、失敗還原）
# 不碰 Windows Forms 的純邏輯 + 網路；設定視窗、背景提醒、tests.ps1 都用 . 載入這支（要先載入 AlarmCore.ps1）。
# 注意：只能用 Windows PowerShell 5.1 有的語法（不要 ??、?.、三元運算子）。
#
# 更新來源只有一個（HTTPS）：latest.json（見 交件說明_真劍鬧鐘.md「一鍵更新」）。
#   {"format":"shinken-alarm-update","version":1,
#    "android":{"versionCode":5,"versionName":"1.3.0","url":"…apk","sha256":"…","notes":"…"},
#    "windows":{"version":"1.6","url":"…zip","sha256":"…","notes":"…"}}
# 安全：網址一定要 https、而且主機要在允許名單內；下載回來的檔案 sha256 對不上就拒絕；
#      zip 解壓縮不准跑出暫存資料夾（zip-slip）；新版的 .ps1 先做語法檢查，壞的不換；
#      換檔前把使用者資料和舊程式都備份，任何一步失敗就還原舊版，使用者資料絕不動。

$script:UpdateManifestUrl = "https://lovanddes.github.io/shinken-alarm/update/latest.json"
$script:UpdateAllowedHosts = @("lovanddes.github.io")
$script:UpdateFormat = "shinken-alarm-update"
# 使用者自己的資料，更新時絕對不能蓋掉、不當成程式檔
$script:UpdateDataFiles = @("alarms.json", "snoozes.json", "settings.json", "sync_state.json", "sync_token.dat", "tray.pid", "alarm_debug.log", "update_state.json", "update_result.json")
$script:UpdateDataPatterns = @("alarms_匯入前備份_*.json")
$script:UpdateBackupDirName = "update_backup"
$script:UpdateRequiredFiles = @("Alarm_Tray.ps1", "Alarm_Manager_GUI.ps1", "AlarmCore.ps1", "AlarmUi.ps1", "AlarmSync.ps1", "AlarmUpdate.ps1", "Setup.ps1")

# 更新的錯誤一律丟 "UPDATE|種類|白話說明"；種類：network（連不上／下載中斷）、hash（指紋不符）、data（更新資訊／更新檔不對）、apply（換檔失敗）
function Stop-Update([string]$kind, [string]$text) { throw "UPDATE|$kind|$text" }

function Get-UpdateErrorInfo($ex) {
    $m = "$($ex.Exception.Message)"
    if ($m.StartsWith("UPDATE|")) { $p = $m.Split("|", 3); return @{ Kind = $p[1]; Text = $p[2] } }
    return @{ Kind = "data"; Text = "更新時發生沒預料到的錯誤：$m" }
}

# ---------- 版本比較 ----------

# "1.6"、"1.5.0"、"v1.4-beta" 都收；數字逐段比，缺的當 0；數字一樣時，有 -beta 之類後綴的比較舊
function Compare-AppVersion([string]$a, [string]$b) {
    $pa = @(ConvertTo-VersionParts $a)
    $pb = @(ConvertTo-VersionParts $b)
    $n = [Math]::Max($pa.Count, $pb.Count)
    for ($i = 0; $i -lt $n; $i++) {
        $x = 0; $y = 0
        if ($i -lt $pa.Count) { $x = $pa[$i] }
        if ($i -lt $pb.Count) { $y = $pb[$i] }
        if ($x -lt $y) { return -1 }
        if ($x -gt $y) { return 1 }
    }
    $sa = ("$a" -match "-"); $sb = ("$b" -match "-")
    if ($sa -and -not $sb) { return -1 }
    if ($sb -and -not $sa) { return 1 }
    return 0
}

function ConvertTo-VersionParts([string]$v) {
    $out = @()
    foreach ($p in ("$v".Trim().TrimStart("v", "V").Split("."))) {
        $m = [regex]::Match($p, "^\d+")
        if ($m.Success) { $out += [int]$m.Value } else { $out += 0 }
    }
    return $out
}

# ---------- 更新資訊（latest.json） ----------

function Test-UpdateUrl([string]$url, [string]$ext) {
    try {
        $u = New-Object System.Uri($url)
        if ($u.Scheme -ne "https") { return $false }
        if ($script:UpdateAllowedHosts -notcontains $u.Host.ToLowerInvariant()) { return $false }
        if ($ext -ne "" -and -not $u.AbsolutePath.ToLowerInvariant().EndsWith($ext)) { return $false }
        return $true
    } catch { return $false }
}

# 回傳 @{ Ok; Error; Windows = @{ Version; Url; Sha256; Notes } }
function Get-UpdateManifestInfo([string]$text) {
    $r = @{ Ok = $false; Error = ""; Windows = $null }
    $bad = "更新資訊的格式不對（可能網站上的檔案出了問題），這次先不更新。"
    if ($null -ne $text -and $text.Length -gt 0 -and [int][char]$text[0] -eq 0xFEFF) { $text = $text.Substring(1) }
    $o = $null
    try { $o = $text | ConvertFrom-Json } catch { $r.Error = $bad; return $r }
    if ($null -eq $o -or "$($o.format)" -ne $script:UpdateFormat) { $r.Error = $bad; return $r }
    $ver = 0
    try { $ver = [int]$o.version } catch {}
    if ($ver -ne 1) { $r.Error = "更新資訊是比較新的格式，這個版本看不懂。請先到網站手動下載新版。"; return $r }
    $w = $o.windows
    if ($null -eq $w) { $r.Error = "更新資訊裡沒有 Windows 版。"; return $r }
    if ("$($w.version)" -eq "" -or "$($w.version)" -notmatch "^\d+(\.\d+)*$") { $r.Error = $bad; return $r }
    if ("$($w.sha256)" -notmatch "^[0-9a-fA-F]{64}$") { $r.Error = $bad; return $r }
    if (-not (Test-UpdateUrl "$($w.url)" ".zip")) { $r.Error = "更新資訊裡的下載網址不安全（不是 https、或不是官方網站），為了安全沒有更新。"; return $r }
    $r.Windows = @{ Version = "$($w.version)"; Url = "$($w.url)"; Sha256 = "$($w.sha256)".ToLowerInvariant(); Notes = "$($w.notes)" }
    $r.Ok = $true
    return $r
}

# 比版本：@{ State = latest | available | error; ... }
function Get-UpdateCheckResult([string]$currentVersion, [string]$manifestText) {
    $m = Get-UpdateManifestInfo $manifestText
    if (-not $m.Ok) { return @{ State = "error"; Error = $m.Error } }
    $w = $m.Windows
    if ((Compare-AppVersion $w.Version $currentVersion) -gt 0) {
        return @{ State = "available"; Version = $w.Version; Notes = $w.Notes; Url = $w.Url; Sha256 = $w.Sha256; Error = "" }
    }
    return @{ State = "latest"; Version = $w.Version; Notes = $w.Notes; Error = "" }
}

# ---------- 網路（可換成假的做測試） ----------

# GET 一個網址，回傳 @{ Status; Body; FinalHost }；連不上才丟例外
function Get-UpdateHttpText([string]$url) {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
    $req = [System.Net.HttpWebRequest]::Create($url)
    $req.Timeout = 15000
    $req.ReadWriteTimeout = 15000
    $req.UserAgent = "ShinkenAlarm/$($script:AppVersion)"
    $req.Headers.Add("Cache-Control", "no-cache")
    $resp = $null
    try { $resp = $req.GetResponse() } catch [System.Net.WebException] { $resp = $_.Exception.Response; if ($null -eq $resp) { throw } }
    try {
        $sr = New-Object System.IO.StreamReader($resp.GetResponseStream(), (New-Object System.Text.UTF8Encoding($false)))
        try { $text = $sr.ReadToEnd() } finally { $sr.Dispose() }
        return @{ Status = [int]$resp.StatusCode; Body = $text; FinalHost = $resp.ResponseUri.Host }
    } finally { $resp.Dispose() }
}

# 開一個下載：回傳 @{ Status; Length（不知道就 -1）; Stream; FinalHost; Close（要呼叫來關掉連線） }
function Open-UpdateDownload([string]$url) {
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
    $req = [System.Net.HttpWebRequest]::Create($url)
    $req.Timeout = 20000
    $req.ReadWriteTimeout = 20000
    $req.UserAgent = "ShinkenAlarm/$($script:AppVersion)"
    $resp = $null
    try { $resp = $req.GetResponse() } catch [System.Net.WebException] { $resp = $_.Exception.Response; if ($null -eq $resp) { throw } }
    $close = { try { $resp.Dispose() } catch {} }.GetNewClosure()
    return @{ Status = [int]$resp.StatusCode; Length = [long]$resp.ContentLength; Stream = $resp.GetResponseStream(); FinalHost = $resp.ResponseUri.Host; Close = $close }
}

# 到網站看有沒有新版。回傳 Get-UpdateCheckResult 的結果；連不上 → State = error（白話）
function Invoke-UpdateCheck([string]$currentVersion) {
    $r = $null
    try { $r = Get-UpdateHttpText $script:UpdateManifestUrl } catch { return @{ State = "error"; Error = "連不上更新網站（沒網路？），稍後再試。" } }
    if ($r.Status -ne 200) { return @{ State = "error"; Error = "更新網站暫時沒有回應（$($r.Status)），稍後再試。" } }
    if ($script:UpdateAllowedHosts -notcontains "$($r.FinalHost)".ToLowerInvariant()) { return @{ State = "error"; Error = "更新資訊被轉到不明的網站，為了安全沒有更新。" } }
    return (Get-UpdateCheckResult $currentVersion $r.Body)
}

# ---------- 下載、核對 ----------

function Get-FileSha256([string]$path) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $fs = [System.IO.File]::OpenRead($path)
    try { return (($sha.ComputeHash($fs) | ForEach-Object { $_.ToString("x2") }) -join "") } finally { $fs.Dispose(); $sha.Dispose() }
}

# 下載到 $dest（先存成 .part，下載完整才改名）。$progress 是 { param($done, $total) }。中斷、大小不對 → 丟 UPDATE|network
function Save-UpdateDownload([string]$url, [string]$dest, [scriptblock]$progress) {
    $part = "$dest.part"
    Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
    $dl = $null
    try { $dl = Open-UpdateDownload $url } catch { Stop-Update "network" "連不上更新網站（沒網路？），沒有下載。" }
    $fs = $null
    try {
        if ($dl.Status -ne 200) { Stop-Update "network" "更新網站暫時沒有回應（$($dl.Status)），沒有下載。" }
        if ($script:UpdateAllowedHosts -notcontains "$($dl.FinalHost)".ToLowerInvariant()) { Stop-Update "data" "下載被轉到不明的網站，為了安全沒有更新。" }
        $fs = [System.IO.File]::Create($part)
        $buf = New-Object byte[] 65536
        $done = [long]0
        try {
            while ($true) {
                $n = $dl.Stream.Read($buf, 0, $buf.Length)
                if ($n -le 0) { break }
                $fs.Write($buf, 0, $n)
                $done += $n
                if ($null -ne $progress) { & $progress $done $dl.Length }
            }
        } catch { Stop-Update "network" "下載到一半中斷了（網路不穩？），沒有更新，可以再試一次。" }
        $fs.Dispose(); $fs = $null
        if ($dl.Length -gt 0 -and $done -ne $dl.Length) { Stop-Update "network" "下載到一半中斷了（只收到 $done / $($dl.Length) 個位元組），沒有更新，可以再試一次。" }
        if ($done -le 0) { Stop-Update "network" "下載回來的檔案是空的，沒有更新。" }
        Move-Item -LiteralPath $part -Destination $dest -Force
    } catch {
        if ($null -ne $fs) { try { $fs.Dispose() } catch {} }
        Remove-Item -LiteralPath $part -Force -ErrorAction SilentlyContinue
        throw
    } finally {
        if ($null -ne $dl -and $null -ne $dl.Close) { & $dl.Close }
    }
}

# 指紋對不上 → 刪掉檔案、丟 UPDATE|hash
function Assert-UpdateSha256([string]$path, [string]$expected) {
    $actual = Get-FileSha256 $path
    if ($actual -ne "$expected".ToLowerInvariant()) {
        Remove-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
        Stop-Update "hash" "下載回來的檔案「指紋」跟更新資訊裡的對不上，為了安全沒有更新。可能是下載中途被改動，或網站上的檔案有問題；請稍後再試，一直這樣的話請聯絡作者。"
    }
}

# ---------- 解壓縮、檢查更新檔 ----------

# 解壓縮到 $dir；任何一個檔案想跑出 $dir 外面（zip-slip）就整個拒絕
function Expand-UpdateZip([string]$zipPath, [string]$dir) {
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
    $root = [System.IO.Path]::GetFullPath($dir).TrimEnd("\", "/") + [System.IO.Path]::DirectorySeparatorChar
    $zip = $null
    try { $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath) } catch { Stop-Update "data" "更新檔打不開（不是正常的 zip），沒有更新。" }
    try {
        foreach ($e in $zip.Entries) {
            $target = [System.IO.Path]::GetFullPath((Join-Path $dir ($e.FullName -replace "/", [System.IO.Path]::DirectorySeparatorChar)))
            if (-not $target.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) { Stop-Update "data" "更新檔裡有不安全的路徑（想寫到暫存資料夾外面），為了安全沒有更新。" }
            if ($e.FullName.EndsWith("/")) { New-Item -ItemType Directory -Path $target -Force | Out-Null; continue }
            $parent = Split-Path -Parent $target
            if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
            [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, $target, $true)
        }
    } finally { $zip.Dispose() }
}

# 在解壓縮出來的東西裡找 app 資料夾，檢查檔案齊全、.ps1 沒有語法錯誤。回傳 app 資料夾路徑
function Find-UpdateAppDir([string]$staging) {
    $cands = @(Get-ChildItem -LiteralPath $staging -Recurse -Filter "Alarm_Tray.ps1" -File | Where-Object { $_.Directory.Name -eq "app" })
    if ($cands.Count -eq 0) { Stop-Update "data" "更新檔裡找不到程式（app 資料夾），沒有更新。" }
    $app = $cands[0].Directory.FullName
    foreach ($f in $script:UpdateRequiredFiles) {
        if (-not (Test-Path -LiteralPath (Join-Path $app $f))) { Stop-Update "data" "更新檔不完整（少了 $f），沒有更新。" }
    }
    foreach ($f in @(Get-ChildItem -LiteralPath $app -Filter "*.ps1" -File)) {
        $errs = $null
        [System.Management.Automation.Language.Parser]::ParseFile($f.FullName, [ref]$null, [ref]$errs) | Out-Null
        if (@($errs).Count -gt 0) { Stop-Update "data" "更新檔裡的 $($f.Name) 有問題（語法錯誤），為了安全沒有更新。" }
    }
    return $app
}

# ---------- 換檔（可以還原） ----------

function Test-UpdateDataName([string]$name) {
    if ($script:UpdateDataFiles -contains $name) { return $true }
    foreach ($p in $script:UpdateDataPatterns) { if ($name -like $p) { return $true } }
    if ($name -eq $script:UpdateBackupDirName) { return $true }
    return $false
}

# app 資料夾裡「程式」的項目（不含使用者資料、備份資料夾、暫存檔）
function Get-UpdateProgramItems([string]$appDir) {
    return @(Get-ChildItem -LiteralPath $appDir -Force | Where-Object { -not (Test-UpdateDataName $_.Name) -and $_.Name -notlike "*.tmp" -and $_.Name -notlike "*.part" })
}

function Copy-UpdateItem($item, [string]$destDir) {
    if ($null -ne $script:UpdateCopyHook) { & $script:UpdateCopyHook $item.Name }
    Copy-Item -LiteralPath $item.FullName -Destination $destDir -Recurse -Force -ErrorAction Stop
}

# 換檔。$newAppDir 是新版的 app 資料夾。
#   1. 備份使用者資料 + 舊程式到 app\update_backup\<時間>\
#   2. 新程式蓋上去，舊版有、新版沒有的程式檔刪掉
#   3. 驗證每個 .ps1 都換成新的；任何一步失敗 → 還原舊程式（使用者資料本來就沒動）
# 回傳 @{ Ok; Error; RolledBack; BackupDir }
function Invoke-UpdateApply([string]$appDir, [string]$newAppDir, [DateTime]$now) {
    if ($null -eq $now) { $now = Get-Date }
    $res = @{ Ok = $false; Error = ""; RolledBack = $false; BackupDir = "" }
    $stamp = $now.ToString("yyyyMMdd_HHmmss", [System.Globalization.CultureInfo]::InvariantCulture)
    $backup = Join-Path (Join-Path $appDir $script:UpdateBackupDirName) $stamp
    $progBackup = Join-Path $backup "program"
    $dataBackup = Join-Path $backup "data"
    $res.BackupDir = $backup
    $oldItems = @()
    try {
        New-Item -ItemType Directory -Path $progBackup -Force | Out-Null
        New-Item -ItemType Directory -Path $dataBackup -Force | Out-Null
        foreach ($f in @(Get-ChildItem -LiteralPath $appDir -Force -File | Where-Object { (Test-UpdateDataName $_.Name) })) {
            Copy-Item -LiteralPath $f.FullName -Destination $dataBackup -Force -ErrorAction Stop
        }
        $oldItems = @(Get-UpdateProgramItems $appDir)
        foreach ($it in $oldItems) { Copy-Item -LiteralPath $it.FullName -Destination $progBackup -Recurse -Force -ErrorAction Stop }
    } catch {
        $res.Error = "更新前的備份失敗，沒有動任何檔案：$($_.Exception.Message)"
        return $res
    }
    $newItems = @(Get-ChildItem -LiteralPath $newAppDir -Force | Where-Object { -not (Test-UpdateDataName $_.Name) })
    try {
        foreach ($it in $newItems) { Copy-UpdateItem $it $appDir }
        # 舊版有、新版沒有的程式檔（改名、刪掉的）
        $newNames = @($newItems | ForEach-Object { $_.Name })
        foreach ($it in $oldItems) { if ($newNames -notcontains $it.Name) { Remove-Item -LiteralPath $it.FullName -Recurse -Force -ErrorAction Stop } }
        # 驗證：每個新的 .ps1 都已經換成新的
        foreach ($f in @($newItems | Where-Object { $_.Name -like "*.ps1" })) {
            if ((Get-FileSha256 $f.FullName) -ne (Get-FileSha256 (Join-Path $appDir $f.Name))) { throw "$($f.Name) 換完之後內容跟更新檔不一樣" }
        }
        $res.Ok = $true
    } catch {
        $res.Error = "換檔時出了問題，已經還原成舊版：$($_.Exception.Message)"
        try {
            # 還原：現有的程式項目全部拿掉，舊程式放回去（使用者資料沒動；有被改到的話從備份放回去）
            foreach ($it in @(Get-UpdateProgramItems $appDir)) { Remove-Item -LiteralPath $it.FullName -Recurse -Force -ErrorAction SilentlyContinue }
            foreach ($it in @(Get-ChildItem -LiteralPath $progBackup -Force)) { Copy-Item -LiteralPath $it.FullName -Destination $appDir -Recurse -Force }
            foreach ($f in @(Get-ChildItem -LiteralPath $dataBackup -Force -File)) {
                $cur = Join-Path $appDir $f.Name
                if (-not (Test-Path -LiteralPath $cur) -or (Get-FileSha256 $cur) -ne (Get-FileSha256 $f.FullName)) { Copy-Item -LiteralPath $f.FullName -Destination $cur -Force }
            }
            $res.RolledBack = $true
        } catch {
            $res.Error = "$($res.Error)（還原也沒成功：$($_.Exception.Message)。舊版的完整備份在：$backup）"
        }
    }
    # 只留最近 3 份備份
    try {
        $all = @(Get-ChildItem -LiteralPath (Join-Path $appDir $script:UpdateBackupDirName) -Directory | Sort-Object Name)
        if ($all.Count -gt 3) { foreach ($d in $all[0..($all.Count - 4)]) { Remove-Item -LiteralPath $d.FullName -Recurse -Force -ErrorAction SilentlyContinue } }
    } catch {}
    return $res
}

# ---------- 更新結果、每天安靜檢查 ----------

function Write-UpdateResult([string]$appDir, [bool]$ok, [string]$from, [string]$to, [string]$message) {
    $o = [ordered]@{ ok = $ok; from = $from; to = $to; message = $message; at = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss", [System.Globalization.CultureInfo]::InvariantCulture); shown = $false }
    [System.IO.File]::WriteAllText((Join-Path $appDir "update_result.json"), (ConvertTo-Json -InputObject $o), (New-Object System.Text.UTF8Encoding($false)))
}

# 上次更新的結果（只回傳一次：讀了就標成看過）；沒有就 $null
function Read-UpdateResultOnce([string]$appDir) {
    $path = Join-Path $appDir "update_result.json"
    if (-not (Test-Path -LiteralPath $path)) { return $null }
    try {
        $o = [System.IO.File]::ReadAllText($path, (New-Object System.Text.UTF8Encoding($false))) | ConvertFrom-Json
        if ($o.shown -eq $true) { return $null }
        $o.shown = $true
        [System.IO.File]::WriteAllText($path, (ConvertTo-Json -InputObject $o), (New-Object System.Text.UTF8Encoding($false)))
        return @{ Ok = ($o.ok -eq $true); From = "$($o.from)"; To = "$($o.to)"; Message = "$($o.message)" }
    } catch { return $null }
}

function Read-UpdateState([string]$path) {
    $s = @{ lastCheckDate = ""; lastAttempt = ""; availableVersion = ""; availableNotes = "" }
    if (-not (Test-Path -LiteralPath $path)) { return $s }
    try {
        $o = [System.IO.File]::ReadAllText($path, (New-Object System.Text.UTF8Encoding($false))) | ConvertFrom-Json
        foreach ($k in @($s.Keys)) { if ($null -ne $o.$k) { $s[$k] = "$($o.$k)" } }
    } catch {}
    return $s
}

function Write-UpdateState([string]$path, $s) {
    [System.IO.File]::WriteAllText($path, (ConvertTo-Json -InputObject $s), (New-Object System.Text.UTF8Encoding($false)))
}

# 每天第一次安靜檢查一次（背景提醒程式呼叫）；失敗不吵人，1 小時後再試。回傳有沒有真的連網檢查
function Invoke-UpdateDailyCheck([string]$statePath, [string]$currentVersion, [DateTime]$now) {
    if ($null -eq $now) { $now = Get-Date }
    $s = Read-UpdateState $statePath
    $today = $now.ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
    if ($s.lastCheckDate -eq $today) { return $false }
    if ($s.lastAttempt -ne "") {
        $t = $null
        try { $t = [DateTime]::ParseExact($s.lastAttempt, "yyyy-MM-dd HH:mm:ss", [System.Globalization.CultureInfo]::InvariantCulture) } catch {}
        if ($null -ne $t -and ($now - $t).TotalMinutes -lt 60 -and $t -le $now) { return $false }
    }
    $s.lastAttempt = $now.ToString("yyyy-MM-dd HH:mm:ss", [System.Globalization.CultureInfo]::InvariantCulture)
    $r = Invoke-UpdateCheck $currentVersion
    if ($r.State -eq "error") { Write-UpdateState $statePath $s; return $true }
    $s.lastCheckDate = $today
    if ($r.State -eq "available") { $s.availableVersion = $r.Version; $s.availableNotes = $r.Notes } else { $s.availableVersion = ""; $s.availableNotes = "" }
    Write-UpdateState $statePath $s
    return $true
}

# 設定視窗要不要顯示小紅點：有記錄到比現在新的版本才算
function Get-UpdateAvailableFromState([string]$statePath, [string]$currentVersion) {
    $s = Read-UpdateState $statePath
    if ($s.availableVersion -ne "" -and (Compare-AppVersion $s.availableVersion $currentVersion) -gt 0) { return @{ Version = $s.availableVersion; Notes = $s.availableNotes } }
    return $null
}

# ---------- 啟動「換檔小程式」 ----------
# 主程式自己沒辦法換自己的檔（正在執行、檔案被占用）：複製一份 AlarmUpdate.ps1 + 一支小腳本到暫存資料夾，
# 另開一個 PowerShell 跑它；它等主程式關掉 → 換檔 → 重新啟動。
function Get-UpdateRunnerScript {
    return @'
param([string]$AppDir, [string]$NewAppDir, [string]$StagingRoot, [string]$FromVersion, [string]$ToVersion, [string]$WaitPids)
$ErrorActionPreference = "Continue"
. (Join-Path $PSScriptRoot "AlarmCore.ps1")
. (Join-Path $PSScriptRoot "AlarmUpdate.ps1")
# 等主程式關掉（最多 40 秒），還沒關的就強制結束這個資料夾裡的真劍鬧鐘
foreach ($p in @("$WaitPids".Split(",") | Where-Object { $_ -match "^\d+$" })) {
    $deadline = (Get-Date).AddSeconds(40)
    while ((Get-Date) -lt $deadline -and (Get-Process -Id ([int]$p) -ErrorAction SilentlyContinue)) { Start-Sleep -Milliseconds 300 }
}
try {
    $procs = Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" -ErrorAction SilentlyContinue
    foreach ($pr in $procs) {
        $cl = "$($pr.CommandLine)"
        if (($cl -like "*Alarm_Tray.ps1*" -or $cl -like "*Alarm_Manager_GUI.ps1*") -and $cl.IndexOf($AppDir, [StringComparison]::OrdinalIgnoreCase) -ge 0 -and $pr.ProcessId -ne $PID) {
            try { Stop-Process -Id $pr.ProcessId -Force -ErrorAction SilentlyContinue } catch {}
        }
    }
} catch {}
Start-Sleep -Milliseconds 800
$res = Invoke-UpdateApply $AppDir $NewAppDir (Get-Date)
if ($res.Ok) { Write-UpdateResult $AppDir $true $FromVersion $ToVersion "已經更新到 v$ToVersion。你的鬧鐘和設定都還在。" }
else { Write-UpdateResult $AppDir $false $FromVersion $ToVersion $res.Error }
try { Remove-Item -LiteralPath $StagingRoot -Recurse -Force -ErrorAction SilentlyContinue } catch {}
# 重新啟動（用 Setup.ps1 的 Launch：背景提醒不在跑就啟動、在跑就開設定視窗）
try {
    $ps = Join-Path $PSHOME "powershell.exe"
    $setup = Join-Path $AppDir "Setup.ps1"
    if (Test-Path -LiteralPath $setup) { Start-Process -FilePath $ps -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", "`"$setup`"", "-Action", "Launch") -WindowStyle Hidden }
} catch {}
'@
}

# 把換檔小程式準備好並啟動；呼叫的人（設定視窗）接著就要結束自己。回傳暫存資料夾
function Start-UpdateApply([string]$appDir, [string]$newAppDir, [string]$stagingRoot, [string]$fromVersion, [string]$toVersion, [int[]]$waitPids) {
    $run = Join-Path ([System.IO.Path]::GetTempPath()) ("shinken_update_run_" + [Guid]::NewGuid().ToString("N").Substring(0, 8))
    New-Item -ItemType Directory -Path $run -Force | Out-Null
    foreach ($f in @("AlarmCore.ps1", "AlarmUpdate.ps1")) {
        $src = Join-Path $appDir $f
        $bytes = [System.IO.File]::ReadAllBytes($src)
        [System.IO.File]::WriteAllBytes((Join-Path $run $f), $bytes)
    }
    [System.IO.File]::WriteAllText((Join-Path $run "Update_Run.ps1"), (Get-UpdateRunnerScript), (New-Object System.Text.UTF8Encoding($true)))
    $ps = Join-Path $PSHOME "powershell.exe"
    $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", "`"$(Join-Path $run 'Update_Run.ps1')`"",
        "-AppDir", "`"$appDir`"", "-NewAppDir", "`"$newAppDir`"", "-StagingRoot", "`"$stagingRoot`"", "-FromVersion", "`"$fromVersion`"", "-ToVersion", "`"$toVersion`"", "-WaitPids", "`"$($waitPids -join ',')`"")
    Start-Process -FilePath $ps -ArgumentList $argList -WindowStyle Hidden
    return $run
}

# 從網站更新到新版（設定視窗用）：下載 → 核對 → 解壓縮 → 檢查。成功回傳 @{ NewAppDir; StagingRoot }，失敗丟 UPDATE|…
function Get-UpdatePackage($check, [scriptblock]$progress) {
    $staging = Join-Path ([System.IO.Path]::GetTempPath()) ("shinken_update_" + [Guid]::NewGuid().ToString("N").Substring(0, 8))
    New-Item -ItemType Directory -Path $staging -Force | Out-Null
    try {
        $zip = Join-Path $staging "update.zip"
        Save-UpdateDownload $check.Url $zip $progress
        Assert-UpdateSha256 $zip $check.Sha256
        $x = Join-Path $staging "x"
        Expand-UpdateZip $zip $x
        $app = Find-UpdateAppDir $x
        return @{ NewAppDir = $app; StagingRoot = $staging }
    } catch {
        Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue
        throw
    }
}

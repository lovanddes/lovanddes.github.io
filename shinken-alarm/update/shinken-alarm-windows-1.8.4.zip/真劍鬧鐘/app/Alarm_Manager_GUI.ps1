﻿# 真劍鬧鐘：設定視窗（鬧鐘列表）
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
[System.Windows.Forms.Application]::EnableVisualStyles()

. (Join-Path $PSScriptRoot "AlarmCore.ps1")
. (Join-Path $PSScriptRoot "AlarmSync.ps1")
. (Join-Path $PSScriptRoot "AlarmUpdate.ps1")
. (Join-Path $PSScriptRoot "AlarmUi.ps1")

$jsonPath = Join-Path $PSScriptRoot "alarms.json"
# 排序方式、自己新增的分類名稱（只有設定視窗會寫）
$settingsPath = Join-Path $PSScriptRoot "settings.json"

# 第一次使用（沒有 alarms.json）→ 建一個範例鬧鐘
try { Initialize-AlarmFile $jsonPath (Get-Date) | Out-Null } catch {}

function Load-Alarms {
    $data = Read-AlarmFile $jsonPath
    if ($data.Count -eq 0) { return @() }
    $data = Repair-DuplicateIds $data
    return $data
}

function Repair-DuplicateIds($alarms) {
    if ($alarms.Count -eq 0) { return $alarms }
    $seen = @{}
    $maxId = 0
    foreach ($a in $alarms) {
        if ($a.id -gt $maxId) { $maxId = $a.id }
    }
    $changed = $false
    foreach ($a in $alarms) {
        if ($seen.ContainsKey($a.id)) {
            $maxId++
            $a.id = $maxId
            $changed = $true
        } else {
            $seen[$a.id] = $true
        }
    }
    if ($changed) {
        Show-AppMessage("偵測到有兩個鬧鐘的內部編號重複（這會導致它們互相影響、其中一個可能不再提醒），已自動改成不重複的編號並存檔。", "$($script:AppName) - 自動修正") | Out-Null
        Save-Alarms $alarms
    }
    return $alarms
}

function Save-Alarms($alarms) {
    Write-AlarmFile $jsonPath $alarms
}

# Get-AlarmBaseType、Get-AlarmDescription 搬到 AlarmCore.ps1（每年固定日期多選的顯示也在那裡）

function Show-AlarmDialog {
    param($existing)

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 鬧鐘設定"
    $dlg.Size = New-Object System.Drawing.Size(380, 920)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $lblType = New-Object System.Windows.Forms.Label
    $lblType.Text = "類型："
    $lblType.Location = New-Object System.Drawing.Point(20, 20)
    $lblType.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblType)

    $cmbType = New-Object System.Windows.Forms.ComboBox
    $cmbType.Location = New-Object System.Drawing.Point(110, 18)
    $cmbType.Size = New-Object System.Drawing.Size(220, 24)
    $cmbType.DropDownStyle = "DropDownList"
    $cmbType.Items.AddRange(@("每月固定日期", "每天", "每週固定星期幾", "單次", "定期倒數提醒", "每年固定日期"))
    $dlg.Controls.Add($cmbType)

    $lblLabel = New-Object System.Windows.Forms.Label
    $lblLabel.Text = "提醒內容："
    $lblLabel.Location = New-Object System.Drawing.Point(20, 60)
    $lblLabel.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblLabel)

    $txtLabel = New-Object System.Windows.Forms.TextBox
    $txtLabel.Location = New-Object System.Drawing.Point(110, 58)
    $txtLabel.Size = New-Object System.Drawing.Size(220, 24)
    $dlg.Controls.Add($txtLabel)

    $lblTime = New-Object System.Windows.Forms.Label
    $lblTime.Text = "提醒時間："
    $lblTime.Location = New-Object System.Drawing.Point(20, 100)
    $lblTime.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblTime)

    $dtpTime = New-Object System.Windows.Forms.DateTimePicker
    $dtpTime.Location = New-Object System.Drawing.Point(110, 98)
    $dtpTime.Size = New-Object System.Drawing.Size(120, 24)
    $dtpTime.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
    $dtpTime.CustomFormat = "HH:mm"
    $dtpTime.ShowUpDown = $true
    $dlg.Controls.Add($dtpTime)

    $lblDays = New-Object System.Windows.Forms.Label
    $lblDays.Text = "哪幾號："
    $lblDays.Location = New-Object System.Drawing.Point(20, 140)
    $lblDays.Size = New-Object System.Drawing.Size(80, 24)

    $txtDays = New-Object System.Windows.Forms.TextBox
    $txtDays.Location = New-Object System.Drawing.Point(110, 138)
    $txtDays.Size = New-Object System.Drawing.Size(220, 24)

    $lblDaysHint = New-Object System.Windows.Forms.Label
    $lblDaysHint.Text = "用逗號分隔，例如 1,16"
    $lblDaysHint.Location = New-Object System.Drawing.Point(110, 164)
    $lblDaysHint.Size = New-Object System.Drawing.Size(220, 20)
    $lblDaysHint.ForeColor = [System.Drawing.Color]::Gray
    $lblDaysHint.Font = New-Object System.Drawing.Font($lblDaysHint.Font.FontFamily, 8)

    $dlg.Controls.Add($lblDays)
    $dlg.Controls.Add($txtDays)
    $dlg.Controls.Add($lblDaysHint)

    $lblWeek = New-Object System.Windows.Forms.Label
    $lblWeek.Text = "星期幾："
    $lblWeek.Location = New-Object System.Drawing.Point(20, 140)
    $lblWeek.Size = New-Object System.Drawing.Size(80, 24)

    $clbWeek = New-Object System.Windows.Forms.CheckedListBox
    $clbWeek.Location = New-Object System.Drawing.Point(110, 138)
    $clbWeek.Size = New-Object System.Drawing.Size(160, 130)
    $clbWeek.Items.AddRange(@("星期一","星期二","星期三","星期四","星期五","星期六","星期日"))
    $clbWeek.CheckOnClick = $true

    $dlg.Controls.Add($lblWeek)
    $dlg.Controls.Add($clbWeek)

    $lblDate = New-Object System.Windows.Forms.Label
    $lblDate.Text = "日期："
    $lblDate.Location = New-Object System.Drawing.Point(20, 140)
    $lblDate.Size = New-Object System.Drawing.Size(80, 24)

    $dtpDate = New-Object System.Windows.Forms.DateTimePicker
    $dtpDate.Location = New-Object System.Drawing.Point(110, 138)
    $dtpDate.Size = New-Object System.Drawing.Size(160, 24)
    $dtpDate.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
    $dtpDate.CustomFormat = "yyyy-MM-dd"

    $dlg.Controls.Add($lblDate)
    $dlg.Controls.Add($dtpDate)

    $lblInterval = New-Object System.Windows.Forms.Label
    $lblInterval.Text = "間隔天數："
    $lblInterval.Location = New-Object System.Drawing.Point(20, 140)
    $lblInterval.Size = New-Object System.Drawing.Size(80, 24)

    $txtInterval = New-Object System.Windows.Forms.TextBox
    $txtInterval.Location = New-Object System.Drawing.Point(110, 138)
    $txtInterval.Size = New-Object System.Drawing.Size(80, 24)

    $lblIntervalHint = New-Object System.Windows.Forms.Label
    $lblIntervalHint.Text = "例如填 80，代表每 80 天提醒一次；`n第一次會從今天算起 80 天後開始，`n之後每次你按「已完成」，就會從那天重新倒數 80 天。"
    $lblIntervalHint.Location = New-Object System.Drawing.Point(110, 164)
    $lblIntervalHint.Size = New-Object System.Drawing.Size(230, 60)
    $lblIntervalHint.ForeColor = [System.Drawing.Color]::Gray
    $lblIntervalHint.Font = New-Object System.Drawing.Font($lblIntervalHint.Font.FontFamily, 8)

    $dlg.Controls.Add($lblInterval)
    $dlg.Controls.Add($txtInterval)
    $dlg.Controls.Add($lblIntervalHint)

    # 每年固定日期：月份可以多選 × 日期可以多個（例如 3、9 月的 1、15 號）
    $lblYearMonths = New-Object System.Windows.Forms.Label
    $lblYearMonths.Text = "哪幾月："
    $lblYearMonths.Location = New-Object System.Drawing.Point(20, 140)
    $lblYearMonths.Size = New-Object System.Drawing.Size(80, 24)

    $clbYearMonths = New-Object System.Windows.Forms.CheckedListBox
    $clbYearMonths.Location = New-Object System.Drawing.Point(110, 138)
    $clbYearMonths.Size = New-Object System.Drawing.Size(240, 56)
    $clbYearMonths.MultiColumn = $true
    $clbYearMonths.ColumnWidth = 58
    $clbYearMonths.CheckOnClick = $true
    $clbYearMonths.Items.AddRange(@("1 月","2 月","3 月","4 月","5 月","6 月","7 月","8 月","9 月","10 月","11 月","12 月"))

    $lblYearDays = New-Object System.Windows.Forms.Label
    $lblYearDays.Text = "哪幾號："
    $lblYearDays.Location = New-Object System.Drawing.Point(20, 200)
    $lblYearDays.Size = New-Object System.Drawing.Size(80, 24)

    $txtYearDays = New-Object System.Windows.Forms.TextBox
    $txtYearDays.Location = New-Object System.Drawing.Point(110, 198)
    $txtYearDays.Size = New-Object System.Drawing.Size(80, 24)

    $lblYearHint = New-Object System.Windows.Forms.Label
    $lblYearHint.Text = "逗號分隔，例如 1,15`n沒有那天(2/30)→月底響"
    $lblYearHint.Location = New-Object System.Drawing.Point(195, 196)
    $lblYearHint.Size = New-Object System.Drawing.Size(160, 30)
    $lblYearHint.ForeColor = [System.Drawing.Color]::Gray
    $lblYearHint.Font = New-Object System.Drawing.Font($lblYearHint.Font.FontFamily, 8)

    $dlg.Controls.Add($lblYearMonths)
    $dlg.Controls.Add($clbYearMonths)
    $dlg.Controls.Add($lblYearDays)
    $dlg.Controls.Add($txtYearDays)
    $dlg.Controls.Add($lblYearHint)

    $lblNotes = New-Object System.Windows.Forms.Label
    $lblNotes.Text = "備註（提醒跳出來時會一起顯示，可以寫步驟）："
    $lblNotes.Location = New-Object System.Drawing.Point(20, 228)
    $lblNotes.Size = New-Object System.Drawing.Size(330, 20)
    $dlg.Controls.Add($lblNotes)

    $txtNotes = New-Object System.Windows.Forms.TextBox
    $txtNotes.Location = New-Object System.Drawing.Point(20, 250)
    $txtNotes.Size = New-Object System.Drawing.Size(330, 65)
    $txtNotes.Multiline = $true
    $txtNotes.ScrollBars = "Vertical"
    $dlg.Controls.Add($txtNotes)

    function Update-PanelVisibility {
        $idx = $cmbType.SelectedIndex
        $lblDays.Visible = ($idx -eq 0)
        $txtDays.Visible = ($idx -eq 0)
        $lblDaysHint.Visible = ($idx -eq 0)

        $lblWeek.Visible = ($idx -eq 2)
        $clbWeek.Visible = ($idx -eq 2)

        $lblDate.Visible = ($idx -eq 3)
        $dtpDate.Visible = ($idx -eq 3)

        $lblYearMonths.Visible = ($idx -eq 5)
        $clbYearMonths.Visible = ($idx -eq 5)
        $lblYearDays.Visible = ($idx -eq 5)
        $txtYearDays.Visible = ($idx -eq 5)
        $lblYearHint.Visible = ($idx -eq 5)

        $lblInterval.Visible = ($idx -eq 4)
        $txtInterval.Visible = ($idx -eq 4)
        $lblIntervalHint.Visible = ($idx -eq 4)
    }

    $cmbType.Add_SelectedIndexChanged({ Update-PanelVisibility })

    $chkTimeLimited = New-Object System.Windows.Forms.CheckBox
    $chkTimeLimited.Text = "限時提醒（超過15分鐘沒看到就不補提醒）"
    $chkTimeLimited.Location = New-Object System.Drawing.Point(20, 325)
    $chkTimeLimited.Size = New-Object System.Drawing.Size(330, 24)
    $dlg.Controls.Add($chkTimeLimited)

    $chkPlaySound = New-Object System.Windows.Forms.CheckBox
    $chkPlaySound.Text = "提醒時要出聲音"
    $chkPlaySound.Location = New-Object System.Drawing.Point(20, 355)
    $chkPlaySound.Size = New-Object System.Drawing.Size(330, 24)
    $chkPlaySound.Checked = $true
    $dlg.Controls.Add($chkPlaySound)

    $chkTimeLimited.Add_CheckedChanged({
        if ($chkTimeLimited.Checked) { $chkPlaySound.Checked = $false }
    })

    $chkStrict = New-Object System.Windows.Forms.CheckBox
    $chkStrict.Text = "認真型：要確實完成（解題+二次確認）才會消失"
    # 不勾＝隨意型
    $chkStrict.Location = New-Object System.Drawing.Point(20, 385)
    $chkStrict.Size = New-Object System.Drawing.Size(330, 24)
    $chkStrict.Checked = $true
    $dlg.Controls.Add($chkStrict)

    $lblStrictHint = New-Object System.Windows.Forms.Label
    $lblStrictHint.Text = "不勾＝隨意型：跳出後按一下「知道了」就會關閉，不用解題"
    $lblStrictHint.Location = New-Object System.Drawing.Point(20, 409)
    $lblStrictHint.Size = New-Object System.Drawing.Size(330, 20)
    $lblStrictHint.ForeColor = [System.Drawing.Color]::Gray
    $lblStrictHint.Font = New-Object System.Drawing.Font($lblStrictHint.Font.FontFamily, 8)
    $dlg.Controls.Add($lblStrictHint)

    # 關鬧鐘的難度（工單 8.5；認真型才有）。手機專屬的「掃 QR」在電腦上會改答 3 題算術
    $lblDiff = New-Object System.Windows.Forms.Label
    $lblDiff.Text = "關閉難度："
    $lblDiff.Location = New-Object System.Drawing.Point(20, 440)
    $lblDiff.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblDiff)

    $cmbDiff = New-Object System.Windows.Forms.ComboBox
    $cmbDiff.Location = New-Object System.Drawing.Point(110, 437)
    $cmbDiff.Size = New-Object System.Drawing.Size(240, 24)
    $cmbDiff.DropDownStyle = "DropDownList"
    $script:diffKeys = @($script:QuizChoices)
    foreach ($k in $script:diffKeys) { $cmbDiff.Items.Add($script:QuizLabels[$k]) | Out-Null }
    $cmbDiff.SelectedIndex = 0
    $dlg.Controls.Add($cmbDiff)

    $lblDiffHint = New-Object System.Windows.Forms.Label
    $lblDiffHint.Text = "預設算 1 題。連答 3 題、兩位數乘法會更難醒。"
    $lblDiffHint.Location = New-Object System.Drawing.Point(110, 464)
    $lblDiffHint.Size = New-Object System.Drawing.Size(250, 20)
    $lblDiffHint.ForeColor = [System.Drawing.Color]::Gray
    $lblDiffHint.Font = New-Object System.Drawing.Font($lblDiffHint.Font.FontFamily, 8)
    $dlg.Controls.Add($lblDiffHint)
    $script:keepQr = $false
    $chkStrict.Add_CheckedChanged({ $cmbDiff.Enabled = $chkStrict.Checked })

    # 重要程度（工單 8.11 B）：普通／要答題才能延後／絕對不能延後。後兩種一定是認真型
    $lblImp = New-Object System.Windows.Forms.Label
    $lblImp.Text = "重要程度："
    $lblImp.Location = New-Object System.Drawing.Point(20, 494)
    $lblImp.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblImp)

    $cmbImp = New-Object System.Windows.Forms.ComboBox
    $cmbImp.Location = New-Object System.Drawing.Point(110, 491)
    $cmbImp.Size = New-Object System.Drawing.Size(240, 24)
    $cmbImp.DropDownStyle = "DropDownList"
    foreach ($k in $script:ImportanceKeys) { $cmbImp.Items.Add($script:ImportanceLabels[$k]) | Out-Null }
    $cmbImp.SelectedIndex = 0
    $dlg.Controls.Add($cmbImp)

    $lblImpHint = New-Object System.Windows.Forms.Label
    $lblImpHint.Text = "普通：跟平常一樣"
    $lblImpHint.Location = New-Object System.Drawing.Point(110, 518)
    $lblImpHint.Size = New-Object System.Drawing.Size(250, 28)
    $lblImpHint.ForeColor = [System.Drawing.Color]::Gray
    $lblImpHint.Font = New-Object System.Drawing.Font($lblImpHint.Font.FontFamily, 8)
    $dlg.Controls.Add($lblImpHint)
    $script:impHints = @{
        normal = "普通：跟平常一樣"
        quiz   = "想按「先等等」「真的沒空」也要先答題，答對才延後（認真型已自動勾選）"
        must   = "提醒視窗沒有「先等等」「真的沒空」，只能答題完成（認真型已自動勾選）"
    }
    $cmbImp.Add_SelectedIndexChanged({
        $k = $script:ImportanceKeys[[Math]::Max(0, $cmbImp.SelectedIndex)]
        $lblImpHint.Text = $script:impHints[$k]
        if ($k -ne "normal") { $chkStrict.Checked = $true; $chkStrict.Enabled = $false } else { $chkStrict.Enabled = $true }
    })

    # 私密：開車不念內容、手機鎖定畫面不顯示內容（主要給手機用；電腦的提醒視窗在自己的電腦上，照常顯示）
    $chkPrivate = New-Object System.Windows.Forms.CheckBox
    $chkPrivate.Text = "私密（開車不念內容、手機鎖定時不顯示內容）"
    $chkPrivate.Location = New-Object System.Drawing.Point(20, 548)
    $chkPrivate.Size = New-Object System.Drawing.Size(340, 24)
    $dlg.Controls.Add($chkPrivate)
    $script:ownPrivate = $false
    $script:privBusy = $false
    $chkPrivate.Add_CheckedChanged({ if (-not $script:privBusy -and $chkPrivate.Enabled) { $script:ownPrivate = $chkPrivate.Checked } })

    $lblPrivateNote = New-Object System.Windows.Forms.Label
    $lblPrivateNote.Text = ""
    $lblPrivateNote.Location = New-Object System.Drawing.Point(38, 572)
    $lblPrivateNote.Size = New-Object System.Drawing.Size(320, 20)
    $lblPrivateNote.ForeColor = [System.Drawing.Color]::Gray
    $lblPrivateNote.Font = New-Object System.Drawing.Font($lblPrivateNote.Font.FontFamily, 8)
    $dlg.Controls.Add($lblPrivateNote)

    # 分類：可以從清單挑，也可以直接打一個新名字（例如 工作 / 家裡 / 孩子）
    $lblCategory = New-Object System.Windows.Forms.Label
    $lblCategory.Text = "分類："
    $lblCategory.Location = New-Object System.Drawing.Point(20, 606)
    $lblCategory.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblCategory)

    $cmbCategory = New-Object System.Windows.Forms.ComboBox
    $cmbCategory.Location = New-Object System.Drawing.Point(110, 604)
    $cmbCategory.Size = New-Object System.Drawing.Size(150, 24)
    $cmbCategory.DropDownStyle = "DropDown"
    foreach ($c in (Get-AllCategories $script:alarms $script:settings.categories)) { $cmbCategory.Items.Add($c) | Out-Null }
    $cmbCategory.Text = $script:DefaultCategory
    $dlg.Controls.Add($cmbCategory)

    $lblCategoryHint = New-Object System.Windows.Forms.Label
    $lblCategoryHint.Text = "可以直接打新的分類名稱"
    $lblCategoryHint.Location = New-Object System.Drawing.Point(265, 602)
    $lblCategoryHint.Size = New-Object System.Drawing.Size(95, 30)
    $lblCategoryHint.ForeColor = [System.Drawing.Color]::Gray
    $lblCategoryHint.Font = New-Object System.Drawing.Font($lblCategoryHint.Font.FontFamily, 8)
    $dlg.Controls.Add($lblCategoryHint)

    # 鈴聲、音量、漸強（2026-10-05：跟手機同一套欄位 ringtone／volume／crescendo，兩邊改都會同步）
    $script:ringSet = Read-RingSettings $script:RingSettingsPath
    $lblTone = New-Object System.Windows.Forms.Label
    $lblTone.Text = "鈴聲："
    $lblTone.Location = New-Object System.Drawing.Point(20, 642)
    $lblTone.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblTone)

    $cmbTone = New-Object System.Windows.Forms.ComboBox
    $cmbTone.Location = New-Object System.Drawing.Point(110, 639)
    $cmbTone.Size = New-Object System.Drawing.Size(240, 24)
    $cmbTone.DropDownStyle = "DropDownList"
    $dlg.Controls.Add($cmbTone)
    $script:toneKeys = @("", "gentle", "standard", "loud")
    foreach ($ct in @(Get-PcCustomTones)) { $script:toneKeys += ($script:ToneCustomPrefix + $ct.id) }
    # 原本的鈴聲這台沒有（手機的自訂、手機鈴聲）→ 也列出來，沒動就照留
    if ($existing) {
        $et = Get-ValidAlarmTone "$($existing.ringtone)"
        if ($et -ne "" -and $script:toneKeys -notcontains $et) { $script:toneKeys += $et }
    }
    foreach ($k in $script:toneKeys) {
        if ($k -eq "") { $cmbTone.Items.Add("跟隨全域設定（" + (Get-ToneLabel $script:ringSet.tone { param($id) Get-PcCustomToneName $id }) + "）") | Out-Null }
        else { $cmbTone.Items.Add((Get-ToneLabel $k { param($id) Get-PcCustomToneName $id })) | Out-Null }
    }
    $cmbTone.SelectedIndex = 0

    $lblVol = New-Object System.Windows.Forms.Label
    $lblVol.Text = "音量："
    $lblVol.Location = New-Object System.Drawing.Point(20, 676)
    $lblVol.Size = New-Object System.Drawing.Size(80, 24)
    $dlg.Controls.Add($lblVol)

    $trkVol = New-Object System.Windows.Forms.TrackBar
    $trkVol.Location = New-Object System.Drawing.Point(105, 670)
    $trkVol.Size = New-Object System.Drawing.Size(190, 34)
    $trkVol.Minimum = $script:VolumeMin
    $trkVol.Maximum = $script:VolumeMax
    $trkVol.SmallChange = $script:VolumeStep
    $trkVol.LargeChange = 10
    $trkVol.TickFrequency = 10
    $trkVol.Value = 80
    $dlg.Controls.Add($trkVol)

    $lblVolNum = New-Object System.Windows.Forms.Label
    $lblVolNum.Text = "80%"
    $lblVolNum.Location = New-Object System.Drawing.Point(300, 676)
    $lblVolNum.Size = New-Object System.Drawing.Size(55, 24)
    $dlg.Controls.Add($lblVolNum)

    $chkCresc = New-Object System.Windows.Forms.CheckBox
    $chkCresc.Text = "慢慢變大（漸強）"
    $chkCresc.Location = New-Object System.Drawing.Point(20, 708)
    $chkCresc.Size = New-Object System.Drawing.Size(200, 24)
    $dlg.Controls.Add($chkCresc)

    $btnPreview = New-Object System.Windows.Forms.Button
    $btnPreview.Text = "試聽"
    $btnPreview.Location = New-Object System.Drawing.Point(250, 705)
    $btnPreview.Size = New-Object System.Drawing.Size(100, 28)
    $dlg.Controls.Add($btnPreview)

    $lblVolDesc = New-Object System.Windows.Forms.Label
    $lblVolDesc.Text = ""
    $lblVolDesc.Location = New-Object System.Drawing.Point(20, 740)
    $lblVolDesc.Size = New-Object System.Drawing.Size(335, 78)
    $lblVolDesc.ForeColor = [System.Drawing.Color]::Gray
    $lblVolDesc.Font = New-Object System.Drawing.Font($lblVolDesc.Font.FontFamily, 8)
    $dlg.Controls.Add($lblVolDesc)

    $script:volTouched = $false
    $script:crescTouched = $false
    $script:volBusy = $false
    $script:previewPlayback = $null
    function Get-DialogImportance { return $script:ImportanceKeys[[Math]::Max(0, $cmbImp.SelectedIndex)] }
    function Update-VolumeUi {
        $imp = Get-DialogImportance
        $script:volBusy = $true
        $v = Limit-AlarmVolume $trkVol.Value $imp
        if ($trkVol.Value -ne $v) { $trkVol.Value = $v }
        $script:volBusy = $false
        $lblVolNum.Text = "$v%"
        $note = ""
        $f = Get-AlarmVolumeFloor $imp
        if ($imp -ne "normal" -and $v -le $f) { $note = "`n重要鬧鐘最低只能到 $f%，避免叫不醒。" }
        $lblVolDesc.Text = (Get-VolumeDescription $imp $v $chkCresc.Checked $chkPlaySound.Checked) + $note
        foreach ($c in @($cmbTone, $trkVol, $chkCresc, $btnPreview)) { $c.Enabled = $chkPlaySound.Checked }
    }
    function Stop-DialogPreview {
        if ($null -ne $script:previewPlayback) { Stop-TonePlayback $script:previewPlayback; $script:previewPlayback = $null }
        $btnPreview.Text = "試聽"
    }
    $trkVol.Add_ValueChanged({ if (-not $script:volBusy) { $script:volTouched = $true; Update-VolumeUi } })
    $chkCresc.Add_CheckedChanged({ if (-not $script:volBusy) { $script:crescTouched = $true }; Update-VolumeUi })
    $chkPlaySound.Add_CheckedChanged({ Update-VolumeUi })
    # 換重要程度：音量、漸強沒自己調過的話跟著換預設；「絕對不能延後」又跟隨全域 → 建議很吵
    $cmbImp.Add_SelectedIndexChanged({
        $imp = Get-DialogImportance
        $script:volBusy = $true
        if (-not $script:volTouched) { $trkVol.Value = Get-DefaultAlarmVolume $imp }
        if (-not $script:crescTouched) { $chkCresc.Checked = Get-DefaultCrescendo $imp ([bool]$script:ringSet.crescendo) }
        $cur = $script:toneKeys[[Math]::Max(0, $cmbTone.SelectedIndex)]
        $sug = Get-SuggestedToneForImportance $imp $cur
        if ($sug -ne $cur) { $cmbTone.SelectedIndex = [Array]::IndexOf($script:toneKeys, $sug) }
        $script:volBusy = $false
        Update-VolumeUi
    })
    # 試聽 5 秒（照現在選的鈴聲、音量、漸強）；再按一次停
    $btnPreview.Add_Click({
        if ($null -ne $script:previewPlayback) { Stop-DialogPreview; return }
        $k = $script:toneKeys[[Math]::Max(0, $cmbTone.SelectedIndex)]
        $tone = Resolve-PcTone $k $script:ringSet.tone { param($id) Test-PcCustomToneExists $id }
        if ($tone -eq "system") { [System.Media.SystemSounds]::Exclamation.Play(); return }
        $script:previewPlayback = Start-TonePlayback $tone ([int]$trkVol.Value) $chkCresc.Checked
        $btnPreview.Text = "停止試聽"
        $stopper = New-Object System.Windows.Forms.Timer
        $stopper.Interval = 5000
        $stopper.Add_Tick({ param($s, $e) $s.Stop(); $s.Dispose(); Stop-DialogPreview })
        $stopper.Start()
    })
    $dlg.Add_FormClosed({ Stop-DialogPreview })

    $btnSave = New-Object System.Windows.Forms.Button
    $btnSave.Text = "儲存"
    $btnSave.Location = New-Object System.Drawing.Point(110, 830)
    $btnSave.Size = New-Object System.Drawing.Size(100, 32)
    $dlg.Controls.Add($btnSave)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "取消"
    $btnCancel.Location = New-Object System.Drawing.Point(230, 830)
    $btnCancel.Size = New-Object System.Drawing.Size(100, 32)
    $dlg.Controls.Add($btnCancel)

    # 分類是私密的 → 勾選框鎖住、打勾（要取消請到「管理分類」）；不是 → 顯示這個鬧鐘自己的設定
    function Update-PrivateBox {
        $cat = $cmbCategory.Text.Trim()
        if ($cat -eq "") { $cat = $script:DefaultCategory }
        $script:privBusy = $true
        if (@($script:settings.privateCategories) -contains $cat) {
            $chkPrivate.Enabled = $false
            $chkPrivate.Checked = $true
            $lblPrivateNote.Text = "「$cat」是私密分類，要取消請到「管理分類」"
        } else {
            $chkPrivate.Enabled = $true
            $chkPrivate.Checked = $script:ownPrivate
            $lblPrivateNote.Text = ""
        }
        $script:privBusy = $false
    }
    $cmbCategory.Add_TextChanged({ Update-PrivateBox })
    Update-PrivateBox

    $script:dialogSaved = $null

    $btnSave.Add_Click({
        if ($txtLabel.Text.Trim() -eq "") {
            Show-AppMessage("請輸入提醒內容", "提醒") | Out-Null
            return
        }
        if ($cmbType.SelectedIndex -lt 0) {
            Show-AppMessage("請選擇類型", "提醒") | Out-Null
            return
        }

        $timeStr = $dtpTime.Value.ToString("HH:mm")
        $idx = $cmbType.SelectedIndex
        $timeLimited = $chkTimeLimited.Checked
        $playSound = $chkPlaySound.Checked
        $strict = $chkStrict.Checked
        $notes = $txtNotes.Text

        if ($idx -eq 0) {
            $daysText = $txtDays.Text.Trim()
            if ($daysText -eq "") {
                Show-AppMessage("請輸入日期（例如 1,16）", "提醒") | Out-Null
                return
            }
            $days = @($daysText -split "," | ForEach-Object { [int]$_.Trim() })
            $script:dialogSaved = [PSCustomObject]@{ type = "monthly"; label = $txtLabel.Text.Trim(); time = $timeStr; days = $days; date = ""; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes }
        }
        elseif ($idx -eq 1) {
            $script:dialogSaved = [PSCustomObject]@{ type = "daily"; label = $txtLabel.Text.Trim(); time = $timeStr; days = @(); date = ""; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes }
        }
        elseif ($idx -eq 2) {
            $days = @()
            for ($i = 0; $i -lt $clbWeek.Items.Count; $i++) {
                if ($clbWeek.GetItemChecked($i)) { $days += ($i + 1) }
            }
            if ($days.Count -eq 0) {
                Show-AppMessage("請至少勾選一個星期", "提醒") | Out-Null
                return
            }
            $script:dialogSaved = [PSCustomObject]@{ type = "weekly"; label = $txtLabel.Text.Trim(); time = $timeStr; days = $days; date = ""; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes }
        }
        elseif ($idx -eq 3) {
            # 單次鬧鐘：日期時間已經過了就不能存（存了也不會響，還會被誤當成漏響）→ 問要不要改成明天
            $onceAt = $dtpDate.Value.Date.AddHours($dtpTime.Value.Hour).AddMinutes($dtpTime.Value.Minute)
            if ($onceAt -le (Get-Date)) {
                $tomorrow = (Get-Date).Date.AddDays(1)
                $ask = Show-AppMessage("你設的 $($onceAt.ToString('yyyy-MM-dd HH:mm')) 已經過了。`n`n要改成明天（$($tomorrow.ToString('yyyy-MM-dd')) $timeStr）嗎？", "這個時間已經過了", [System.Windows.Forms.MessageBoxButtons]::YesNo)
                if ($ask -ne [System.Windows.Forms.DialogResult]::Yes) { return }
                $dtpDate.Value = $tomorrow
            }
            $dateStr = $dtpDate.Value.ToString("yyyy-MM-dd")
            $script:dialogSaved = [PSCustomObject]@{ type = "once"; label = $txtLabel.Text.Trim(); time = $timeStr; days = @(); date = $dateStr; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes }
        }
        elseif ($idx -eq 5) {
            $months = @()
            for ($i = 0; $i -lt $clbYearMonths.Items.Count; $i++) {
                if ($clbYearMonths.GetItemChecked($i)) { $months += ($i + 1) }
            }
            if ($months.Count -eq 0) {
                Show-AppMessage("請至少勾選一個月份", "$($script:AppName)") | Out-Null
                return
            }
            $yearDays = @()
            foreach ($part in ($txtYearDays.Text -split "[,，、 ]")) {
                $pt = $part.Trim()
                if ($pt -eq "") { continue }
                $dn = 0
                if (-not [int]::TryParse($pt, [ref]$dn) -or $dn -lt 1 -or $dn -gt 31) {
                    Show-AppMessage("「$pt」不是 1~31 的日期喔。請輸入像 1,15 這樣的數字。", "$($script:AppName)") | Out-Null
                    return
                }
                if ($yearDays -notcontains $dn) { $yearDays += $dn }
            }
            if ($yearDays.Count -eq 0) {
                Show-AppMessage("請輸入日期（例如 1,15）", "$($script:AppName)") | Out-Null
                return
            }
            $yearDays = @($yearDays | Sort-Object)
            $script:dialogSaved = [PSCustomObject]@{ type = "yearly"; label = $txtLabel.Text.Trim(); time = $timeStr; days = $yearDays; months = $months; date = ""; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes }
        }
        elseif ($idx -eq 4) {
            $intervalText = $txtInterval.Text.Trim()
            $intervalDays = 0
            if (-not [int]::TryParse($intervalText, [ref]$intervalDays) -or $intervalDays -le 0) {
                Show-AppMessage("請輸入大於0的間隔天數", "提醒") | Out-Null
                return
            }
            $script:dialogSaved = [PSCustomObject]@{ type = "interval"; label = $txtLabel.Text.Trim(); time = $timeStr; days = @(); date = ""; timeLimited = $timeLimited; playSound = $playSound; strict = $strict; notes = $notes; intervalDays = $intervalDays; nextDueDate = (Get-Date).AddDays($intervalDays).ToString("yyyy-MM-dd") }
        }

        $cat = $cmbCategory.Text.Trim()
        if ($cat -eq "") { $cat = $script:DefaultCategory }
        $script:dialogSaved | Add-Member -NotePropertyName category -NotePropertyValue $cat -Force
        $script:dialogSaved | Add-Member -NotePropertyName private -NotePropertyValue ([bool]$script:ownPrivate) -Force
        # 難度：原本是手機的「掃 QR」而這次沒動它 → 維持 qr（QR 密碼也照留）；否則存選的
        $diffKey = "math1"
        if ($cmbDiff.SelectedIndex -ge 0 -and $cmbDiff.SelectedIndex -lt $script:diffKeys.Count) { $diffKey = $script:diffKeys[$cmbDiff.SelectedIndex] }
        if ($script:keepQr -and $diffKey -eq "math3") { $diffKey = "qr" }
        $script:dialogSaved | Add-Member -NotePropertyName difficulty -NotePropertyValue $diffKey -Force
        $impKey = $script:ImportanceKeys[[Math]::Max(0, $cmbImp.SelectedIndex)]
        $script:dialogSaved | Add-Member -NotePropertyName importance -NotePropertyValue $impKey -Force
        if ($impKey -ne "normal") { $script:dialogSaved.strict = $true }
        # 鈴聲、音量、漸強（跟手機同欄位）
        $script:dialogSaved | Add-Member -NotePropertyName ringtone -NotePropertyValue ($script:toneKeys[[Math]::Max(0, $cmbTone.SelectedIndex)]) -Force
        $script:dialogSaved | Add-Member -NotePropertyName volume -NotePropertyValue ([int](Limit-AlarmVolume $trkVol.Value $impKey)) -Force
        $script:dialogSaved | Add-Member -NotePropertyName crescendo -NotePropertyValue ([bool]$chkCresc.Checked) -Force

        $dlg.Tag = "OK"
        $dlg.Close()
    })

    $btnCancel.Add_Click({
        $dlg.Tag = "CANCEL"
        $dlg.Close()
    })

    if ($existing) {
        $txtLabel.Text = $existing.label
        $tparts = $existing.time -split ":"
        $dtpTime.Value = (Get-Date -Hour ([int]$tparts[0]) -Minute ([int]$tparts[1]) -Second 0)
        $chkTimeLimited.Checked = [bool]$existing.timeLimited
        $chkPlaySound.Checked = ($existing.playSound -ne $false)
        if ($null -ne $existing.strict) { $chkStrict.Checked = [bool]$existing.strict }
        else { $chkStrict.Checked = -not [bool]$existing.timeLimited }
        $impIdx = [Array]::IndexOf($script:ImportanceKeys, (Get-AlarmImportance $existing))
        if ($impIdx -ge 0) { $cmbImp.SelectedIndex = $impIdx }
        $txtNotes.Text = "$($existing.notes)"
        $existingDiff = "$($existing.difficulty)"
        if ($existingDiff -eq "qr") { $script:keepQr = $true; $existingDiff = "math3" }
        $di = [Array]::IndexOf($script:diffKeys, $existingDiff)
        if ($di -ge 0) { $cmbDiff.SelectedIndex = $di }
        $cmbDiff.Enabled = $chkStrict.Checked
        $script:volBusy = $true
        $ti = [Array]::IndexOf($script:toneKeys, (Get-ValidAlarmTone "$($existing.ringtone)"))
        if ($ti -ge 0) { $cmbTone.SelectedIndex = $ti }
        $trkVol.Value = Get-AlarmVolume $existing
        $chkCresc.Checked = Get-AlarmCrescendo $existing ([bool]$script:ringSet.crescendo)
        $script:volTouched = $true; $script:crescTouched = $true
        $script:volBusy = $false
        $script:ownPrivate = (Test-AlarmOwnPrivate $existing)
        $cmbCategory.Text = (Get-AlarmCategory $existing)
        Update-PrivateBox

        if ($existing.type -eq "monthly") {
            $cmbType.SelectedIndex = 0
            $txtDays.Text = ($existing.days -join ",")
        }
        elseif ($existing.type -eq "daily") {
            $cmbType.SelectedIndex = 1
        }
        elseif ($existing.type -eq "weekly") {
            $cmbType.SelectedIndex = 2
            foreach ($d in $existing.days) { $clbWeek.SetItemChecked($d - 1, $true) }
        }
        elseif ($existing.type -eq "once") {
            $cmbType.SelectedIndex = 3
            $dtpDate.Value = [DateTime]::ParseExact($existing.date, "yyyy-MM-dd", $null)
        }
        elseif ($existing.type -eq "yearly") {
            $cmbType.SelectedIndex = 5
            # 舊的單一日期（date）和新的多月多日（months + days）都讀得進來
            $rule = Get-YearlyRule $existing
            if ($null -ne $rule) {
                foreach ($m in $rule.Months) { if ($m -ge 1 -and $m -le 12) { $clbYearMonths.SetItemChecked($m - 1, $true) } }
                $txtYearDays.Text = ($rule.Days -join ",")
            }
        }
        elseif ($existing.type -eq "interval") {
            $cmbType.SelectedIndex = 4
            $txtInterval.Text = "$($existing.intervalDays)"
        }
    } else {
        $cmbType.SelectedIndex = 0
    }

    Update-PanelVisibility
    if (-not $existing) { $script:volBusy = $true; $chkCresc.Checked = Get-DefaultCrescendo "normal" ([bool]$script:ringSet.crescendo); $script:volBusy = $false }
    Update-VolumeUi

    # 大字／深色（v1.1）
    Complete-AppForm $dlg
    $dlg.ShowDialog() | Out-Null

    if ($dlg.Tag -eq "OK") { return $script:dialogSaved }
    else { return $null }
}

$script:settings = Read-AppSettings $settingsPath

$form = New-Object System.Windows.Forms.Form
$form.Text = "$($script:AppName) - 我的鬧鐘"
$form.Size = New-Object System.Drawing.Size(800, 560)
$form.StartPosition = "CenterScreen"
Set-AppFormStyle $form

# 排序方式：分類（同分類放一起）/ 下次響的時間 / 名稱
$lblSort = New-Object System.Windows.Forms.Label
$lblSort.Text = "排序："
$lblSort.Location = New-Object System.Drawing.Point(15, 15)
$lblSort.Size = New-Object System.Drawing.Size(45, 22)
$form.Controls.Add($lblSort)

$cmbSort = New-Object System.Windows.Forms.ComboBox
$cmbSort.Location = New-Object System.Drawing.Point(60, 12)
$cmbSort.Size = New-Object System.Drawing.Size(160, 24)
$cmbSort.DropDownStyle = "DropDownList"
$cmbSort.Items.AddRange(@("依分類", "依下次響的時間", "依名稱"))
$script:sortKeys = @("category", "next", "name")
$cmbSort.SelectedIndex = [Math]::Max(0, [Array]::IndexOf($script:sortKeys, $script:settings.sortBy))
$form.Controls.Add($cmbSort)

# 找鬧鐘（工單 8.3）：依名稱搜尋、依分類／即將響篩選
$lblSearch = New-Object System.Windows.Forms.Label
$lblSearch.Text = "搜尋："
$lblSearch.Location = New-Object System.Drawing.Point(15, 47)
$lblSearch.Size = New-Object System.Drawing.Size(45, 22)
$form.Controls.Add($lblSearch)

$txtSearch = New-Object System.Windows.Forms.TextBox
$txtSearch.Location = New-Object System.Drawing.Point(60, 44)
$txtSearch.Size = New-Object System.Drawing.Size(200, 24)
$form.Controls.Add($txtSearch)

$lblFilter = New-Object System.Windows.Forms.Label
$lblFilter.Text = "只看："
$lblFilter.Location = New-Object System.Drawing.Point(280, 47)
$lblFilter.Size = New-Object System.Drawing.Size(45, 22)
$form.Controls.Add($lblFilter)

$cmbFilter = New-Object System.Windows.Forms.ComboBox
$cmbFilter.Location = New-Object System.Drawing.Point(325, 44)
$cmbFilter.Size = New-Object System.Drawing.Size(190, 24)
$cmbFilter.DropDownStyle = "DropDownList"
$form.Controls.Add($cmbFilter)
$script:filterKeys = @("all")
$script:filterBusy = $false

$btnClearFilter = New-Object System.Windows.Forms.Button
$btnClearFilter.Text = "清除"
$btnClearFilter.Location = New-Object System.Drawing.Point(530, 43)
$btnClearFilter.Size = New-Object System.Drawing.Size(70, 26)
$form.Controls.Add($btnClearFilter)

$lblSortHint = New-Object System.Windows.Forms.Label
$lblSortHint.Text = "（雙擊一列可以直接編輯）"
$lblSortHint.Location = New-Object System.Drawing.Point(230, 15)
$lblSortHint.Size = New-Object System.Drawing.Size(180, 22)
$lblSortHint.ForeColor = [System.Drawing.Color]::Gray
$form.Controls.Add($lblSortHint)

# v1.1：字體大小（高齡友善）、外觀（深色對眼睛友善）。選了會記住，設定視窗會自己重新打開套用
$lblFontSize = New-Object System.Windows.Forms.Label
$lblFontSize.Text = "字體："
$lblFontSize.Location = New-Object System.Drawing.Point(415, 15)
$lblFontSize.Size = New-Object System.Drawing.Size(45, 22)
$form.Controls.Add($lblFontSize)

$cmbFontSize = New-Object System.Windows.Forms.ComboBox
$cmbFontSize.Location = New-Object System.Drawing.Point(460, 12)
$cmbFontSize.Size = New-Object System.Drawing.Size(75, 24)
$cmbFontSize.DropDownStyle = "DropDownList"
$cmbFontSize.Items.AddRange(@("標準", "大", "特大"))
$script:fontSizeKeys = @("normal", "large", "xlarge")
$cmbFontSize.SelectedIndex = [Math]::Max(0, [Array]::IndexOf($script:fontSizeKeys, $script:settings.fontSize))
$form.Controls.Add($cmbFontSize)

$chkBold = New-Object System.Windows.Forms.CheckBox
$chkBold.Text = "粗體"
$chkBold.Location = New-Object System.Drawing.Point(540, 12)
$chkBold.Size = New-Object System.Drawing.Size(62, 24)
$chkBold.Checked = [bool]$script:settings.bold
$form.Controls.Add($chkBold)

$lblTheme = New-Object System.Windows.Forms.Label
$lblTheme.Text = "外觀："
$lblTheme.Location = New-Object System.Drawing.Point(606, 15)
$lblTheme.Size = New-Object System.Drawing.Size(45, 22)
$form.Controls.Add($lblTheme)

$cmbTheme = New-Object System.Windows.Forms.ComboBox
$cmbTheme.Location = New-Object System.Drawing.Point(651, 12)
$cmbTheme.Size = New-Object System.Drawing.Size(119, 24)
$cmbTheme.DropDownStyle = "DropDownList"
$cmbTheme.Items.AddRange(@("淺色", "深色（護眼）"))
$script:themeKeys = @("light", "dark")
$cmbTheme.SelectedIndex = [Math]::Max(0, [Array]::IndexOf($script:themeKeys, $script:settings.theme))
$form.Controls.Add($cmbTheme)

# 篩選標籤列（2026-10-05 先生：手機的「即將響」很好用，像行事曆一樣看得到今天有幾個提醒；電腦版以前只藏在「只看」下拉裡）
# 全部｜⏰ 即將響｜各分類，跟手機主畫面一樣；按標籤 = 幫你選「只看」下拉（下拉照留，兩邊一定一致）
$pnlFilterTabs = New-Object System.Windows.Forms.FlowLayoutPanel
$pnlFilterTabs.Location = New-Object System.Drawing.Point(15, 74)
$pnlFilterTabs.Size = New-Object System.Drawing.Size(755, 34)
$pnlFilterTabs.WrapContents = $false
$pnlFilterTabs.AutoScroll = $true
$pnlFilterTabs.Anchor = [System.Windows.Forms.AnchorStyles]"Top, Left, Right"
$form.Controls.Add($pnlFilterTabs)

$listView = New-Object System.Windows.Forms.ListView
$listView.Location = New-Object System.Drawing.Point(15, 110)
$listView.Size = New-Object System.Drawing.Size(755, 197)
$listView.View = [System.Windows.Forms.View]::Details
$listView.FullRowSelect = $true
$listView.GridLines = $true
$listView.HideSelection = $false
$listView.Columns.Add("內容", 150) | Out-Null
$listView.Columns.Add("分類", 70) | Out-Null
$listView.Columns.Add("類型", 150) | Out-Null
$listView.Columns.Add("時間", 50) | Out-Null
$listView.Columns.Add("下次響", 120) | Out-Null
$listView.Columns.Add("限時", 45) | Out-Null
$listView.Columns.Add("聲音", 45) | Out-Null
$listView.Columns.Add("模式", 50) | Out-Null
$form.Controls.Add($listView)

$btnAdd = New-Object System.Windows.Forms.Button
$btnAdd.Text = "新增"
$btnAdd.Location = New-Object System.Drawing.Point(15, 320)
$btnAdd.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnAdd)

$btnEdit = New-Object System.Windows.Forms.Button
$btnEdit.Text = "編輯"
$btnEdit.Location = New-Object System.Drawing.Point(125, 320)
$btnEdit.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnEdit)

$btnDelete = New-Object System.Windows.Forms.Button
$btnDelete.Text = "刪除"
$btnDelete.Location = New-Object System.Drawing.Point(235, 320)
$btnDelete.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnDelete)

$btnClose = New-Object System.Windows.Forms.Button
$btnClose.Text = "關閉"
$btnClose.Location = New-Object System.Drawing.Point(430, 320)
$btnClose.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnClose)

$btnAddCategory = New-Object System.Windows.Forms.Button
$btnAddCategory.Text = "管理分類"
$btnAddCategory.Location = New-Object System.Drawing.Point(560, 320)
$btnAddCategory.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnAddCategory)

$btnAbout = New-Object System.Windows.Forms.Button
$btnAbout.Text = "關於"
$btnAbout.Location = New-Object System.Drawing.Point(670, 320)
$btnAbout.Size = New-Object System.Drawing.Size(100, 35)
$form.Controls.Add($btnAbout)

# 角落的新跪（圖檔不在就不顯示）
$picSettings = New-AppPictureBox "xg_settings.png" 600 362 170 150
$form.Controls.Add($picSettings)

$lblStartupStatus = New-Object System.Windows.Forms.Label
$lblStartupStatus.Location = New-Object System.Drawing.Point(15, 365)
$lblStartupStatus.Size = New-Object System.Drawing.Size(515, 24)
$lblStartupStatus.Font = New-Object System.Drawing.Font($lblStartupStatus.Font, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($lblStartupStatus)

$btnEnableStartup = New-Object System.Windows.Forms.Button
$btnEnableStartup.Text = "設定開機自動啟動"
$btnEnableStartup.Location = New-Object System.Drawing.Point(15, 395)
$btnEnableStartup.Size = New-Object System.Drawing.Size(160, 35)
$form.Controls.Add($btnEnableStartup)

$btnDisableStartup = New-Object System.Windows.Forms.Button
$btnDisableStartup.Text = "取消開機自動啟動"
$btnDisableStartup.Location = New-Object System.Drawing.Point(185, 395)
$btnDisableStartup.Size = New-Object System.Drawing.Size(160, 35)
$form.Controls.Add($btnDisableStartup)

# v1.3：匯出／匯入（換電腦、換手機時把鬧鐘帶走；格式跟 Android 版一樣）
$btnExport = New-Object System.Windows.Forms.Button
$btnExport.Text = "匯出鬧鐘"
$btnExport.Location = New-Object System.Drawing.Point(355, 395)
$btnExport.Size = New-Object System.Drawing.Size(110, 35)
$form.Controls.Add($btnExport)

$btnImport = New-Object System.Windows.Forms.Button
$btnImport.Text = "匯入鬧鐘"
$btnImport.Location = New-Object System.Drawing.Point(475, 395)
$btnImport.Size = New-Object System.Drawing.Size(110, 35)
$form.Controls.Add($btnImport)

$tipExport = New-Object System.Windows.Forms.ToolTip
$tipExport.SetToolTip($btnExport, "把鬧鐘存成一個 .json 檔（可以存到 Google 雲端硬碟，手機再匯入）")
$tipExport.SetToolTip($btnImport, "從匯出的 .json 檔把鬧鐘讀進來（可以選全部取代或合併）")

$startupFolder = [Environment]::GetFolderPath("Startup")
$shortcutPath = Join-Path $startupFolder "真劍鬧鐘.lnk"
# 改名前（桌面鬧鐘）建的開機捷徑：還在的話一樣算「已啟用」，取消時一起刪
$legacyShortcutPath = Join-Path $startupFolder "桌面鬧鐘背景提醒.lnk"

function Update-StartupStatus {
    if ((Test-Path -LiteralPath $shortcutPath) -or (Test-Path -LiteralPath $legacyShortcutPath)) {
        $lblStartupStatus.Text = "開機自動啟動：已啟用"
        $lblStartupStatus.ForeColor = Get-StatusColor "ok"
    } else {
        $lblStartupStatus.Text = "開機自動啟動：未啟用"
        $lblStartupStatus.ForeColor = Get-StatusColor "muted"
    }
}

$btnEnableStartup.Add_Click({
    try {
        $wshShell = New-Object -ComObject WScript.Shell
        $shortcut = $wshShell.CreateShortcut($shortcutPath)
        # 直接叫 powershell.exe 隱藏視窗執行（不用 .vbs，免得被防毒誤判）
        $shortcut.TargetPath = Join-Path $PSHOME "powershell.exe"
        $shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $PSScriptRoot 'Alarm_Tray.ps1')`""
        $shortcut.WorkingDirectory = $PSScriptRoot
        $shortcut.WindowStyle = 7
        $shortcut.IconLocation = Join-Path (Join-Path $PSScriptRoot "assets") "jellyfish.ico"
        $shortcut.Description = "真劍鬧鐘 背景提醒"
        $shortcut.Save()
        # 有了新捷徑，舊的就不用了（不然開機會啟動兩次，雖然第二個會自己結束）
        if (Test-Path -LiteralPath $legacyShortcutPath) { Remove-Item -LiteralPath $legacyShortcutPath -Force -ErrorAction SilentlyContinue }
        Update-StartupStatus
        Show-AppMessage("已設定為開機自動啟動背景提醒。", "$($script:AppName) - 完成") | Out-Null
    } catch {
        Show-AppMessage("設定失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

$btnDisableStartup.Add_Click({
    try {
        if ((Test-Path -LiteralPath $shortcutPath) -or (Test-Path -LiteralPath $legacyShortcutPath)) {
            if (Test-Path -LiteralPath $shortcutPath) { Remove-Item -LiteralPath $shortcutPath -Force }
            if (Test-Path -LiteralPath $legacyShortcutPath) { Remove-Item -LiteralPath $legacyShortcutPath -Force }
            Show-AppMessage("已取消開機自動啟動。", "$($script:AppName) - 完成") | Out-Null
        } else {
            Show-AppMessage("目前並未設定開機自動啟動。", "$($script:AppName)") | Out-Null
        }
        Update-StartupStatus
    } catch {
        Show-AppMessage("取消失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

$lblTrayStatus = New-Object System.Windows.Forms.Label
$lblTrayStatus.Location = New-Object System.Drawing.Point(15, 440)
$lblTrayStatus.Size = New-Object System.Drawing.Size(515, 24)
$lblTrayStatus.Font = New-Object System.Drawing.Font($lblTrayStatus.Font, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($lblTrayStatus)

$btnStartTray = New-Object System.Windows.Forms.Button
$btnStartTray.Text = "啟動背景提醒"
$btnStartTray.Location = New-Object System.Drawing.Point(15, 470)
$btnStartTray.Size = New-Object System.Drawing.Size(160, 35)
$form.Controls.Add($btnStartTray)

$btnStopTray = New-Object System.Windows.Forms.Button
$btnStopTray.Text = "停止背景提醒"
$btnStopTray.Location = New-Object System.Drawing.Point(185, 470)
$btnStopTray.Size = New-Object System.Drawing.Size(160, 35)
$form.Controls.Add($btnStopTray)

# v1.5：用 Google 帳號登入、電腦和手機同步鬧鐘
$btnSync = New-Object System.Windows.Forms.Button
$btnSync.Text = "同步"
$btnSync.Location = New-Object System.Drawing.Point(355, 470)
$btnSync.Size = New-Object System.Drawing.Size(110, 35)
$form.Controls.Add($btnSync)
$tipSync = New-Object System.Windows.Forms.ToolTip
$tipSync.SetToolTip($btnSync, "用 Google 帳號登入，電腦和手機的鬧鐘就會自動保持一樣")

# v1.6：檢查更新（每天第一次打開時背景安靜檢查，有新版這顆會變紅；不跳窗打擾）
$btnUpdate = New-Object System.Windows.Forms.Button
$btnUpdate.Text = "檢查更新"
$btnUpdate.Location = New-Object System.Drawing.Point(475, 470)
$btnUpdate.Size = New-Object System.Drawing.Size(110, 35)
$form.Controls.Add($btnUpdate)
$tipSync.SetToolTip($btnUpdate, "看有沒有新版；有的話按一下就能更新（鬧鐘和設定都會保留）")

# 視窗放大時跟著伸縮(2026-09-30 先生:鬧鐘太多,按放大以為能一次看完,結果只多出空白)
# 列表四邊都黏住 → 放大就多顯示幾列;下面的按鈕與狀態黏在下緣;右邊那排按鈕與新跪黏在右下角
$form.MinimumSize = $form.Size
$AnchorAll = [System.Windows.Forms.AnchorStyles]"Top, Bottom, Left, Right"
$AnchorBL = [System.Windows.Forms.AnchorStyles]"Bottom, Left"
$AnchorBR = [System.Windows.Forms.AnchorStyles]"Bottom, Right"
$listView.Anchor = $AnchorAll
foreach ($c in @($btnAdd, $btnEdit, $btnDelete, $lblStartupStatus, $btnEnableStartup, $btnDisableStartup, $lblTrayStatus, $btnStartTray, $btnStopTray)) { $c.Anchor = $AnchorBL }
foreach ($c in @($btnClose, $btnAddCategory, $btnAbout)) { $c.Anchor = $AnchorBR }
if ($picSettings) { $picSettings.Anchor = $AnchorBR }
foreach ($c in @($btnExport, $btnImport, $btnSync, $btnUpdate)) { $c.Anchor = $AnchorBL }
# 字體、外觀的選單黏在右上角
$AnchorTR = [System.Windows.Forms.AnchorStyles]"Top, Right"
foreach ($c in @($lblFontSize, $cmbFontSize, $chkBold, $lblTheme, $cmbTheme)) { $c.Anchor = $AnchorTR }
# 多出來的寬度依各欄原本寬度的比例分給每一欄（v1.1，先生 21:9 寬螢幕：以前全給「內容」欄，中間很空）
# 「內容」欄用 2 倍權重多拿一點；視窗縮回原大小時各欄回到原寬度。
# 原寬度要等套用大字（Complete-AppForm）之後才記，所以一開始是 $null。
$script:baseColumnWidths = $null
function Update-ContentColumnWidth {
    if ($null -eq $script:baseColumnWidths) { return }
    $widths = Get-DistributedColumnWidths $script:baseColumnWidths ($listView.ClientSize.Width - 4) 2.0
    for ($i = 0; $i -lt $listView.Columns.Count -and $i -lt $widths.Count; $i++) {
        if ($listView.Columns[$i].Width -ne $widths[$i]) { $listView.Columns[$i].Width = $widths[$i] }
    }
}
$listView.Add_Resize({ Update-ContentColumnWidth })

$pidFile = Join-Path $PSScriptRoot "tray.pid"
$trayScript = Join-Path $PSScriptRoot "Alarm_Tray.ps1"

function Test-TrayRunning {
    if (Test-Path $pidFile) {
        $storedPid = (Get-Content $pidFile -Raw).Trim()
        $proc = Get-Process -Id $storedPid -ErrorAction SilentlyContinue
        if ($proc) { return $true }
        else {
            Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
            return $false
        }
    }
    return $false
}

function Update-TrayStatus {
    if (Test-TrayRunning) {
        $lblTrayStatus.Text = "背景提醒：運作中（工作列有常駐圖示）"
        $lblTrayStatus.ForeColor = Get-StatusColor "ok"
    } else {
        $lblTrayStatus.Text = "背景提醒：未運作"
        $lblTrayStatus.ForeColor = Get-StatusColor "muted"
    }
}

$btnStartTray.Add_Click({
    if (Test-TrayRunning) {
        Show-AppMessage("背景提醒已經在運作中了。", "$($script:AppName)") | Out-Null
        return
    }
    try {
        Start-AppScript "Alarm_Tray.ps1"
        Start-Sleep -Milliseconds 800
        Update-TrayStatus
    } catch {
        Show-AppMessage("啟動失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

$btnStopTray.Add_Click({
    if (-not (Test-TrayRunning)) {
        Show-AppMessage("背景提醒目前並未運作。", "$($script:AppName)") | Out-Null
        return
    }
    try {
        $storedPid = (Get-Content $pidFile -Raw).Trim()
        Stop-Process -Id $storedPid -Force -ErrorAction SilentlyContinue
        Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
        Update-TrayStatus
        Show-AppMessage("已停止背景提醒。", "$($script:AppName) - 完成") | Out-Null
    } catch {
        Show-AppMessage("停止失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

# 一律用 @() 包起來：只有一個鬧鐘時才不會變成「不是陣列」而沒辦法編輯
$script:alarms = @(Load-Alarms)

function Get-NextText($a, $now) {
    $n = Get-NextOccurrence $a $now
    if ($null -eq $n) { return "（不會再響）" }
    $w = @("日","一","二","三","四","五","六")[[int]$n.DayOfWeek]
    $text = "$($n.ToString('yyyy-MM-dd'))（$w）"
    if ($n -le $now) { $text = "$text 待完成" }
    return $text
}

# 篩選下拉：全部｜即將響（24 小時內）｜各分類｜未分類（有鬧鐘才列），後面帶數量；記住目前選的
function Update-FilterCombo($now) {
    $cur = "all"
    if ($cmbFilter.SelectedIndex -ge 0 -and $cmbFilter.SelectedIndex -lt $script:filterKeys.Count) { $cur = $script:filterKeys[$cmbFilter.SelectedIndex] }
    $script:filterBusy = $true
    $cmbFilter.Items.Clear()
    $keys = @(); $labels = @()
    $keys += "all"; $labels += "全部（$(@($script:alarms).Count)）"
    $soonN = @($script:alarms | Where-Object { Test-AlarmSoon $_ $now }).Count
    $keys += "soon"; $labels += "即將響（24 小時內，$soonN）"
    foreach ($c in @(Get-AllCategories $script:alarms $script:settings.categories)) {
        $n = @($script:alarms | Where-Object { (Get-AlarmCategory $_) -eq $c }).Count
        if ($c -eq $script:DefaultCategory -and $n -eq 0) { continue }
        $keys += "cat:$c"; $labels += "$c（$n）"
    }
    foreach ($l in $labels) { $cmbFilter.Items.Add($l) | Out-Null }
    $script:filterKeys = $keys
    $i = [Array]::IndexOf($keys, $cur)
    if ($i -lt 0) { $i = 0 }
    $cmbFilter.SelectedIndex = $i
    $script:filterBusy = $false
}

# 篩選標籤列：照「只看」下拉的內容一顆一顆排出來（名稱一樣、數量一樣），目前選的那顆是紅底白字
function Update-FilterTabs {
    $pnlFilterTabs.SuspendLayout()
    foreach ($old in @($pnlFilterTabs.Controls)) { $old.Dispose() }
    $pnlFilterTabs.Controls.Clear()
    $dark = [bool]$script:UiAppearance.Dark
    for ($i = 0; $i -lt $cmbFilter.Items.Count; $i++) {
        $key = $script:filterKeys[$i]
        $text = "$($cmbFilter.Items[$i])"
        if ($key -eq "soon") { $text = "⏰ " + $text.Replace("（24 小時內，", "（") }
        $b = New-Object System.Windows.Forms.Button
        $b.Text = $text
        $b.AutoSize = $true
        $b.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
        $b.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $b.Margin = New-Object System.Windows.Forms.Padding(0, 2, 6, 2)
        $b.Padding = New-Object System.Windows.Forms.Padding(4, 0, 4, 0)
        $b.Tag = $i
        if ($i -eq $cmbFilter.SelectedIndex) {
            $b.BackColor = $(if ($dark) { $script:DarkRed } else { $script:ThemeRed })
            $b.ForeColor = $(if ($dark) { $script:DarkBack } else { [System.Drawing.Color]::White })
            $b.FlatAppearance.BorderColor = $b.BackColor
        } else {
            $b.BackColor = $(if ($dark) { $script:DarkButton } else { $script:ThemePanel })
            $b.ForeColor = $(if ($dark) { $script:DarkText } else { $script:ThemeText })
            $b.FlatAppearance.BorderColor = $(if ($dark) { $script:DarkBorder } else { [System.Drawing.Color]::Silver })
        }
        if ($key -eq "soon") { $tipSync.SetToolTip($b, "接下來 24 小時內會響的鬧鐘，照時間排（像行事曆看今天有幾個提醒）") }
        $b.Add_Click({ param($s, $e) if ($cmbFilter.SelectedIndex -ne [int]$s.Tag) { $cmbFilter.SelectedIndex = [int]$s.Tag } })
        $pnlFilterTabs.Controls.Add($b) | Out-Null
    }
    $pnlFilterTabs.ResumeLayout()
}

function Refresh-List {
    $now = Get-Date
    $sortBy = $script:sortKeys[[Math]::Max(0, $cmbSort.SelectedIndex)]
    Update-FilterCombo $now
    try { Update-FilterTabs } catch {}
    $filterKey = $script:filterKeys[[Math]::Max(0, $cmbFilter.SelectedIndex)]
    $shownAlarms = @(Get-FilteredAlarms $script:alarms $filterKey $txtSearch.Text $now)
    if ($filterKey -eq "soon") { $sortBy = "next" }
    $sorted = @(Get-SortedAlarms $shownAlarms $sortBy $now)
    $showHeaders = ($sortBy -eq "category" -and $filterKey -eq "all")

    $listView.BeginUpdate()
    $listView.Items.Clear()
    $listView.Groups.Clear()
    # 分類標題一律自己畫成「有底色的色塊標籤列」（不能選來編輯），鬧鐘列帶該分類的色條和淡淡的底色（工單 7.1）
    $listView.ShowGroups = $false
    $isDark = [bool]$script:UiAppearance.Dark
    $colors = Update-CategoryColors (Get-AllCategories $script:alarms $script:settings.categories) $script:settings.categoryColors
    # 補上的顏色（新分類、舊資料）存回設定
    if ((ConvertTo-SyncCanonicalJson (ConvertTo-CategoryColorObject $colors)) -ne (ConvertTo-SyncCanonicalJson (ConvertTo-CategoryColorObject $script:settings.categoryColors))) {
        $script:settings.categoryColors = $colors
        try { Write-AppSettings $settingsPath $script:settings } catch {}
    }
    $lastCat = $null
    $boldFont = New-Object System.Drawing.Font($listView.Font, [System.Drawing.FontStyle]::Bold)

    foreach ($a in $sorted) {
        $cat = Get-AlarmCategory $a
        $style = Get-CategoryColorStyle (Get-CategoryColorOf $cat $colors) $isDark
        if ($showHeaders -and $cat -ne $lastCat) {
            $count = @($sorted | Where-Object { (Get-AlarmCategory $_) -eq $cat }).Count
            $header = New-Object System.Windows.Forms.ListViewItem("$cat（$count）")
            $header.Name = "__group__"
            $header.Tag = $null
            $header.Font = $boldFont
            $header.BackColor = [System.Drawing.Color]::FromArgb(255, (($style.chip -shr 16) -band 255), (($style.chip -shr 8) -band 255), ($style.chip -band 255))
            $header.ForeColor = [System.Drawing.Color]::FromArgb(255, (($style.chipText -shr 16) -band 255), (($style.chipText -shr 8) -band 255), ($style.chipText -band 255))
            for ($k = 1; $k -lt $listView.Columns.Count; $k++) { $header.SubItems.Add("") | Out-Null }
            $listView.Items.Add($header) | Out-Null
            $lastCat = $cat
        }
        $isStrict = Test-AlarmStrict $a
        $lockMark = ""
        if (Test-AlarmPrivate $a $script:settings.privateCategories) { $lockMark = "[私密] " }
        $item = New-Object System.Windows.Forms.ListViewItem("$lockMark$($a.label)")
        # 排序後位置會變，用 id 對回鬧鐘（不能再用第幾列）
        $item.Tag = $a.id
        # 色條顏色放在 Name（"c:RRGGBB"），底色是淡淡的分類色調（列表自己畫，見 AlarmUi.ps1 的 Enable-ColorListView）
        $item.Name = "c:" + ("{0:X6}" -f $style.stripe)
        $item.BackColor = [System.Drawing.Color]::FromArgb(255, (($style.tint -shr 16) -band 255), (($style.tint -shr 8) -band 255), ($style.tint -band 255))
        $item.SubItems.Add($cat) | Out-Null
        $item.SubItems.Add((Get-AlarmBaseType $a)) | Out-Null
        $item.SubItems.Add($a.time) | Out-Null
        $item.SubItems.Add((Get-NextText $a $now)) | Out-Null
        $item.SubItems.Add($(if ($a.timeLimited) { "是" } else { "否" })) | Out-Null
        $item.SubItems.Add($(if ($a.playSound -ne $false) { "開" } else { "關" })) | Out-Null
        $item.SubItems.Add($(if ($isStrict) { "認真" } else { "隨意" })) | Out-Null
        $listView.Items.Add($item) | Out-Null
    }
    if ($sorted.Count -eq 0 -and @($script:alarms).Count -gt 0) {
        $msg = if ("$($txtSearch.Text)".Trim() -ne "") { "沒有名稱含「$("$($txtSearch.Text)".Trim())」的鬧鐘（按「清除」看全部）" } elseif ($filterKey -eq "soon") { "接下來 24 小時內沒有鬧鐘要響（按「清除」看全部）" } else { "這一類目前沒有鬧鐘（按「清除」看全部）" }
        $empty = New-Object System.Windows.Forms.ListViewItem($msg)
        $empty.Name = "__group__"
        $empty.Tag = $null
        for ($k = 1; $k -lt $listView.Columns.Count; $k++) { $empty.SubItems.Add("") | Out-Null }
        $listView.Items.Add($empty) | Out-Null
    }
    $listView.EndUpdate()
}

$cmbFilter.Add_SelectedIndexChanged({ if (-not $script:filterBusy) { Refresh-List } })
$txtSearch.Add_TextChanged({ Refresh-List })
$btnClearFilter.Add_Click({
    $txtSearch.Text = ""
    if ($cmbFilter.Items.Count -gt 0) { $script:filterBusy = $true; $cmbFilter.SelectedIndex = 0; $script:filterBusy = $false }
    Refresh-List
})

# 目前選到的鬧鐘在 $script:alarms 裡的位置；沒選回傳 -1
function Get-SelectedAlarmIndex {
    if ($listView.SelectedItems.Count -eq 0) { return -1 }
    $id = $listView.SelectedItems[0].Tag
    for ($i = 0; $i -lt $script:alarms.Count; $i++) {
        if ("$($script:alarms[$i].id)" -eq "$id") { return $i }
    }
    return -1
}

$cmbSort.Add_SelectedIndexChanged({
    try {
        $script:settings.sortBy = $script:sortKeys[[Math]::Max(0, $cmbSort.SelectedIndex)]
        Write-AppSettings $settingsPath $script:settings
    } catch {}
    Refresh-List
})

# 從調色盤選分類顏色：每個顏色一顆色塊按鈕（目前的打勾）。回傳色票編號，取消回傳 $null
function Show-CategoryColorPicker($owner, [string]$catName, [string]$current) {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 「$catName」的顏色"
    $dlg.Size = New-Object System.Drawing.Size(380, 380)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg
    $dark = [bool]$script:UiAppearance.Dark
    $script:pickedColor = $null
    $i = 0
    foreach ($id in $script:CategoryColorIds) {
        $st = Get-CategoryColorStyle $id $dark
        $b = New-Object System.Windows.Forms.Button
        $mark = ""
        if ($id -eq $current) { $mark = "✓ " }
        $b.Text = $mark + $script:CategoryColorNames[$id]
        $b.Tag = $id
        $b.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $b.FlatAppearance.BorderColor = [System.Drawing.Color]::FromArgb(255, (($st.stripe -shr 16) -band 255), (($st.stripe -shr 8) -band 255), ($st.stripe -band 255))
        $b.BackColor = [System.Drawing.Color]::FromArgb(255, (($st.chip -shr 16) -band 255), (($st.chip -shr 8) -band 255), ($st.chip -band 255))
        $b.ForeColor = [System.Drawing.Color]::FromArgb(255, (($st.chipText -shr 16) -band 255), (($st.chipText -shr 8) -band 255), ($st.chipText -band 255))
        $b.Location = New-Object System.Drawing.Point((15 + 175 * ($i % 2)), (15 + 55 * [Math]::Floor($i / 2)))
        $b.Size = New-Object System.Drawing.Size(160, 44)
        $b.Add_Click({ param($s, $e) $script:pickedColor = "$($s.Tag)"; $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK; $dlg.Close() })
        $dlg.Controls.Add($b)
        $i++
    }
    $btnX = New-Object System.Windows.Forms.Button
    $btnX.Text = "取消"
    $btnX.Location = New-Object System.Drawing.Point(255, 300)
    $btnX.Size = New-Object System.Drawing.Size(100, 35)
    $btnX.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($btnX)
    $dlg.CancelButton = $btnX
    Complete-AppForm $dlg
    $null = $dlg.ShowDialog($owner)
    $dlg.Dispose()
    return $script:pickedColor
}

# v1.1：分類管理（新增、改名、刪除）。改名／刪除的邏輯在 AlarmCore.ps1（有測試）
function Show-CategoryManager {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 管理分類"
    $dlg.Size = New-Object System.Drawing.Size(440, 420)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $lblHead = New-Object System.Windows.Forms.Label
    $lblHead.Text = "分類（括號裡是底下有幾個鬧鐘）："
    $lblHead.Location = New-Object System.Drawing.Point(15, 12)
    $lblHead.Size = New-Object System.Drawing.Size(290, 22)
    $dlg.Controls.Add($lblHead)

    $lbCats = New-Object System.Windows.Forms.ListBox
    $lbCats.Location = New-Object System.Drawing.Point(15, 38)
    $lbCats.Size = New-Object System.Drawing.Size(270, 250)
    $lbCats.IntegralHeight = $false
    # 每個分類一個色塊：左側色條＋淡淡的底色（自己畫，淺色、深色都用同一套色值）
    $lbCats.DrawMode = [System.Windows.Forms.DrawMode]::OwnerDrawFixed
    $lbCats.ItemHeight = [int]($lbCats.Font.Height + 10)
    $lbCats.Add_DrawItem({
        param($sender, $e)
        if ($e.Index -lt 0) { return }
        $dark = [bool]$script:UiAppearance.Dark
        $name = $script:catNames[$e.Index]
        $style = Get-CategoryColorStyle (Get-CategoryColorOf $name $script:settings.categoryColors) $dark
        $sel = (($e.State -band [System.Windows.Forms.DrawItemState]::Selected) -ne 0)
        $back = [System.Drawing.Color]::FromArgb(255, (($style.tint -shr 16) -band 255), (($style.tint -shr 8) -band 255), ($style.tint -band 255))
        $fore = [System.Drawing.SystemColors]::WindowText
        if ($dark) { $fore = [System.Drawing.Color]::FromArgb(0xDA, 0xD6, 0xCE) }
        if ($sel) { $back = [System.Drawing.Color]::FromArgb(255, (($style.chip -shr 16) -band 255), (($style.chip -shr 8) -band 255), ($style.chip -band 255)); $fore = [System.Drawing.Color]::FromArgb(255, (($style.chipText -shr 16) -band 255), (($style.chipText -shr 8) -band 255), ($style.chipText -band 255)) }
        $br = New-Object System.Drawing.SolidBrush($back)
        $e.Graphics.FillRectangle($br, $e.Bounds)
        $br.Dispose()
        $sb = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, (($style.stripe -shr 16) -band 255), (($style.stripe -shr 8) -band 255), ($style.stripe -band 255)))
        $e.Graphics.FillRectangle($sb, $e.Bounds.X, $e.Bounds.Y, 6, $e.Bounds.Height)
        $sb.Dispose()
        $r = New-Object System.Drawing.Rectangle(($e.Bounds.X + 12), $e.Bounds.Y, ($e.Bounds.Width - 14), $e.Bounds.Height)
        $flags = [System.Windows.Forms.TextFormatFlags]"Left, VerticalCenter, SingleLine, EndEllipsis, NoPrefix"
        [System.Windows.Forms.TextRenderer]::DrawText($e.Graphics, "$($sender.Items[$e.Index])", $e.Font, $r, $fore, $flags)
    })
    $dlg.Controls.Add($lbCats)

    $btnCatAdd = New-Object System.Windows.Forms.Button
    $btnCatAdd.Text = "新增"
    $btnCatAdd.Location = New-Object System.Drawing.Point(300, 38)
    $btnCatAdd.Size = New-Object System.Drawing.Size(110, 35)
    $dlg.Controls.Add($btnCatAdd)

    $btnCatRename = New-Object System.Windows.Forms.Button
    $btnCatRename.Text = "改名"
    $btnCatRename.Location = New-Object System.Drawing.Point(300, 83)
    $btnCatRename.Size = New-Object System.Drawing.Size(110, 35)
    $dlg.Controls.Add($btnCatRename)

    $btnCatDelete = New-Object System.Windows.Forms.Button
    $btnCatDelete.Text = "刪除"
    $btnCatDelete.Location = New-Object System.Drawing.Point(300, 128)
    $btnCatDelete.Size = New-Object System.Drawing.Size(110, 35)
    $dlg.Controls.Add($btnCatDelete)

    $btnCatColor = New-Object System.Windows.Forms.Button
    $btnCatColor.Text = "改顏色"
    $btnCatColor.Location = New-Object System.Drawing.Point(300, 173)
    $btnCatColor.Size = New-Object System.Drawing.Size(110, 35)
    $dlg.Controls.Add($btnCatColor)

    $btnCatPrivate = New-Object System.Windows.Forms.Button
    $btnCatPrivate.Text = "設成私密"
    $btnCatPrivate.Location = New-Object System.Drawing.Point(300, 213)
    $btnCatPrivate.Size = New-Object System.Drawing.Size(110, 35)
    $dlg.Controls.Add($btnCatPrivate)

    $btnCatClose = New-Object System.Windows.Forms.Button
    $btnCatClose.Text = "關閉"
    $btnCatClose.Location = New-Object System.Drawing.Point(300, 253)
    $btnCatClose.Size = New-Object System.Drawing.Size(110, 35)
    $btnCatClose.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $dlg.Controls.Add($btnCatClose)
    $dlg.CancelButton = $btnCatClose

    $lblCatHint = New-Object System.Windows.Forms.Label
    $lblCatHint.Text = "・改名：用到這個分類的鬧鐘會一起改名`n・改顏色：主畫面的分類標題和鬧鐘都會用這個顏色`n・刪除：鬧鐘不會被刪，會變成「未分類」`n・「未分類」固定灰色，不能改名或刪除"
    $lblCatHint.Location = New-Object System.Drawing.Point(15, 296)
    $lblCatHint.Size = New-Object System.Drawing.Size(400, 74)
    $lblCatHint.ForeColor = [System.Drawing.Color]::Gray
    $dlg.Controls.Add($lblCatHint)

    # 清單裡每一列對應的分類名稱
    $script:catNames = @()
    function Refresh-CategoryList([string]$select) {
        $script:alarms = @(Load-Alarms)
        $counts = @(Get-CategoryCounts $script:alarms $script:settings.categories)
        $script:settings.categoryColors = Update-CategoryColors (@($counts | ForEach-Object { $_.Name })) $script:settings.categoryColors
        try { Write-AppSettings $settingsPath $script:settings } catch {}
        $lbCats.Items.Clear()
        $script:catNames = @()
        foreach ($c in $counts) {
            $lock = ""
            if (@($script:settings.privateCategories) -contains $c.Name) { $lock = "　[私密]" }
            $lbCats.Items.Add("$($c.Name)（$($c.Count)）$lock") | Out-Null
            $script:catNames += $c.Name
        }
        $i = [Array]::IndexOf($script:catNames, $select)
        if ($i -ge 0) { $lbCats.SelectedIndex = $i } elseif ($lbCats.Items.Count -gt 0) { $lbCats.SelectedIndex = 0 }
    }

    function Get-SelectedCategoryName {
        if ($lbCats.SelectedIndex -lt 0) { return $null }
        return $script:catNames[$lbCats.SelectedIndex]
    }

    $btnCatAdd.Add_Click({
        $name = Show-TextInputDialog $dlg "$($script:AppName) - 新增分類" "新分類的名字（例如 工作、家裡、孩子）：" ""
        if ($null -eq $name) { return }
        $name = "$name".Trim()
        if ($name -eq "" -or $name -eq $script:DefaultCategory) { return }
        $cats = @($script:settings.categories)
        if ($cats -notcontains $name) {
            $script:settings.categories = $cats + $name
            try { Write-AppSettings $settingsPath $script:settings } catch {}
        }
        Refresh-CategoryList $name
    })

    $btnCatRename.Add_Click({
        $old = Get-SelectedCategoryName
        if ($null -eq $old) { return }
        if ($old -eq $script:DefaultCategory) {
            Show-AppMessage("「$($script:DefaultCategory)」不能改名。", "$($script:AppName)") | Out-Null
            return
        }
        $new = Show-TextInputDialog $dlg "$($script:AppName) - 分類改名" "把「$old」改成：" $old
        if ($null -eq $new) { return }
        $new = "$new".Trim()
        if ($new -eq $old) { return }
        if ($script:catNames -contains $new -and $new -ne $script:DefaultCategory) {
            $merge = Show-AppMessage("「$new」已經有了。要把「$old」底下的鬧鐘全部併到「$new」嗎？", "$($script:AppName) - 合併分類", [System.Windows.Forms.MessageBoxButtons]::YesNo)
            if ($merge -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        }
        # 先重讀檔案再改，免得蓋掉背景提醒剛寫進去的紀錄
        $fresh = @(Load-Alarms)
        $r = Rename-AlarmCategory $fresh $script:settings.categories $old $new
        if (-not $r.Ok) {
            Show-AppMessage($r.Error, "$($script:AppName)") | Out-Null
            return
        }
        if ($r.Changed -gt 0) { Save-Alarms $fresh }
        $script:settings.categories = $r.Categories
        $script:settings.categoryColors = Rename-CategoryColor $script:settings.categoryColors $old $new
        $script:settings.privateCategories = @(Rename-PrivateCategory $script:settings.privateCategories $old $new)
        try { Write-AppSettings $settingsPath $script:settings } catch {}
        Refresh-CategoryList $new
    })

    $btnCatDelete.Add_Click({
        $name = Get-SelectedCategoryName
        if ($null -eq $name) { return }
        if ($name -eq $script:DefaultCategory) {
            Show-AppMessage("「$($script:DefaultCategory)」不能刪除。", "$($script:AppName)") | Out-Null
            return
        }
        $fresh = @(Load-Alarms)
        $n = @($fresh | Where-Object { (Get-AlarmCategory $_) -eq $name }).Count
        $msg = "確定要刪除分類「$name」嗎？"
        if ($n -gt 0) { $msg = "$msg`n`n底下有 $n 個鬧鐘會變成「$($script:DefaultCategory)」（鬧鐘本身不會被刪）。" }
        else { $msg = "$msg`n`n底下沒有鬧鐘。" }
        $ok = Show-AppMessage($msg, "$($script:AppName) - 刪除分類", [System.Windows.Forms.MessageBoxButtons]::YesNo)
        if ($ok -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        $r = Remove-AlarmCategory $fresh $script:settings.categories $name
        if (-not $r.Ok) {
            Show-AppMessage($r.Error, "$($script:AppName)") | Out-Null
            return
        }
        if ($r.Changed -gt 0) { Save-Alarms $fresh }
        $script:settings.categories = $r.Categories
        $script:settings.categoryColors = Remove-CategoryColor $script:settings.categoryColors $name
        $script:settings.privateCategories = @(Remove-PrivateCategory $script:settings.privateCategories $name)
        try { Write-AppSettings $settingsPath $script:settings } catch {}
        Refresh-CategoryList $script:DefaultCategory
    })

    # 私密分類：底下所有鬧鐘都視為私密（開車不念內容、手機鎖定畫面不顯示內容）
    $btnCatPrivate.Add_Click({
        $name = Get-SelectedCategoryName
        if ($null -eq $name) { return }
        if ($name -eq $script:DefaultCategory) {
            Show-AppMessage("「$($script:DefaultCategory)」不能設成私密分類。要私密的話，請在鬧鐘本身勾「私密」。", "$($script:AppName)") | Out-Null
            return
        }
        if (@($script:settings.privateCategories) -contains $name) { $script:settings.privateCategories = @(Remove-PrivateCategory $script:settings.privateCategories $name) }
        else { $script:settings.privateCategories = @(Get-CleanPrivateCategories (@($script:settings.privateCategories) + $name)) }
        try { Write-AppSettings $settingsPath $script:settings } catch {}
        Refresh-CategoryList $name
    })

    $lbCats.Add_SelectedIndexChanged({
        $n = Get-SelectedCategoryName
        if ($null -ne $n -and @($script:settings.privateCategories) -contains $n) { $btnCatPrivate.Text = "取消私密" } else { $btnCatPrivate.Text = "設成私密" }
    })

    $btnCatColor.Add_Click({
        $name = Get-SelectedCategoryName
        if ($null -eq $name) { return }
        if ($name -eq $script:DefaultCategory) {
            Show-AppMessage("「$($script:DefaultCategory)」固定是灰色，不能改顏色。", "$($script:AppName)") | Out-Null
            return
        }
        $cur = Get-CategoryColorOf $name $script:settings.categoryColors
        $pick = Show-CategoryColorPicker $dlg $name $cur
        if ($null -eq $pick -or $pick -eq $cur) { return }
        $script:settings.categoryColors[$name] = $pick
        try { Write-AppSettings $settingsPath $script:settings } catch {}
        $lbCats.Invalidate()
    })

    $lbCats.Add_DoubleClick({ $btnCatRename.PerformClick() })

    Refresh-CategoryList $null
    Complete-AppForm $dlg
    $dlg.ShowDialog($form) | Out-Null
    $dlg.Dispose()
}

$btnAddCategory.Add_Click({
    Show-CategoryManager
    $script:alarms = @(Load-Alarms)
    Refresh-List
})

# 換字體大小／外觀：存起來，設定視窗重新打開一次套用（提醒視窗下次跳出來就會用新的設定）
function Save-AppearanceAndReopen {
    $newFont = $script:fontSizeKeys[[Math]::Max(0, $cmbFontSize.SelectedIndex)]
    $newTheme = $script:themeKeys[[Math]::Max(0, $cmbTheme.SelectedIndex)]
    $newBold = [bool]$chkBold.Checked
    if ($newFont -eq $script:settings.fontSize -and $newTheme -eq $script:settings.theme -and $newBold -eq [bool]$script:settings.bold) { return }
    $script:settings.fontSize = $newFont
    $script:settings.bold = $newBold
    $script:settings.theme = $newTheme
    try { Write-AppSettings $settingsPath $script:settings } catch {}
    try {
        Start-AppScript "Alarm_Manager_GUI.ps1"
        $form.Close()
    } catch {
        Show-AppMessage("已經記住了，下次打開設定視窗就會套用。", "$($script:AppName)") | Out-Null
    }
}
$cmbFontSize.Add_SelectionChangeCommitted({ Save-AppearanceAndReopen })
$cmbTheme.Add_SelectionChangeCommitted({ Save-AppearanceAndReopen })
$chkBold.Add_Click({ Save-AppearanceAndReopen })

$btnAbout.Add_Click({ Show-AboutDialog $form })

$listView.Add_DoubleClick({ $btnEdit.PerformClick() })

$btnAdd.Add_Click({
    $result = Show-AlarmDialog $null
    if ($result) {
        # 先重讀一次檔案，免得蓋掉背景提醒剛寫進去的「已完成」紀錄
        $script:alarms = @(Load-Alarms)
        $newId = 1
        if ($script:alarms.Count -gt 0) { $newId = ($script:alarms | Measure-Object -Property id -Maximum).Maximum + 1 }
        $result | Add-Member -NotePropertyName id -NotePropertyValue $newId -Force
        $result | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @() -Force
        $result | Add-Member -NotePropertyName createdDate -NotePropertyValue ((Get-Date).ToString("yyyy-MM-dd")) -Force
        Set-AlarmArmed $result (Get-Date)      # 從建立這一刻起算生效
        $script:alarms = @($script:alarms) + $result
        Save-Alarms $script:alarms
        Refresh-List
    }
})

$btnEdit.Add_Click({
    if ($listView.SelectedIndices.Count -eq 0) {
        Show-AppMessage("請先選擇一個鬧鐘", "$($script:AppName)") | Out-Null
        return
    }
    $idx = Get-SelectedAlarmIndex
    if ($idx -lt 0) {
        Show-AppMessage("請先選擇一個鬧鐘（分類標題那一列不能編輯）", "$($script:AppName)") | Out-Null
        return
    }
    $existing = $script:alarms[$idx]
    $result = Show-AlarmDialog $existing
    if ($result) {
        # 先重讀一次檔案，免得蓋掉背景提醒剛寫進去的「已完成」紀錄
        $editId = $existing.id
        $script:alarms = @(Load-Alarms)
        $idx = -1
        for ($i = 0; $i -lt $script:alarms.Count; $i++) { if ("$($script:alarms[$i].id)" -eq "$editId") { $idx = $i } }
        if ($idx -lt 0) {
            Show-AppMessage("這個鬧鐘好像已經被刪掉了，沒有存。", "$($script:AppName)") | Out-Null
            Refresh-List
            return
        }
        $existing = $script:alarms[$idx]
        $todayKey = (Get-Date).ToString("yyyy-MM-dd")
        # 工單 8.16：只有改了時間／類型／日期才拿掉今天的「已完成」（改到之後的時間今天還能響）；
        # 只改名稱、聲音、重要程度…時保留，不然今天已經過去的那次會被當成「時間到」又響一次
        $preservedDates = @(Get-PreservedTriggeredDates $existing $result $todayKey)
        $result | Add-Member -NotePropertyName id -NotePropertyValue $existing.id -Force
        $result | Add-Member -NotePropertyName triggeredDates -NotePropertyValue $preservedDates -Force
        if ($null -ne $existing.createdDate -and $existing.createdDate -ne "") {
            $result | Add-Member -NotePropertyName createdDate -NotePropertyValue $existing.createdDate -Force
        }
        if ($existing.type -eq "interval" -and $result.type -eq "interval" -and $null -ne $existing.nextDueDate -and $existing.nextDueDate -ne "") {
            $result | Add-Member -NotePropertyName nextDueDate -NotePropertyValue $existing.nextDueDate -Force
        }
        # 改了時間／類型／日期：從現在起算生效，不補已經過的時刻（沒改排程就沿用原本的生效時間）
        if (-not (Test-SameSchedule $existing $result)) { Set-AlarmArmed $result (Get-Date) }
        # 舊鬧鐘有、這次沒填到的欄位照留（例如別的版本加的欄位），不讓資料在編輯時掉了
        $result = Copy-MissingAlarmFields $existing $result
        $script:alarms[$idx] = $result
        Save-Alarms $script:alarms
        Refresh-List
    }
})

$btnDelete.Add_Click({
    if ($listView.SelectedIndices.Count -eq 0) {
        Show-AppMessage("請先選擇一個鬧鐘", "$($script:AppName)") | Out-Null
        return
    }
    $idx = Get-SelectedAlarmIndex
    if ($idx -lt 0) {
        Show-AppMessage("請先選擇一個鬧鐘（分類標題那一列不能編輯）", "$($script:AppName)") | Out-Null
        return
    }
    $confirm = Show-AppMessage("確定要刪除「$($script:alarms[$idx].label)」這個鬧鐘嗎？", "$($script:AppName) - 確認刪除", [System.Windows.Forms.MessageBoxButtons]::YesNo)
    if ($confirm -eq [System.Windows.Forms.DialogResult]::Yes) {
        $targetId = $script:alarms[$idx].id
        # 先重讀一次檔案，免得蓋掉背景提醒剛寫進去的「已完成」紀錄
        $script:alarms = @(Load-Alarms)
        $script:alarms = @($script:alarms | Where-Object { $_.id -ne $targetId })
        Save-Alarms $script:alarms
        Refresh-List
    }
})

# ---------- v1.3 匯出／匯入 ----------

# 問要「全部取代」還是「合併」：回傳 "replace" / "merge"，按取消回傳 $null
function Show-ImportModeDialog($owner, [int]$count, [string]$exportedAt) {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 匯入鬧鐘"
    $dlg.Size = New-Object System.Drawing.Size(500, 300)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $when = ""
    if ("$exportedAt" -ne "") { $when = "（匯出時間：$exportedAt）" }
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = "這個檔案裡有 $count 個鬧鐘$when。要怎麼匯入？`n`n" +
        "・全部取代：目前的鬧鐘換成檔案裡的。換之前會自動備份目前的鬧鐘（alarms_匯入前備份_時間.json，跟 alarms.json 放在一起）。`n`n" +
        "・合併：目前的鬧鐘都留著，只把檔案裡「這邊還沒有的」加進來；同一個鬧鐘不會重複加。"
    $lbl.Location = New-Object System.Drawing.Point(15, 12)
    $lbl.Size = New-Object System.Drawing.Size(455, 170)
    $dlg.Controls.Add($lbl)

    $btnReplace = New-Object System.Windows.Forms.Button
    $btnReplace.Text = "全部取代"
    $btnReplace.Location = New-Object System.Drawing.Point(15, 200)
    $btnReplace.Size = New-Object System.Drawing.Size(140, 38)
    $btnReplace.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    $dlg.Controls.Add($btnReplace)

    $btnMerge = New-Object System.Windows.Forms.Button
    $btnMerge.Text = "合併"
    $btnMerge.Location = New-Object System.Drawing.Point(170, 200)
    $btnMerge.Size = New-Object System.Drawing.Size(140, 38)
    $btnMerge.DialogResult = [System.Windows.Forms.DialogResult]::No
    $dlg.Controls.Add($btnMerge)

    $btnCancelImport = New-Object System.Windows.Forms.Button
    $btnCancelImport.Text = "取消"
    $btnCancelImport.Location = New-Object System.Drawing.Point(330, 200)
    $btnCancelImport.Size = New-Object System.Drawing.Size(140, 38)
    $btnCancelImport.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($btnCancelImport)
    $dlg.CancelButton = $btnCancelImport
    $dlg.AcceptButton = $btnMerge

    Complete-AppForm $dlg
    $r = $dlg.ShowDialog($owner)
    $dlg.Dispose()
    if ($r -eq [System.Windows.Forms.DialogResult]::Yes) { return "replace" }
    if ($r -eq [System.Windows.Forms.DialogResult]::No) { return "merge" }
    return $null
}

$btnExport.Add_Click({
    try {
        # 先重讀一次檔案，匯出的才是最新的
        $fresh = @(Load-Alarms)
        $gdrive = Find-GoogleDriveFolder $null
        $dlgSave = New-Object System.Windows.Forms.SaveFileDialog
        $dlgSave.Filter = "真劍鬧鐘匯出檔 (*.json)|*.json|所有檔案 (*.*)|*.*"
        $dlgSave.DefaultExt = "json"
        $dlgSave.AddExtension = $true
        $dlgSave.OverwritePrompt = $true
        $dlgSave.FileName = Get-ExportFileName (Get-Date)
        if ($gdrive) {
            $dlgSave.InitialDirectory = $gdrive
            $dlgSave.Title = "匯出鬧鐘 —— 存在這裡（$gdrive）會自動上傳到 Google 雲端硬碟"
        } else {
            $dlgSave.InitialDirectory = [Environment]::GetFolderPath("Desktop")
            $dlgSave.Title = "匯出鬧鐘 —— 選一個地方存"
        }
        if ($dlgSave.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { $dlgSave.Dispose(); return }
        $path = $dlgSave.FileName
        $dlgSave.Dispose()
        $exp = Export-AlarmFile $path $fresh $script:settings.categories (Get-Date) $script:settings.categoryColors $script:settings.privateCategories
        $msg = "已匯出 $(@($exp.alarms).Count) 個鬧鐘到：`n$path"
        if ($gdrive -and $path.StartsWith($gdrive, [System.StringComparison]::OrdinalIgnoreCase)) {
            $msg = "$msg`n`n這個資料夾在 Google 雲端硬碟裡，會自動上傳。`n手機上打開真劍鬧鐘 →「匯入」→ 在檔案選擇器選「雲端硬碟」就找得到。"
        } else {
            $msg = "$msg`n`n要帶到手機：把這個檔案傳到手機（例如上傳到 Google 雲端硬碟），再從手機的真劍鬧鐘按「匯入」。"
        }
        $msg = "$msg`n`n（已完成紀錄、「真的沒空」的延後不會匯出，只匯出鬧鐘本身。）"
        Show-AppMessage($msg, "$($script:AppName) - 匯出完成") | Out-Null
    } catch {
        Show-AppMessage("匯出失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

$btnImport.Add_Click({
    try {
        $gdrive = Find-GoogleDriveFolder $null
        $dlgOpen = New-Object System.Windows.Forms.OpenFileDialog
        $dlgOpen.Filter = "真劍鬧鐘匯出檔 (*.json)|*.json|所有檔案 (*.*)|*.*"
        $dlgOpen.Title = "匯入鬧鐘 —— 選匯出的 .json 檔"
        if ($gdrive) { $dlgOpen.InitialDirectory = $gdrive } else { $dlgOpen.InitialDirectory = [Environment]::GetFolderPath("Desktop") }
        if ($dlgOpen.ShowDialog($form) -ne [System.Windows.Forms.DialogResult]::OK) { $dlgOpen.Dispose(); return }
        $path = $dlgOpen.FileName
        $dlgOpen.Dispose()

        $r = Read-AlarmExport $path
        if (-not $r.Ok) {
            Show-AppMessage($r.Error, "$($script:AppName) - 沒有匯入") | Out-Null
            return
        }
        $mode = Show-ImportModeDialog $form (@($r.Alarms).Count) $r.ExportedAt
        if ($null -eq $mode) { return }

        $now = Get-Date
        if ($mode -eq "replace") {
            $bk = Backup-AlarmFileBeforeImport $jsonPath $now
            $newAlarms = @(Get-ReplacedAlarms $r.Alarms $now)
            Save-Alarms $newAlarms
            $script:settings.categories = @(Merge-CategoryLists $r.Categories @())
            $script:settings.categoryColors = $r.Colors            # 全部取代：顏色也換成檔案裡的（沒帶顏色的之後自動補）
            $script:settings.privateCategories = @($r.PrivateCats)  # 私密分類也換成檔案裡的
            try { Write-AppSettings $settingsPath $script:settings } catch {}
            $msg = "已全部取代成檔案裡的 $($newAlarms.Count) 個鬧鐘。"
            if ($bk) { $msg = "$msg`n`n原本的鬧鐘備份在：`n$bk" }
        } else {
            # 先重讀一次檔案，免得蓋掉背景提醒剛寫進去的「已完成」紀錄
            $fresh = @(Load-Alarms)
            $m = Merge-ImportedAlarms $fresh $r.Alarms $now
            Save-Alarms @($m.Alarms)
            $script:settings.categories = @(Merge-CategoryLists $script:settings.categories $r.Categories)
            foreach ($k in @($r.Colors.Keys)) { if (-not $script:settings.categoryColors.ContainsKey($k)) { $script:settings.categoryColors[$k] = $r.Colors[$k] } }   # 合併：本機已經有顏色的分類不動
            $script:settings.privateCategories = @(Get-CleanPrivateCategories (@($script:settings.privateCategories) + @($r.PrivateCats)))   # 合併：私密只增不減（隱私優先）
            try { Write-AppSettings $settingsPath $script:settings } catch {}
            $msg = "合併完成：新增 $($m.Added) 個鬧鐘"
            if ($m.Renumbered -gt 0) { $msg = "$msg（其中 $($m.Renumbered) 個跟這邊的編號撞到、內容不同，當成新鬧鐘加入）" }
            $msg = "$msg；$($m.Skipped) 個這邊本來就有，沒有重複加。"
        }
        $msg = "$msg`n`n已經過去的提醒不會一次全部跳出來，從下一次開始照常響。"
        $script:alarms = @(Load-Alarms)
        Refresh-List
        Show-AppMessage($msg, "$($script:AppName) - 匯入完成") | Out-Null
    } catch {
        Show-AppMessage("匯入失敗：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null
    }
})

# ---------- v1.5 Google 帳號同步 ----------
# 同步本身的邏輯在 AlarmSync.ps1（有測試）；這裡只有視窗。背景提醒程式（Alarm_Tray.ps1）每 15 分鐘會自己同步一次。
$script:syncCancel = $false

function Update-AfterSync($res) {
    if ($res.Changed) {
        $script:alarms = @(Load-Alarms)
        $script:settings = Read-AppSettings $settingsPath
        Refresh-List
    }
}

function Show-SyncDialog($owner) {
    $ctx = Get-SyncContext $PSScriptRoot
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 同步"
    $dlg.Size = New-Object System.Drawing.Size(520, 420)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $lblInfo = New-Object System.Windows.Forms.Label
    $lblInfo.Text = "用你自己的 Google 帳號登入後，電腦和手機的鬧鐘會自動保持一樣：新增、修改、刪除，連「已完成」「真的沒空」也一起同步（手機按了已完成，電腦就不會再催）。`n`n" +
        "資料只放在你自己 Google 雲端硬碟裡、這個 App 專用的隱藏資料夾，作者和別人都看不到。Google 的授權畫面只會問「存取這個 App 自己的資料」這一項。`n`n" +
        "沒登入的話，真劍鬧鐘照常運作，只是不同步。"
    $lblInfo.Location = New-Object System.Drawing.Point(15, 12)
    $lblInfo.Size = New-Object System.Drawing.Size(470, 170)
    $dlg.Controls.Add($lblInfo)

    $lblStatus = New-Object System.Windows.Forms.Label
    $lblStatus.Location = New-Object System.Drawing.Point(15, 190)
    $lblStatus.Size = New-Object System.Drawing.Size(470, 100)
    $lblStatus.Font = New-Object System.Drawing.Font($lblStatus.Font, [System.Drawing.FontStyle]::Bold)
    $dlg.Controls.Add($lblStatus)

    $btnLogin = New-Object System.Windows.Forms.Button
    $btnLogin.Text = "用 Google 帳號登入"
    $btnLogin.Location = New-Object System.Drawing.Point(15, 300)
    $btnLogin.Size = New-Object System.Drawing.Size(200, 38)
    $dlg.Controls.Add($btnLogin)

    $btnNow = New-Object System.Windows.Forms.Button
    $btnNow.Text = "立即同步"
    $btnNow.Location = New-Object System.Drawing.Point(15, 300)
    $btnNow.Size = New-Object System.Drawing.Size(140, 38)
    $dlg.Controls.Add($btnNow)

    $btnLogout = New-Object System.Windows.Forms.Button
    $btnLogout.Text = "登出"
    $btnLogout.Location = New-Object System.Drawing.Point(165, 300)
    $btnLogout.Size = New-Object System.Drawing.Size(120, 38)
    $dlg.Controls.Add($btnLogout)

    $btnCloseSync = New-Object System.Windows.Forms.Button
    $btnCloseSync.Text = "關閉"
    $btnCloseSync.Location = New-Object System.Drawing.Point(385, 300)
    $btnCloseSync.Size = New-Object System.Drawing.Size(100, 38)
    $btnCloseSync.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($btnCloseSync)
    $dlg.CancelButton = $btnCloseSync

    $refresh = {
        $signed = Test-GoogleSignedIn $ctx.TokenPath
        $lblStatus.Text = (@(Get-SyncStatusLines $ctx.StatePath $ctx.TokenPath) -join "`n")
        $btnLogin.Visible = (-not $signed)
        $btnNow.Visible = $signed
        $btnLogout.Visible = $signed
    }

    $syncNow = {
        $btnNow.Enabled = $false; $btnLogout.Enabled = $false
        $lblStatus.Text = "同步中…"
        [System.Windows.Forms.Application]::DoEvents()
        $res = Invoke-SyncRunWithRetry $ctx
        Update-AfterSync $res
        & $refresh
        $btnNow.Enabled = $true; $btnLogout.Enabled = $true
        if (-not $res.Ok) { Show-AppMessage($res.Error, "$($script:AppName) - 同步沒有成功") | Out-Null }
        return $res
    }

    $btnLogin.Add_Click({
        if ($btnLogin.Text -eq "取消登入") { $script:syncCancel = $true; return }
        $script:syncCancel = $false
        $btnLogin.Text = "取消登入"
        $lblStatus.Text = "已經用瀏覽器打開 Google 的登入畫面。請在那裡選帳號、按「允許」。`n登入完成後回到這裡。"
        try {
            Invoke-GoogleLogin $ctx.ClientPath $ctx.TokenPath $null { [System.Windows.Forms.Application]::DoEvents() } { $script:syncCancel } 180
            $btnLogin.Text = "用 Google 帳號登入"
            & $refresh
            $dlg.Activate()
            & $syncNow | Out-Null
        } catch {
            $info = Get-SyncErrorInfo $_
            $btnLogin.Text = "用 Google 帳號登入"
            & $refresh
            $dlg.Activate()
            if ($info.Text -ne "已取消登入。") { Show-AppMessage($info.Text, "$($script:AppName) - 登入沒有成功") | Out-Null }
        }
    })
    $btnNow.Add_Click({ & $syncNow | Out-Null })
    $btnLogout.Add_Click({
        $ans = Show-AppMessage("登出之後，這台電腦就不再同步。雲端上的資料和這台電腦上的鬧鐘都不會被刪掉。`n`n要登出嗎？", "$($script:AppName) - 登出", [System.Windows.Forms.MessageBoxButtons]::YesNo)
        if ($ans -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        Invoke-GoogleLogout $ctx.TokenPath
        Clear-SyncState $ctx.StatePath
        & $refresh
    })

    & $refresh
    Complete-AppForm $dlg
    if ($null -ne $owner) { $dlg.ShowDialog($owner) | Out-Null } else { $dlg.ShowDialog() | Out-Null }
    $script:syncCancel = $true
    $dlg.Dispose()
}

$btnSync.Add_Click({
    try { Show-SyncDialog $form } catch { Show-AppMessage("同步視窗發生錯誤：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null }
})

# ---------- v1.6 一鍵更新 ----------
# 更新的邏輯在 AlarmUpdate.ps1（有測試）；這裡只有視窗。流程：檢查 → 顯示說明 → 按「更新」→ 下載 → 核對指紋 → 關掉程式 → 換檔 → 自動重開。
$script:updateStatePath = Join-Path $PSScriptRoot "update_state.json"
$script:updateDotColor = $null

function Update-UpdateButton {
    $a = $null
    try { $a = Get-UpdateAvailableFromState $script:updateStatePath $script:AppVersion } catch {}
    if ($null -ne $a) {
        $btnUpdate.Text = "● 有新版"
        if ($null -eq $script:updateDotColor) { $script:updateDotColor = Get-StatusColor "bad" }
        $btnUpdate.ForeColor = $script:updateDotColor
        $script:updateAvailable = $true
        $lblUpdateHint.Text = "● 有新版 v$($a.Version)：按左邊的水母更新"
        $lblUpdateHint.ForeColor = $script:updateDotColor
        $lblUpdateHint.Visible = $true
    } else {
        $btnUpdate.Text = "檢查更新"
        $btnUpdate.ForeColor = $btnSync.ForeColor
        $script:updateAvailable = $false
        $lblUpdateHint.Visible = $false
    }
    try { $picJelly.Invalidate() } catch {}
}

function Show-UpdateDialog($owner) {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 檢查更新"
    $dlg.Size = New-Object System.Drawing.Size(520, 400)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $lblVer = New-Object System.Windows.Forms.Label
    $lblVer.Text = "目前的版本：v$($script:AppVersion)"
    $lblVer.Location = New-Object System.Drawing.Point(15, 12)
    $lblVer.Size = New-Object System.Drawing.Size(470, 24)
    $dlg.Controls.Add($lblVer)

    $lblStatus = New-Object System.Windows.Forms.Label
    $lblStatus.Text = "正在看有沒有新版…"
    $lblStatus.Location = New-Object System.Drawing.Point(15, 42)
    $lblStatus.Size = New-Object System.Drawing.Size(470, 24)
    $lblStatus.Font = New-Object System.Drawing.Font($lblStatus.Font, [System.Drawing.FontStyle]::Bold)
    $dlg.Controls.Add($lblStatus)

    $txtNotes = New-Object System.Windows.Forms.TextBox
    $txtNotes.Multiline = $true
    $txtNotes.ReadOnly = $true
    $txtNotes.ScrollBars = "Vertical"
    $txtNotes.Location = New-Object System.Drawing.Point(15, 72)
    $txtNotes.Size = New-Object System.Drawing.Size(470, 150)
    $dlg.Controls.Add($txtNotes)

    $prog = New-Object System.Windows.Forms.ProgressBar
    $prog.Location = New-Object System.Drawing.Point(15, 232)
    $prog.Size = New-Object System.Drawing.Size(470, 18)
    $prog.Visible = $false
    $dlg.Controls.Add($prog)

    $lblHint = New-Object System.Windows.Forms.Label
    $lblHint.Text = "更新會把背景提醒程式和這個視窗關掉再自動重開；你的鬧鐘、設定、同步登入都會保留（更新前也會自動備份一份）。"
    $lblHint.Location = New-Object System.Drawing.Point(15, 256)
    $lblHint.Size = New-Object System.Drawing.Size(470, 50)
    $dlg.Controls.Add($lblHint)

    $btnGo = New-Object System.Windows.Forms.Button
    $btnGo.Text = "更新"
    $btnGo.Location = New-Object System.Drawing.Point(15, 315)
    $btnGo.Size = New-Object System.Drawing.Size(140, 38)
    $btnGo.Visible = $false
    $dlg.Controls.Add($btnGo)

    $btnRecheck = New-Object System.Windows.Forms.Button
    $btnRecheck.Text = "再檢查一次"
    $btnRecheck.Location = New-Object System.Drawing.Point(165, 315)
    $btnRecheck.Size = New-Object System.Drawing.Size(140, 38)
    $dlg.Controls.Add($btnRecheck)

    $btnCloseUpd = New-Object System.Windows.Forms.Button
    $btnCloseUpd.Text = "關閉"
    $btnCloseUpd.Location = New-Object System.Drawing.Point(385, 315)
    $btnCloseUpd.Size = New-Object System.Drawing.Size(100, 38)
    $btnCloseUpd.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($btnCloseUpd)
    $dlg.CancelButton = $btnCloseUpd

    $state = @{ Check = $null; Busy = $false }

    $doCheck = {
        $btnGo.Visible = $false; $btnRecheck.Enabled = $false
        $lblStatus.Text = "正在看有沒有新版…"; $txtNotes.Text = ""
        [System.Windows.Forms.Application]::DoEvents()
        $r = Invoke-UpdateCheck $script:AppVersion
        $state.Check = $r
        if ($r.State -eq "available") {
            $lblStatus.Text = "有新版：v$($r.Version)" + $(if ("$($r.Date)" -ne "") { "（$($r.Date) 發布）" } else { "" })
            $txtNotes.Text = ("更新內容：`r`n" + ((@(Get-UpdateNoteLines "$($r.Notes)") | ForEach-Object { "・" + $_ }) -join "`r`n"))
            $btnGo.Visible = $true
        } elseif ($r.State -eq "latest") {
            $lblStatus.Text = "已經是最新版了。"
            $txtNotes.Text = ""
        } else {
            $lblStatus.Text = "沒有檢查成功"
            $txtNotes.Text = "$($r.Error)"
        }
        # 順手更新「每天檢查」的記錄，主畫面的小紅點才會跟著變
        try {
            $s = Read-UpdateState $script:updateStatePath
            if ($r.State -ne "error") {
                $s.lastCheckDate = (Get-Date).ToString("yyyy-MM-dd", [System.Globalization.CultureInfo]::InvariantCulture)
                $s.lastCheckAt = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss", [System.Globalization.CultureInfo]::InvariantCulture)
                if ($r.State -eq "available") { $s.availableVersion = $r.Version; $s.availableNotes = $r.Notes } else { $s.availableVersion = ""; $s.availableNotes = "" }
                Write-UpdateState $script:updateStatePath $s
            }
        } catch {}
        Update-UpdateButton
        $btnRecheck.Enabled = $true
    }

    $btnRecheck.Add_Click({ & $doCheck })
    $dlg.Add_Shown({ & $doCheck })

    $btnGo.Add_Click({
        $r = $state.Check
        if ($null -eq $r -or $r.State -ne "available" -or $state.Busy) { return }
        $ans = Show-AppMessage("要更新到 v$($r.Version) 嗎？`n`n更新時會把背景提醒程式和這個視窗關掉，換好檔案後自動重開（大約十幾秒）。你的鬧鐘、設定、同步登入都會保留，更新前也會自動備份一份。", "$($script:AppName) - 更新", [System.Windows.Forms.MessageBoxButtons]::YesNo)
        if ($ans -ne [System.Windows.Forms.DialogResult]::Yes) { return }
        $state.Busy = $true
        $btnGo.Enabled = $false; $btnRecheck.Enabled = $false; $btnCloseUpd.Enabled = $false
        $prog.Visible = $true; $prog.Value = 0
        $lblStatus.Text = "下載中…"
        [System.Windows.Forms.Application]::DoEvents()
        try {
            $pkg = Get-UpdatePackage $r { param($done, $total)
                if ($total -gt 0) { $prog.Value = [Math]::Min(100, [int](100.0 * $done / $total)); $lblStatus.Text = "下載中… $([int](100.0 * $done / $total))%" }
                [System.Windows.Forms.Application]::DoEvents()
            }
            $lblStatus.Text = "下載完成、指紋核對過了，準備換檔…"
            [System.Windows.Forms.Application]::DoEvents()
            $waitPids = @($PID)
            try { $tp = [int](Get-Content -LiteralPath (Join-Path $PSScriptRoot "tray.pid") -ErrorAction Stop | Select-Object -First 1); if ($tp -gt 0) { $waitPids += $tp } } catch {}
            Start-UpdateApply $PSScriptRoot $pkg.NewAppDir $pkg.StagingRoot $script:AppVersion $r.Version $waitPids | Out-Null
            # 換檔時視窗會全部關掉一陣子，先講清楚，免得以為當掉（2026-10-05 先生回報）
            $lblStatus.Text = "準備好了！程式會先關掉換檔，約 10~20 秒後自動重新打開，請稍候…"
            [System.Windows.Forms.Application]::DoEvents()
            Start-Sleep -Milliseconds 2500
            $form.Close()
            [System.Windows.Forms.Application]::Exit()
            return
        } catch {
            $info = Get-UpdateErrorInfo $_
            $lblStatus.Text = "更新沒有成功"
            $txtNotes.Text = $info.Text
            $prog.Visible = $false
            $btnGo.Enabled = $true; $btnRecheck.Enabled = $true; $btnCloseUpd.Enabled = $true
            $state.Busy = $false
            if ($info.Kind -eq "hash") { Show-AppMessage($info.Text, "$($script:AppName) - 為了安全沒有更新") | Out-Null }
        }
    })

    Complete-AppForm $dlg
    if ($null -ne $owner) { $dlg.ShowDialog($owner) | Out-Null } else { $dlg.ShowDialog() | Out-Null }
    $dlg.Dispose()
}

$btnUpdate.Add_Click({
    try { Show-UpdateDialog $form } catch { Show-AppMessage("更新視窗發生錯誤：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null }
})

# ---------- 工單 8.6：設定視窗（左邊分類清單、右邊內容、左上搜尋）----------
# 裡面的按鈕都是呼叫上面那些原本就有的功能（匯出、匯入、同步、檢查更新…），邏輯只有一份。
function Invoke-ControlClick($c) {
    try {
        $m = $c.GetType().GetMethod("OnClick", [System.Reflection.BindingFlags]"Instance,NonPublic")
        if ($null -ne $m) { $m.Invoke($c, @([System.EventArgs]::Empty)) | Out-Null; return }
    } catch {}
    try { $c.PerformClick() } catch {}
}

$script:privacyText = "鬧鐘只存在這台電腦裡，沒有自己的伺服器、不收集任何資料。`r`n`r`n唯一會連網的是：你自己按「同步」用 Google 帳號登入之後的同步（只放在你自己雲端硬碟裡這個程式專用的隱藏資料夾）、和「檢查更新」。`r`n`r`n「私密」的鬧鐘不會在提醒視窗以外的地方顯示內容。"

function Get-SetupProblemOnWindows {
    try { return (-not (Test-TrayRunning)) } catch { return $false }
}

function Show-SettingsDialog([string]$startSection = "", [string]$focusKey = "") {
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 設定"
    $dlg.Size = New-Object System.Drawing.Size(780, 540)
    $dlg.StartPosition = "CenterParent"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    Set-AppFormStyle $dlg

    $txtFind = New-Object System.Windows.Forms.TextBox
    $txtFind.Location = New-Object System.Drawing.Point(12, 12)
    $txtFind.Size = New-Object System.Drawing.Size(210, 26)
    $dlg.Controls.Add($txtFind)
    $tipFind = New-Object System.Windows.Forms.ToolTip
    $tipFind.SetToolTip($txtFind, "搜尋設定，例如：震動、同步、深色")

    $lstSec = New-Object System.Windows.Forms.ListBox
    $lstSec.Location = New-Object System.Drawing.Point(12, 44)
    $lstSec.Size = New-Object System.Drawing.Size(210, 400)
    $lstSec.IntegralHeight = $false
    $lstSec.ItemHeight = 32
    $lstSec.DrawMode = [System.Windows.Forms.DrawMode]::OwnerDrawFixed
    $dlg.Controls.Add($lstSec)

    $pnl = New-Object System.Windows.Forms.Panel
    $pnl.Location = New-Object System.Drawing.Point(235, 12)
    $pnl.Size = New-Object System.Drawing.Size(520, 432)
    $pnl.AutoScroll = $true
    $dlg.Controls.Add($pnl)

    $btnDlgClose = New-Object System.Windows.Forms.Button
    $btnDlgClose.Text = "關閉"
    $btnDlgClose.Location = New-Object System.Drawing.Point(655, 455)
    $btnDlgClose.Size = New-Object System.Drawing.Size(100, 34)
    $dlg.Controls.Add($btnDlgClose)
    $btnDlgClose.Add_Click({ $dlg.Close() })

    $script:setRows = @()          # 目前列表上每一列：@{ Kind = "sec"/"hit"; Id = 分類; Key = 項目 }
    $script:setCtrls = @{}         # 項目 key → 畫面上的控制項
    $script:setY = 6
    $script:setPendingAppearance = $false
    $secs = @(Get-SettingsSectionsOrdered (Get-SetupProblemOnWindows))
    $secTitle = @{}
    foreach ($s in (Get-SettingsSections)) { $secTitle[$s.Id] = $s.Icon + " " + $s.Title }

    $lstSec.Add_DrawItem({
        param($sender, $e)
        if ($e.Index -lt 0) { return }
        $e.DrawBackground()
        $row = $script:setRows[$e.Index]
        $txt = [string]$sender.Items[$e.Index]
        $color = $e.ForeColor
        if ($row.Kind -eq "sec" -and $row.Id -eq "setup" -and (Get-SetupProblemOnWindows)) { $color = [System.Drawing.Color]::FromArgb(211, 47, 47) }
        $brush = New-Object System.Drawing.SolidBrush $color
        $e.Graphics.DrawString($txt, $e.Font, $brush, ($e.Bounds.X + 6), ($e.Bounds.Y + 6))
        $brush.Dispose()
        $e.DrawFocusRectangle()
    })

    function Add-SetText([string]$text, [bool]$bold = $false, [bool]$gray = $false, [string]$key = "") {
        $l = New-Object System.Windows.Forms.Label
        $l.AutoSize = $true
        $l.MaximumSize = New-Object System.Drawing.Size(480, 0)
        $l.Text = $text
        $l.Location = New-Object System.Drawing.Point(6, $script:setY)
        if ($bold) { $l.Font = New-Object System.Drawing.Font($l.Font, [System.Drawing.FontStyle]::Bold) }
        if ($gray) { $l.ForeColor = [System.Drawing.Color]::Gray }
        $pnl.Controls.Add($l)
        $h = $l.GetPreferredSize((New-Object System.Drawing.Size(480, 0))).Height
        $script:setY += $h + 8
        if ($key -ne "") { $script:setCtrls[$key] = $l }
        return $l
    }

    function Add-SetHeading([string]$text) {
        $script:setY += 8
        [void](Add-SetText $text $true $false "")
    }

    function Add-SetButton([string]$text, [scriptblock]$onClick, [string]$key = "", [int]$w = 220) {
        $b = New-Object System.Windows.Forms.Button
        $b.Text = $text
        $b.Size = New-Object System.Drawing.Size($w, 34)
        $b.Location = New-Object System.Drawing.Point(6, $script:setY)
        $b.Add_Click($onClick)
        $pnl.Controls.Add($b)
        $script:setY += 42
        if ($key -ne "") { $script:setCtrls[$key] = $b }
        return $b
    }

    function Build-SettingsSection([string]$id, [string]$focus) {
        $pnl.SuspendLayout()
        $pnl.Controls.Clear()
        $script:setCtrls = @{}
        $script:setY = 6
        [void](Add-SetText $secTitle[$id] $true $false "")
        $script:setY += 4
        switch ($id) {
            "ring" {
                [void](Add-SetText "鬧鐘會一直響，直到你處理（已完成、先等等、真的沒空）才停。" $false $true "")
                # 鈴聲（2026-10-05：跟手機一樣有內建三種＋自訂；每個鬧鐘也可以在編輯視窗自己選）
                $rs = Read-RingSettings $script:RingSettingsPath
                Add-SetHeading "鈴聲（沒有自己選鈴聲的鬧鐘用這個）"
                $cmbG = New-Object System.Windows.Forms.ComboBox
                $cmbG.DropDownStyle = "DropDownList"
                $cmbG.Size = New-Object System.Drawing.Size(300, 28)
                $cmbG.Location = New-Object System.Drawing.Point(6, $script:setY)
                $script:gToneKeys = @("gentle", "standard", "loud")
                foreach ($ct in @(Get-PcCustomTones)) { $script:gToneKeys += ($script:ToneCustomPrefix + $ct.id) }
                $script:gToneKeys += "system"
                foreach ($k in $script:gToneKeys) { $cmbG.Items.Add((Get-ToneLabel $k { param($id) Get-PcCustomToneName $id })) | Out-Null }
                $gi = [Array]::IndexOf($script:gToneKeys, $rs.tone)
                $cmbG.SelectedIndex = [Math]::Max(0, $gi)
                $cmbG.Add_SelectedIndexChanged({
                    param($s, $e)
                    $r = Read-RingSettings $script:RingSettingsPath
                    $r.tone = $script:gToneKeys[[Math]::Max(0, $s.SelectedIndex)]
                    try { Write-RingSettings $script:RingSettingsPath $r } catch { Show-AppMessage("存不了設定：$($_.Exception.Message)", "$($script:AppName)") | Out-Null }
                })
                $pnl.Controls.Add($cmbG)
                $script:setCtrls["ring.tone"] = $cmbG
                $script:setY += 38
                [void](Add-SetButton "試聽 5 秒" {
                    $r = Read-RingSettings $script:RingSettingsPath
                    if ($r.tone -eq "system") { [System.Media.SystemSounds]::Exclamation.Play(); return }
                    $pb = Start-TonePlayback $r.tone 80 $false
                    $stopper = New-Object System.Windows.Forms.Timer
                    $stopper.Interval = 5000
                    $stopper.Tag = $pb
                    $stopper.Add_Tick({ param($s, $e) $s.Stop(); Stop-TonePlayback $s.Tag; $s.Dispose() })
                    $stopper.Start()
                } "ring.preview" 160)
                [void](Add-SetText "三種內建鈴聲一樣大聲，「溫和」只是曲調溫和。「Windows 提示音」是舊版的叮一聲。手機上設成「手機的鬧鐘鈴聲」的鬧鐘，在電腦上用這裡選的。每個鬧鐘的音量（Windows 目前音量的幾 %）在新增／編輯視窗裡調。" $false $true "")
                $chkGC = New-Object System.Windows.Forms.CheckBox
                $chkGC.Text = "漸強音量（普通鬧鐘的預設：前 30 秒從一半慢慢變大）"
                $chkGC.AutoSize = $true
                $chkGC.Location = New-Object System.Drawing.Point(6, $script:setY)
                $chkGC.Checked = [bool]$rs.crescendo
                $chkGC.Add_CheckedChanged({
                    param($s, $e)
                    $r = Read-RingSettings $script:RingSettingsPath
                    $r.crescendo = $s.Checked
                    try { Write-RingSettings $script:RingSettingsPath $r } catch {}
                })
                $pnl.Controls.Add($chkGC)
                $script:setCtrls["ring.crescendo"] = $chkGC
                $script:setY += 34

                Add-SetHeading "自訂鈴聲（最多 5 個，只存在這台電腦）"
                $customs = @(Get-PcCustomTones)
                if ($customs.Count -eq 0) { [void](Add-SetText "還沒有自訂鈴聲。" $false $true "") }
                foreach ($ct in $customs) {
                    $l = New-Object System.Windows.Forms.Label
                    $l.Text = "♪ " + $ct.name
                    $l.AutoSize = $false
                    $l.Size = New-Object System.Drawing.Size(250, 28)
                    $l.Location = New-Object System.Drawing.Point(6, ($script:setY + 6))
                    $pnl.Controls.Add($l)
                    $bR = New-Object System.Windows.Forms.Button
                    $bR.Text = "改名"
                    $bR.Size = New-Object System.Drawing.Size(80, 30)
                    $bR.Location = New-Object System.Drawing.Point(262, $script:setY)
                    $bR.Tag = $ct.id
                    $bR.Add_Click({
                        param($s, $e)
                        $list = @(Get-PcCustomTones)
                        $t = $list | Where-Object { $_.id -eq $s.Tag } | Select-Object -First 1
                        if ($null -eq $t) { return }
                        $n = Show-TextInputDialog $dlg "改名" "新的名稱（最多 30 字）：" $t.name
                        if ($null -eq $n) { return }
                        $t.name = Get-CleanToneName $n
                        Write-CustomTones $script:RingtoneListPath $list
                        Build-SettingsSection "ring" ""
                    })
                    $pnl.Controls.Add($bR)
                    $bD = New-Object System.Windows.Forms.Button
                    $bD.Text = "刪除"
                    $bD.Size = New-Object System.Drawing.Size(80, 30)
                    $bD.Location = New-Object System.Drawing.Point(348, $script:setY)
                    $bD.Tag = $ct.id
                    $bD.Add_Click({
                        param($s, $e)
                        $list = @(Get-PcCustomTones)
                        $t = $list | Where-Object { $_.id -eq $s.Tag } | Select-Object -First 1
                        if ($null -eq $t) { return }
                        $ask = Show-AppMessage("刪掉自訂鈴聲「$($t.name)」？`n用到它的鬧鐘會改用內建・標準。", "$($script:AppName)", [System.Windows.Forms.MessageBoxButtons]::YesNo)
                        if ($ask -ne [System.Windows.Forms.DialogResult]::Yes) { return }
                        try { Remove-Item -LiteralPath (Join-Path $script:RingtoneDir $t.file) -Force -ErrorAction SilentlyContinue } catch {}
                        Write-CustomTones $script:RingtoneListPath @($list | Where-Object { $_.id -ne $s.Tag })
                        $r = Read-RingSettings $script:RingSettingsPath
                        if ($r.tone -eq ($script:ToneCustomPrefix + $s.Tag)) { $r.tone = "standard"; Write-RingSettings $script:RingSettingsPath $r }
                        Build-SettingsSection "ring" ""
                    })
                    $pnl.Controls.Add($bD)
                    $script:setY += 36
                }
                [void](Add-SetButton "新增自訂鈴聲…" {
                    $list = @(Get-PcCustomTones)
                    $why = Test-CustomToneAddable $list.Count 1 "x.mp3"
                    if ($null -ne $why) { Show-AppMessage($why, "$($script:AppName)") | Out-Null; return }
                    $ofd = New-Object System.Windows.Forms.OpenFileDialog
                    $ofd.Title = "選一個音檔當鈴聲"
                    $ofd.Filter = "音檔 (*.mp3;*.wav;*.wma;*.m4a;*.aac)|*.mp3;*.wav;*.wma;*.m4a;*.aac"
                    if ($ofd.ShowDialog($dlg) -ne [System.Windows.Forms.DialogResult]::OK) { return }
                    $src = $ofd.FileName
                    $size = (Get-Item -LiteralPath $src).Length
                    $why = Test-CustomToneAddable $list.Count $size $src
                    if ($null -ne $why) { Show-AppMessage($why, "$($script:AppName)") | Out-Null; return }
                    $id = [Guid]::NewGuid().ToString("N").Substring(0, 12)
                    $ext = [System.IO.Path]::GetExtension($src).ToLowerInvariant()
                    try {
                        if (-not (Test-Path -LiteralPath $script:RingtoneDir)) { New-Item -ItemType Directory -Path $script:RingtoneDir -Force | Out-Null }
                        Copy-Item -LiteralPath $src -Destination (Join-Path $script:RingtoneDir "$id$ext") -Force
                        $list += [PSCustomObject]@{ id = $id; name = (Get-CleanToneName ([System.IO.Path]::GetFileName($src))); file = "$id$ext"; bytes = [long]$size }
                        Write-CustomTones $script:RingtoneListPath $list
                    } catch { Show-AppMessage("加不進來：$($_.Exception.Message)", "$($script:AppName)") | Out-Null; return }
                    Build-SettingsSection "ring" ""
                } "ring.custom" 200)
                [void](Add-SetText "手機上的自訂鈴聲只在手機，電腦用不到；手機設了自訂鈴聲的鬧鐘，在電腦上會改用內建・標準（反過來也一樣）。" $false $true "")
                Add-SetHeading "響鈴規則"
                [void](Add-SetText "連續響 10 分鐘沒人理就先停聲，停 5 分鐘再響（當作你不在）；總共響到 60 分鐘還沒處理就不再出聲，改成常駐的「沒處理」提醒。電腦版這三個數字固定，沒辦法改；手機版可以調。" $false $false "ring.rules")
                Add-SetHeading "震動"
                [void](Add-SetText "電腦沒有震動。要震動的鬧鐘請用手機版。" $false $false "ring.vibrate")
                Add-SetHeading "確認醒了、關鬧鐘難度"
                [void](Add-SetText "每個鬧鐘各自設定：在「新增／編輯鬧鐘」視窗裡選難度（連答三題、變難）。這裡沒有全部通用的預設值。" $false $false "ring.confirm")
            }
            "privacy" {
                [void](Add-SetText "「私密」的鬧鐘，內容不會讓旁邊的人看到。" $false $true "")
                Add-SetHeading "私密分類"
                [void](Add-SetText "在「管理分類」裡，把分類設成私密 🔒。" $false $false "")
                [void](Add-SetButton "打開管理分類" { Invoke-ControlClick $btnAddCategory; $script:alarms = @(Load-Alarms); Refresh-List } "privacy.cats")
                Add-SetHeading "資料放在哪"
                [void](Add-SetText $script:privacyText $false $false "privacy.data")
                [void](Add-SetButton "隱私權政策（網頁）" { try { Start-Process $script:PrivacyUrl } catch { Show-AppMessage("打不開瀏覽器。網址：$($script:PrivacyUrl)", "$($script:AppName)") | Out-Null } } "privacy.policy")
            }
            "sync" {
                Add-SetHeading "Google 同步（電腦 ↔ 手機）"
                [void](Add-SetText "用你自己的 Google 帳號登入後，電腦和手機的鬧鐘會自動保持一樣。資料只放在你自己雲端硬碟裡這個程式專用的隱藏資料夾。登入、登出、立即同步、上次同步時間都在下面這個視窗。" $false $true "")
                [void](Add-SetButton "同步（登入／立即同步／登出）…" { Invoke-ControlClick $btnSync } "sync.account" 280)
                Add-SetHeading "匯出／匯入備份"
                [void](Add-SetText "匯出：把鬧鐘存成 .json 檔（可以存到雲端硬碟，手機再匯入）。匯入：選匯出的檔，可以全部取代或合併。" $false $true "")
                [void](Add-SetButton "匯出鬧鐘" { Invoke-ControlClick $btnExport } "sync.export")
                [void](Add-SetButton "匯入鬧鐘" { Invoke-ControlClick $btnImport } "sync.import")
            }
            "look" {
                Add-SetHeading "字體大小"
                $cf = New-Object System.Windows.Forms.ComboBox
                $cf.DropDownStyle = "DropDownList"
                $cf.Items.AddRange(@("標準", "大", "特大"))
                $cf.SelectedIndex = [Math]::Max(0, [Array]::IndexOf($script:fontSizeKeys, $script:settings.fontSize))
                $cf.Size = New-Object System.Drawing.Size(160, 26)
                $cf.Location = New-Object System.Drawing.Point(6, ($script:setY - 4))
                $script:setCf = $cf
                $pnl.Controls.Add($cf); $script:setCtrls["look.font"] = $cf
                $script:setY += 38
                $cb = New-Object System.Windows.Forms.CheckBox
                $cb.Text = "粗體"
                $cb.AutoSize = $true
                $cb.Checked = [bool]$script:settings.bold
                $cb.Location = New-Object System.Drawing.Point(6, $script:setY)
                $script:setCb = $cb
                $pnl.Controls.Add($cb); $script:setCtrls["look.bold"] = $cb
                $script:setY += 34
                Add-SetHeading "深色／淺色"
                $ct = New-Object System.Windows.Forms.ComboBox
                $ct.DropDownStyle = "DropDownList"
                $ct.Items.AddRange(@("淺色", "深色（護眼）"))
                $ct.SelectedIndex = [Math]::Max(0, [Array]::IndexOf($script:themeKeys, $script:settings.theme))
                $ct.Size = New-Object System.Drawing.Size(160, 26)
                $ct.Location = New-Object System.Drawing.Point(6, ($script:setY - 4))
                $script:setCt = $ct
                $pnl.Controls.Add($ct); $script:setCtrls["look.theme"] = $ct
                $script:setY += 38
                $apply = {
                    $cmbFontSize.SelectedIndex = $script:setCf.SelectedIndex
                    $cmbTheme.SelectedIndex = $script:setCt.SelectedIndex
                    $chkBold.Checked = $script:setCb.Checked
                    $script:setPendingAppearance = $true
                    $dlg.Close()
                }
                $cf.Add_SelectionChangeCommitted($apply)
                $ct.Add_SelectionChangeCommitted($apply)
                $cb.Add_Click($apply)
                [void](Add-SetText "改了以後設定視窗會重新打開一次套用。" $false $true "")
                Add-SetHeading "分類顏色"
                [void](Add-SetText "每個分類的顏色在「管理分類」裡改。" $false $true "")
                [void](Add-SetButton "打開管理分類" { Invoke-ControlClick $btnAddCategory; $script:alarms = @(Load-Alarms); Refresh-List } "look.catcolor")
            }
            "setup" {
                [void](Add-SetText "電腦要讓鬧鐘準時響，「背景提醒」程式要一直在跑（工作列右下角有水母圖示）。" $false $true "")
                Add-SetHeading "背景提醒"
                $script:setLblT = Add-SetText $lblTrayStatus.Text $true $false "setup.tray"
                $script:setLblT.ForeColor = $lblTrayStatus.ForeColor
                [void](Add-SetButton "啟動背景提醒" { Invoke-ControlClick $btnStartTray; $script:setLblT.Text = $lblTrayStatus.Text; $script:setLblT.ForeColor = $lblTrayStatus.ForeColor })
                [void](Add-SetButton "停止背景提醒" { Invoke-ControlClick $btnStopTray; $script:setLblT.Text = $lblTrayStatus.Text; $script:setLblT.ForeColor = $lblTrayStatus.ForeColor })
                Add-SetHeading "開機自動啟動"
                $script:setLblS = Add-SetText $lblStartupStatus.Text $true $false "setup.startup"
                $script:setLblS.ForeColor = $lblStartupStatus.ForeColor
                [void](Add-SetButton "設定開機自動啟動" { Invoke-ControlClick $btnEnableStartup; $script:setLblS.Text = $lblStartupStatus.Text; $script:setLblS.ForeColor = $lblStartupStatus.ForeColor })
                [void](Add-SetButton "取消開機自動啟動" { Invoke-ControlClick $btnDisableStartup; $script:setLblS.Text = $lblStartupStatus.Text; $script:setLblS.ForeColor = $lblStartupStatus.ForeColor })
            }
            default {
                [void](Add-SetText "目前的版本：v$($script:AppVersion)" $true $false "about.version")
                Add-SetHeading "更新"
                [void](Add-SetButton $btnUpdate.Text { Invoke-ControlClick $btnUpdate } "about.update")
                Add-SetHeading "關於"
                [void](Add-SetButton "關於$($script:AppName)" { Invoke-ControlClick $btnAbout } "about.about")
                [void](Add-SetButton "隱私權政策" { try { Start-Process $script:PrivacyUrl } catch { Show-AppMessage("打不開瀏覽器。網址：$($script:PrivacyUrl)", "$($script:AppName)") | Out-Null } } "about.privacy")
                [void](Add-SetButton "分享給朋友（複製下載網址）" { Copy-SiteUrlToClipboard } "about.share" 260)
            }
        }
        $pnl.ResumeLayout()
        if ($focus -ne "" -and $script:setCtrls.ContainsKey($focus)) {
            $c = $script:setCtrls[$focus]
            if ($c -is [System.Windows.Forms.Label]) { $c.BackColor = [System.Drawing.Color]::FromArgb(255, 248, 220) }
            try { $pnl.ScrollControlIntoView($c); $c.Focus() } catch {}
        }
    }

    function Show-SectionList {
        $script:setRows = @()
        $lstSec.Items.Clear()
        foreach ($s in $secs) {
            $script:setRows += @{ Kind = "sec"; Id = $s.Id; Key = "" }
            [void]$lstSec.Items.Add($s.Icon + " " + $s.Title)
        }
    }

    $script:setBusy = $false
    $lstSec.Add_SelectedIndexChanged({
        if ($script:setBusy -or $lstSec.SelectedIndex -lt 0) { return }
        $r = $script:setRows[$lstSec.SelectedIndex]
        Build-SettingsSection $r.Id $r.Key
    })

    $txtFind.Add_TextChanged({
        $script:setBusy = $true
        try {
            $q = $txtFind.Text
            if ($q.Trim() -eq "") { Show-SectionList; return }
            $hits = @(Search-SettingsIndex $q)
            $script:setRows = @()
            $lstSec.Items.Clear()
            if ($hits.Count -eq 0) {
                $script:setRows += @{ Kind = "none"; Id = ""; Key = "" }
                [void]$lstSec.Items.Add("找不到「$($q.Trim())」")
            }
            foreach ($h in $hits) {
                $script:setRows += @{ Kind = "hit"; Id = $h.Section; Key = $h.Key }
                [void]$lstSec.Items.Add($h.Label + "  〔" + ($secTitle[$h.Section] -replace '^\S+ ', '') + "〕")
            }
        } finally { $script:setBusy = $false }
    })

    Show-SectionList
    $startIdx = 0
    if ($startSection -ne "") { for ($i = 0; $i -lt $secs.Count; $i++) { if ($secs[$i].Id -eq $startSection) { $startIdx = $i } } }
    $script:setBusy = $true
    $lstSec.SelectedIndex = $startIdx
    $script:setBusy = $false
    Build-SettingsSection $secs[$startIdx].Id $focusKey

    Complete-AppForm $dlg
    $dlg.ShowDialog($form) | Out-Null
    $dlg.Dispose()
    if ($script:setPendingAppearance) { Save-AppearanceAndReopen }
}

# 左下角：水母（有新版時右上角有紅點，按一下開更新）＋「設定…」
$script:updateAvailable = $false
$picJelly = New-AppPictureBox "jellyfish.png" 15 368 64 64
$form.Controls.Add($picJelly)
$picJelly.Cursor = [System.Windows.Forms.Cursors]::Hand
$picJelly.Anchor = $AnchorBL
$picJelly.Add_Paint({
    param($sender, $e)
    if (-not $script:updateAvailable) { return }
    $d = 20
    $x = $sender.Width - $d - 1
    $e.Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $e.Graphics.FillEllipse([System.Drawing.Brushes]::White, $x - 1, 0, $d + 2, $d + 2)
    $red = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 211, 47, 47))
    $e.Graphics.FillEllipse($red, $x + 1, 2, $d - 2, $d - 2)
    $f = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
    $e.Graphics.DrawString("!", $f, [System.Drawing.Brushes]::White, ($x + 6), 3)
    $f.Dispose(); $red.Dispose()
})
$picJelly.Add_Click({
    if ($script:updateAvailable) { Show-SettingsDialog "about" "about.update" }
})
$tipSync.SetToolTip($picJelly, "有新版時這裡會有紅點，按一下就能更新")

$btnSettings = New-Object System.Windows.Forms.Button
$btnSettings.Text = "⚙ 設定…"
$btnSettings.Location = New-Object System.Drawing.Point(90, 368)
$btnSettings.Size = New-Object System.Drawing.Size(170, 40)
$btnSettings.Anchor = $AnchorBL
$form.Controls.Add($btnSettings)
$btnSettings.Add_Click({
    try { Show-SettingsDialog "" "" } catch { Show-AppMessage("設定視窗發生錯誤：$($_.Exception.Message)", "$($script:AppName) - 錯誤") | Out-Null }
})

$lblUpdateHint = New-Object System.Windows.Forms.Label
$lblUpdateHint.Location = New-Object System.Drawing.Point(270, 378)
$lblUpdateHint.Size = New-Object System.Drawing.Size(320, 24)
$lblUpdateHint.Anchor = $AnchorBL
$lblUpdateHint.Visible = $false
$form.Controls.Add($lblUpdateHint)

# 原本散在視窗上的設定項目（字體、外觀、開機啟動、背景提醒、匯出匯入、同步、更新）搬進設定視窗；
# 控制項本身還留著（隱藏），設定視窗的按鈕直接呼叫它們，所以功能一個都沒少。
foreach ($c in @($lblFontSize, $cmbFontSize, $chkBold, $lblTheme, $cmbTheme, $btnEnableStartup, $btnDisableStartup, $btnStartTray, $btnStopTray, $btnExport, $btnImport, $btnSync, $btnUpdate)) { $c.Visible = $false }
$lblStartupStatus.Location = New-Object System.Drawing.Point(90, 418)
$lblStartupStatus.Size = New-Object System.Drawing.Size(500, 24)
$lblTrayStatus.Location = New-Object System.Drawing.Point(90, 444)
$lblTrayStatus.Size = New-Object System.Drawing.Size(500, 24)

$btnClose.Add_Click({ $form.Close() })

# 大字／深色（v1.1）：先套用，再記下各欄的原寬度、最小視窗大小
Complete-AppForm $form
$script:baseColumnWidths = @($listView.Columns | ForEach-Object { $_.Width })
Update-ContentColumnWidth

Refresh-List
Update-StartupStatus
Update-UpdateButton

# 視窗開著的時候，背景提醒程式查到新版 → 水母的紅點自己冒出來（每分鐘看一次記錄檔，不連網）
$updDotTimer = New-Object System.Windows.Forms.Timer
$updDotTimer.Interval = 60000
$updDotTimer.Add_Tick({ try { Update-UpdateButton } catch {} })
$updDotTimer.Start()

# 打開視窗就在背景查一次新版（10 分鐘內查過就不查），查完水母馬上亮紅點，不用等背景提醒的 3 小時（2026-10-05）
$script:homeUpdJob = $null
try { if (Test-UpdateCheckDue $script:updateStatePath (Get-Date) 10) { $script:homeUpdJob = Start-UpdateCheckJob $PSScriptRoot $script:updateStatePath $script:AppVersion } } catch {}
if ($null -ne $script:homeUpdJob) {
    $homeUpdTimer = New-Object System.Windows.Forms.Timer
    $homeUpdTimer.Interval = 2000
    $script:homeUpdTicks = 0
    $homeUpdTimer.Add_Tick({
        $script:homeUpdTicks++
        try {
            if ($script:homeUpdJob.State -ne "Running" -or $script:homeUpdTicks -gt 45) {
                $homeUpdTimer.Stop()
                try { Remove-Job -Job $script:homeUpdJob -Force -ErrorAction SilentlyContinue } catch {}
                Update-UpdateButton
            }
        } catch { $homeUpdTimer.Stop() }
    })
    $homeUpdTimer.Start()
}

if (-not (Test-TrayRunning)) {
    try {
        Start-AppScript "Alarm_Tray.ps1"
        Start-Sleep -Milliseconds 800
    } catch {}
}
Update-TrayStatus

[System.Windows.Forms.Application]::Run($form)

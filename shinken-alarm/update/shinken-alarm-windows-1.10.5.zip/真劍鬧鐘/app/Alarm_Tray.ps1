﻿# 真劍鬧鐘：背景提醒（系統匣常駐 + 到點跳提醒）
# -Welcome：從「啟動真劍鬧鐘」或開始功能表打開時，右下角冒一個「我在這裡」的提示
param([switch]$Welcome)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

. (Join-Path $PSScriptRoot "AlarmCore.ps1")
. (Join-Path $PSScriptRoot "AlarmSync.ps1")
. (Join-Path $PSScriptRoot "AlarmUpdate.ps1")
. (Join-Path $PSScriptRoot "AlarmUi.ps1")

$mutexName = "DesktopAlarmTray_SingleInstance_Lock"
$createdNew = $false
$script:singleInstanceMutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$createdNew)
if (-not $createdNew) {
    exit
}

$jsonPath = Join-Path $PSScriptRoot "alarms.json"
$pidFile = Join-Path $PSScriptRoot "tray.pid"
# 「真的沒空」延後的提醒存在這裡，重開機、重開程式都不會忘
$script:snoozePath = Join-Path $PSScriptRoot "snoozes.json"
Set-Content -Path $pidFile -Value $PID -Encoding UTF8 -Force

# 第一次使用（沒有 alarms.json）→ 建一個範例鬧鐘
$script:firstRun = $false
try { $script:firstRun = Initialize-AlarmFile $jsonPath (Get-Date) } catch {}

function Load-Alarms {
    $data = Read-AlarmFile $jsonPath
    if ($data.Count -eq 0) { return @() }
    $data = Repair-DuplicateIds $data
    # 舊資料沒有「開始生效」時間：第一次載入蓋成現在（寧可少補一次，也不要亂響）
    if (Set-MissingArmed $data (Get-Date)) { Write-AlarmFile $jsonPath $data }
    return $data
}

function Repair-DuplicateIds($alarms) {
    if ($alarms.Count -eq 0) { return $alarms }
    $seen = @{}
    $maxId = 0
    foreach ($a in $alarms) {
        if ($a.id -gt $maxId) { $maxId = $a.id }
    }
    $changed = $false
    foreach ($a in $alarms) {
        if ($seen.ContainsKey($a.id)) {
            $maxId++
            $a.id = $maxId
            $changed = $true
        } else {
            $seen[$a.id] = $true
        }
    }
    if ($changed) {
        Save-Alarms $alarms
    }
    return $alarms
}

function Save-Alarms($alarms) {
    Write-AlarmFile $jsonPath $alarms
}

# Get-AlarmDescription、Get-CandidateDates 搬到 AlarmCore.ps1（才能寫測試）

$global:AlarmReminderState = @{}
$global:AlarmOpenForms = @{}

function Complete-Alarm($alarmId, $dateKey) {
    $current = Load-Alarms
    $snTable = @{}
    try { $snTable = Read-SnoozeFile $script:snoozePath } catch {}
    foreach ($x in $current) {
        if ($x.id -eq $alarmId) {
            if ($x.type -eq "interval") {
                $intervalDays = [int]$x.intervalDays
                $base = (Get-Date).Date
                try { $base = [DateTime]::ParseExact($dateKey, "yyyy-MM-dd", $null) } catch {}
                $newDue = $base.AddDays($intervalDays)
                while ($newDue.Date -le (Get-Date).Date) { $newDue = $newDue.AddDays($intervalDays) }
                $x | Add-Member -NotePropertyName nextDueDate -NotePropertyValue ($newDue.ToString("yyyy-MM-dd")) -Force
            } else {
                if ($null -eq $x.triggeredDates) { $x | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @() -Force }
                if ($x.triggeredDates -notcontains $dateKey) {
                    $x.triggeredDates = @($x.triggeredDates) + $dateKey
                }
            }
            # 答對一次 = 這個鬧鐘這次全部收掉：其他欠著的日子（漏響補提醒、之前按過「真的沒空」的）一起結清，不用再答第二次（工單 8.8）
            $mg = Merge-AlarmPending $x $snTable $global:AlarmReminderState $dateKey (Get-Date) $false
            if ($mg.SnoozeChanged) { try { Write-SnoozeFile $script:snoozePath $snTable } catch {} }
        }
    }
    Save-Alarms $current
    # 答題完成 → 這筆「真的沒空」的延後也一起結清
    try { Remove-NoTimeSnooze $script:snoozePath $alarmId $dateKey } catch {}
}

# 延後（先等等／真的沒空）之後：同一個鬧鐘只留這一筆待響（取代，不追加），其他欠著的日子併進來（工單 8.8）
function Settle-AlarmPending($alarmId, [string]$dateKey) {
    try {
        $current = Load-Alarms
        $a = @($current | Where-Object { $_.id -eq $alarmId })[0]
        if ($null -eq $a) { return }
        $sn = Read-SnoozeFile $script:snoozePath
        $mg = Merge-AlarmPending $a $sn $global:AlarmReminderState $dateKey (Get-Date) $true
        if ($mg.AlarmChanged) { Save-Alarms $current }
        if ($mg.SnoozeChanged) { Write-SnoozeFile $script:snoozePath $sn }
    } catch {}
}

# 「真的沒空」選時間的小視窗；選好回傳 DateTime，按「算了」回傳 $null
function Show-NoTimeDialog($owner) {
    $now = Get-Date
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = "$($script:AppName) - 真的沒空"
    $dlg.Size = New-Object System.Drawing.Size(500, 360)
    $dlg.StartPosition = "CenterScreen"
    $dlg.FormBorderStyle = "FixedDialog"
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.TopMost = $true
    Set-AppFormStyle $dlg
    $dlg.Tag = $null

    $pb = New-AppPictureBox "xg_no_time.png" 12 15 150 150
    $dlg.Controls.Add($pb)

    $lblAsk = New-Object System.Windows.Forms.Label
    $lblAsk.Text = "真的沒空？好啦，躺平一下也可以。`n那你說，什麼時候再來叫你？（時間到一定會回來喔）"
    $lblAsk.Location = New-Object System.Drawing.Point(172, 12)
    $lblAsk.Size = New-Object System.Drawing.Size(300, 40)
    $lblAsk.ForeColor = $script:ThemeText
    $dlg.Controls.Add($lblAsk)

    $tonight = Get-NoTimeUntil "tonight" $now $null
    $tonightText = if ($tonight.Date -eq $now.Date) { "今晚" } else { "明晚" }
    $tomorrow = Get-NoTimeUntil "tomorrow" $now $null
    $choices = @(
        @{ Choice = "30m";      Text = "30 分鐘後（約 $($now.AddMinutes(30).ToString('HH:mm'))）" },
        @{ Choice = "2h";       Text = "2 小時後（約 $($now.AddHours(2).ToString('HH:mm'))）" },
        @{ Choice = "tonight";  Text = "$tonightText 20:00（$($tonight.ToString('M/d'))）" },
        @{ Choice = "tomorrow"; Text = "明天早上 09:00（$($tomorrow.ToString('M/d'))）" }
    )

    $onChoice = {
        param($sender, $e)
        try {
            $f = $sender.FindForm()
            $f.Tag = Get-NoTimeUntil "$($sender.Tag)" (Get-Date) $null
            $f.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $f.Close()
        } catch {
            Show-AppMessage("發生錯誤：$($_.Exception.Message)", "除錯訊息") | Out-Null
        }
    }

    $y = 58
    foreach ($c in $choices) {
        $b = New-Object System.Windows.Forms.Button
        $b.Text = $c.Text
        $b.Tag = $c.Choice
        $b.Location = New-Object System.Drawing.Point(172, $y)
        $b.Size = New-Object System.Drawing.Size(300, 32)
        $b.BackColor = $script:ThemeJelly
        $b.Add_Click($onChoice)
        $dlg.Controls.Add($b)
        $y += 38
    }

    $lblCustom = New-Object System.Windows.Forms.Label
    $lblCustom.Text = "自訂時間："
    $lblCustom.Location = New-Object System.Drawing.Point(172, ($y + 8))
    $lblCustom.Size = New-Object System.Drawing.Size(70, 24)
    $dlg.Controls.Add($lblCustom)

    $dtpCustom = New-Object System.Windows.Forms.DateTimePicker
    $dtpCustom.Name = "dtpCustom"
    $dtpCustom.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
    $dtpCustom.CustomFormat = "yyyy-MM-dd HH:mm"
    $dtpCustom.Location = New-Object System.Drawing.Point(245, ($y + 5))
    $dtpCustom.Size = New-Object System.Drawing.Size(140, 24)
    $start = $now.AddHours(1)
    $dtpCustom.Value = New-Object DateTime($start.Year, $start.Month, $start.Day, $start.Hour, 0, 0)
    $dlg.Controls.Add($dtpCustom)

    $btnCustom = New-Object System.Windows.Forms.Button
    $btnCustom.Text = "就這個時間"
    $btnCustom.Location = New-Object System.Drawing.Point(392, ($y + 3))
    $btnCustom.Size = New-Object System.Drawing.Size(80, 28)
    $btnCustom.Add_Click({
        param($sender, $e)
        try {
            $f = $sender.FindForm()
            $picker = $f.Controls["dtpCustom"]
            $until = Get-NoTimeUntil "custom" (Get-Date) $picker.Value
            if ($null -eq $until) {
                Show-AppMessage("這個時間已經過了啦，選一個「還沒到」的時間。", "$($script:AppName)") | Out-Null
                return
            }
            $f.Tag = $until
            $f.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $f.Close()
        } catch {
            Show-AppMessage("發生錯誤：$($_.Exception.Message)", "除錯訊息") | Out-Null
        }
    })
    $dlg.Controls.Add($btnCustom)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = "算了，我回去面對"
    $btnCancel.Location = New-Object System.Drawing.Point(12, 270)
    $btnCancel.Size = New-Object System.Drawing.Size(150, 32)
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.CancelButton = $btnCancel
    $dlg.Controls.Add($btnCancel)

    $result = $null
    Complete-AppForm $dlg
    if ($null -ne $owner) { $r = $dlg.ShowDialog($owner) } else { $r = $dlg.ShowDialog() }
    if ($r -eq [System.Windows.Forms.DialogResult]::OK -and $dlg.Tag -is [DateTime]) { $result = $dlg.Tag }
    $dlg.Dispose()
    return $result
}

# 提醒視窗的聲音停掉：計時器和鈴聲播放器一起停（2026-10-05 起有播放器）
function Stop-ReminderSound($f) {
    try {
        $t = $f.Tag.RingTimer
        if ($null -eq $t) { return }
        $t.Stop()
        if ($t.Tag -is [hashtable] -and $null -ne $t.Tag.Playback) { Stop-TonePlayback $t.Tag.Playback }
    } catch {}
}

function Show-ReminderForm($alarmId, $label, $dateKey, $stateKey, $playSound, $isStrict, $notes, $difficulty = "math1", $importance = "normal", $alarmObj = $null) {
    if ($script:ImportanceKeys -notcontains "$importance") { $importance = "normal" }
    $isMust = ($importance -eq "must")
    $isQuiz = ($importance -eq "quiz")
    if ($importance -ne "normal") { $isStrict = $true }
    if ($null -eq $global:AlarmReminderState) { $global:AlarmReminderState = @{} }
    if ($null -eq $global:AlarmOpenForms) { $global:AlarmOpenForms = @{} }

    # 一直響到處理為止（工單 8.4）：先響一聲，之後每 3 秒再響，直到按「先等等」「已完成」「真的沒空」或視窗關掉；
    # 連續響、停聲、最久響照 ring_settings.json（預設 10/5/60）；規則見 AlarmCore.ps1 的 Get-RingPhase
    # 2026-10-05：照這個鬧鐘的鈴聲／音量／漸強放（跟手機同一套欄位）；鈴聲設成「Windows 提示音」或沒有鬧鐘資料時，照舊每 3 秒響一聲
    $ringTimer = $null
    $tonePlayback = $null
    if ($playSound -ne $false) {
        $plan = @{ Tone = "system"; Volume = 100; Crescendo = $false }
        if ($null -ne $alarmObj) { try { $plan = Get-PcRingPlan $alarmObj } catch {} }
        try { Write-DebugLog "響鈴：id=$alarmId 鈴聲=$($plan.Tone) 音量=$($plan.Volume)% 漸強=$($plan.Crescendo)" } catch {}
        if ($plan.Tone -eq "system") { [System.Media.SystemSounds]::Exclamation.Play() }
        else { $tonePlayback = Start-TonePlayback $plan.Tone ([int]$plan.Volume) ([bool]$plan.Crescendo) }
        $ringStart = Get-Date
        $ringTimer = New-Object System.Windows.Forms.Timer
        $ringTimer.Interval = 3000
        $ringTimer.Add_Tick({
            param($sender, $e)
            try {
                $st = $sender.Tag
                $elapsed = ((Get-Date) - $st.Start).TotalSeconds
                $phase = Get-RingPhase $elapsed
                if ($null -ne $st.Playback) {
                    if ($phase -eq "ring") { Resume-TonePlayback $st.Playback }
                    elseif ($phase -eq "pause") { Suspend-TonePlayback $st.Playback }
                    else { Stop-TonePlayback $st.Playback; $sender.Stop() }
                } else {
                    if ($phase -eq "ring") { [System.Media.SystemSounds]::Exclamation.Play() }
                    elseif ($phase -eq "gaveup") { $sender.Stop() }
                }
            } catch {}
        })
        $ringTimer.Tag = @{ Start = $ringStart; Playback = $tonePlayback }
        $ringTimer.Start()
    }

    $form = New-Object System.Windows.Forms.Form
    $form.Text = "$($script:AppName) - 鬧鐘提醒"
    $form.Size = New-Object System.Drawing.Size(530, 300)
    $form.TopMost = $true
    $form.FormBorderStyle = "FixedDialog"
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    Set-AppFormStyle $form

    # 依目前已開著的提醒視窗數量錯開位置，避免多個提醒疊在同一個地方看不出來有好幾個
    try {
        $workArea = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $baseX = [int](($workArea.Width - $form.Width) / 2)
        $baseY = [int](($workArea.Height - $form.Height) / 3)
        $openCount = $global:AlarmOpenForms.Count
        $step = ($openCount % 8) * 34
        $form.StartPosition = "Manual"
        $form.Location = New-Object System.Drawing.Point(($baseX + $step), ($baseY + $step))
    } catch {
        $form.StartPosition = "CenterScreen"
    }

    # 所有識別資訊都存在 $form.Tag 上，按鈕事件一律從 $sender.FindForm() 或這裡取用，
    # 不依賴外部函式參數的閉包捕捉，避免變數在事件觸發當下遺失。
    $form.Tag = @{
        AlarmId   = $alarmId
        DateKey   = $dateKey
        StateKey  = $stateKey
        IsStrict  = ($isStrict -ne $false)
        Importance = $importance
        PendingAction = "done"
        AllowClose = $false
        Emergency  = $false
        Quiz      = (Get-QuizSpec $difficulty)
        QuizDone  = 0
        QuizCur   = $null
        RingTimer = $ringTimer
        MathAnswer = 0
        Completed  = $false
        SnoozePath = $script:snoozePath
    }

    # 右邊的新跪：剛跳出來(嚇到冒汗) → 答錯(龍蝦冒問號) → 答對(跳起來)
    $picXg = New-AppPictureBox "xg_ring.png" 345 10 160 200
    $form.Controls.Add($picXg)

    $lblMessage = New-Object System.Windows.Forms.Label
    $lblMessage.Text = "$label`n(原定：$dateKey)"
    $lblMessage.Location = New-Object System.Drawing.Point(20, 15)
    $lblMessage.Size = New-Object System.Drawing.Size(310, 40)
    $form.Controls.Add($lblMessage)

    if ($null -ne $notes -and "$notes".Trim() -ne "") {
        $txtNotesBox = New-Object System.Windows.Forms.TextBox
        $txtNotesBox.Text = "$notes"
        $txtNotesBox.Location = New-Object System.Drawing.Point(20, 58)
        $txtNotesBox.Size = New-Object System.Drawing.Size(310, 60)
        $txtNotesBox.Multiline = $true
        $txtNotesBox.ReadOnly = $true
        $txtNotesBox.ScrollBars = "Vertical"
        $txtNotesBox.BackColor = [System.Drawing.Color]::FromArgb(255, 250, 235)
        $form.Controls.Add($txtNotesBox)
    }

    $btnSnooze = New-Object System.Windows.Forms.Button
    $btnSnooze.Text = "先等等，我還在忙"
    $btnSnooze.Location = New-Object System.Drawing.Point(20, 128)
    $btnSnooze.Size = New-Object System.Drawing.Size(150, 40)
    $form.Controls.Add($btnSnooze)

    $btnComplete = New-Object System.Windows.Forms.Button
    $btnComplete.Text = if ($isStrict -ne $false) { "已完成，結束提醒" } else { "知道了，關閉" }
    $btnComplete.Location = New-Object System.Drawing.Point(180, 128)
    $btnComplete.Size = New-Object System.Drawing.Size(150, 40)
    $form.Controls.Add($btnComplete)

    $btnNoTime = New-Object System.Windows.Forms.Button
    $btnNoTime.Text = "真的沒空（自己選多久後再響）"
    $btnNoTime.Location = New-Object System.Drawing.Point(20, 176)
    $btnNoTime.Size = New-Object System.Drawing.Size(310, 34)
    $btnNoTime.BackColor = $script:ThemeJelly
    $form.Controls.Add($btnNoTime)

    # 絕對不能延後（工單 8.11 B）：完全沒有「先等等」「真的沒空」，只剩「已完成」
    if ($isMust) {
        $btnSnooze.Visible = $false
        $btnNoTime.Visible = $false
        $btnComplete.Location = New-Object System.Drawing.Point(20, 128)
        $btnComplete.Size = New-Object System.Drawing.Size(310, 50)
    }
    # 2026-10-08 先生回報:確認畫面「對,真的完成了／還沒」兩顆按鈕被紅字蓋住看不見(絕對不能延後的紅字固定在 y=188,確認按鈕 173~213)
    # → 紅字只在主畫面顯示,進答題／確認時藏起來,回主畫面再顯示
    $lblImpNote = $null
    if ($importance -ne "normal") {
        $lblImpNote = New-Object System.Windows.Forms.Label
        $lblImpNote.Text = if ($isMust) { "⛔ 絕對不能延後：只能答題完成" } else { "⚠ 要答題才能延後：想延後也要先答題" }
        $lblImpNote.ForeColor = [System.Drawing.Color]::FromArgb(201, 58, 50)
        $lblImpNote.Location = New-Object System.Drawing.Point(20, $(if ($isMust) { 188 } else { 214 }))
        $lblImpNote.Size = New-Object System.Drawing.Size(310, 22)
        $form.Controls.Add($lblImpNote)
    }

    $lblQuestion = New-Object System.Windows.Forms.Label
    $lblQuestion.Location = New-Object System.Drawing.Point(20, 128)
    $lblQuestion.Size = New-Object System.Drawing.Size(310, 24)
    $lblQuestion.Visible = $false
    $form.Controls.Add($lblQuestion)

    $txtAnswer = New-Object System.Windows.Forms.TextBox
    $txtAnswer.Location = New-Object System.Drawing.Point(20, 158)
    $txtAnswer.Size = New-Object System.Drawing.Size(100, 24)
    $txtAnswer.Visible = $false
    $form.Controls.Add($txtAnswer)

    $btnSubmit = New-Object System.Windows.Forms.Button
    $btnSubmit.Text = "提交答案"
    $btnSubmit.Location = New-Object System.Drawing.Point(130, 156)
    $btnSubmit.Size = New-Object System.Drawing.Size(90, 28)
    $btnSubmit.Visible = $false
    $form.Controls.Add($btnSubmit)

    $btnBack = New-Object System.Windows.Forms.Button
    $btnBack.Text = "返回"
    $btnBack.Location = New-Object System.Drawing.Point(230, 156)
    $btnBack.Size = New-Object System.Drawing.Size(90, 28)
    $btnBack.Visible = $false
    $form.Controls.Add($btnBack)

    $lblError = New-Object System.Windows.Forms.Label
    $lblError.Text = "答案不對，再試一次"
    $lblError.ForeColor = [System.Drawing.Color]::Red
    $lblError.Location = New-Object System.Drawing.Point(20, 188)
    $lblError.Size = New-Object System.Drawing.Size(310, 24)
    $lblError.Visible = $false
    $form.Controls.Add($lblError)

    $lblConfirm = New-Object System.Windows.Forms.Label
    $lblConfirm.Text = "再次確認：這件事真的已經處理完成了嗎？"
    $lblConfirm.Location = New-Object System.Drawing.Point(20, 128)
    $lblConfirm.Size = New-Object System.Drawing.Size(310, 40)
    $lblConfirm.Visible = $false
    $form.Controls.Add($lblConfirm)

    $btnConfirmYes = New-Object System.Windows.Forms.Button
    $btnConfirmYes.Text = "對，真的完成了"
    $btnConfirmYes.Location = New-Object System.Drawing.Point(20, 173)
    $btnConfirmYes.Size = New-Object System.Drawing.Size(150, 40)
    $btnConfirmYes.Visible = $false
    $form.Controls.Add($btnConfirmYes)

    $btnConfirmNo = New-Object System.Windows.Forms.Button
    $btnConfirmNo.Text = "還沒，先返回"
    $btnConfirmNo.Location = New-Object System.Drawing.Point(180, 173)
    $btnConfirmNo.Size = New-Object System.Drawing.Size(150, 40)
    $btnConfirmNo.Visible = $false
    $form.Controls.Add($btnConfirmNo)

    # 出題（「已完成」和「要答題才能延後」共用）。action：done＝答對進最後確認；snooze／notime＝答對才延後
    $startQuiz = {
        param($f, $action)
        $f.Tag.PendingAction = $action
        if ($null -ne $f.Tag.RingTimer) { Stop-ReminderSound $f }    # 開始處理：聲音停
        $f.Tag.QuizDone = 0
        $q = Get-QuizQuestion $f.Tag.Quiz.Diff
        $f.Tag.MathAnswer = $q.Answer
        $lblQuestion.Text = if ($f.Tag.Quiz.Need -gt 1) { "請回答（第 $($f.Tag.QuizDone + 1)／$($f.Tag.Quiz.Need) 題）：$($q.Text) = ?" } else { "請回答：$($q.Text) = ?" }
        $lblQuestion.Visible = $true
        $txtAnswer.Text = ""
        $txtAnswer.Visible = $true
        $btnSubmit.Visible = $true
        $btnBack.Visible = $true
        $lblError.Visible = $false
        $btnSnooze.Visible = $false
        $btnComplete.Visible = $false
        $btnNoTime.Visible = $false
        if ($null -ne $lblImpNote) { $lblImpNote.Visible = $false }
        $txtAnswer.Focus()
    }.GetNewClosure()

    # 延後的實際動作（先等等／真的沒空）；quiz 鬧鐘答對後、普通鬧鐘直接按時呼叫
    $doSnooze = {
        param($f)
        if ($null -ne $f.Tag.RingTimer) { Stop-ReminderSound $f }
        if ($null -eq $global:AlarmReminderState) { $global:AlarmReminderState = @{} }
        $sk = $f.Tag.StateKey
        if ($null -ne $sk) {
            $global:AlarmReminderState[$sk] = @{ Status = "snoozed"; SnoozeUntil = (Get-Date).AddMinutes(5) }
        }
        Settle-AlarmPending $f.Tag.AlarmId $f.Tag.DateKey
        $f.Tag.AllowClose = $true
        $f.Close()
        Show-TipForm "xg_busy.png" "好，先讓你忙" "5 分鐘後再來催你。`n別以為我會忘記。" 2500
    }.GetNewClosure()
    $doNoTime = {
        param($f)
        $until = Show-NoTimeDialog $f
        if ($null -eq $until) { return }
        if ($null -ne $f.Tag.RingTimer) { Stop-ReminderSound $f }
        if ($null -eq $global:AlarmReminderState) { $global:AlarmReminderState = @{} }
        $sk = $f.Tag.StateKey
        if ($null -ne $sk) {
            $global:AlarmReminderState[$sk] = @{ Status = "snoozed"; SnoozeUntil = $until }
        }
        Set-NoTimeSnooze $f.Tag.SnoozePath $f.Tag.AlarmId $f.Tag.DateKey $until
        Settle-AlarmPending $f.Tag.AlarmId $f.Tag.DateKey
        $f.Tag.AllowClose = $true
        $f.Close()
        $when = $until.ToString("M/d HH:mm")
        Show-TipForm "xg_no_time.png" "好啦，先放你一馬" "$when 會再來叫你。`n這次逃不掉的。" 3500
    }.GetNewClosure()

    $btnComplete.Add_Click({
        param($sender, $e)
        try {
            $f = $sender.FindForm()
            if ($null -ne $f.Tag.RingTimer) { Stop-ReminderSound $f }    # 按了「已完成」：開始處理，聲音停
            if (-not $f.Tag.IsStrict) {
                $f.Tag.Completed = $true
                $f.Close()
                Show-TipForm "xg_done.png" "搞定！" "又撐過一件事了。" 2500
                return
            }
            & $startQuiz $f "done"
        } catch {
            Show-AppMessage("發生錯誤：$($_.Exception.Message)", "除錯訊息") | Out-Null
        }
    }.GetNewClosure())

    $btnBack.Add_Click({
        try {
            $lblQuestion.Visible = $false
            $txtAnswer.Visible = $false
            $btnSubmit.Visible = $false
            $btnBack.Visible = $false
            $lblError.Visible = $false
            $btnSnooze.Visible = (-not $isMust)
            $btnComplete.Visible = $true
            $btnNoTime.Visible = (-not $isMust)
            if ($null -ne $lblImpNote) { $lblImpNote.Visible = $true }
            $btnBack.FindForm().Tag.PendingAction = "done"
            Set-AppPicture $picXg "xg_ring.png"
        } catch {
            Show-AppMessage("發生錯誤：$($_.Exception.Message)", "除錯訊息") | Out-Null
        }
    }.GetNewClosure())

    $btnSubmit.Add_Click({
        param($sender, $e)
        try {
            $f = $sender.FindForm()
            $userAns = 0
            if ([int]::TryParse($txtAnswer.Text.Trim(), [ref]$userAns) -and $userAns -eq $f.Tag.MathAnswer) {
                $f.Tag.QuizDone = $f.Tag.QuizDone + 1
                if ($f.Tag.QuizDone -lt $f.Tag.Quiz.Need) {
                    # 還沒連續答對夠：下一題
                    $q = Get-QuizQuestion $f.Tag.Quiz.Diff
                    $f.Tag.MathAnswer = $q.Answer
                    $lblQuestion.Text = "請回答（第 $($f.Tag.QuizDone + 1)／$($f.Tag.Quiz.Need) 題）：$($q.Text) = ?"
                    $lblError.Visible = $false
                    $txtAnswer.Text = ""
                    $txtAnswer.Focus()
                    return
                }
                if ($f.Tag.PendingAction -ne "done") {
                    # 「要答題才能延後」答對了 → 才真的延後
                    $act = $f.Tag.PendingAction
                    $f.Tag.PendingAction = "done"
                    $lblQuestion.Visible = $false; $txtAnswer.Visible = $false; $btnSubmit.Visible = $false; $btnBack.Visible = $false; $lblError.Visible = $false
                    $btnSnooze.Visible = $true; $btnComplete.Visible = $true; $btnNoTime.Visible = $true
                    if ($null -ne $lblImpNote) { $lblImpNote.Visible = $true }
                    if ($act -eq "snooze") { & $doSnooze $f } else { & $doNoTime $f }
                    return
                }
                $lblQuestion.Visible = $false
                $txtAnswer.Visible = $false
                $btnSubmit.Visible = $false
                $btnBack.Visible = $false
                $lblError.Visible = $false
                $lblConfirm.Visible = $true
                $btnConfirmYes.Visible = $true
                $btnConfirmNo.Visible = $true
                Set-AppPicture $picXg "xg_done.png"
            } else {
                if ($f.Tag.Quiz.Need -gt 1) {
                    # 連續題：錯一題從頭，換新題（不能靠猜）
                    $f.Tag.QuizDone = 0
                    $q = Get-QuizQuestion $f.Tag.Quiz.Diff
                    $f.Tag.MathAnswer = $q.Answer
                    $lblQuestion.Text = "請回答（第 1／$($f.Tag.Quiz.Need) 題）：$($q.Text) = ?"
                    $lblError.Text = "答錯了，要從頭連續答對 $($f.Tag.Quiz.Need) 題"
                } else { $lblError.Text = "答案不對，再試一次" }
                $lblError.Visible = $true
                Set-AppPicture $picXg "xg_wrong.png"
                $txtAnswer.Text = ""
                $txtAnswer.Focus()
            }
        } catch {
            Show-AppMessage("發生錯誤：$($_.Exception.Message)", "除錯訊息") | Out-Null
        }
    }.GetNewClosure())

    $btnConfirmYes.Add_Click({
        param($sender, $e)
        try {
            $f = $sender.FindForm()
            $f.Tag.Completed = $true
            $f.Close()
            Show-TipForm "xg_done.png" "搞定！" "答對了，這件事正式結案。`n新跪跳起來了。" 2500
        } catch {
            Show-AppMessage("發生錯誤：$($_.Exception.Message)", "除錯訊息") | Out-Null
        }
    }.GetNewClosure())

    $btnConfirmNo.Add_Click({
        try {
            $lblConfirm.Visible = $false
            $btnConfirmYes.Visible = $false
            $btnConfirmNo.Visible = $false
            $btnSnooze.Visible = (-not $isMust)
            $btnComplete.Visible = $true
            $btnNoTime.Visible = (-not $isMust)
            if ($null -ne $lblImpNote) { $lblImpNote.Visible = $true }
            Set-AppPicture $picXg "xg_ring.png"
        } catch {
            Show-AppMessage("發生錯誤：$($_.Exception.Message)", "除錯訊息") | Out-Null
        }
    }.GetNewClosure())

    $btnSnooze.Add_Click({
        param($sender, $e)
        try {
            $f = $sender.FindForm()
            if ($f.Tag.Importance -eq "quiz") { & $startQuiz $f "snooze" } else { & $doSnooze $f }
        } catch {
            Show-AppMessage("發生錯誤：$($_.Exception.Message)", "除錯訊息") | Out-Null
        }
    }.GetNewClosure())

    # 真的沒空：自己選多久後再響；存進 snoozes.json，重開機也不會忘，直到答題完成為止
    $btnNoTime.Add_Click({
        param($sender, $e)
        try {
            $f = $sender.FindForm()
            if ($f.Tag.Importance -eq "quiz") { & $startQuiz $f "notime" } else { & $doNoTime $f }
        } catch {
            Show-AppMessage("發生錯誤：$($_.Exception.Message)", "除錯訊息") | Out-Null
        }
    }.GetNewClosure())

    $form.Add_FormClosing({
        param($sender, $e)
        try {
            $f = $sender
            if ($null -eq $global:AlarmReminderState) { $global:AlarmReminderState = @{} }
            # 重要鬧鐘（要答題才能延後／絕對不能延後）：按右上角 X、Alt+F4 不能當成延後，視窗關不掉（工單 8.11 B）。
            # 只有 答題完成、答對後的延後、緊急停止（系統匣選單）可以關
            if ($f.Tag.Importance -ne "normal" -and -not ($f.Tag.Completed -or $f.Tag.AllowClose -or $f.Tag.Emergency) -and $e.CloseReason -eq [System.Windows.Forms.CloseReason]::UserClosing) {
                $e.Cancel = $true
                return
            }
            $sk = $f.Tag.StateKey
            if ($f.Tag.Completed) {
                Complete-Alarm $f.Tag.AlarmId $f.Tag.DateKey
                if ($null -ne $sk -and $global:AlarmReminderState.ContainsKey($sk)) { $global:AlarmReminderState.Remove($sk) }
            }
            elseif ($null -ne $sk -and (-not $global:AlarmReminderState.ContainsKey($sk) -or $global:AlarmReminderState[$sk].Status -ne "snoozed")) {
                $global:AlarmReminderState[$sk] = @{ Status = "snoozed"; SnoozeUntil = (Get-Date).AddMinutes(5) }
            }
        } catch {
            Show-AppMessage("結束提醒視窗時發生錯誤：$($_.Exception.Message)", "除錯訊息") | Out-Null
        }
    }.GetNewClosure())

    $form.Add_FormClosed({
        param($sender, $e)
        try {
            $f = $sender
            if ($null -ne $f.Tag.RingTimer) { try { Stop-ReminderSound $f; $f.Tag.RingTimer.Dispose() } catch {} }
            if ($null -ne $global:AlarmOpenForms -and $null -ne $f.Tag.AlarmId -and $global:AlarmOpenForms.ContainsKey($f.Tag.AlarmId) -and $global:AlarmOpenForms[$f.Tag.AlarmId] -eq $f) {
                $global:AlarmOpenForms.Remove($f.Tag.AlarmId)
            }
        } catch {}
    }.GetNewClosure())

    # 套用大字／深色（v1.1）；放大後視窗變大了，重新算一次錯開的位置
    Complete-AppForm $form
    try {
        $workArea = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
        $baseX = [int](($workArea.Width - $form.Width) / 2)
        $baseY = [int](($workArea.Height - $form.Height) / 3)
        $step = ($global:AlarmOpenForms.Count % 8) * 34
        $form.Location = New-Object System.Drawing.Point([Math]::Max(0, ($baseX + $step)), [Math]::Max(0, ($baseY + $step)))
    } catch {}

    $form.Show()
    $form.Activate()
    $form.BringToFront()

    if ($null -eq $global:AlarmOpenForms) { $global:AlarmOpenForms = @{} }
    $global:AlarmOpenForms[$alarmId] = $form

    return $form
}

$script:checkRunning = $false
$script:debugLogPath = Join-Path $PSScriptRoot "alarm_debug.log"

function Write-DebugLog($msg) {
    try {
        if ((Test-Path $script:debugLogPath) -and (Get-Item $script:debugLogPath).Length -gt 300KB) {
            Remove-Item $script:debugLogPath -Force -ErrorAction SilentlyContinue
        }
        Add-Content -Path $script:debugLogPath -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')  $msg" -Encoding UTF8
    } catch {}
}

function Invoke-AlarmCheck {
    if ($script:checkRunning) {
        Write-DebugLog "略過這次檢查：上一次檢查還沒跑完（重入）"
        return
    }
    $script:checkRunning = $true
    try {
        $now = Get-Date
        $alarms = Load-Alarms
        $changed = $false
        Write-DebugLog "---- 開始檢查，共 $($alarms.Count) 筆鬧鐘 ----"

        # 「真的沒空」延後的提醒（存在 snoozes.json）；鬧鐘已經被刪掉的就順手清掉
        $noTime = @{}
        try {
            $noTime = Read-SnoozeFile $script:snoozePath
            $ids = @($alarms | ForEach-Object { "$($_.id)" })
            $orphan = @($noTime.Keys | Where-Object { $ids -notcontains "$($noTime[$_].AlarmId)" })
            if ($orphan.Count -gt 0) {
                foreach ($k in $orphan) { $noTime.Remove($k) }
                Write-SnoozeFile $script:snoozePath $noTime
            }
        } catch {
            Write-DebugLog "讀取 snoozes.json 失敗：$($_.Exception.Message)"
            $noTime = @{}
        }

        foreach ($a in $alarms) {
            try {
                if ($null -eq $a.triggeredDates) { $a | Add-Member -NotePropertyName triggeredDates -NotePropertyValue @() -Force }

                if ($null -ne $global:AlarmOpenForms -and $global:AlarmOpenForms.ContainsKey($a.id)) {
                    $existingForm = $global:AlarmOpenForms[$a.id]
                    if ($null -ne $existingForm -and -not $existingForm.IsDisposed) {
                        Write-DebugLog "id=$($a.id) [$($a.label)] 略過：這個id已經有一個視窗開著"
                        continue
                    } else {
                        $global:AlarmOpenForms.Remove($a.id)
                    }
                }

                $isStrict = Test-AlarmStrict $a

                # 先看「真的沒空」：時間到了就一定再跳（不受「只補 7 天」「限時 15 分」限制），直到答題完成
                $noTimeHandled = $false
                foreach ($s in @(Get-DueNoTimeSnoozes $noTime $a.id $now)) {
                    $nKey = $s.DateKey
                    $nStateKey = "$($a.id)|$nKey"
                    $stale = $false
                    if ($a.type -eq "interval") {
                        $due = ConvertTo-DateOnly $a.nextDueDate
                        $orig = ConvertTo-DateOnly $nKey
                        if ($null -ne $due -and $null -ne $orig -and $due -gt $orig) { $stale = $true }
                    } elseif ($a.triggeredDates -contains $nKey) { $stale = $true }
                    if ($stale) {
                        Remove-NoTimeSnooze $script:snoozePath $a.id $nKey
                        $noTime.Remove($nStateKey)
                        continue
                    }
                    if ($global:AlarmReminderState.ContainsKey($nStateKey)) {
                        $st = $global:AlarmReminderState[$nStateKey]
                        if ($st.Status -eq "showing") { $noTimeHandled = $true; break }
                        if ($st.Status -eq "snoozed" -and $now -lt $st.SnoozeUntil) { $noTimeHandled = $true; break }
                    }
                    Write-DebugLog "id=$($a.id) [$($a.label)] key=$nKey ==> 真的沒空的時間到了，跳出提醒視窗"
                    $global:AlarmReminderState[$nStateKey] = @{ Status = "showing" }
                    # 同一個鬧鐘只留這一筆待響：別的日子的延後、欠著的漏響併進來（工單 8.8）
                    $mg = Merge-AlarmPending $a $noTime $global:AlarmReminderState $nKey $now $true
                    if ($mg.AlarmChanged) { $changed = $true }
                    if ($mg.SnoozeChanged) { try { Write-SnoozeFile $script:snoozePath $noTime } catch {} }
                    Show-ReminderForm $a.id $a.label $nKey $nStateKey $a.playSound $isStrict $a.notes $a.difficulty (Get-AlarmImportance $a) $a | Out-Null
                    $noTimeHandled = $true
                    break
                }
                if ($noTimeHandled) { continue }

                $timeParts = $a.time -split ":"
                $hour = [int]$timeParts[0]
                $minute = [int]$timeParts[1]

                $candidateDates = @(Get-CandidateDates $a $now)

                if ($a.timeLimited) {
                    $candidateDates = @($candidateDates | Where-Object { $null -ne $_ -and $_.Date -eq $now.Date })
                }

                Write-DebugLog "id=$($a.id) [$($a.label)] type=$($a.type) days=$($a.days -join ',') 候選日期數=$($candidateDates.Count) 已完成清單=$($a.triggeredDates -join ',')"

                foreach ($cd in $candidateDates) {
                    if ($null -eq $cd) { continue }
                    $occDateTime = $cd.AddHours($hour).AddMinutes($minute)
                    $key = $cd.ToString("yyyy-MM-dd")

                    if ($occDateTime -gt $now) { continue }
                    if ($a.triggeredDates -contains $key) { continue }

                    # 開始生效（建立／改時間）之前的時刻不算漏響：晚上 9 點新增「每天 06:00」，不會馬上補響今天早上的。
                    # 定期倒數：這個到期日在生效之前 → 直接往後推，不留一個永遠過不去的舊日期
                    if (Test-OccurrenceBeforeArmed $a $occDateTime) {
                        if ($a.type -eq "interval") {
                            $iv = [int]$a.intervalDays
                            if ($iv -lt 1) { $iv = 1 }
                            $nd = $cd.AddDays($iv)
                            while ($nd.Date -le $now.Date) { $nd = $nd.AddDays($iv) }
                            $a | Add-Member -NotePropertyName nextDueDate -NotePropertyValue ($nd.ToString("yyyy-MM-dd")) -Force
                            $changed = $true
                        }
                        continue
                    }

                    $stateKey = "$($a.id)|$key"

                    # 這一次按過「真的沒空」→ 交給上面的延後邏輯，這裡不動它（也不會被限時 15 分鐘規則吃掉）
                    if ($noTime.ContainsKey($stateKey)) { continue }

                    if ($a.timeLimited) {
                        $minutesLate = ($now - $occDateTime).TotalMinutes
                        if ($minutesLate -gt 15) {
                            if ($a.type -eq "interval") {
                                $intervalDays = [int]$a.intervalDays
                                $newDue = $cd.AddDays($intervalDays)
                                while ($newDue.Date -le $now.Date) { $newDue = $newDue.AddDays($intervalDays) }
                                $a | Add-Member -NotePropertyName nextDueDate -NotePropertyValue ($newDue.ToString("yyyy-MM-dd")) -Force
                            } else {
                                $a.triggeredDates = @($a.triggeredDates) + $key
                            }
                            $changed = $true
                            if ($global:AlarmReminderState.ContainsKey($stateKey)) { $global:AlarmReminderState.Remove($stateKey) }
                            continue
                        }
                    }

                    if ($global:AlarmReminderState.ContainsKey($stateKey)) {
                        $st = $global:AlarmReminderState[$stateKey]
                        if ($st.Status -eq "showing") {
                            Write-DebugLog "id=$($a.id) [$($a.label)] key=$key 略過整個鬧鐘：這筆已經是 showing"
                            break
                        }
                        if ($st.Status -eq "snoozed" -and $now -lt $st.SnoozeUntil) {
                            Write-DebugLog "id=$($a.id) [$($a.label)] key=$key 略過整個鬧鐘：這筆還在snooze中，到 $($st.SnoozeUntil) 才會再問"
                            break
                        }
                    }

                    Write-DebugLog "id=$($a.id) [$($a.label)] key=$key ==> 跳出提醒視窗"
                    $global:AlarmReminderState[$stateKey] = @{ Status = "showing" }
                    $mg = Merge-AlarmPending $a $noTime $global:AlarmReminderState $key $now $true
                    if ($mg.AlarmChanged) { $changed = $true }
                    if ($mg.SnoozeChanged) { try { Write-SnoozeFile $script:snoozePath $noTime } catch {} }
                    Show-ReminderForm $a.id $a.label $key $stateKey $a.playSound $isStrict $a.notes $a.difficulty (Get-AlarmImportance $a) $a
                    break
                }
            } catch {
                Write-DebugLog "id=$($a.id) [$($a.label)] 發生例外：$($_.Exception.Message)"
                Show-AppMessage("有一筆鬧鐘資料檢查時發生錯誤，已略過這筆：`n$($_.Exception.Message)", "除錯訊息") | Out-Null
            }
        }

        if ($changed) { Save-Alarms $alarms }
    } finally {
        $script:checkRunning = $false
    }
}

function Open-ManagerGui {
    # 直接用 powershell.exe 隱藏視窗啟動（不再依賴 .vbs，免得被防毒誤判）
    Start-AppScript "Alarm_Manager_GUI.ps1"
}

function New-PawIcon {
    $bmp = New-Object System.Drawing.Bitmap 128, 128
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.Clear([System.Drawing.Color]::Transparent)

    $grayBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 138, 133, 128))
    $pinkBrush = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 240, 174, 187))

    $g.FillEllipse($grayBrush, 26, 62, 68, 56)
    $g.FillEllipse($grayBrush, 1, 29, 34, 34)
    $g.FillEllipse($grayBrush, 28, 3, 34, 34)
    $g.FillEllipse($grayBrush, 61, 3, 34, 34)
    $g.FillEllipse($grayBrush, 88, 29, 34, 34)

    $g.FillEllipse($pinkBrush, 40, 74, 40, 32)
    $g.FillEllipse($pinkBrush, 9, 37, 18, 18)
    $g.FillEllipse($pinkBrush, 36, 11, 18, 18)
    $g.FillEllipse($pinkBrush, 69, 11, 18, 18)
    $g.FillEllipse($pinkBrush, 96, 37, 18, 18)

    $g.Dispose()
    $hIcon = $bmp.GetHicon()
    return [System.Drawing.Icon]::FromHandle($hIcon)
}

$notifyIcon = New-Object System.Windows.Forms.NotifyIcon
# 系統匣換成欸唉新跪的水母；圖檔不見了就退回原本畫的貓掌
$trayIcon = Get-TrayIcon $false
if ($null -eq $trayIcon) { $trayIcon = New-PawIcon }
$notifyIcon.Icon = $trayIcon
$notifyIcon.Text = "$($script:AppName)（背景待命中）"
$notifyIcon.Visible = $true

$menu = New-Object System.Windows.Forms.ContextMenuStrip

$menu.Add_Opening({
    $menu.Items.Clear()
    $currentAlarms = Load-Alarms

    if ($currentAlarms.Count -eq 0) {
        $emptyItem = $menu.Items.Add("（尚未設定任何鬧鐘）")
        $emptyItem.Enabled = $false
    } else {
        $headerItem = $menu.Items.Add("== 目前的鬧鐘 ==")
        $headerItem.Enabled = $false
        foreach ($a in $currentAlarms) {
            $desc = "$($a.label)　[$(Get-AlarmDescription $a) $($a.time)]"
            $listItem = $menu.Items.Add($desc)
            $listItem.Enabled = $false
        }

        # 按過「真的沒空」、還欠著的提醒
        try {
            $pending = Read-SnoozeFile $script:snoozePath
            if ($pending.Count -gt 0) {
                $menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null
                $pendingHeader = $menu.Items.Add("== 真的沒空，晚點會再響 ==")
                $pendingHeader.Enabled = $false
                foreach ($k in @($pending.Keys)) {
                    $p = $pending[$k]
                    $name = "$($p.AlarmId)"
                    foreach ($a in $currentAlarms) { if ("$($a.id)" -eq "$($p.AlarmId)") { $name = $a.label } }
                    $pendingItem = $menu.Items.Add("$name　→ $($p.Until.ToString('M/d HH:mm')) 再響")
                    $pendingItem.Enabled = $false
                }
            }
        } catch {}
    }

    $menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null

    # 即將響鈴：普通鬧鐘一按就跳；重要鬧鐘答題後才能跳過
    Invoke-UpcomingCheck
    if ($null -ne $script:upcoming) {
        $u = $script:upcoming
        $uName = "$($u.Alarm.label)"
        try { if (Test-AlarmPrivate $u.Alarm (Read-AppSettings (Join-Path $PSScriptRoot "settings.json")).privateCategories) { $uName = "（私密）" } } catch {}
        $uTitle = Get-UpcomingTitle $u.At (Get-Date)
        if (Test-UpcomingSkippable $u.Alarm) {
            $itemSkip = $menu.Items.Add("跳過這一次：$uTitle $uName")
        } else {
            $itemSkip = $menu.Items.Add("答題後跳過：$uTitle $uName（重要鬧鐘，答題後才能跳過）")
        }
        $itemSkip.Add_Click({ Invoke-SkipUpcomingFromTray })
        $menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null
    }

    $itemOpen = $menu.Items.Add("開啟鬧鐘設定...")
    $itemOpen.Add_Click({ Open-ManagerGui })

    $itemCheck = $menu.Items.Add("立即檢查一次")
    $itemCheck.Add_Click({ Invoke-AlarmCheck })

    # 緊急停止（工單 8.11 B 的保險）：「絕對不能延後」的提醒視窗如果壞了、關不掉，從這裡結案。只有開著重要提醒時才出現，要連按兩次確認
    $impForms = @(Get-ImportantOpenForms $global:AlarmOpenForms)
    if ($impForms.Count -gt 0) {
        $itemEmergency = $menu.Items.Add("緊急停止目前的重要提醒（$($impForms.Count) 個）...")
        $itemEmergency.Add_Click({
            try {
                $yn = [System.Windows.Forms.MessageBoxButtons]::YesNo
                $a1 = Show-AppMessage("這會把正在響的「要答題才能延後／絕對不能延後」的提醒直接結案（算已完成，今天不會再響）。`n`n只有在提醒視窗壞了、關不掉的時候才用。要繼續嗎？", "$($script:AppName) - 緊急停止", $yn)
                if ($a1 -ne [System.Windows.Forms.DialogResult]::Yes) { return }
                $a2 = Show-AppMessage("真的要停止嗎？（這不是答題完成，是緊急出口）", "$($script:AppName) - 再確認一次", $yn)
                if ($a2 -ne [System.Windows.Forms.DialogResult]::Yes) { return }
                foreach ($f in @(Get-ImportantOpenForms $global:AlarmOpenForms)) {
                    if ($null -ne $f.Tag.RingTimer) { Stop-ReminderSound $f }
                    $f.Tag.Emergency = $true
                    $f.Tag.Completed = $true
                    $f.Close()
                }
            } catch { Show-AppMessage("緊急停止時發生錯誤：$($_.Exception.Message)", "$($script:AppName)") | Out-Null }
        })
    }

    $itemAbout = $menu.Items.Add("關於$($script:AppName)...")
    $itemAbout.Add_Click({ Show-AboutDialog $null })

    $menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator)) | Out-Null

    $itemExit = $menu.Items.Add("結束背景提醒程式")
    $itemExit.Add_Click({
        if (Test-Path $pidFile) { Remove-Item $pidFile -Force -ErrorAction SilentlyContinue }
        $notifyIcon.Visible = $false
        $notifyIcon.Dispose()
        [System.Windows.Forms.Application]::Exit()
    })
})

$notifyIcon.ContextMenuStrip = $menu

$notifyIcon.Add_DoubleClick({ Open-ManagerGui })

# v1.5：登入 Google 之後，每 15 分鐘同步一次；鬧鐘檔有變動（改了、按了已完成）等 8 秒也同步。
# 同步失敗（沒網路…）不影響提醒，5 分鐘後再試。
$script:syncCtx = Get-SyncContext $PSScriptRoot
$script:nextSyncAt = (Get-Date).AddSeconds(30)
$script:syncSoonAt = $null
$script:alarmsStamp = $null
function Get-AlarmsStamp {
    try { return (Get-Item -LiteralPath $jsonPath).LastWriteTimeUtc.Ticks } catch { return 0 }
}
function Invoke-BackgroundSync {
    try {
        if (-not (Test-GoogleSignedIn $script:syncCtx.TokenPath)) { return }
        $now = Get-Date
        $stamp = Get-AlarmsStamp
        if ($null -ne $script:alarmsStamp -and $stamp -ne $script:alarmsStamp -and $null -eq $script:syncSoonAt) { $script:syncSoonAt = $now.AddSeconds(8) }
        $script:alarmsStamp = $stamp
        $due = ($now -ge $script:nextSyncAt) -or ($null -ne $script:syncSoonAt -and $now -ge $script:syncSoonAt)
        if (-not $due) { return }
        $script:syncSoonAt = $null
        $res = Invoke-SyncRun $script:syncCtx $now
        if ($res.Ok) { $script:nextSyncAt = $now.AddMinutes(15) } else { $script:nextSyncAt = $now.AddMinutes(5); Write-DebugLog "同步沒成功：$($res.Error)" }
        if ($res.Changed) { Write-DebugLog "同步：新增 $($res.Added)、更新 $($res.Updated)、刪除 $($res.Removed)" }
        $script:alarmsStamp = Get-AlarmsStamp
    } catch { Write-DebugLog "同步發生錯誤：$($_.Exception.Message)" }
}

# v1.6：每天第一次安靜檢查一次有沒有新版（只在設定視窗的「檢查更新」顯示小紅點，不跳窗）
$script:updateStatePath = Join-Path $PSScriptRoot "update_state.json"
$script:nextUpdateCheckAt = (Get-Date).AddSeconds(15)     # 啟動後很快先查一次
$script:updateForceFirst = $true                          # 啟動時那一次不看「上次什麼時候查的」（工單 8.9）
# 系統匣圖示：有新版就在水母右上角加紅點（工單 8.6）
$script:trayDotOn = $false
function Update-TrayDot {
    try {
        $a = Get-UpdateAvailableFromState $script:updateStatePath $script:AppVersion
        $want = ($null -ne $a)
        if ($want -eq $script:trayDotOn) { return }
        $icon = Get-TrayIcon $want
        if ($null -ne $icon) { $notifyIcon.Icon = $icon }
        $script:trayBaseText = if ($want) { "$($script:AppName)（有新版 v$($a.Version)）" } else { "$($script:AppName)（背景待命中）" }
        $notifyIcon.Text = $script:trayBaseText
        $script:trayDotOn = $want
    } catch { Write-DebugLog "更新系統匣圖示發生錯誤：$($_.Exception.Message)" }
}

function Invoke-QuietUpdateCheck {
    try {
        $now = Get-Date
        if ($now -lt $script:nextUpdateCheckAt) { Update-TrayDot; return }
        $script:nextUpdateCheckAt = $now.AddMinutes(30)
        $force = $script:updateForceFirst
        $script:updateForceFirst = $false
        Invoke-UpdateDailyCheck $script:updateStatePath $script:AppVersion $now $force | Out-Null
        Update-TrayDot
    } catch { Write-DebugLog "檢查更新發生錯誤：$($_.Exception.Message)" }
}

# 升級／開機後第一次：已經累積的重複「真的沒空」清掉，每個鬧鐘只留最新的一筆（工單 8.8）
try {
    $startAlarms = @(Load-Alarms)
    $startSn = Read-SnoozeFile $script:snoozePath
    $cl = Clear-DuplicateSnoozes $startAlarms $startSn @{} (Get-Date)
    if ($cl.AlarmChanged) { Save-Alarms $startAlarms }
    if ($cl.SnoozeChanged) { Write-SnoozeFile $script:snoozePath $startSn }
} catch { Write-DebugLog "啟動清理重複延後失敗：$($_.Exception.Message)" }

# 即將響鈴（2026-10-05 電腦版補齊；跟手機 1.8.1 同一套）：系統匣提示文字顯示「13:17 即將響鈴：名稱」，
# 第一次進入提醒時間跳一次通知氣泡；右鍵選單可以「跳過這一次」（重要鬧鐘答題後才能跳過）
$script:upcoming = $null
$script:upcomingNotified = @{}
function Get-BusyAlarmIds {
    $ids = @()
    try { if ($null -ne $global:AlarmOpenForms) { $ids += @($global:AlarmOpenForms.Keys | ForEach-Object { "$_" }) } } catch {}
    try {
        if ($null -ne $global:AlarmReminderState) {
            foreach ($k in @($global:AlarmReminderState.Keys)) { $ids += ("$k" -split '\|')[0] }
        }
    } catch {}
    try { foreach ($p in (Read-SnoozeFile $script:snoozePath).Values) { $ids += "$($p.AlarmId)" } } catch {}
    return $ids
}
function Invoke-UpcomingCheck {
    try {
        $now = Get-Date
        $rs = Read-RingSettings $script:RingSettingsPath
        $up = Get-UpcomingAlarm @(Load-Alarms) $now ([int]$rs.upcomingMin) (Get-BusyAlarmIds)
        $script:upcoming = $up
        $base = if ($script:trayBaseText) { $script:trayBaseText } else { "$($script:AppName)（背景待命中）" }
        if ($null -eq $up) { $notifyIcon.Text = $base; return }
        $settings = Read-AppSettings (Join-Path $PSScriptRoot "settings.json")
        $priv = Test-AlarmPrivate $up.Alarm $settings.privateCategories
        $title = Get-UpcomingTitle $up.At $now
        $name = if ($priv) { "（私密）" } else { "$($up.Alarm.label)" }
        $tip = if (Test-UpcomingSkippable $up.Alarm) { "$title：$name" } else { "$title（重要鬧鐘，答題後才能跳過）：$name" }
        if ($tip.Length -gt 63) { $tip = $tip.Substring(0, 62) + "…" }    # 系統匣提示文字超過 63 字會出錯
        $notifyIcon.Text = $tip
        $k = "$($up.Alarm.id)|$($up.DateKey)"
        if (-not $script:upcomingNotified.ContainsKey($k)) {
            $script:upcomingNotified[$k] = $true
            $more = if (Test-UpcomingSkippable $up.Alarm) { "要先跳過這一次：右鍵點水母 →「跳過這一次」" } else { "（重要鬧鐘，答題後才能跳過）右鍵點水母 →「答題後跳過」" }
            $notifyIcon.ShowBalloonTip(6000, $title, "$name`n$more", [System.Windows.Forms.ToolTipIcon]::Info)
        }
    } catch { Write-DebugLog "即將響鈴檢查發生錯誤：$($_.Exception.Message)" }
}
# 與響鈴共用難度／出題函式（qr → math3），輸入視窗沿用 AlarmUi；取消不算答對。
function Show-UpcomingSkipQuiz($a, [string]$dateKey) {
    $spec = Get-QuizSpec $a.difficulty
    $done = 0
    $errorText = ""
    while ($done -lt $spec.Need) {
        if (@(Get-BusyAlarmIds) -contains "$($a.id)") { return $false }
        $at = Get-NextPendingOccurrence $a (Get-Date)
        if ($null -eq $at -or $at.ToString("yyyy-MM-dd") -ne $dateKey) { return $false }
        $q = Get-QuizQuestion $spec.Diff
        $prompt = "$($a.label)`n$dateKey $($a.time)`n${errorText}請回答（第 $($done + 1)／$($spec.Need) 題）：$($q.Text) = ?"
        $text = Show-TextInputDialog $null "答題後跳過" $prompt ""
        if ($null -eq $text) { return $false }
        $answer = 0
        if ([int]::TryParse($text.Trim(), [ref]$answer) -and $answer -eq $q.Answer) {
            $done++
            $errorText = ""
        } else {
            $done = 0
            $errorText = "答錯了，要從頭連續答對 $($spec.Need) 題。`n"
        }
    }
    return $true
}
# 開題快照不包含名稱；同一天改時間、排程版本或答題政策都要重答。
function Get-UpcomingSkipPolicy($a, [datetime]$now) {
    $at = Get-NextPendingOccurrence $a $now
    if ($null -eq $at) { return $null }
    $spec = Get-QuizSpec $a.difficulty
    return @{ Uid = "$($a.uid)"; At = $at; ArmedAt = "$($a.armedAt)"; Importance = (Get-AlarmImportance $a); Difficulty = "$($a.difficulty)"; Diff = $spec.Diff; Need = $spec.Need }
}
function Test-UpcomingSkipPolicy($opened, $current) {
    if ($null -eq $opened -or $null -eq $current) { return $false }
    foreach ($key in @("Uid", "At", "ArmedAt", "Importance", "Difficulty", "Diff", "Need")) {
        if ($opened[$key] -cne $current[$key]) { return $false }
    }
    return $true
}
function Invoke-SkipUpcomingFromTray {
    try {
        $up = $script:upcoming
        if ($null -eq $up) { return }
        $alarms = @(Load-Alarms)
        $a = $alarms | Where-Object { "$($_.id)" -eq "$($up.Alarm.id)" } | Select-Object -First 1
        $dateKey = $up.DateKey
        $requireQuiz = $false
        while ($null -ne $a) {
            if (@(Get-BusyAlarmIds) -contains "$($a.id)") { return }
            $opened = Get-UpcomingSkipPolicy $a (Get-Date)
            if ($null -eq $opened -or $opened.At.ToString("yyyy-MM-dd") -ne $dateKey) { return }
            $quizPassed = $false
            $requireQuiz = $requireQuiz -or (-not (Test-UpcomingSkippable $a))
            if ($requireQuiz) {
                $quizPassed = Show-UpcomingSkipQuiz $a $dateKey
                if (-not $quizPassed) { return }
            }
            $restart = $false
            $skipped = $false
            # 與同步套用共用鎖；對照、busy 檢查及寫入之間不放開鎖。答題視窗不持鎖。
            $mutex = Enter-RingSettingsLock
            try {
                $alarms = @(Load-Alarms)
                $a = $alarms | Where-Object { "$($_.id)" -eq "$($up.Alarm.id)" } | Select-Object -First 1
                if ($null -eq $a -or @(Get-BusyAlarmIds) -contains "$($a.id)") { return }
                $now = Get-Date
                $current = Get-UpcomingSkipPolicy $a $now
                if (-not (Test-UpcomingSkipPolicy $opened $current)) {
                    if ($null -eq $current) { return }
                    $dateKey = $current.At.ToString("yyyy-MM-dd")
                    $restart = $true
                } elseif (Invoke-SkipUpcoming $a $dateKey $now -quizPassed $quizPassed -busyIds (Get-BusyAlarmIds)) {
                    Save-Alarms $alarms
                    $skipped = $true
                }
            } finally {
                try { $mutex.ReleaseMutex() } finally { $mutex.Dispose() }
            }
            if ($restart) { continue }
            if ($skipped) {
                Write-DebugLog "即將響鈴 → 跳過這一次：$($a.id)|$($dateKey)"
                $notifyIcon.ShowBalloonTip(4000, $script:AppName, "已跳過：$($opened.At.ToString('HH:mm')) 這一次不會響（重複的鬧鐘下次照常）。", [System.Windows.Forms.ToolTipIcon]::Info)
            }
            break
        }
        Invoke-UpcomingCheck
    } catch { Write-DebugLog "跳過這一次發生錯誤：$($_.Exception.Message)" }
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 20000
$timer.Add_Tick({ Invoke-AlarmCheck; Invoke-BackgroundSync; Invoke-QuietUpdateCheck; Invoke-UpcomingCheck })
$timer.Start()

Invoke-AlarmCheck

# 第一次使用：直接打開設定視窗，讓人看到範例鬧鐘
if ($script:firstRun) {
    try { Open-ManagerGui } catch {}
}
# 剛更新完：告訴使用者結果（成功或還原了）
$script:justUpdated = $false
try {
    $ur = Read-UpdateResultOnce $PSScriptRoot
    if ($null -ne $ur) {
        $script:justUpdated = $true
        $icon = [System.Windows.Forms.ToolTipIcon]::Info
        if (-not $ur.Ok) { $icon = [System.Windows.Forms.ToolTipIcon]::Warning }
        $notifyIcon.ShowBalloonTip(8000, $script:AppName, $ur.Message, $icon)
        # 更新完把設定視窗打開，使用者才看得到「真的重新開好了」（2026-10-05：原本只回到右下角，像沒跑完）
        if (-not $script:firstRun) { try { Open-ManagerGui } catch {} }
    }
} catch {}
# 剛更新完就不跳歡迎氣泡（會蓋掉上面「已經更新到 vX」那則）
if (($Welcome -or $script:firstRun) -and -not $script:justUpdated) {
    try {
        $notifyIcon.ShowBalloonTip(6000, $script:AppName, "我在右下角待命了（那隻水母就是我）。`n右鍵點水母：看鬧鐘、開設定、關掉程式。", [System.Windows.Forms.ToolTipIcon]::Info)
    } catch {}
}

[System.Windows.Forms.Application]::Run()
